Grailbird.data.tweets_2018_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/dOTiPRoD38",
      "expanded_url" : "http:\/\/dirk.eddelbuettel.com\/code\/rcpp.html",
      "display_url" : "dirk.eddelbuettel.com\/code\/rcpp.html"
    } ]
  },
  "geo" : { },
  "id_str" : "990984121080991744",
  "text" : "You can use the Rcpp package to convert simple R loops into fast C++ code: https:\/\/t.co\/dOTiPRoD38 #rstats",
  "id" : 990984121080991744,
  "created_at" : "2018-04-30 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/DAK9hoQKno",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/Control",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "989896961422692353",
  "text" : "In a \"for\" loop \u2014 for(var in seq) expr \u2014 seq can be *any* vector. e.g. seq &lt;- c(100,12,1000)  https:\/\/t.co\/DAK9hoQKno #rstats",
  "id" : 989896961422692353,
  "created_at" : "2018-04-27 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/NELdhIIIah",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/TTR",
      "display_url" : "mran.microsoft.com\/package\/TTR"
    } ]
  },
  "geo" : { },
  "id_str" : "989534583153573888",
  "text" : "Package TTR contains EMA() (exponential moving average) and 8 other moving average functions https:\/\/t.co\/NELdhIIIah #rstats",
  "id" : 989534583153573888,
  "created_at" : "2018-04-26 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Muenchen",
      "screen_name" : "BobMuenchen",
      "indices" : [ 68, 80 ],
      "id_str" : "25741608",
      "id" : 25741608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/PompZlrpOL",
      "expanded_url" : "http:\/\/r4stats.com\/books\/free-version\/",
      "display_url" : "r4stats.com\/books\/free-ver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "989172187432144896",
  "text" : "A free, 80-page excerpt of the book \"R for SAS and SPSS\" users , by @BobMuenchen https:\/\/t.co\/PompZlrpOL #rstats",
  "id" : 989172187432144896,
  "created_at" : "2018-04-25 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/lH6atMcGFm",
      "expanded_url" : "https:\/\/cloud.r-project.org",
      "display_url" : "cloud.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "988824897785806848",
  "text" : "Download R from (and set your CRAN mirror to) https:\/\/t.co\/lH6atMcGFm. It automatically chooses a fast, nearby mirror for you. #rstats",
  "id" : 988824897785806848,
  "created_at" : "2018-04-24 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/OczABmkOH8",
      "expanded_url" : "https:\/\/science.nature.nps.gov\/im\/datamgmt\/statistics\/r\/formulas\/",
      "display_url" : "science.nature.nps.gov\/im\/datamgmt\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "988447418713804802",
  "text" : "An overview of R formulas for statistical models, from the National Park Service https:\/\/t.co\/OczABmkOH8 #rstats",
  "id" : 988447418713804802,
  "created_at" : "2018-04-23 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/H8Dm5OoXta",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/format",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "987360245210058754",
  "text" : "format(x, scientific=TRUE) prints numeric data in exponential format, so 0.0001 prints as 1e-04 https:\/\/t.co\/H8Dm5OoXta #rstats",
  "id" : 987360245210058754,
  "created_at" : "2018-04-20 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "986997867922501632",
  "text" : "The arrow assignment operator works in both directions. This is valid #rstats syntax: x &lt;- value -&gt; y",
  "id" : 986997867922501632,
  "created_at" : "2018-04-19 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/1wPNjs6HVL",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2018\/03\/r-and-docker.html",
      "display_url" : "blog.revolutionanalytics.com\/2018\/03\/r-and-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "986635474339938305",
  "text" : "How to launch a container with R using Azure Container Instances https:\/\/t.co\/1wPNjs6HVL #rstats",
  "id" : 986635474339938305,
  "created_at" : "2018-04-18 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/KoHOOVGnHb",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/beepr\/versions\/1.2\/topics\/beep",
      "display_url" : "rdocumentation.org\/packages\/beepr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "986273092967186433",
  "text" : "Use the \"beep\" function (in the beepr package) to make R play a sound when a long computation finishes https:\/\/t.co\/KoHOOVGnHb #rstats",
  "id" : 986273092967186433,
  "created_at" : "2018-04-17 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/JiquBCPHue",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/textConnection",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "985910689603534851",
  "text" : "Use textConnection() to import data that's already stored in an R character object (rather than a file): https:\/\/t.co\/JiquBCPHue #rstats",
  "id" : 985910689603534851,
  "created_at" : "2018-04-16 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/9ZMWk4sXQy",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/methods",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "984823539109912576",
  "text" : "Many functions, like \"plot\", are generic. Use methods(plot) to see all the object types that can be visualized https:\/\/t.co\/9ZMWk4sXQy #rstats",
  "id" : 984823539109912576,
  "created_at" : "2018-04-13 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/LfE6feS8Ra",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/checks\/check_summary_by_package.html#summary_by_package",
      "display_url" : "cran.r-project.org\/web\/checks\/che\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "984461154171998208",
  "text" : "Can't find a package binary on CRAN? Check its build status on all platforms here: https:\/\/t.co\/LfE6feS8Ra #rstats",
  "id" : 984461154171998208,
  "created_at" : "2018-04-12 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/gXEFFu6OwO",
      "expanded_url" : "https:\/\/cda.ms\/pq",
      "display_url" : "cda.ms\/pq"
    } ]
  },
  "geo" : { },
  "id_str" : "984098774359334913",
  "text" : "SQL Server R tutorials: Data science deep dive, and in-database R https:\/\/t.co\/gXEFFu6OwO #rstats",
  "id" : 984098774359334913,
  "created_at" : "2018-04-11 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 179, 186 ]
    } ],
    "urls" : [ {
      "indices" : [ 155, 178 ],
      "url" : "https:\/\/t.co\/4s14p1MaeY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stringi\/versions\/1.1.6\/topics\/stri_trans_general",
      "display_url" : "rdocumentation.org\/packages\/strin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "983736370224123905",
  "text" : "Normalize accented words to their plain ASCII equivalents with the stringi package: stri_trans_general(\"L\u00FCtzowstra\u00DFe\",\"latin-ascii\") becomes Lutzowstrasse https:\/\/t.co\/4s14p1MaeY #rstats",
  "id" : 983736370224123905,
  "created_at" : "2018-04-10 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/7Pzqw1qCii",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/head",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "983373985806041088",
  "text" : "Use head() to quickly check the first few rows\/elements of a large data frame, vector, list, etc.  #rstats https:\/\/t.co\/7Pzqw1qCii",
  "id" : 983373985806041088,
  "created_at" : "2018-04-09 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/pBLCXlV9MN",
      "expanded_url" : "https:\/\/github.com\/Rdatatable\/data.table\/wiki",
      "display_url" : "github.com\/Rdatatable\/dat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "982286831327875073",
  "text" : "#rstats Try data.table as a substitute for data frames when working with big data https:\/\/t.co\/pBLCXlV9MN",
  "id" : 982286831327875073,
  "created_at" : "2018-04-06 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/8AvIWZOgWQ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/paste",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "981924426076901376",
  "text" : "The paste0 function concatenates strings back-to-back, without any separating characters https:\/\/t.co\/8AvIWZOgWQ #rstats",
  "id" : 981924426076901376,
  "created_at" : "2018-04-05 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Studio Code",
      "screen_name" : "code",
      "indices" : [ 30, 35 ],
      "id_str" : "3167734591",
      "id" : 3167734591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/ZEbnEqB0ys",
      "expanded_url" : "https:\/\/marketplace.visualstudio.com\/items?itemName=Ikuyadeu.r",
      "display_url" : "marketplace.visualstudio.com\/items?itemName\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "981562046293528579",
  "text" : "R extension for Visual Studio @code https:\/\/t.co\/ZEbnEqB0ys #rstats",
  "id" : 981562046293528579,
  "created_at" : "2018-04-04 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/3bbplXVf0E",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/chartr",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "981199650286985216",
  "text" : "Convert character strings to their all-lower-case equivalents with tolower https:\/\/t.co\/3bbplXVf0E #rstats",
  "id" : 981199650286985216,
  "created_at" : "2018-04-03 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 141, 148 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/P1xNA92mJW",
      "expanded_url" : "http:\/\/do.call",
      "display_url" : "do.call"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xZwD0WZ9H2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/do.call",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "980837273066491904",
  "text" : "Want to pass a whole bunch of arguments to a function, but need to wrangle them in code? Use https:\/\/t.co\/P1xNA92mJW https:\/\/t.co\/xZwD0WZ9H2 #rstats",
  "id" : 980837273066491904,
  "created_at" : "2018-04-02 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]