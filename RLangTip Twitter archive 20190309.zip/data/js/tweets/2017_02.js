Grailbird.data.tweets_2017_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Rowlingson\uD83D\uDC3A",
      "screen_name" : "geospacedman",
      "indices" : [ 53, 66 ],
      "id_str" : "88731801",
      "id" : 88731801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/wzSJdLuX6Z",
      "expanded_url" : "http:\/\/www.maths.lancs.ac.uk\/~rowlings\/R\/TaskViews\/",
      "display_url" : "maths.lancs.ac.uk\/~rowlings\/R\/Ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836621996708409345",
  "text" : "An index to CRAN Task Views with some visual puns by @geospacedman https:\/\/t.co\/wzSJdLuX6Z #rstats",
  "id" : 836621996708409345,
  "created_at" : "2017-02-28 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/FrasVJsjEw",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/xtable\/versions\/1.8-2\/topics\/xtable",
      "display_url" : "rdocumentation.org\/packages\/xtabl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836259613246894083",
  "text" : "Generate a LaTeX or HTML table from an R object with xtable https:\/\/t.co\/FrasVJsjEw #rstats",
  "id" : 836259613246894083,
  "created_at" : "2017-02-27 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/DJWkBpTm4t",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Startup",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835172445141282816",
  "text" : "Create a file called .Rprofile of commands to run each time R starts. Good for setting options etc. Example: https:\/\/t.co\/DJWkBpTm4t #rstats",
  "id" : 835172445141282816,
  "created_at" : "2017-02-24 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/eQn9ADB8Im",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.3.2\/topics\/locator",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834810057699229697",
  "text" : "Not sure where to add text or other annotations to your #rstats chart? Use 'locator' to pinpoint with the mouse: https:\/\/t.co\/eQn9ADB8Im",
  "id" : 834810057699229697,
  "created_at" : "2017-02-23 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/jSJgK5l3Hl",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.2\/topics\/ks.test",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834447682496258048",
  "text" : "Compare the distribution of two samples with the Kolmogorov-Smirnov Test: ks.test() https:\/\/t.co\/jSJgK5l3Hl #rstats",
  "id" : 834447682496258048,
  "created_at" : "2017-02-22 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/6jgMfREy20",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/6429180\/how-do-you-you-determine-the-namespace-of-a-function",
      "display_url" : "stackoverflow.com\/questions\/6429\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834414937418104832",
  "text" : "Ways to find which namespace a function comes from https:\/\/t.co\/6jgMfREy20 #rstats",
  "id" : 834414937418104832,
  "created_at" : "2017-02-22 14:49:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/7HnkZpAXbX",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/regex",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833722894169436160",
  "text" : "Type ?regex in the console to get the R manual on regular expressions https:\/\/t.co\/7HnkZpAXbX #rstats",
  "id" : 833722894169436160,
  "created_at" : "2017-02-20 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/isSFA2fdPp",
      "expanded_url" : "http:\/\/topepo.github.io\/caret\/train-models-by-tag.html",
      "display_url" : "topepo.github.io\/caret\/train-mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832635739150114816",
  "text" : "List of predictive model types supported by the caret package: https:\/\/t.co\/isSFA2fdPp #rstats",
  "id" : 832635739150114816,
  "created_at" : "2017-02-17 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 39, 53 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/OjCJ0AvEmJ",
      "expanded_url" : "http:\/\/adv-r.had.co.nz\/Vocabulary.html",
      "display_url" : "adv-r.had.co.nz\/Vocabulary.html"
    } ]
  },
  "geo" : { },
  "id_str" : "832273349128499201",
  "text" : "A basic \"working vocabulary\" for R (by @hadleywickham) https:\/\/t.co\/OjCJ0AvEmJ\u00A0#rstats",
  "id" : 832273349128499201,
  "created_at" : "2017-02-16 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/RukoWUEfcY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/colSums",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831910952966713344",
  "text" : "Use colSums to quickly calculate totals from the columns of a large matrix or table: https:\/\/t.co\/RukoWUEfcY #rstats",
  "id" : 831910952966713344,
  "created_at" : "2017-02-15 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Munroe",
      "screen_name" : "xkcd",
      "indices" : [ 65, 70 ],
      "id_str" : "21146468",
      "id" : 21146468
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Tr5RSFzbsr",
      "expanded_url" : "http:\/\/xkcd.com\/1047\/",
      "display_url" : "xkcd.com\/1047\/"
    } ]
  },
  "geo" : { },
  "id_str" : "831548559916941312",
  "text" : "Jenny's constant in R: (7^(exp(1)-1\/exp(1))-9)*pi^2 #rstats (via @xkcd https:\/\/t.co\/Tr5RSFzbsr ) Happy V Day!",
  "id" : 831548559916941312,
  "created_at" : "2017-02-14 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/bpmyi018O2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/sample",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831186177814302720",
  "text" : "By default, sample(x) randomly permutes x. With the option replace=TRUE it samples with replacement. https:\/\/t.co\/bpmyi018O2 #rstats",
  "id" : 831186177814302720,
  "created_at" : "2017-02-13 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/he7Y9vNVFZ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.1\/topics\/hclust",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830099009696067586",
  "text" : "Try hclust() in the stats package for hierarchical clustering https:\/\/t.co\/he7Y9vNVFZ #rstats",
  "id" : 830099009696067586,
  "created_at" : "2017-02-10 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "indices" : [ 29, 41 ],
      "id_str" : "152862026",
      "id" : 152862026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/DetnSdLXqh",
      "expanded_url" : "http:\/\/dirk.eddelbuettel.com\/code\/tint.html",
      "display_url" : "dirk.eddelbuettel.com\/code\/tint.html"
    } ]
  },
  "geo" : { },
  "id_str" : "829736634547441664",
  "text" : "Write a book in the style of @edwardtufte with the tint package: https:\/\/t.co\/DetnSdLXqh #rstats",
  "id" : 829736634547441664,
  "created_at" : "2017-02-09 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/RazfNUijYh",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/OfficialStatistics.html",
      "display_url" : "cran.r-project.org\/web\/views\/Offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829374249785765888",
  "text" : "List of R packages for survey design and official statistics: https:\/\/t.co\/RazfNUijYh #rstats",
  "id" : 829374249785765888,
  "created_at" : "2017-02-08 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/FEZsZrGexx",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Sys.sleep",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829011851870547969",
  "text" : "Make R pause for 3 seconds during a script or function: Sys.sleep(3) #rstats https:\/\/t.co\/FEZsZrGexx",
  "id" : 829011851870547969,
  "created_at" : "2017-02-07 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/VgnlRVf80l",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.2\/topics\/getAnywhere",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828649483269464065",
  "text" : "Hunt for an object in all loaded namespaces with getAnywhere(object) https:\/\/t.co\/VgnlRVf80l #rstats",
  "id" : 828649483269464065,
  "created_at" : "2017-02-06 17:00:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/AP5kx9htIr",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/MASS\/versions\/7.3-45\/topics\/confint-MASS",
      "display_url" : "rdocumentation.org\/packages\/MASS\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "827623953552257024",
  "text" : "confint() in the MASS package will compute confidence intervals for glm models https:\/\/t.co\/AP5kx9htIr #rstats",
  "id" : 827623953552257024,
  "created_at" : "2017-02-03 21:05:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RTVS",
      "screen_name" : "RT4VS",
      "indices" : [ 30, 36 ],
      "id_str" : "706175863113428992",
      "id" : 706175863113428992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/rjiYAhawCc",
      "expanded_url" : "https:\/\/microsoft.github.io\/RTVS-docs\/sqlserver.html",
      "display_url" : "microsoft.github.io\/RTVS-docs\/sqls\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826837519354490880",
  "text" : "Use R Tools for Visual Studio @RT4VS to write R code as a SQL Server 2016 stored procedure https:\/\/t.co\/rjiYAhawCc #rstats",
  "id" : 826837519354490880,
  "created_at" : "2017-02-01 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]