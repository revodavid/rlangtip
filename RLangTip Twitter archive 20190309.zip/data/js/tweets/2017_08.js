Grailbird.data.tweets_2017_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/uuShAGGEzs",
      "expanded_url" : "https:\/\/mran.microsoft.com\/web\/packages\/rio\/vignettes\/rio.html",
      "display_url" : "mran.microsoft.com\/web\/packages\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903286274429259777",
  "text" : "The rio package provides a simple interface to import a wide variety of data formats https:\/\/t.co\/uuShAGGEzs #rstats",
  "id" : 903286274429259777,
  "created_at" : "2017-08-31 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/UB8J1AKNwJ",
      "expanded_url" : "https:\/\/blogs.msdn.microsoft.com\/rserver\/2017\/07\/20\/using-r-to-generate-api-client-from-swagger\/",
      "display_url" : "blogs.msdn.microsoft.com\/rserver\/2017\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902923886869659648",
  "text" : "How to programatically generate an R client for a Swagger API https:\/\/t.co\/UB8J1AKNwJ #rstats",
  "id" : 902923886869659648,
  "created_at" : "2017-08-30 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo Grossenbacher",
      "screen_name" : "grssnbchr",
      "indices" : [ 53, 63 ],
      "id_str" : "396746547",
      "id" : 396746547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/OcymKAfLQc",
      "expanded_url" : "https:\/\/timogrossenbacher.ch\/2017\/07\/a-truly-reproducible-r-workflow\/",
      "display_url" : "timogrossenbacher.ch\/2017\/07\/a-trul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902561487847165953",
  "text" : "A workflow for reproducible data analysis in R, from @grssnbchr https:\/\/t.co\/OcymKAfLQc #rstats",
  "id" : 902561487847165953,
  "created_at" : "2017-08-29 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/KFLEbOlXS6",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/row",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902199099667210240",
  "text" : "A single index can be used to select from a matrix. For example, X[row(X)==col(X)] is the same as diag(X) https:\/\/t.co\/KFLEbOlXS6 #rstats",
  "id" : 902199099667210240,
  "created_at" : "2017-08-28 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RStudio",
      "screen_name" : "rstudio",
      "indices" : [ 80, 88 ],
      "id_str" : "235261861",
      "id" : 235261861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/LF0cVtgrM2",
      "expanded_url" : "https:\/\/www.rstudio.com\/resources\/cheatsheets\/",
      "display_url" : "rstudio.com\/resources\/chea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "901111947806027776",
  "text" : "Collection of cheatsheets on data import, visualization, Markdown and more from @Rstudio https:\/\/t.co\/LF0cVtgrM2 #rstats",
  "id" : 901111947806027776,
  "created_at" : "2017-08-25 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WVP7RcKX2S",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/",
      "display_url" : "cran.r-project.org\/web\/views\/"
    } ]
  },
  "geo" : { },
  "id_str" : "900749551761412096",
  "text" : "CRAN task views list R packages by topic area (Bayesian, Finance, Web Technologies etc) https:\/\/t.co\/WVP7RcKX2S #rstats",
  "id" : 900749551761412096,
  "created_at" : "2017-08-24 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/IPoxbezU3z",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/visualstudio\/ide\/walkthrough-creating-a-code-snippet",
      "display_url" : "docs.microsoft.com\/en-us\/visualst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900387167121403904",
  "text" : "How to create a code snippet in R Tools for Visual Studio https:\/\/t.co\/IPoxbezU3z #rstats",
  "id" : 900387167121403904,
  "created_at" : "2017-08-23 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/FUHv8bJXsA",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/03\/16-years-of-r-history.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/03\/16-yea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900024775703056384",
  "text" : "History of R project:\n1993 Project begins in NZ\n1997 R-core forms\n2000 v1.0 release\n2003 R Foundation formed\nhttps:\/\/t.co\/FUHv8bJXsA #rstats",
  "id" : 900024775703056384,
  "created_at" : "2017-08-22 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899662381923659776",
  "text" : "To get help on some R operators, use quotes, e.g. ?\"%*%\", ?\"if\", ?\"!\" etc. If in doubt, add quotes. #rstats",
  "id" : 899662381923659776,
  "created_at" : "2017-08-21 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yXFh0r2aCz",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/MASS\/versions\/7.3-47\/topics\/fitdistr",
      "display_url" : "rdocumentation.org\/packages\/MASS\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898575223791996931",
  "text" : "fitdistr fits a univariate probability distribution to a vector of data using maximum likelihood estimation: https:\/\/t.co\/yXFh0r2aCz #rstats",
  "id" : 898575223791996931,
  "created_at" : "2017-08-18 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/SR0GlgzH4d",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.1\/topics\/memory.size",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898212840091377664",
  "text" : "Find the maximum amount of memory available to R (in Mb) with memory.limit() #rstats https:\/\/t.co\/SR0GlgzH4d",
  "id" : 898212840091377664,
  "created_at" : "2017-08-17 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/uu3dqWRjC8",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2017\/01\/remote-and-local-r-workspaces.html",
      "display_url" : "blog.revolutionanalytics.com\/2017\/01\/remote\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897850456696737794",
  "text" : "Interactively execute R functions on a remote Microsoft R Server with remoteLogin() https:\/\/t.co\/uu3dqWRjC8 #rstats",
  "id" : 897850456696737794,
  "created_at" : "2017-08-16 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Kearney\uD83D\uDCCA",
      "screen_name" : "kearneymw",
      "indices" : [ 97, 107 ],
      "id_str" : "2973406683",
      "id" : 2973406683
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/k3GXDr6i4k",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/lengths",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897488071725375489",
  "text" : "Use lengths(x) to find the length of every element in a list https:\/\/t.co\/k3GXDr6i4k #rstats via @kearneymw",
  "id" : 897488071725375489,
  "created_at" : "2017-08-15 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/WWRkNULNxp",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/NA",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897125678306480129",
  "text" : "In R, NA represents missing values. To check for NAs, use the is.na function, not the == operator https:\/\/t.co\/WWRkNULNxp #rstats",
  "id" : 897125678306480129,
  "created_at" : "2017-08-14 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/yMBRT30QcY",
      "expanded_url" : "http:\/\/www.jstatsoft.org\/index",
      "display_url" : "jstatsoft.org\/index"
    } ]
  },
  "geo" : { },
  "id_str" : "896038513124233216",
  "text" : "For some really good #rstats reading have a look at the Journal of Statistical Software https:\/\/t.co\/yMBRT30QcY",
  "id" : 896038513124233216,
  "created_at" : "2017-08-11 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/BDmKkIq5iu",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.1\/topics\/quantile",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895676122351796224",
  "text" : "R has nine different algorithms for computing quantiles https:\/\/t.co\/BDmKkIq5iu #rstats",
  "id" : 895676122351796224,
  "created_at" : "2017-08-10 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/GyXO2BaTmj",
      "expanded_url" : "https:\/\/www.edx.org\/course\/introduction-r-data-science-microsoft-dat204x-5",
      "display_url" : "edx.org\/course\/introdu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895313740412981248",
  "text" : "A free, 4-week online course for beginners: \"Introduction to R for Data Science\" https:\/\/t.co\/GyXO2BaTmj #rstats",
  "id" : 895313740412981248,
  "created_at" : "2017-08-09 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yihui Xie",
      "screen_name" : "xieyihui",
      "indices" : [ 87, 96 ],
      "id_str" : "39010299",
      "id" : 39010299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Aa7Nkb2w32",
      "expanded_url" : "https:\/\/yihui.name\/en\/2017\/06\/top-level-r-expressions\/",
      "display_url" : "yihui.name\/en\/2017\/06\/top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "894951343055446016",
  "text" : "R automatically prints most expressions evaluated at the command line, as explained by @xieyihui https:\/\/t.co\/Aa7Nkb2w32 #rstats",
  "id" : 894951343055446016,
  "created_at" : "2017-08-08 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/yF4Eb5Jzdu",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/missing",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "894588955362025472",
  "text" : "Use missing(x) to test whether an argument x was supplied when a function was invoked: https:\/\/t.co\/yF4Eb5Jzdu #rstats",
  "id" : 894588955362025472,
  "created_at" : "2017-08-07 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ateYsijIHl",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/cluster\/versions\/2.0.6\/topics\/daisy",
      "display_url" : "rdocumentation.org\/packages\/clust\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "893501801672187904",
  "text" : "daisy(df) computes all pairwise dissimilarities between observations in a data frame https:\/\/t.co\/ateYsijIHl #rstats",
  "id" : 893501801672187904,
  "created_at" : "2017-08-04 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ESbY4VYHsT",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/FAQ\/R-FAQ.html#How-do-file-names-work-in-Windows_003f",
      "display_url" : "cran.r-project.org\/doc\/FAQ\/R-FAQ.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "893139413319811072",
  "text" : "On Windows, you can substitute forward slashes for backslashes in filenames (for convenience or portability) https:\/\/t.co\/ESbY4VYHsT #rstats",
  "id" : 893139413319811072,
  "created_at" : "2017-08-03 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/uZTNcyy1zS",
      "expanded_url" : "https:\/\/blogs.msdn.microsoft.com\/rserver\/2017\/04\/12\/pleasingly-parallel-using-rxexecby\/",
      "display_url" : "blogs.msdn.microsoft.com\/rserver\/2017\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892777022291935234",
  "text" : "Parallel group-by operations on clusters, SQL Server or Spark with rExecBy in Microsoft R Server https:\/\/t.co\/uZTNcyy1zS #rstats",
  "id" : 892777022291935234,
  "created_at" : "2017-08-02 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892414633952149505",
  "text" : "It's usually best *not* to save and reload your R workspace. Unexpected objects in the environment can be a source of bugs #rstats",
  "id" : 892414633952149505,
  "created_at" : "2017-08-01 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]