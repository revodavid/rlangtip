Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/gaFumMy6Yz",
      "expanded_url" : "http:\/\/bit.ly\/RE2H6l",
      "display_url" : "bit.ly\/RE2H6l"
    } ]
  },
  "geo" : { },
  "id_str" : "693117953399660544",
  "text" : "Use \"deriv\" to create a function that returns the derivative and hessian of a symbolic expression: https:\/\/t.co\/gaFumMy6Yz #rstats",
  "id" : 693117953399660544,
  "created_at" : "2016-01-29 17:06:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/8VMflVaPAe",
      "expanded_url" : "http:\/\/bit.ly\/NaI9lG",
      "display_url" : "bit.ly\/NaI9lG"
    } ]
  },
  "geo" : { },
  "id_str" : "692740365854580736",
  "text" : "Type ?Syntax to learn the precedence of operators in the R language: https:\/\/t.co\/8VMflVaPAe #rstats",
  "id" : 692740365854580736,
  "created_at" : "2016-01-28 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/CTFr8K8frS",
      "expanded_url" : "http:\/\/bit.ly\/18cN8XN",
      "display_url" : "bit.ly\/18cN8XN"
    } ]
  },
  "geo" : { },
  "id_str" : "692393201844510721",
  "text" : "Use variable name in plot title: hist(var,main=substitute(paste(\"Dist of \",var))) #rstats https:\/\/t.co\/CTFr8K8frS",
  "id" : 692393201844510721,
  "created_at" : "2016-01-27 17:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/PYYxISom0J",
      "expanded_url" : "http:\/\/bit.ly\/1ZHL3yA",
      "display_url" : "bit.ly\/1ZHL3yA"
    } ]
  },
  "geo" : { },
  "id_str" : "692393202054238209",
  "text" : "inSide() \u007Bmgcv\u007D may help you determine if points are inside a boundary. https:\/\/t.co\/PYYxISom0J #rstats",
  "id" : 692393202054238209,
  "created_at" : "2016-01-27 17:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/B38pGNSqpq",
      "expanded_url" : "http:\/\/bit.ly\/1zFZMhl",
      "display_url" : "bit.ly\/1zFZMhl"
    } ]
  },
  "geo" : { },
  "id_str" : "691668336086814720",
  "text" : "diag(n) \u007Bbase\u007D will construct an nxn  \"Identity matrix\" https:\/\/t.co\/B38pGNSqpq #rstats",
  "id" : 691668336086814720,
  "created_at" : "2016-01-25 17:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/PQeAQsbn1m",
      "expanded_url" : "http:\/\/bit.ly\/SpgMXb",
      "display_url" : "bit.ly\/SpgMXb"
    } ]
  },
  "geo" : { },
  "id_str" : "690581224516096001",
  "text" : "Serialization: save a single R object to disk with saveRDS; restore in a new session with readRDS https:\/\/t.co\/PQeAQsbn1m #rstats",
  "id" : 690581224516096001,
  "created_at" : "2016-01-22 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/knuJLflYvf",
      "expanded_url" : "http:\/\/bit.ly\/M6mDiL",
      "display_url" : "bit.ly\/M6mDiL"
    } ]
  },
  "geo" : { },
  "id_str" : "690218813749641216",
  "text" : "On Windows, substitute forward slashes for backslashes in filenames (for convenience or portability): https:\/\/t.co\/knuJLflYvf #rstats",
  "id" : 690218813749641216,
  "created_at" : "2016-01-21 17:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/BN195HVaow",
      "expanded_url" : "http:\/\/bit.ly\/1J7qLwo",
      "display_url" : "bit.ly\/1J7qLwo"
    } ]
  },
  "geo" : { },
  "id_str" : "689856453839097856",
  "text" : "scan() \u007Bbase\u007D will read data into a vector or list from the console or from a file. https:\/\/t.co\/BN195HVaow #rstats",
  "id" : 689856453839097856,
  "created_at" : "2016-01-20 17:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/gsfN0TAHiY",
      "expanded_url" : "http:\/\/bit.ly\/1bwnJPS",
      "display_url" : "bit.ly\/1bwnJPS"
    } ]
  },
  "geo" : { },
  "id_str" : "689494038400004096",
  "text" : "#rstats Send plots to pdf file: run pdf(\"myOut.pdf\"), produce plots, turn off with dev.off() https:\/\/t.co\/gsfN0TAHiY",
  "id" : 689494038400004096,
  "created_at" : "2016-01-19 17:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/k9T3jIuxgR",
      "expanded_url" : "http:\/\/bit.ly\/1QbKZqe",
      "display_url" : "bit.ly\/1QbKZqe"
    } ]
  },
  "geo" : { },
  "id_str" : "689131642120704002",
  "text" : "Typing \"fix(foo)\" from \u007Butils\u007D package will bring up a template for creating a function named foo. https:\/\/t.co\/k9T3jIuxgR #rstats",
  "id" : 689131642120704002,
  "created_at" : "2016-01-18 17:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/MQslKlNOu1",
      "expanded_url" : "http:\/\/bit.ly\/pbemkM",
      "display_url" : "bit.ly\/pbemkM"
    } ]
  },
  "geo" : { },
  "id_str" : "688044533830053888",
  "text" : "options(stringsAsFactors=FALSE) will force R to always import character data as character objects: https:\/\/t.co\/MQslKlNOu1 #rstats",
  "id" : 688044533830053888,
  "created_at" : "2016-01-15 17:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/03vhrrhWK4",
      "expanded_url" : "http:\/\/bit.ly\/17ZXbWM",
      "display_url" : "bit.ly\/17ZXbWM"
    } ]
  },
  "geo" : { },
  "id_str" : "687682092226973696",
  "text" : "In R it is possible to use a matrix of integers as an index into another matrix https:\/\/t.co\/03vhrrhWK4 #rstats",
  "id" : 687682092226973696,
  "created_at" : "2016-01-14 17:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/3RljHQEYSw",
      "expanded_url" : "http:\/\/bit.ly\/9b9IS",
      "display_url" : "bit.ly\/9b9IS"
    } ]
  },
  "geo" : { },
  "id_str" : "687319698921369600",
  "text" : "Write professional looking code with Google's R style guide https:\/\/t.co\/3RljHQEYSw #rstats",
  "id" : 687319698921369600,
  "created_at" : "2016-01-13 17:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/i4e91qPwkn",
      "expanded_url" : "http:\/\/bit.ly\/1n8D15H",
      "display_url" : "bit.ly\/1n8D15H"
    } ]
  },
  "geo" : { },
  "id_str" : "686957291493548033",
  "text" : "The pracma package contains a number of functions for linear algebra and numerical analysis. https:\/\/t.co\/i4e91qPwkn #rstats",
  "id" : 686957291493548033,
  "created_at" : "2016-01-12 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ztdCKArZSm",
      "expanded_url" : "http:\/\/bit.ly\/1SEFssK",
      "display_url" : "bit.ly\/1SEFssK"
    } ]
  },
  "geo" : { },
  "id_str" : "686594893423210496",
  "text" : "gnls(model) \u007Bnlme\u007D will fit a nonlinear model using generalized least squares. https:\/\/t.co\/ztdCKArZSm #rstats",
  "id" : 686594893423210496,
  "created_at" : "2016-01-11 17:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kc4xxrFSk3",
      "expanded_url" : "http:\/\/bit.ly\/AE2djP",
      "display_url" : "bit.ly\/AE2djP"
    } ]
  },
  "geo" : { },
  "id_str" : "685507772285370368",
  "text" : "Try demo('graphics') ... and type demo() to see other demos available in attached packages. https:\/\/t.co\/kc4xxrFSk3 #rstats",
  "id" : 685507772285370368,
  "created_at" : "2016-01-08 17:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/DIi53UjDJ7",
      "expanded_url" : "http:\/\/bit.ly\/TqVLZ3",
      "display_url" : "bit.ly\/TqVLZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "685145369752174592",
  "text" : "If two packages define functions with the same name, use :: to call the one you want: https:\/\/t.co\/DIi53UjDJ7  #rstats",
  "id" : 685145369752174592,
  "created_at" : "2016-01-07 17:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/5CvqlToq6H",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "684782976236949504",
  "text" : "Negative indexes remove elements from a vector. x[-1] is x without the first element. https:\/\/t.co\/5CvqlToq6H #rstats",
  "id" : 684782976236949504,
  "created_at" : "2016-01-06 17:05:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/AcdkvKeEU8",
      "expanded_url" : "http:\/\/bit.ly\/1NWECUW",
      "display_url" : "bit.ly\/1NWECUW"
    } ]
  },
  "geo" : { },
  "id_str" : "684420576388198400",
  "text" : "gam() in \u007Bmgcv\u007D fits generalized additive models (any quadratically penalized GLM) https:\/\/t.co\/AcdkvKeEU8 #rstats",
  "id" : 684420576388198400,
  "created_at" : "2016-01-05 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/3PoVzrQdAi",
      "expanded_url" : "http:\/\/bit.ly\/1PBzKqP",
      "display_url" : "bit.ly\/1PBzKqP"
    } ]
  },
  "geo" : { },
  "id_str" : "684058171917385728",
  "text" : "matpow() \u007Bexpm\u007D: M %^% n is an efficient function for raising a matrix to a power https:\/\/t.co\/3PoVzrQdAi #rstats",
  "id" : 684058171917385728,
  "created_at" : "2016-01-04 17:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/J0LDLgM4o0",
      "expanded_url" : "http:\/\/bit.ly\/1NFTt60",
      "display_url" : "bit.ly\/1NFTt60"
    } ]
  },
  "geo" : { },
  "id_str" : "682970271536574464",
  "text" : "Find dates of many international public holidays:  holiday(Holiday=\"JPNationalCultureDay\") \u007BtimeDate\u007D https:\/\/t.co\/J0LDLgM4o0 #rstats",
  "id" : 682970271536574464,
  "created_at" : "2016-01-01 17:02:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]