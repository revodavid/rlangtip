Grailbird.data.tweets_2019_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/PVl91vnweg",
      "expanded_url" : "http:\/\/journal.r-project.org\/",
      "display_url" : "journal.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "1101195329074978817",
  "text" : "Keep up with R by reading the R Journal: https:\/\/t.co\/PVl91vnweg #rstats",
  "id" : 1101195329074978817,
  "created_at" : "2019-02-28 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ws6hH6zyzg",
      "expanded_url" : "https:\/\/cloud.r-project.org\/web\/packages\/AzureStor\/vignettes\/intro.html",
      "display_url" : "cloud.r-project.org\/web\/packages\/A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1100832945831534592",
  "text" : "Introduction to AzureStor, a package to manage Blob storage, File storage, and Data Lake Storage in Azure https:\/\/t.co\/ws6hH6zyzg #rstats",
  "id" : 1100832945831534592,
  "created_at" : "2019-02-27 19:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/RozRAq2T3c",
      "expanded_url" : "https:\/\/www.statmethods.net\/interface\/packages.html",
      "display_url" : "statmethods.net\/interface\/pack\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1100470556078600192",
  "text" : "Use library() to see all packages installed, search() to see all packages loaded #rstats https:\/\/t.co\/RozRAq2T3c",
  "id" : 1100470556078600192,
  "created_at" : "2019-02-26 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/OcAqhjqaOD",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.5.2\/topics\/rug",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1100108170943492096",
  "text" : "In base graphics, use rug() to add a rug representation (1-d plot) of the data to a plot https:\/\/t.co\/OcAqhjqaOD #rstats",
  "id" : 1100108170943492096,
  "created_at" : "2019-02-25 19:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 171, 178 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/as9rMAfdob",
      "expanded_url" : "http:\/\/help.search",
      "display_url" : "help.search"
    }, {
      "indices" : [ 147, 170 ],
      "url" : "https:\/\/t.co\/MOD92teHI0",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.2\/topics\/help",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1098990810404712448",
  "text" : "? is a shortcut for help(). ?? is a shortcut for https:\/\/t.co\/as9rMAfdob(). Use \"packagename::query\" to restrict the search to a specific package. https:\/\/t.co\/MOD92teHI0 #rstats",
  "id" : 1098990810404712448,
  "created_at" : "2019-02-22 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 146, 153 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/CfJN4vOYem",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/KernSmooth\/versions\/2.23-15\/topics\/dpih",
      "display_url" : "rdocumentation.org\/packages\/KernS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1098628420018294784",
  "text" : "The function dpih() \u007BKernSmooth\u007D uses the direct plug-in methodology to automatically select the bin width of a histogram https:\/\/t.co\/CfJN4vOYem #rstats",
  "id" : 1098628420018294784,
  "created_at" : "2019-02-21 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi B Robbins",
      "screen_name" : "nbrgraphs",
      "indices" : [ 15, 25 ],
      "id_str" : "25151614",
      "id" : 25151614
    }, {
      "name" : "Joyce Robbins",
      "screen_name" : "jtrnyc",
      "indices" : [ 30, 37 ],
      "id_str" : "4406202856",
      "id" : 4406202856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Z3Ox4c9vur",
      "expanded_url" : "http:\/\/www.joyce-robbins.com\/wp-content\/uploads\/2016\/04\/effectivegraphsmro1.pdf",
      "display_url" : "joyce-robbins.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1098266036095340546",
  "text" : "Free e-book by @nbrgraphs and @jtrnyc \"Effective Graphs with Microsoft R Open\" https:\/\/t.co\/Z3Ox4c9vur #rstats",
  "id" : 1098266036095340546,
  "created_at" : "2019-02-20 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/GoQU4MkKSp",
      "expanded_url" : "https:\/\/bbc.github.io\/rcookbook\/",
      "display_url" : "bbc.github.io\/rcookbook\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1097903646241705984",
  "text" : "BBC Visual and Data Journalism cookbook for R graphics https:\/\/t.co\/GoQU4MkKSp #rstats",
  "id" : 1097903646241705984,
  "created_at" : "2019-02-19 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ZxuiovANpJ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/mapply",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1097541255091896322",
  "text" : "Use mapply to call a multi-argument function repeatedly, e.g. mapply(sample, list(1:56, 1:46), c(5,1)) #rstats https:\/\/t.co\/ZxuiovANpJ",
  "id" : 1097541255091896322,
  "created_at" : "2019-02-18 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/sClPwUofbW",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/unname",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1096454088777035777",
  "text" : "Use unname() to remove the names of an R object #rstats https:\/\/t.co\/sClPwUofbW",
  "id" : 1096454088777035777,
  "created_at" : "2019-02-15 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Tqccke54Bf",
      "expanded_url" : "https:\/\/stackoverflow.com\/questions\/8082429\/plot-a-heart-in-r",
      "display_url" : "stackoverflow.com\/questions\/8082\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1096091713968340993",
  "text" : "Send an R valentine https:\/\/t.co\/Tqccke54Bf #rstats",
  "id" : 1096091713968340993,
  "created_at" : "2019-02-14 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/oTxnemdrVA",
      "expanded_url" : "https:\/\/docs.microsoft.com\/azure\/machine-learning\/team-data-science-process\/walkthroughs-sql-server?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/azure\/machine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1095729316997017600",
  "text" : "Walkthroughs of data analyses using SQL Server and R under the Team Data Science Process https:\/\/t.co\/oTxnemdrVA #rstats",
  "id" : 1095729316997017600,
  "created_at" : "2019-02-13 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Wy3ox3CsVn",
      "expanded_url" : "https:\/\/blogs.rstudio.com\/tensorflow\/posts\/2019-01-08-getting-started-with-tf-probability\/",
      "display_url" : "blogs.rstudio.com\/tensorflow\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1095366930100338690",
  "text" : "Getting started with Tensorflow Probability from R https:\/\/t.co\/Wy3ox3CsVn #rstats",
  "id" : 1095366930100338690,
  "created_at" : "2019-02-12 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/1AagkTGy8v",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/cluster\/topics\/agnes",
      "display_url" : "rdocumentation.org\/packages\/clust\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1095034736093945856",
  "text" : "agnes() (in the cluster package) implements 6 methods of agglomerative clustering https:\/\/t.co\/1AagkTGy8v #rstats",
  "id" : 1095034736093945856,
  "created_at" : "2019-02-11 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/iZNHFboJSa",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/readRDS",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1093947576989081600",
  "text" : "Use saveRDS(obj,\"myfile\") and readRDS(obj,\"myfile\") to save \/ read an R object to \/ from a file https:\/\/t.co\/iZNHFboJSa #rstats",
  "id" : 1093947576989081600,
  "created_at" : "2019-02-08 19:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/vU3P8fi52o",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/Logic",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1093585186590257152",
  "text" : "xor(x,y) (element wise exclusive OR) is one of R's logical operators https:\/\/t.co\/vU3P8fi52o #rstats",
  "id" : 1093585186590257152,
  "created_at" : "2019-02-07 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/04ij9up69q",
      "expanded_url" : "https:\/\/docs.microsoft.com\/azure\/notebooks\/azure-notebooks-overview?WT.mc_id=RLangTip-Twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/azure\/notebook\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1093222797742993408",
  "text" : "Free hosted Jupyter notebooks with R support: Azure Notebooks https:\/\/t.co\/04ij9up69q #rstats",
  "id" : 1093222797742993408,
  "created_at" : "2019-02-06 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/sW6GE1xzRd",
      "expanded_url" : "https:\/\/colinfay.me\/docker-r-reproducibility\/",
      "display_url" : "colinfay.me\/docker-r-repro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1092860407889313792",
  "text" : "Use containers for reproducibility: Introduction to Docker for R users https:\/\/t.co\/sW6GE1xzRd #rstats",
  "id" : 1092860407889313792,
  "created_at" : "2019-02-05 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/hkfNCN35Kr",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/which.min",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1092467825422336005",
  "text" : "Locate the largest number in a vector with which.max(mydata) https:\/\/t.co\/hkfNCN35Kr #rstats",
  "id" : 1092467825422336005,
  "created_at" : "2019-02-04 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ed8zQJIDNE",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/noquote",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1091380664333590535",
  "text" : "If ch is a character vector, then noquote(ch) prints it without the usual quotes surrounding each element #rstats https:\/\/t.co\/ed8zQJIDNE",
  "id" : 1091380664333590535,
  "created_at" : "2019-02-01 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]