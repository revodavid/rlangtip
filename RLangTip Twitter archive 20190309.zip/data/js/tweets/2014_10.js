Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/AJOg8fEACM",
      "expanded_url" : "http:\/\/bit.ly\/PF2fa7",
      "display_url" : "bit.ly\/PF2fa7"
    } ]
  },
  "geo" : { },
  "id_str" : "528216276779683840",
  "text" : "Create a Halloween card with #rstats: http:\/\/t.co\/AJOg8fEACM",
  "id" : 528216276779683840,
  "created_at" : "2014-10-31 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/2Ks501yFIq",
      "expanded_url" : "http:\/\/bit.ly\/TN15uC",
      "display_url" : "bit.ly\/TN15uC"
    } ]
  },
  "geo" : { },
  "id_str" : "527853836946636800",
  "text" : "How R finds variables used in statistical models: http:\/\/t.co\/2Ks501yFIq #rstats",
  "id" : 527853836946636800,
  "created_at" : "2014-10-30 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/G83J1FfFiq",
      "expanded_url" : "http:\/\/bit.ly\/qXsMe5",
      "display_url" : "bit.ly\/qXsMe5"
    } ]
  },
  "geo" : { },
  "id_str" : "527491470899826688",
  "text" : "Turn off all warnings in R with options(warn=-1), or use suppressWarnings(&lt;expr&gt;) http:\/\/t.co\/G83J1FfFiq #rstats",
  "id" : 527491470899826688,
  "created_at" : "2014-10-29 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/7GlKaEuUTt",
      "expanded_url" : "http:\/\/bit.ly\/163iD5E",
      "display_url" : "bit.ly\/163iD5E"
    } ]
  },
  "geo" : { },
  "id_str" : "527129140039020545",
  "text" : "Remove all objects from your current environment with rm(list=ls()) but be careful #rstats http:\/\/t.co\/7GlKaEuUTt",
  "id" : 527129140039020545,
  "created_at" : "2014-10-28 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/hM2vaFFqq3",
      "expanded_url" : "http:\/\/bit.ly\/1sZjwL3",
      "display_url" : "bit.ly\/1sZjwL3"
    } ]
  },
  "geo" : { },
  "id_str" : "526766702621888513",
  "text" : "The function missing.pattern.plot() from the mi package let you see how NAs are distributed http:\/\/t.co\/hM2vaFFqq3 #rstats",
  "id" : 526766702621888513,
  "created_at" : "2014-10-27 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525680735358042112",
  "text" : "The # character introduces comments in R. Everything after the # character to end-of-line is ignored by the interpreter. #rstats",
  "id" : 525680735358042112,
  "created_at" : "2014-10-24 16:10:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525318113525784576",
  "text" : "When selecting from vectors, repeated indexes are allowed. x[c(1,1,2,2,3,3)] duplicates the first 3 elements of x #rstats",
  "id" : 525318113525784576,
  "created_at" : "2014-10-23 16:09:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/e7y8jTwKas",
      "expanded_url" : "http:\/\/bit.ly\/pM20DY",
      "display_url" : "bit.ly\/pM20DY"
    } ]
  },
  "geo" : { },
  "id_str" : "524955325888495616",
  "text" : "The foreach function can be used to speed up loops by running in parallel on multi-core machines: http:\/\/t.co\/e7y8jTwKas",
  "id" : 524955325888495616,
  "created_at" : "2014-10-22 16:07:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/yU0Olx9now",
      "expanded_url" : "http:\/\/bit.ly\/1tC9LWK",
      "display_url" : "bit.ly\/1tC9LWK"
    } ]
  },
  "geo" : { },
  "id_str" : "524592925091856384",
  "text" : "Install packages as they were on CRAN on a specified date with the checkpoint package time machine: http:\/\/t.co\/yU0Olx9now #rstats",
  "id" : 524592925091856384,
  "created_at" : "2014-10-21 16:07:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/yU0Olx9now",
      "expanded_url" : "http:\/\/bit.ly\/1tC9LWK",
      "display_url" : "bit.ly\/1tC9LWK"
    } ]
  },
  "geo" : { },
  "id_str" : "524229978855342081",
  "text" : "Install packages as they were on CRAN on a specified date with the checkpoint package time machine: http:\/\/t.co\/yU0Olx9now #rstats",
  "id" : 524229978855342081,
  "created_at" : "2014-10-20 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/I22xoiBTqr",
      "expanded_url" : "http:\/\/bit.ly\/t2OR0K",
      "display_url" : "bit.ly\/t2OR0K"
    } ]
  },
  "geo" : { },
  "id_str" : "523142815321448449",
  "text" : "To speed an R function, use cmpfun to byte-compile it: http:\/\/t.co\/I22xoiBTqr #rstats",
  "id" : 523142815321448449,
  "created_at" : "2014-10-17 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kHOQ1JzvZv",
      "expanded_url" : "http:\/\/bit.ly\/WzSaeR",
      "display_url" : "bit.ly\/WzSaeR"
    } ]
  },
  "geo" : { },
  "id_str" : "522418032929677312",
  "text" : "Include .progress=\"text\" as an argument to many plyr functions to display a progress bar during computation: http:\/\/t.co\/kHOQ1JzvZv #rstats",
  "id" : 522418032929677312,
  "created_at" : "2014-10-15 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/OsZ8sEuPh8",
      "expanded_url" : "http:\/\/bit.ly\/1uSwtZf",
      "display_url" : "bit.ly\/1uSwtZf"
    } ]
  },
  "geo" : { },
  "id_str" : "522055643247955968",
  "text" : "Arrange multiple ggplot2 plots in the same window (Stephen Turner) http:\/\/t.co\/OsZ8sEuPh8 #rstats",
  "id" : 522055643247955968,
  "created_at" : "2014-10-14 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/I7A2BOI2Ou",
      "expanded_url" : "http:\/\/www.ats.ucla.edu\/stat\/r\/faq\/missing.htm",
      "display_url" : "ats.ucla.edu\/stat\/r\/faq\/mis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521693213418352640",
  "text" : "Some tips for dealing with missing values: http:\/\/t.co\/I7A2BOI2Ou #rstats",
  "id" : 521693213418352640,
  "created_at" : "2014-10-13 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/DclzHmbH8g",
      "expanded_url" : "http:\/\/bit.ly\/wIGrFC",
      "display_url" : "bit.ly\/wIGrFC"
    } ]
  },
  "geo" : { },
  "id_str" : "520606081794703360",
  "text" : "A single index can be used to select from a matrix. For example, X[row(X)==col(X)] is the same as diag(X) #rstats http:\/\/t.co\/DclzHmbH8g",
  "id" : 520606081794703360,
  "created_at" : "2014-10-10 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 95, 109 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/PXm8Oi8ZbT",
      "expanded_url" : "http:\/\/bit.ly\/KGRu37",
      "display_url" : "bit.ly\/KGRu37"
    } ]
  },
  "geo" : { },
  "id_str" : "520243701101367296",
  "text" : "Get a quick visual overview of your data with the tabplot package: http:\/\/t.co\/PXm8Oi8ZbT (via @JacquelynGill)",
  "id" : 520243701101367296,
  "created_at" : "2014-10-09 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/vH6SSlC3j1",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "519881331468414976",
  "text" : "Return the row\/column indices of positive elements of matrix x: which(x&gt;0, arr.ind=TRUE) #rstats http:\/\/t.co\/vH6SSlC3j1",
  "id" : 519881331468414976,
  "created_at" : "2014-10-08 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ZFV5YIcT3b",
      "expanded_url" : "http:\/\/bit.ly\/1pxOcze",
      "display_url" : "bit.ly\/1pxOcze"
    } ]
  },
  "geo" : { },
  "id_str" : "519519079288565760",
  "text" : "Conditional indexing. For vectors X and Y: Y[X &gt; 5]  yields elements of Y for which X &gt; 5. http:\/\/t.co\/ZFV5YIcT3b #rstats",
  "id" : 519519079288565760,
  "created_at" : "2014-10-07 16:06:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/I7nuuvKYrm",
      "expanded_url" : "http:\/\/bit.ly\/1vDE7GR",
      "display_url" : "bit.ly\/1vDE7GR"
    } ]
  },
  "geo" : { },
  "id_str" : "519156491597918208",
  "text" : "In base graphics, use segments(x0,y0,x1,y1) to draw a line between two points on a plot(x,y) http:\/\/t.co\/I7nuuvKYrm #rstats",
  "id" : 519156491597918208,
  "created_at" : "2014-10-06 16:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Lemaitre",
      "screen_name" : "joshlemaitre",
      "indices" : [ 114, 127 ],
      "id_str" : "21264652",
      "id" : 21264652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/lIC5QjwC5s",
      "expanded_url" : "http:\/\/bit.ly\/QKKDsn",
      "display_url" : "bit.ly\/QKKDsn"
    } ]
  },
  "geo" : { },
  "id_str" : "518069403657973761",
  "text" : "Forgot to save the output from the last #rstats command? Retrieve it with .Last.value http:\/\/t.co\/lIC5QjwC5s (via @joshlemaitre)",
  "id" : 518069403657973761,
  "created_at" : "2014-10-03 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 22, 31 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/lR26mDEvaq",
      "expanded_url" : "http:\/\/bit.ly\/ISiZD6",
      "display_url" : "bit.ly\/ISiZD6"
    } ]
  },
  "geo" : { },
  "id_str" : "517707042774339584",
  "text" : "Browse past tips from @RLangTip at http:\/\/t.co\/lR26mDEvaq #rstats",
  "id" : 517707042774339584,
  "created_at" : "2014-10-02 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/wnXPKkbvDy",
      "expanded_url" : "http:\/\/bit.ly\/1yugeVU",
      "display_url" : "bit.ly\/1yugeVU"
    } ]
  },
  "geo" : { },
  "id_str" : "517344663834222592",
  "text" : "Look at the partykit package for tools to visualize classification tree models. http:\/\/t.co\/wnXPKkbvDy #rstats",
  "id" : 517344663834222592,
  "created_at" : "2014-10-01 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]