Grailbird.data.tweets_2017_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/q38ShuvfbM",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/TimeSeries.html",
      "display_url" : "cran.r-project.org\/web\/views\/Time\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892082433549623297",
  "text" : "List of R functions and packages for Time Series Analysis https:\/\/t.co\/q38ShuvfbM #rstats",
  "id" : 892082433549623297,
  "created_at" : "2017-07-31 18:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Jwm7fFBfiK",
      "expanded_url" : "http:\/\/stat.ethz.ch\/R-manual\/R-devel\/doc\/html\/NEWS.html",
      "display_url" : "stat.ethz.ch\/R-manual\/R-dev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890995282992930817",
  "text" : "Find the list of changes in the forthcoming release of R (R-devel) here: https:\/\/t.co\/Jwm7fFBfiK #rstats",
  "id" : 890995282992930817,
  "created_at" : "2017-07-28 18:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/5lRW8mSbld",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/statmod\/",
      "display_url" : "mran.microsoft.com\/package\/statmo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890632881596276736",
  "text" : "Many zeroes in your data? Fit a Tweedie GLM with tweedie() function in the statmod package https:\/\/t.co\/5lRW8mSbld #rstats",
  "id" : 890632881596276736,
  "created_at" : "2017-07-27 18:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/JVLly9OMsa",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/r-server\/operationalize\/how-to-deploy-web-service-publish-manage-in-r",
      "display_url" : "docs.microsoft.com\/en-us\/r-server\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890270502354288640",
  "text" : "Use publishService(serviceType=\"realtime\") to deploy a trained model object as a real-time scoring service https:\/\/t.co\/JVLly9OMsa #rstats",
  "id" : 890270502354288640,
  "created_at" : "2017-07-26 18:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/EjE8WPXt05",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/purrr\/versions\/0.2.2.2\/topics\/safely",
      "display_url" : "rdocumentation.org\/packages\/purrr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "889908120813785090",
  "text" : "Capture errors, warning and functions by wrapping the call in safely( ) from the purrr package https:\/\/t.co\/EjE8WPXt05 #rstats",
  "id" : 889908120813785090,
  "created_at" : "2017-07-25 18:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/Rx3IC59FZI",
      "expanded_url" : "http:\/\/motioninsocial.com\/tufte\/",
      "display_url" : "motioninsocial.com\/tufte\/"
    } ]
  },
  "geo" : { },
  "id_str" : "889515518683754496",
  "text" : "Create Tufte-inspired graphics in R https:\/\/t.co\/Rx3IC59FZI #rstats",
  "id" : 889515518683754496,
  "created_at" : "2017-07-24 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ycPbnI1xEY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.4.0\/topics\/par",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "888277360218226689",
  "text" : "See help(par) for many options for controlling the appearance of base graphics in R https:\/\/t.co\/ycPbnI1xEY #rstats",
  "id" : 888277360218226689,
  "created_at" : "2017-07-21 06:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/V9uEJs03Uh",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/order",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "888065989652475904",
  "text" : "List row\/col matrix indices, from largest value to smallest: cbind(row(x)[order(-x)],col(x)[order(-x)]) #rstats https:\/\/t.co\/V9uEJs03Uh",
  "id" : 888065989652475904,
  "created_at" : "2017-07-20 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/gLSNIutmT3",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2017\/05\/azuredsvm-a-new-r-package-for-elastic-use-of-the-azure-data-science-virtual-machine.html",
      "display_url" : "blog.revolutionanalytics.com\/2017\/05\/azured\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887703592068460545",
  "text" : "Use the AzureDSVM package to spin up and use Data Science VM clusters from R https:\/\/t.co\/gLSNIutmT3 #rstats",
  "id" : 887703592068460545,
  "created_at" : "2017-07-19 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R-Ladies Global",
      "screen_name" : "RLadiesGlobal",
      "indices" : [ 77, 91 ],
      "id_str" : "770490229769789440",
      "id" : 770490229769789440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/idRPhr3tmG",
      "expanded_url" : "http:\/\/rladies.org\/",
      "display_url" : "rladies.org"
    } ]
  },
  "geo" : { },
  "id_str" : "887341193931104256",
  "text" : "Find R-ladies meetups in your area. Visit https:\/\/t.co\/idRPhr3tmG and follow @RLadiesGlobal #rstats",
  "id" : 887341193931104256,
  "created_at" : "2017-07-18 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/AbFeyZezdH",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/file.path",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "886978819550085120",
  "text" : "file.path is a fast, platform-independent function to create paths to filenames https:\/\/t.co\/AbFeyZezdH #rstats",
  "id" : 886978819550085120,
  "created_at" : "2017-07-17 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1dFFS22YfC",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/match",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "885891650198753280",
  "text" : "X %in% Y tests whether elements of X can be found in Y -- same as !is.na(match(X,Y)) #rstats https:\/\/t.co\/1dFFS22YfC",
  "id" : 885891650198753280,
  "created_at" : "2017-07-14 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/whxBfVsk4E",
      "expanded_url" : "https:\/\/github.com\/search",
      "display_url" : "github.com\/search"
    } ]
  },
  "geo" : { },
  "id_str" : "885529270272966656",
  "text" : "Add \"user:cran\" to a search query on Github to search the code of all R packages on CRAN https:\/\/t.co\/whxBfVsk4E #rstats",
  "id" : 885529270272966656,
  "created_at" : "2017-07-13 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/UJ8NIR4LSf",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/azure\/machine-learning\/machine-learning-data-science-linux-dsvm-intro",
      "display_url" : "docs.microsoft.com\/en-us\/azure\/ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "885166870248206337",
  "text" : "The Data Science VM for Linux is an Azure instance with Microsoft R, Rstudio, Rattle, CNTK, and more: https:\/\/t.co\/UJ8NIR4LSf #rstats",
  "id" : 885166870248206337,
  "created_at" : "2017-07-12 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/3EeD4monPN",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-exts.html#The-DESCRIPTION-file",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "884804485838651397",
  "text" : "Package developers: add\nByteCompile:yes\nto the DESCRIPTION file to have your package compiled on install https:\/\/t.co\/3EeD4monPN #rstats",
  "id" : 884804485838651397,
  "created_at" : "2017-07-11 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/tVdWyPF7sv",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.0\/topics\/hclust",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "884442106382700545",
  "text" : "Use hclust() for hierarchical clustering https:\/\/t.co\/tVdWyPF7sv #rstats",
  "id" : 884442106382700545,
  "created_at" : "2017-07-10 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/xlJoIavODF",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/07\/understanding-na-in-r.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/07\/unders\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883354938155204608",
  "text" : "NA's have special handling for logical comparisons. NA &amp; FALSE is always FALSE, NA | TRUE is TRUE https:\/\/t.co\/xlJoIavODF #rstats",
  "id" : 883354938155204608,
  "created_at" : "2017-07-07 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/qStxmGg9qd",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-lang.html#Indexing-matrices-and-arrays",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "882992554119110656",
  "text" : "You can use a two-column matrix of integers to select disjoint values in a matrix by row\/column https:\/\/t.co\/qStxmGg9qd #rstats",
  "id" : 882992554119110656,
  "created_at" : "2017-07-06 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/at0k4MYvbj",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/checkpoint\/versions\/0.4.0\/topics\/checkpoint",
      "display_url" : "rdocumentation.org\/packages\/check\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "882630157177151492",
  "text" : "The checkpoint function automatically finds and installs all packages required by the current project https:\/\/t.co\/at0k4MYvbj #rstats",
  "id" : 882630157177151492,
  "created_at" : "2017-07-05 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/3wre1JQEme",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/maps\/",
      "display_url" : "mran.microsoft.com\/package\/maps\/"
    } ]
  },
  "geo" : { },
  "id_str" : "882267776777424898",
  "text" : "Create a map of the continental USA: \nlibrary(maps); map(\"\"state\"\") \nhttps:\/\/t.co\/3wre1JQEme #rstats",
  "id" : 882267776777424898,
  "created_at" : "2017-07-04 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/N7RsPcM6mH",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.0\/topics\/recover",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881905374357594113",
  "text" : "Add options(error=utils::recover) to .Rprofile to make it easier to debug errors thrown by R functions: https:\/\/t.co\/N7RsPcM6mH #rstats",
  "id" : 881905374357594113,
  "created_at" : "2017-07-03 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]