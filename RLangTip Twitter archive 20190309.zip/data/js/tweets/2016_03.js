Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/dfKUJ42in7",
      "expanded_url" : "http:\/\/bit.ly\/PIZFgJ",
      "display_url" : "bit.ly\/PIZFgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "715570792927531008",
  "text" : "Function to find the peaks in a time series: https:\/\/t.co\/dfKUJ42in7 #rstats (via @therealprotonk)",
  "id" : 715570792927531008,
  "created_at" : "2016-03-31 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/jdFkT7gp9L",
      "expanded_url" : "http:\/\/bit.ly\/1pCpSD3",
      "display_url" : "bit.ly\/1pCpSD3"
    } ]
  },
  "geo" : { },
  "id_str" : "715208413836361729",
  "text" : "deviance(fit) \u007Bstats\u007D returns the deviance of a fitted model object. https:\/\/t.co\/jdFkT7gp9L #rstats",
  "id" : 715208413836361729,
  "created_at" : "2016-03-30 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/NbahHYVt1d",
      "expanded_url" : "http:\/\/bit.ly\/21LqRg8",
      "display_url" : "bit.ly\/21LqRg8"
    } ]
  },
  "geo" : { },
  "id_str" : "714846009411690496",
  "text" : "sum(!complete.cases(dF)) counts the number of rows in a data frame that have missing values https:\/\/t.co\/NbahHYVt1d #rstats",
  "id" : 714846009411690496,
  "created_at" : "2016-03-29 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/XcE5Sh99rA",
      "expanded_url" : "http:\/\/bit.ly\/H9C2Xp",
      "display_url" : "bit.ly\/H9C2Xp"
    } ]
  },
  "geo" : { },
  "id_str" : "714483594731921408",
  "text" : "Start planning for Easter next year: library(timeDate); Easter(2017) #rstats https:\/\/t.co\/XcE5Sh99rA",
  "id" : 714483594731921408,
  "created_at" : "2016-03-28 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/r0yACngQRp",
      "expanded_url" : "http:\/\/bit.ly\/sXKxj8",
      "display_url" : "bit.ly\/sXKxj8"
    } ]
  },
  "geo" : { },
  "id_str" : "713396446347862016",
  "text" : "Format numbers \"v\" as currency, like $2,101,944: gsub(\"^ *\",\"$\",prettyNum(v, big.mark=\",\")) #rstats https:\/\/t.co\/r0yACngQRp",
  "id" : 713396446347862016,
  "created_at" : "2016-03-25 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/AGW3Eqg51g",
      "expanded_url" : "http:\/\/bit.ly\/H7Ako0",
      "display_url" : "bit.ly\/H7Ako0"
    } ]
  },
  "geo" : { },
  "id_str" : "713034063687376896",
  "text" : "Use methods(class='lm') to list all the special operations available on \"lm\" regression objects: https:\/\/t.co\/AGW3Eqg51g #rstats",
  "id" : 713034063687376896,
  "created_at" : "2016-03-24 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TDlKOW7QV5",
      "expanded_url" : "http:\/\/bit.ly\/J7Yvvs",
      "display_url" : "bit.ly\/J7Yvvs"
    } ]
  },
  "geo" : { },
  "id_str" : "712671695228768257",
  "text" : "Efficiency tip: When selecting from a data frame, df$a[1] is much faster than df[1,\"a\"] #rstats https:\/\/t.co\/TDlKOW7QV5",
  "id" : 712671695228768257,
  "created_at" : "2016-03-23 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/qRYoz1Atnc",
      "expanded_url" : "http:\/\/bit.ly\/1MfFPcG",
      "display_url" : "bit.ly\/1MfFPcG"
    } ]
  },
  "geo" : { },
  "id_str" : "712309297556885504",
  "text" : "as.hexmode(N) \u007Bbase\u007D will convert integers into hexadecimal format.#rstats https:\/\/t.co\/qRYoz1Atnc",
  "id" : 712309297556885504,
  "created_at" : "2016-03-22 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/WC2ANkP9t8",
      "expanded_url" : "http:\/\/bit.ly\/1S8Rxou",
      "display_url" : "bit.ly\/1S8Rxou"
    } ]
  },
  "geo" : { },
  "id_str" : "711946880549265408",
  "text" : "rpart() \u007Brpart\u007D is R's function for CART like classification and regression trees. #rstats https:\/\/t.co\/WC2ANkP9t8",
  "id" : 711946880549265408,
  "created_at" : "2016-03-21 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DZMuTBtXUP",
      "expanded_url" : "http:\/\/bit.ly\/1hJffYE",
      "display_url" : "bit.ly\/1hJffYE"
    } ]
  },
  "geo" : { },
  "id_str" : "710859748753727488",
  "text" : "Use apropos() to find a variable when you can only remember part of its name #rstats https:\/\/t.co\/DZMuTBtXUP",
  "id" : 710859748753727488,
  "created_at" : "2016-03-18 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/gkqxsIbtEu",
      "expanded_url" : "http:\/\/bit.ly\/17pf8vS",
      "display_url" : "bit.ly\/17pf8vS"
    } ]
  },
  "geo" : { },
  "id_str" : "710497364054818816",
  "text" : "Plot sample with error bars and color coded legend https:\/\/t.co\/gkqxsIbtEu #rstats",
  "id" : 710497364054818816,
  "created_at" : "2016-03-17 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/UYEUq86IHJ",
      "expanded_url" : "http:\/\/bit.ly\/O8Qg3A",
      "display_url" : "bit.ly\/O8Qg3A"
    } ]
  },
  "geo" : { },
  "id_str" : "710134966819147776",
  "text" : "Search the documentation for any function in base R or any CRAN package at https:\/\/t.co\/UYEUq86IHJ #rstats",
  "id" : 710134966819147776,
  "created_at" : "2016-03-16 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstata",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/SiBkOnjxCM",
      "expanded_url" : "http:\/\/bit.ly\/1WfICD1",
      "display_url" : "bit.ly\/1WfICD1"
    } ]
  },
  "geo" : { },
  "id_str" : "709772568522301442",
  "text" : "cv.glm() \u007Bboot\u007D will calculate cross validation prediction error for glm models https:\/\/t.co\/SiBkOnjxCM #rstata",
  "id" : 709772568522301442,
  "created_at" : "2016-03-15 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IpTkwS8oOw",
      "expanded_url" : "http:\/\/bit.ly\/1pdh8Tt",
      "display_url" : "bit.ly\/1pdh8Tt"
    } ]
  },
  "geo" : { },
  "id_str" : "709410192815955968",
  "text" : "write.matrix(M) \u007BMASS\u007D will print out a matrix, M, without the row and column index labels https:\/\/t.co\/IpTkwS8oOw #rstats",
  "id" : 709410192815955968,
  "created_at" : "2016-03-14 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/xoDljK7bX8",
      "expanded_url" : "http:\/\/bit.ly\/1QY5313",
      "display_url" : "bit.ly\/1QY5313"
    } ]
  },
  "geo" : { },
  "id_str" : "708338141996916736",
  "text" : "read.table(\"clipboard\") can be a timesaver for quick copy-and-paste from spreadsheets into R #rstats https:\/\/t.co\/xoDljK7bX8",
  "id" : 708338141996916736,
  "created_at" : "2016-03-11 17:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/5KHiRZA3IN",
      "expanded_url" : "http:\/\/bit.ly\/zhOVTI",
      "display_url" : "bit.ly\/zhOVTI"
    } ]
  },
  "geo" : { },
  "id_str" : "707975780333199360",
  "text" : "List of R functions and packages for robust statistics: https:\/\/t.co\/5KHiRZA3IN #rstats",
  "id" : 707975780333199360,
  "created_at" : "2016-03-10 17:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/XON4zbK9FE",
      "expanded_url" : "http:\/\/bit.ly\/Nm81FJ",
      "display_url" : "bit.ly\/Nm81FJ"
    } ]
  },
  "geo" : { },
  "id_str" : "707613443474464768",
  "text" : "Use readOGR() (gets the projection) rather than readShapeSpatial() (that doesn't) to open .shp shapefiles #rstats https:\/\/t.co\/XON4zbK9FE",
  "id" : 707613443474464768,
  "created_at" : "2016-03-09 17:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/83awmWZbsg",
      "expanded_url" : "http:\/\/bit.ly\/21KCLfO",
      "display_url" : "bit.ly\/21KCLfO"
    } ]
  },
  "geo" : { },
  "id_str" : "707251046716989444",
  "text" : "Use rep(x,n_times) \u007Bbase\u007D to replicate elements of vectors and lists https:\/\/t.co\/83awmWZbsg #rstats",
  "id" : 707251046716989444,
  "created_at" : "2016-03-08 17:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/RTw5g06p7I",
      "expanded_url" : "http:\/\/bit.ly\/21NLOZZ",
      "display_url" : "bit.ly\/21NLOZZ"
    } ]
  },
  "geo" : { },
  "id_str" : "706888652966727680",
  "text" : "You may find debug(fun) \u007Bbase\u007D helpful in debugging an R function. https:\/\/t.co\/RTw5g06p7I #rstats",
  "id" : 706888652966727680,
  "created_at" : "2016-03-07 17:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/9zKGOS02qy",
      "expanded_url" : "http:\/\/bit.ly\/1KQTZAx",
      "display_url" : "bit.ly\/1KQTZAx"
    } ]
  },
  "geo" : { },
  "id_str" : "705801590259752960",
  "text" : "acf() \u007Bstats\u007D computes the autocovariance or autocorrelation of a vector or time series https:\/\/t.co\/9zKGOS02qy",
  "id" : 705801590259752960,
  "created_at" : "2016-03-04 17:06:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/VR7TFZxEQ8",
      "expanded_url" : "http:\/\/bit.ly\/vVAG8G",
      "display_url" : "bit.ly\/vVAG8G"
    } ]
  },
  "geo" : { },
  "id_str" : "705439125663576064",
  "text" : "Add options(error=utils::recover) to .Rprofile to make it easier to debug errors thrown by R functions: https:\/\/t.co\/VR7TFZxEQ8 #rstats",
  "id" : 705439125663576064,
  "created_at" : "2016-03-03 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/XMkrEHdv98",
      "expanded_url" : "http:\/\/bit.ly\/1QlTRpD",
      "display_url" : "bit.ly\/1QlTRpD"
    } ]
  },
  "geo" : { },
  "id_str" : "705076728994131968",
  "text" : "To include a quote character in a string, use \\\" , use \\\\ for a single backslash. #rstats https:\/\/t.co\/XMkrEHdv98",
  "id" : 705076728994131968,
  "created_at" : "2016-03-02 17:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/DZMuTBtXUP",
      "expanded_url" : "http:\/\/bit.ly\/1hJffYE",
      "display_url" : "bit.ly\/1hJffYE"
    } ]
  },
  "geo" : { },
  "id_str" : "704714362808885249",
  "text" : "Don't know the full name of a function? Perform a fuzzy search with the apropos function: apropos(\"summary\") #rstats https:\/\/t.co\/DZMuTBtXUP",
  "id" : 704714362808885249,
  "created_at" : "2016-03-01 17:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]