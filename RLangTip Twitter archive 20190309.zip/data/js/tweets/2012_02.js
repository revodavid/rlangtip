Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD Long",
      "screen_name" : "CMastication",
      "indices" : [ 3, 16 ],
      "id_str" : "43186378",
      "id" : 43186378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174900508014804992",
  "text" : "RT @cmastication: to read text from the clipboard into an #rstats data.frame on Mac OS X try read.table(pipe(\"pbpaste\"))",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174886967656464385",
    "text" : "to read text from the clipboard into an #rstats data.frame on Mac OS X try read.table(pipe(\"pbpaste\"))",
    "id" : 174886967656464385,
    "created_at" : "2012-02-29 16:01:16 +0000",
    "user" : {
      "name" : "JD Long",
      "screen_name" : "CMastication",
      "protected" : false,
      "id_str" : "43186378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/957631888557998080\/8ofyRfqP_normal.jpg",
      "id" : 43186378,
      "verified" : false
    }
  },
  "id" : 174900508014804992,
  "created_at" : "2012-02-29 16:55:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/3ZzoCzIk",
      "expanded_url" : "http:\/\/bit.ly\/zrvgHJ",
      "display_url" : "bit.ly\/zrvgHJ"
    } ]
  },
  "geo" : { },
  "id_str" : "174887060908425216",
  "text" : "Use the xtable package to convert a table or matrix to HTML: print(xtable(X), type=\"html\") #rstats http:\/\/t.co\/3ZzoCzIk",
  "id" : 174887060908425216,
  "created_at" : "2012-02-29 16:01:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerzy Wieczorek",
      "screen_name" : "civilstat",
      "indices" : [ 3, 13 ],
      "id_str" : "213030756",
      "id" : 213030756
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174524646782275585",
  "text" : "RT @civilstat read.table(\"clipboard\") can be a timesaver for quick copy-and-paste from spreadsheets into R #rstats",
  "id" : 174524646782275585,
  "created_at" : "2012-02-28 16:01:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/HMit1Stf",
      "expanded_url" : "http:\/\/bit.ly\/zhOVTI",
      "display_url" : "bit.ly\/zhOVTI"
    } ]
  },
  "geo" : { },
  "id_str" : "174162357541539840",
  "text" : "List of R functions and packages for robust statistics: http:\/\/t.co\/HMit1Stf #rstats",
  "id" : 174162357541539840,
  "created_at" : "2012-02-27 16:01:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/nDUTAfjs",
      "expanded_url" : "http:\/\/bit.ly\/yoyRNm",
      "display_url" : "bit.ly\/yoyRNm"
    } ]
  },
  "geo" : { },
  "id_str" : "173075180225183744",
  "text" : "How many people do you need to gather to assure a 95% probability of a shared birthday: qbirthday(0.95) #rstats http:\/\/t.co\/nDUTAfjs",
  "id" : 173075180225183744,
  "created_at" : "2012-02-24 16:01:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Eddelbuettel",
      "screen_name" : "eddelbuettel",
      "indices" : [ 3, 16 ],
      "id_str" : "2385131",
      "id" : 2385131
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 90, 99 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172735548748869633",
  "text" : "RT @eddelbuettel: Or use one of the CRAN packages getopt and optparse written for this MT @RLangTip Send parameters to #rstats script",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/choqok.gnufolks.org\/\" rel=\"nofollow\"\u003EKubuntu Choqok\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 72, 81 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "172712791394889730",
    "geo" : { },
    "id_str" : "172719523680620544",
    "in_reply_to_user_id" : 295344317,
    "text" : "Or use one of the CRAN packages getopt and optparse written for this MT @RLangTip Send parameters to #rstats script",
    "id" : 172719523680620544,
    "in_reply_to_status_id" : 172712791394889730,
    "created_at" : "2012-02-23 16:28:38 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Dirk Eddelbuettel",
      "screen_name" : "eddelbuettel",
      "protected" : false,
      "id_str" : "2385131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509888693478248448\/rvqUa5YA_normal.jpeg",
      "id" : 2385131,
      "verified" : false
    }
  },
  "id" : 172735548748869633,
  "created_at" : "2012-02-23 17:32:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/y86QPMfm",
      "expanded_url" : "http:\/\/bit.ly\/xIsZyt",
      "display_url" : "bit.ly\/xIsZyt"
    } ]
  },
  "geo" : { },
  "id_str" : "172712791394889730",
  "text" : "Send parameters to #rstats script: \"R script.R --args myplot.png\"; use commandArgs(trailingOnly=TRUE) in script.R # http:\/\/t.co\/y86QPMfm",
  "id" : 172712791394889730,
  "created_at" : "2012-02-23 16:01:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/mO9Z4Byd",
      "expanded_url" : "http:\/\/bit.ly\/AfpXZF",
      "display_url" : "bit.ly\/AfpXZF"
    } ]
  },
  "geo" : { },
  "id_str" : "172350280590049280",
  "text" : "How to credit R in a manuscript or article: citation(). Works for packages, too: citation(\"MASS\") #rstats http:\/\/t.co\/mO9Z4Byd",
  "id" : 172350280590049280,
  "created_at" : "2012-02-22 16:01:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/oUptNb8V",
      "expanded_url" : "http:\/\/bit.ly\/yEaOO2",
      "display_url" : "bit.ly\/yEaOO2"
    } ]
  },
  "geo" : { },
  "id_str" : "171987964279271424",
  "text" : "A collection of free tutorials provided by R users: http:\/\/t.co\/oUptNb8V #rstats",
  "id" : 171987964279271424,
  "created_at" : "2012-02-21 16:01:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/9NzHAaHw",
      "expanded_url" : "http:\/\/bit.ly\/wEsIlS",
      "display_url" : "bit.ly\/wEsIlS"
    } ]
  },
  "geo" : { },
  "id_str" : "171625593803255808",
  "text" : "List of R packages for comparative phylogenetics (evolutionary relatedness in ancestral family trees): http:\/\/t.co\/9NzHAaHw #rstats",
  "id" : 171625593803255808,
  "created_at" : "2012-02-20 16:01:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/u38srKVu",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "170538430969815041",
  "text" : "Create a deck of cards in #rstats: expand.grid(rank=c(\"A\",2:10,\"J\",\"Q\",\"K\"),suit=c(\"S\",\"H\",\"D\",\"C\")) # http:\/\/t.co\/u38srKVu",
  "id" : 170538430969815041,
  "created_at" : "2012-02-17 16:01:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/AIrMU04K",
      "expanded_url" : "http:\/\/bit.ly\/ywEk5w",
      "display_url" : "bit.ly\/ywEk5w"
    } ]
  },
  "geo" : { },
  "id_str" : "170175963915763713",
  "text" : "Qualification and validation of R for 21CFR11 compliance and use in FDA clinical trials: http:\/\/t.co\/AIrMU04K #rstats",
  "id" : 170175963915763713,
  "created_at" : "2012-02-16 16:01:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 3, 17 ],
      "id_str" : "69133574",
      "id" : 69133574
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 19, 28 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169849015989567488",
  "text" : "RT @hadleywickham: @RLangTip sample(x) randomly shuffles the elements of a vector x unless x is a length 1 numeric vector #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169847972333486080",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip sample(x) randomly shuffles the elements of a vector x unless x is a length 1 numeric vector #rstats",
    "id" : 169847972333486080,
    "created_at" : "2012-02-15 18:18:06 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "protected" : false,
      "id_str" : "69133574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905186381995147264\/7zKAG5sY_normal.jpg",
      "id" : 69133574,
      "verified" : true
    }
  },
  "id" : 169849015989567488,
  "created_at" : "2012-02-15 18:22:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/lmyJNaYC",
      "expanded_url" : "http:\/\/bit.ly\/x9UdLI",
      "display_url" : "bit.ly\/x9UdLI"
    } ]
  },
  "geo" : { },
  "id_str" : "169833214762950656",
  "text" : "sample(x) randomly shuffles the elements of a vector or list x #rstats http:\/\/t.co\/lmyJNaYC",
  "id" : 169833214762950656,
  "created_at" : "2012-02-15 17:19:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/GitlhSKx",
      "expanded_url" : "http:\/\/bit.ly\/zNSp7Z",
      "display_url" : "bit.ly\/zNSp7Z"
    } ]
  },
  "geo" : { },
  "id_str" : "169451238633652224",
  "text" : "Three free books on R for Statistics: http:\/\/t.co\/GitlhSKx #rstats",
  "id" : 169451238633652224,
  "created_at" : "2012-02-14 16:01:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/BXlNdfjS",
      "expanded_url" : "http:\/\/bit.ly\/xYZJ3s",
      "display_url" : "bit.ly\/xYZJ3s"
    } ]
  },
  "geo" : { },
  "id_str" : "169088848813490178",
  "text" : "List of R packages related to networks, graphs, Bayesian models, and flow diagrams: http:\/\/t.co\/BXlNdfjS #rstats",
  "id" : 169088848813490178,
  "created_at" : "2012-02-13 16:01:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168025852016201728",
  "text" : "In R for MacOS X, Command-Enter sends the selected commands from the script window to the command line #rstats",
  "id" : 168025852016201728,
  "created_at" : "2012-02-10 17:37:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167666481826496513",
  "text" : "The $ operator uses partial matching. mylist$el will return the contents of mylist$element if there's no exact match #rstats",
  "id" : 167666481826496513,
  "created_at" : "2012-02-09 17:49:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/FgXzzY48",
      "expanded_url" : "http:\/\/bit.ly\/waAR5v",
      "display_url" : "bit.ly\/waAR5v"
    } ]
  },
  "geo" : { },
  "id_str" : "167295127713366016",
  "text" : "How to install R on an Android device: http:\/\/t.co\/FgXzzY48 #rstats",
  "id" : 167295127713366016,
  "created_at" : "2012-02-08 17:14:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/d2OhEIA3",
      "expanded_url" : "http:\/\/bit.ly\/zBaVM4",
      "display_url" : "bit.ly\/zBaVM4"
    } ]
  },
  "geo" : { },
  "id_str" : "166935563079917570",
  "text" : "Use the RMySQL package to read data from MySQL into R using SQL queries: http:\/\/t.co\/d2OhEIA3 #rstats",
  "id" : 166935563079917570,
  "created_at" : "2012-02-07 17:25:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/UKcR10SQ",
      "expanded_url" : "http:\/\/bit.ly\/y3ecGN",
      "display_url" : "bit.ly\/y3ecGN"
    } ]
  },
  "geo" : { },
  "id_str" : "166576564291641344",
  "text" : "List of 100+ probability distributions (densities, quantiles, simulation) supported in R: http:\/\/t.co\/UKcR10SQ #rstats",
  "id" : 166576564291641344,
  "created_at" : "2012-02-06 17:38:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165494185061924864",
  "text" : "Get an overview of documentation for an installed package: help(package=\"&lt;package-name&gt;\") #rstats",
  "id" : 165494185061924864,
  "created_at" : "2012-02-03 17:57:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165179608155697153",
  "text" : "Common style for comments is # on a line of #rstats code, ## within functions, and ### at the top level of scripts. ESS indents accordingly",
  "id" : 165179608155697153,
  "created_at" : "2012-02-02 21:07:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/EY1uMfny",
      "expanded_url" : "http:\/\/bit.ly\/wIGrFC",
      "display_url" : "bit.ly\/wIGrFC"
    } ]
  },
  "geo" : { },
  "id_str" : "164770502416678912",
  "text" : "A single index can be used to select from a matrix. For example, X[row(X)==col(X)] is the same as diag(X) #rstats http:\/\/t.co\/EY1uMfny",
  "id" : 164770502416678912,
  "created_at" : "2012-02-01 18:02:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]