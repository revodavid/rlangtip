Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/SuvjUnBvOT",
      "expanded_url" : "http:\/\/bit.ly\/1iW0MrP",
      "display_url" : "bit.ly\/1iW0MrP"
    } ]
  },
  "geo" : { },
  "id_str" : "461536869860540416",
  "text" : "signif(x,digits=n) rounds x to n significant digits http:\/\/t.co\/SuvjUnBvOT #rstats",
  "id" : 461536869860540416,
  "created_at" : "2014-04-30 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/rnaWi1gwME",
      "expanded_url" : "http:\/\/rfunction.com",
      "display_url" : "rfunction.com"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/81igovoC2M",
      "expanded_url" : "http:\/\/bit.ly\/1mI1RnG",
      "display_url" : "bit.ly\/1mI1RnG"
    } ]
  },
  "geo" : { },
  "id_str" : "461174518703468544",
  "text" : "Some examples of get() to call an R object using a character string: http:\/\/t.co\/rnaWi1gwME (http:\/\/t.co\/81igovoC2M) #rstats",
  "id" : 461174518703468544,
  "created_at" : "2014-04-29 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/NQr4P9gIos",
      "expanded_url" : "http:\/\/bit.ly\/1rtSpXd",
      "display_url" : "bit.ly\/1rtSpXd"
    } ]
  },
  "geo" : { },
  "id_str" : "460812148336492545",
  "text" : "Annotate ggplot2 graphs by creating an annotation layer with annotate() #rstats http:\/\/t.co\/NQr4P9gIos",
  "id" : 460812148336492545,
  "created_at" : "2014-04-28 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/fgXAkP38qR",
      "expanded_url" : "http:\/\/bit.ly\/I2UQ0v",
      "display_url" : "bit.ly\/I2UQ0v"
    } ]
  },
  "geo" : { },
  "id_str" : "459725582885212160",
  "text" : "Explore the capabilities of your installed R packages with browseVignettes() #rstats http:\/\/t.co\/fgXAkP38qR",
  "id" : 459725582885212160,
  "created_at" : "2014-04-25 16:08:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dJ0bNdR52s",
      "expanded_url" : "http:\/\/bit.ly\/Hft5M9",
      "display_url" : "bit.ly\/Hft5M9"
    } ]
  },
  "geo" : { },
  "id_str" : "459362578742145024",
  "text" : "Avoid namespace clashes! Use :: to specify an object within a specific package, e.g. MASS::mvnorm #rstats http:\/\/t.co\/dJ0bNdR52s",
  "id" : 459362578742145024,
  "created_at" : "2014-04-24 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dg4FEN3zaA",
      "expanded_url" : "http:\/\/bit.ly\/ILpoTs",
      "display_url" : "bit.ly\/ILpoTs"
    } ]
  },
  "geo" : { },
  "id_str" : "459000218206605313",
  "text" : "Merge two data frames with merge(df1, df2) for an inner join and merge(df1,df2,all=TRUE) for an outer join. #rstats http:\/\/t.co\/dg4FEN3zaA",
  "id" : 459000218206605313,
  "created_at" : "2014-04-23 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/YOBOysONrN",
      "expanded_url" : "http:\/\/bit.ly\/1hUTWmv",
      "display_url" : "bit.ly\/1hUTWmv"
    } ]
  },
  "geo" : { },
  "id_str" : "458637759297896448",
  "text" : "Determine the class of every variable in a data frame: sapply(df,class) http:\/\/t.co\/YOBOysONrN #rstats",
  "id" : 458637759297896448,
  "created_at" : "2014-04-22 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YmlyQqcet2",
      "expanded_url" : "http:\/\/bit.ly\/PdIWVF",
      "display_url" : "bit.ly\/PdIWVF"
    } ]
  },
  "geo" : { },
  "id_str" : "458275391183290368",
  "text" : "The WDI package provides access to the World Bank's World Development Indicators http:\/\/t.co\/YmlyQqcet2 #rstats",
  "id" : 458275391183290368,
  "created_at" : "2014-04-21 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/nPM7h4JLNo",
      "expanded_url" : "http:\/\/bit.ly\/IfI9Zw",
      "display_url" : "bit.ly\/IfI9Zw"
    } ]
  },
  "geo" : { },
  "id_str" : "457188349842063361",
  "text" : "How to unshorten a bit.ly, t.co or other short URL with R: http:\/\/t.co\/nPM7h4JLNo #rstats",
  "id" : 457188349842063361,
  "created_at" : "2014-04-18 16:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/FJYNPCRu5R",
      "expanded_url" : "http:\/\/bit.ly\/IyE1Wa",
      "display_url" : "bit.ly\/IyE1Wa"
    } ]
  },
  "geo" : { },
  "id_str" : "456825884662435842",
  "text" : "Use the plyr package to easily sort a data frame by a column: arrange(df, desc(colname)) #rstats http:\/\/t.co\/FJYNPCRu5R",
  "id" : 456825884662435842,
  "created_at" : "2014-04-17 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/f0ylP6eB3h",
      "expanded_url" : "http:\/\/bit.ly\/1hHnLSE",
      "display_url" : "bit.ly\/1hHnLSE"
    } ]
  },
  "geo" : { },
  "id_str" : "456463571824553984",
  "text" : "For base graphics, par(mfrow=c(m,n)) will divide a graphics window into a grid of m x n plots http:\/\/t.co\/f0ylP6eB3h #rstats",
  "id" : 456463571824553984,
  "created_at" : "2014-04-16 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/bJ9UclQL5Y",
      "expanded_url" : "http:\/\/bit.ly\/RaEOHM",
      "display_url" : "bit.ly\/RaEOHM"
    } ]
  },
  "geo" : { },
  "id_str" : "456101045933199362",
  "text" : "cor.test(x,y) will tell you if the correlation between vectors x and y is statistically significant http:\/\/t.co\/bJ9UclQL5Y #rstats",
  "id" : 456101045933199362,
  "created_at" : "2014-04-15 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/U81h4VGoEH",
      "expanded_url" : "http:\/\/bit.ly\/1iCurm5",
      "display_url" : "bit.ly\/1iCurm5"
    } ]
  },
  "geo" : { },
  "id_str" : "455738689524875264",
  "text" : "Use findFn() from the sos package to get help on R topics, e.g. findFn(\"glm\") http:\/\/t.co\/U81h4VGoEH #rstats",
  "id" : 455738689524875264,
  "created_at" : "2014-04-14 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/3TyR8aQBHk",
      "expanded_url" : "http:\/\/bit.ly\/H9AbSs",
      "display_url" : "bit.ly\/H9AbSs"
    } ]
  },
  "geo" : { },
  "id_str" : "454651577744510976",
  "text" : "Use mapply to call a multi-argument function repeatedly, e.g. mapply(sample, list(1:56, 1:46), c(5,1)) #rstats http:\/\/t.co\/3TyR8aQBHk",
  "id" : 454651577744510976,
  "created_at" : "2014-04-11 16:05:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/4ihvA2ZM6J",
      "expanded_url" : "http:\/\/bit.ly\/QMrRnl",
      "display_url" : "bit.ly\/QMrRnl"
    } ]
  },
  "geo" : { },
  "id_str" : "454289177178542080",
  "text" : "Define your own binary operators http:\/\/t.co\/4ihvA2ZM6J #rstats",
  "id" : 454289177178542080,
  "created_at" : "2014-04-10 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/GNRoT4iWMq",
      "expanded_url" : "http:\/\/bit.ly\/1q1Pkej",
      "display_url" : "bit.ly\/1q1Pkej"
    } ]
  },
  "geo" : { },
  "id_str" : "453926862407073793",
  "text" : "X %in% Y ia the same as !is.na(match(X,Y)) #rstats http:\/\/t.co\/GNRoT4iWMq",
  "id" : 453926862407073793,
  "created_at" : "2014-04-09 16:06:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/N1mrlUhZoG",
      "expanded_url" : "http:\/\/bit.ly\/1hEJC1f",
      "display_url" : "bit.ly\/1hEJC1f"
    } ]
  },
  "geo" : { },
  "id_str" : "453564388445003777",
  "text" : "A collection of resources for working with GLMs in R #rstats http:\/\/t.co\/N1mrlUhZoG",
  "id" : 453564388445003777,
  "created_at" : "2014-04-08 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/dMWn1ylnvc",
      "expanded_url" : "http:\/\/bit.ly\/1dYTDqR",
      "display_url" : "bit.ly\/1dYTDqR"
    } ]
  },
  "geo" : { },
  "id_str" : "453201981419823104",
  "text" : "Use package XLConnect to read and write Excel files #rstats http:\/\/t.co\/dMWn1ylnvc",
  "id" : 453201981419823104,
  "created_at" : "2014-04-07 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Allen",
      "screen_name" : "TrestleJeff",
      "indices" : [ 111, 123 ],
      "id_str" : "707254393",
      "id" : 707254393
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9xdd1kX3sS",
      "expanded_url" : "http:\/\/bit.ly\/100gwhr",
      "display_url" : "bit.ly\/100gwhr"
    } ]
  },
  "geo" : { },
  "id_str" : "452114832540848128",
  "text" : "Deleting a function from a package will surprise your users. Deprecate it instead: http:\/\/t.co\/9xdd1kX3sS (via @TrestleJeff) #rstats",
  "id" : 452114832540848128,
  "created_at" : "2014-04-04 16:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Patterson",
      "screen_name" : "M_T_Patterson",
      "indices" : [ 89, 103 ],
      "id_str" : "101678082",
      "id" : 101678082
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/tvZCsRqF5q",
      "expanded_url" : "http:\/\/bit.ly\/Y21xrG",
      "display_url" : "bit.ly\/Y21xrG"
    } ]
  },
  "geo" : { },
  "id_str" : "451752485817188353",
  "text" : "Locate the largest number in a vector with which.max(mydata) http:\/\/t.co\/tvZCsRqF5q (via @M_T_Patterson) #rstats",
  "id" : 451752485817188353,
  "created_at" : "2014-04-03 16:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/3FSzySHDcY",
      "expanded_url" : "http:\/\/bit.ly\/1jgN4zN",
      "display_url" : "bit.ly\/1jgN4zN"
    } ]
  },
  "geo" : { },
  "id_str" : "451390141937229825",
  "text" : "One line, Two Way Factorial Design ANOVA: fit &lt;- aov(y ~ A + B + A:B, data=mydataframe) #rstats http:\/\/t.co\/3FSzySHDcY",
  "id" : 451390141937229825,
  "created_at" : "2014-04-02 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ZZdTtSirfG",
      "expanded_url" : "http:\/\/bit.ly\/1gKVAYv",
      "display_url" : "bit.ly\/1gKVAYv"
    } ]
  },
  "geo" : { },
  "id_str" : "451027694294409216",
  "text" : "April 1, 1997: R Help mailing list goes live. Many thanks to all who have contributed! #rstats http:\/\/t.co\/ZZdTtSirfG",
  "id" : 451027694294409216,
  "created_at" : "2014-04-01 16:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]