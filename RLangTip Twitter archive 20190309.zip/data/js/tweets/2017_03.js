Grailbird.data.tweets_2017_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/LuT8iJrm8k",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/4442518\/general-suggestions-for-debugging-in-r#5156351",
      "display_url" : "stackoverflow.com\/questions\/4442\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847840927884259328",
  "text" : "List of R debugging tips: https:\/\/t.co\/LuT8iJrm8k #rstats",
  "id" : 847840927884259328,
  "created_at" : "2017-03-31 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/jCb2sisfcv",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.2\/topics\/uniroot",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847478540933054464",
  "text" : "uniroot(fun,c(a,b)) will find where fun(x) equals zero in the interval [a,b] https:\/\/t.co\/jCb2sisfcv #rstats",
  "id" : 847478540933054464,
  "created_at" : "2017-03-30 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/MySOuyjXsP",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Extract",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "847116139822039041",
  "text" : "Negative indexes remove elements from a vector. x[-1] is x without the first element https:\/\/t.co\/MySOuyjXsP #rstats",
  "id" : 847116139822039041,
  "created_at" : "2017-03-29 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/FLVDGXUR2L",
      "expanded_url" : "http:\/\/www.brodrigues.co\/blog\/2017-02-17-lesser_known_tricks\/",
      "display_url" : "brodrigues.co\/blog\/2017-02-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846753766288195585",
  "text" : "Some handy tricks for handling columns in data frames with dplyr: https:\/\/t.co\/FLVDGXUR2L #rstats",
  "id" : 846753766288195585,
  "created_at" : "2017-03-28 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/EWZ3puKTeE",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Syntax",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "846391365923717120",
  "text" : "Type ?Syntax to learn the precedence of operators in the R language: https:\/\/t.co\/EWZ3puKTeE #rstats",
  "id" : 846391365923717120,
  "created_at" : "2017-03-27 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/werFfshcaa",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.2\/topics\/acf",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "845304220140130304",
  "text" : "acf() computes the autocovariance or autocorrelation of a vector or time series https:\/\/t.co\/werFfshcaa #rstats",
  "id" : 845304220140130304,
  "created_at" : "2017-03-24 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/H6GE9rtGrQ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/hexmode",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844941819561623552",
  "text" : "as.hexmode(N) will convert integers into hexadecimal format https:\/\/t.co\/H6GE9rtGrQ #rstats",
  "id" : 844941819561623552,
  "created_at" : "2017-03-23 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/EOwZGeHk1w",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Vectorize",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844579440789118976",
  "text" : "Convert a scalar function to one thar operates on vectors with Vectorize https:\/\/t.co\/EOwZGeHk1w #rstats",
  "id" : 844579440789118976,
  "created_at" : "2017-03-22 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/wDKV1gsSDy",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/10\/sharing-r-code-with-style.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/10\/sharin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844217048313950208",
  "text" : "Style guide for R programming by Graham Williams https:\/\/t.co\/wDKV1gsSDy #rstats",
  "id" : 844217048313950208,
  "created_at" : "2017-03-21 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/x0RyopbO7k",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.2\/topics\/object.size",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843854662012887040",
  "text" : "Use object.size() to estimate the amount of memory an R object is consuming #rstats https:\/\/t.co\/x0RyopbO7k",
  "id" : 843854662012887040,
  "created_at" : "2017-03-20 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/OVPMjagLTg",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/lmtest\/versions\/0.9-35\/topics\/lrtest",
      "display_url" : "rdocumentation.org\/packages\/lmtes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842767484960690177",
  "text" : "Perform a likelihood ratio test for nested GLM models with lrtest(m1,m2) https:\/\/t.co\/OVPMjagLTg #rstats",
  "id" : 842767484960690177,
  "created_at" : "2017-03-17 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/FLIh3Kc5Cd",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/12\/azuresmr.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/12\/azures\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842405107408887808",
  "text" : "The AzureSMR package provides R functions to control various Azure services, like VMs, blobs, and clusers https:\/\/t.co\/FLIh3Kc5Cd #rstats",
  "id" : 842405107408887808,
  "created_at" : "2017-03-16 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MKZ2OiPHnm",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/basename",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "842042726484987905",
  "text" : "basename(path) removes all of the file path up to and including the last (Windows or Unix) path separator #rstats https:\/\/t.co\/MKZ2OiPHnm",
  "id" : 842042726484987905,
  "created_at" : "2017-03-15 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/RsvrVm79AF",
      "expanded_url" : "http:\/\/davidbau.com\/archives\/2010\/03\/14\/the_mystery_of_355113.html",
      "display_url" : "davidbau.com\/archives\/2010\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "841680333879803904",
  "text" : "Trigonometric functions in R use radians. For example, cos(355) prints as -1 (and this is why: https:\/\/t.co\/RsvrVm79AF) #rstats",
  "id" : 841680333879803904,
  "created_at" : "2017-03-14 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/A3iVCqFF0M",
      "expanded_url" : "http:\/\/rattle.togaware.com\/",
      "display_url" : "rattle.togaware.com"
    } ]
  },
  "geo" : { },
  "id_str" : "841317950602776576",
  "text" : "Try the rattle package for a GUI based introduction to machine learning using R https:\/\/t.co\/A3iVCqFF0M #rstats",
  "id" : 841317950602776576,
  "created_at" : "2017-03-13 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 143, 150 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/yRroUrwQ6x",
      "expanded_url" : "http:\/\/www.burns-stat.com\/pages\/Tutor\/R_inferno.pdf",
      "display_url" : "burns-stat.com\/pages\/Tutor\/R_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "840245883849461762",
  "text" : "The operator &lt;&lt;- does global assignment. If you think you need &lt;&lt;-, think again. -- P Burns, The R Inferno https:\/\/t.co\/yRroUrwQ6x #rstats",
  "id" : 840245883849461762,
  "created_at" : "2017-03-10 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/UeG42pCEB3",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/timeDate\/versions\/3012.100\/topics\/holiday",
      "display_url" : "rdocumentation.org\/packages\/timeD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839883488899792896",
  "text" : "Find dates of many public holidays with the timeDate package: holiday(Holiday=\"JPNationalCultureDay\") https:\/\/t.co\/UeG42pCEB3 #rstats",
  "id" : 839883488899792896,
  "created_at" : "2017-03-09 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/WLSmF2WW5Y",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/svd",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "839521100128116737",
  "text" : "svd(X) will compute the singular value decomposition of a matrix https:\/\/t.co\/WLSmF2WW5Y #rstats",
  "id" : 839521100128116737,
  "created_at" : "2017-03-08 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenny carrillo",
      "screen_name" : "jennybc",
      "indices" : [ 78, 86 ],
      "id_str" : "132682227",
      "id" : 132682227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/bpW5VqFMv0",
      "expanded_url" : "http:\/\/happygitwithr.com\/",
      "display_url" : "happygitwithr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "839158720147959808",
  "text" : "Version control for R projects: Guide to using Git and Github with RStudio by @jennybc https:\/\/t.co\/bpW5VqFMv0 #rstats",
  "id" : 839158720147959808,
  "created_at" : "2017-03-07 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/q2dnnCKoBE",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/R.Version",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "838796329769803777",
  "text" : "R.version.string is character string describing the version of R you are running https:\/\/t.co\/q2dnnCKoBE #rstats",
  "id" : 838796329769803777,
  "created_at" : "2017-03-06 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/9LGPvMQKU7",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/rev",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837709172607049728",
  "text" : "Reverse the elements of  a vector x with rev(x) -- works on lists, too https:\/\/t.co\/9LGPvMQKU7 #rstats",
  "id" : 837709172607049728,
  "created_at" : "2017-03-03 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/xlZpoeeLCX",
      "expanded_url" : "http:\/\/socserv.mcmaster.ca\/jfox\/Books\/Companion\/appendix\/Appendix-Robust-Regression.pdf",
      "display_url" : "socserv.mcmaster.ca\/jfox\/Books\/Com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "837346775686074369",
  "text" : "Robust regression in R (PDF, Fox &amp; Weisberg): https:\/\/t.co\/xlZpoeeLCX #rstats",
  "id" : 837346775686074369,
  "created_at" : "2017-03-02 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/CpxXoKfngu",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/operationalize\/data-scientist-manage-services",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836984388382490625",
  "text" : "Publish R functions as web services with mrsdeploy in Microsoft R Server: https:\/\/t.co\/CpxXoKfngu #rstats",
  "id" : 836984388382490625,
  "created_at" : "2017-03-01 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]