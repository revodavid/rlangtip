Grailbird.data.tweets_2018_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomaz Kastrun",
      "screen_name" : "tomaz_tsql",
      "indices" : [ 63, 74 ],
      "id_str" : "379167308",
      "id" : 379167308
    }, {
      "name" : "Julie Koesmarno",
      "screen_name" : "MsSQLGirl",
      "indices" : [ 79, 89 ],
      "id_str" : "381779268",
      "id" : 381779268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/x8tkFkPAQm",
      "expanded_url" : "https:\/\/www.packtpub.com\/big-data-and-business-intelligence\/sql-server-2017-machine-learning-services-r",
      "display_url" : "packtpub.com\/big-data-and-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1012727401762222080",
  "text" : "SQL Server 2017 Machine Learning Services with R, an e-book by @tomaz_tsql and @MsSQLGirl by https:\/\/t.co\/x8tkFkPAQm #rstats",
  "id" : 1012727401762222080,
  "created_at" : "2018-06-29 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/3LrfnJzfGJ",
      "expanded_url" : "https:\/\/jumpingrivers.github.io\/meetingsR\/r-user-groups.html",
      "display_url" : "jumpingrivers.github.io\/meetingsR\/r-us\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1012365017163993088",
  "text" : "Meet other R users at a local R user group in your area: https:\/\/t.co\/3LrfnJzfGJ #rstats",
  "id" : 1012365017163993088,
  "created_at" : "2018-06-28 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/9sXtzmYiSw",
      "expanded_url" : "http:\/\/ess.r-project.org\/",
      "display_url" : "ess.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "1012002625682694145",
  "text" : "ESS (Emacs Speaks Statistics) is a popular add-on for working with R inside Emacs https:\/\/t.co\/9sXtzmYiSw #rstats",
  "id" : 1012002625682694145,
  "created_at" : "2018-06-27 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UC R Programming",
      "screen_name" : "UC_Rstats",
      "indices" : [ 84, 94 ],
      "id_str" : "755762312590585857",
      "id" : 755762312590585857
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 158, 165 ]
    } ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/MOEzz4Gc7Q",
      "expanded_url" : "http:\/\/uc-r.github.io\/",
      "display_url" : "uc-r.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "1011640228602187777",
  "text" : "Tutorials on various machine learning and statistical forecasting techniques in the @UC_Rstats Business Analytics R Programming Guide https:\/\/t.co\/MOEzz4Gc7Q #rstats",
  "id" : 1011640228602187777,
  "created_at" : "2018-06-26 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/R34i0WrkXU",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/rpart\/versions\/4.1-13\/topics\/residuals.rpart",
      "display_url" : "rdocumentation.org\/packages\/rpart\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1011277848236060672",
  "text" : "For rpart classification trees, residuals(fit,type=\"deviance\") returns the deviance residuals https:\/\/t.co\/R34i0WrkXU #rstats",
  "id" : 1011277848236060672,
  "created_at" : "2018-06-25 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Ec0XwAR7tv",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.0\/topics\/BATCH",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1010190680860307456",
  "text" : "Run an R script from the command line in batch mode with R CMD BATCH: https:\/\/t.co\/Ec0XwAR7tv #rstats",
  "id" : 1010190680860307456,
  "created_at" : "2018-06-22 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/40fB4bf5Im",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/formatC",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1009828289299574784",
  "text" : "Format numbers \"v\" as currency, like $2,101,944: \ngsub(\"^ *\",\"$\",prettyNum(v, big.mark=\",\")) \nhttps:\/\/t.co\/40fB4bf5Im #rstats",
  "id" : 1009828289299574784,
  "created_at" : "2018-06-21 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/g7WR97QEbH",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-lang.html#Operators",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1009465902272638976",
  "text" : "You can call any R operator as a function. For example\n  x + y\ncan be written as \n  `+`(x, y) \nhttps:\/\/t.co\/g7WR97QEbH",
  "id" : 1009465902272638976,
  "created_at" : "2018-06-20 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/71r3Z2nrpe",
      "expanded_url" : "http:\/\/www.win-vector.com\/blog\/2018\/06\/r-tip-use-istrue\/",
      "display_url" : "win-vector.com\/blog\/2018\/06\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1009103520597831680",
  "text" : "if(isTRUE(condition)) may be preferable to if(condition) https:\/\/t.co\/71r3Z2nrpe #rstats",
  "id" : 1009103520597831680,
  "created_at" : "2018-06-19 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/yUPTUTXoUH",
      "expanded_url" : "http:\/\/data.princeton.edu\/R\/default.html",
      "display_url" : "data.princeton.edu\/R\/default.html"
    } ]
  },
  "geo" : { },
  "id_str" : "1008741133193658369",
  "text" : "An online Introduction to R with some R history, linear models, glm and more #rstats https:\/\/t.co\/yUPTUTXoUH",
  "id" : 1008741133193658369,
  "created_at" : "2018-06-18 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/grJ29lTqYX",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.0\/topics\/birthday",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1007653970452463616",
  "text" : "The number of people you need to gather for a 95% probability of at least one shared birthday: qbirthday(0.95) https:\/\/t.co\/grJ29lTqYX #rstats",
  "id" : 1007653970452463616,
  "created_at" : "2018-06-15 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/WoOXEb9PZe",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/seq",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1007291585418158086",
  "text" : "seq(n1,n2,m) will generate a sequence of numbers from n1 to n2 counting by m https:\/\/t.co\/WoOXEb9PZe #stats",
  "id" : 1007291585418158086,
  "created_at" : "2018-06-14 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/K9Qy3kQb0R",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.0\/topics\/na.fail",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1006929194545057792",
  "text" : "na.omit(df) returns all rows of a data frame except those containing any missing values https:\/\/t.co\/K9Qy3kQb0R #rstats",
  "id" : 1006929194545057792,
  "created_at" : "2018-06-13 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincent Arel-Bundock",
      "screen_name" : "VincentAB",
      "indices" : [ 66, 76 ],
      "id_str" : "566754263",
      "id" : 566754263
    }, {
      "name" : "Mike Freeman",
      "screen_name" : "mf_viz",
      "indices" : [ 82, 89 ],
      "id_str" : "282130842",
      "id" : 282130842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/oR2ngOA5xl",
      "expanded_url" : "https:\/\/vincentarelbundock.github.io\/Rdatasets\/datasets.html",
      "display_url" : "vincentarelbundock.github.io\/Rdatasets\/data\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1006566799830278145",
  "text" : "A list of over 1,000 datasets available in R packages, curated by @VincentAB (via @mf_viz) https:\/\/t.co\/oR2ngOA5xl #rstats",
  "id" : 1006566799830278145,
  "created_at" : "2018-06-12 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/zw8nRR9659",
      "expanded_url" : "https:\/\/darrenjw.wordpress.com\/2011\/11\/23\/lexical-scope-and-function-closures-in-r\/",
      "display_url" : "darrenjw.wordpress.com\/2011\/11\/23\/lex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1006204420558688257",
  "text" : "Explanations of lexical scope, function closures and environments in R: https:\/\/t.co\/zw8nRR9659 #rstats",
  "id" : 1006204420558688257,
  "created_at" : "2018-06-11 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/oFKKMf6Itb",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/gmodels\/versions\/2.16.2\/topics\/CrossTable",
      "display_url" : "rdocumentation.org\/packages\/gmode\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1005117251882758150",
  "text" : "CrossTable() in \u007Bgmodels\u007D produces crosstabulations modeled after SAS's PROC FREQ https:\/\/t.co\/oFKKMf6Itb #rstats",
  "id" : 1005117251882758150,
  "created_at" : "2018-06-08 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/NYPiDbL05g",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.0\/topics\/summaryRprof",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1004754858287611906",
  "text" : "To speed up your R code, use Rprof() to turn on profiling, and summaryRprof() to find the slow parts: https:\/\/t.co\/NYPiDbL05g #rstats",
  "id" : 1004754858287611906,
  "created_at" : "2018-06-07 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RStudio",
      "screen_name" : "rstudio",
      "indices" : [ 4, 12 ],
      "id_str" : "235261861",
      "id" : 235261861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/nbGPxktxy5",
      "expanded_url" : "https:\/\/github.com\/rstudio\/cheatsheets\/raw\/master\/data-visualization-2.1.pdf",
      "display_url" : "github.com\/rstudio\/cheats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1004392481432064000",
  "text" : "The @Rstudio cheat sheet for data visualization with ggplot2 (PDF): https:\/\/t.co\/nbGPxktxy5 #rstats",
  "id" : 1004392481432064000,
  "created_at" : "2018-06-06 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1OBV1OAyFr",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/NumericConstants",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1004030085031256069",
  "text" : "When reading data from files, R will accept \"infinity\", \"inf\" and \"nan\" as a valid numeric values https:\/\/t.co\/1OBV1OAyFr #rstats",
  "id" : 1004030085031256069,
  "created_at" : "2018-06-05 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/YtBplSVL5B",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/diff",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1003667700852244482",
  "text" : "Calculate the differences between every nth value of a vector x with diff(x,n) https:\/\/t.co\/YtBplSVL5B #rstats",
  "id" : 1003667700852244482,
  "created_at" : "2018-06-04 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 138, 145 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/2DDxkUW1S7",
      "expanded_url" : "https:\/\/github.com\/Rdatatable\/data.table\/wiki\/Convenience-features-of-fread",
      "display_url" : "github.com\/Rdatatable\/dat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1002580532771713030",
  "text" : "Convenience features of the fread function in the data.table package for reading small and large data sets into R https:\/\/t.co\/2DDxkUW1S7 #rstats",
  "id" : 1002580532771713030,
  "created_at" : "2018-06-01 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]