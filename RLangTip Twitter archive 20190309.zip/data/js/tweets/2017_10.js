Grailbird.data.tweets_2017_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/5q8Xw1zNSy",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=s3JldKoA0zw",
      "display_url" : "youtube.com\/watch?v=s3JldK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925391923073892352",
  "text" : "A reproducibility horror story, with a happy ending: R #rstats https:\/\/t.co\/5q8Xw1zNSy",
  "id" : 925391923073892352,
  "created_at" : "2017-10-31 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/3xmZS4XMQg",
      "expanded_url" : "http:\/\/as.Date",
      "display_url" : "as.Date"
    }, {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ErFgWMBrgc",
      "expanded_url" : "http:\/\/Sys.Date",
      "display_url" : "Sys.Date"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/3MgB908vuY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/difftime",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925029534122041349",
  "text" : "Weeks to Christmas: difftime(https:\/\/t.co\/3xmZS4XMQg(\"2017-12-15\"),https:\/\/t.co\/ErFgWMBrgc(),units=\"weeks\") https:\/\/t.co\/3MgB908vuY #rstats",
  "id" : 925029534122041349,
  "created_at" : "2017-10-30 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/UsYoLfq27E",
      "expanded_url" : "https:\/\/mran.revolutionanalytics.com\/package\/pls\/",
      "display_url" : "mran.revolutionanalytics.com\/package\/pls\/"
    } ]
  },
  "geo" : { },
  "id_str" : "923942372936843264",
  "text" : "Consider partial least sqares (PLS) for regresssion problems with many predictors https:\/\/t.co\/UsYoLfq27E #rstats",
  "id" : 923942372936843264,
  "created_at" : "2017-10-27 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/5QVxUPkjm5",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-lang.html",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923579980289839105",
  "text" : "The official specification of the R language: https:\/\/t.co\/5QVxUPkjm5  #rstats",
  "id" : 923579980289839105,
  "created_at" : "2017-10-26 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/GnWzbS6Hz6",
      "expanded_url" : "http:\/\/mran.microsoft.com\/taskview\/",
      "display_url" : "mran.microsoft.com\/taskview\/"
    } ]
  },
  "geo" : { },
  "id_str" : "923217605212635136",
  "text" : "R packages by topic area: explore packages included in CRAN Task Views at https:\/\/t.co\/GnWzbS6Hz6 #rstats",
  "id" : 923217605212635136,
  "created_at" : "2017-10-25 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/3UYIJPBTPn",
      "expanded_url" : "http:\/\/dplyr.tidyverse.org\/articles\/programming.html",
      "display_url" : "dplyr.tidyverse.org\/articles\/progr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922855210002903041",
  "text" : "All about using pronouns, quasiquotation and quosures with dplyr: https:\/\/t.co\/3UYIJPBTPn #rstats",
  "id" : 922855210002903041,
  "created_at" : "2017-10-24 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/GojvD8LFMR",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/conditions",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922495332310593537",
  "text" : "Try: tryCatch(...) to allow R code to continue to run in the event of errors #rstats https:\/\/t.co\/GojvD8LFMR",
  "id" : 922495332310593537,
  "created_at" : "2017-10-23 16:10:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "921405669189791744",
  "text" : "Get an overview of documentation for an installed package: help(package=\"&lt;package-name&gt;\") #rstats",
  "id" : 921405669189791744,
  "created_at" : "2017-10-20 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/leXcc1kLF1",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/parallel\/versions\/3.4.1\/topics\/clusterApply",
      "display_url" : "rdocumentation.org\/packages\/paral\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "921073480531173377",
  "text" : "clusterApply() in \u007Bparallel\u007D is a parallel version of apply() that uses clusters https:\/\/t.co\/leXcc1kLF1 #rstats",
  "id" : 921073480531173377,
  "created_at" : "2017-10-19 18:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mICeRqP7dO",
      "expanded_url" : "https:\/\/github.com\/tidyverse\/glue",
      "display_url" : "github.com\/tidyverse\/glue"
    } ]
  },
  "geo" : { },
  "id_str" : "920318496415760389",
  "text" : "Use\nglue(\"\n     To format multiline strings\n       (with indentation)\n     and insert \u007Br.code\u007D\", r.code=\"#rstats\") \nhttps:\/\/t.co\/mICeRqP7dO",
  "id" : 920318496415760389,
  "created_at" : "2017-10-17 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "919956107497422849",
  "text" : "A handy alias for #rstats to prevent saving or loading workspaces: R --no-save --no-restore-data --quiet",
  "id" : 919956107497422849,
  "created_at" : "2017-10-16 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/DaUwCFIQ9a",
      "expanded_url" : "https:\/\/davidgohel.github.io\/officer\/",
      "display_url" : "davidgohel.github.io\/officer\/"
    } ]
  },
  "geo" : { },
  "id_str" : "918868948296269824",
  "text" : "Use R to add text, tables and charts to a Word or Powerpoint template with the officer package #rstats https:\/\/t.co\/DaUwCFIQ9a",
  "id" : 918868948296269824,
  "created_at" : "2017-10-13 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/DZ1jcYfGUq",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/01\/getting-started-with-markov-chains.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/01\/gettin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918506548380487680",
  "text" : "Getting started with Markov chains in R: https:\/\/t.co\/DZ1jcYfGUq #rstats",
  "id" : 918506548380487680,
  "created_at" : "2017-10-12 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/2pXaK9PdLg",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/readRDS",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918144171881373698",
  "text" : "Serialization: save a single R object to disk with saveRDS; restore in a new session with readRDS https:\/\/t.co\/2pXaK9PdLg #rstats",
  "id" : 918144171881373698,
  "created_at" : "2017-10-11 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/dwwLEKigg3",
      "expanded_url" : "https:\/\/www.tidyverse.org\/",
      "display_url" : "tidyverse.org"
    } ]
  },
  "geo" : { },
  "id_str" : "917781779494330368",
  "text" : "tidyverse: a collection of essential packages for working with data in R https:\/\/t.co\/dwwLEKigg3 #rstats",
  "id" : 917781779494330368,
  "created_at" : "2017-10-10 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/yaEG39iMb7",
      "expanded_url" : "https:\/\/ironholds.org\/projects\/rbitrary\/#whats-with-and-whats-the-difference-why-not-start-with",
      "display_url" : "ironholds.org\/projects\/rbitr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917419401904717824",
  "text" : "Whats the difference between :: and ::: ? https:\/\/t.co\/yaEG39iMb7 #rstats",
  "id" : 917419401904717824,
  "created_at" : "2017-10-09 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/85t1MFbB4k",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/Robust.html",
      "display_url" : "cran.r-project.org\/web\/views\/Robu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916332244909801472",
  "text" : "List of R functions and packages for robust statistics: https:\/\/t.co\/85t1MFbB4k #rstats",
  "id" : 916332244909801472,
  "created_at" : "2017-10-06 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/WcTora39z2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/MASS\/versions\/7.3-47\/topics\/fractions",
      "display_url" : "rdocumentation.org\/packages\/MASS\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915969845396742144",
  "text" : "Find rational approximations to real numbers: x &lt;- rnorm(4); library(MASS); fractions(x) https:\/\/t.co\/WcTora39z2 #rstats",
  "id" : 915969845396742144,
  "created_at" : "2017-10-05 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/lpK9BKV5pn",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/azure\/hdinsight\/hdinsight-hadoop-r-server-get-started",
      "display_url" : "docs.microsoft.com\/en-us\/azure\/hd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "915607453693366277",
  "text" : "Step-by-step guide for launching a Spark cluster with R on Azure: https:\/\/t.co\/lpK9BKV5pn #rstats",
  "id" : 915607453693366277,
  "created_at" : "2017-10-04 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/H1mHIEWi0F",
      "expanded_url" : "https:\/\/awesome-r.com\/",
      "display_url" : "awesome-r.com"
    } ]
  },
  "geo" : { },
  "id_str" : "915245059724918784",
  "text" : "A curated list of R packages and tools, by category https:\/\/t.co\/H1mHIEWi0F #rstats",
  "id" : 915245059724918784,
  "created_at" : "2017-10-03 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portfolio Probe",
      "screen_name" : "portfolioprobe",
      "indices" : [ 67, 82 ],
      "id_str" : "177229649",
      "id" : 177229649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VZkPRYksCK",
      "expanded_url" : "http:\/\/www.portfolioprobe.com\/2012\/07\/26\/r-inferno-ism-order-is-not-rank\/",
      "display_url" : "portfolioprobe.com\/2012\/07\/26\/r-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "914912869866541056",
  "text" : "The difference between the order and rank functions in #rstats (by @portfolioprobe): https:\/\/t.co\/VZkPRYksCK",
  "id" : 914912869866541056,
  "created_at" : "2017-10-02 18:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]