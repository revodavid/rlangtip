Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nimrod Priell",
      "screen_name" : "nimrodpriell",
      "indices" : [ 121, 134 ],
      "id_str" : "85273149",
      "id" : 85273149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/zwSsm7GcdD",
      "expanded_url" : "http:\/\/bit.ly\/PG3G30",
      "display_url" : "bit.ly\/PG3G30"
    } ]
  },
  "geo" : { },
  "id_str" : "649253854610104320",
  "text" : "Run-length encoding: count the number of times sequential repeats appear with rle(x) #rstats http:\/\/t.co\/zwSsm7GcdD (via @nimrodpriell)",
  "id" : 649253854610104320,
  "created_at" : "2015-09-30 16:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/mkxvPOBIiw",
      "expanded_url" : "http:\/\/bit.ly\/1Fz9Ssy",
      "display_url" : "bit.ly\/1Fz9Ssy"
    } ]
  },
  "geo" : { },
  "id_str" : "648891470020259840",
  "text" : "The arules package provides functions for mining itemsets and discovering association rules http:\/\/t.co\/mkxvPOBIiw #rstats",
  "id" : 648891470020259840,
  "created_at" : "2015-09-29 16:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/tXQ9GIvRXz",
      "expanded_url" : "http:\/\/bit.ly\/1MvgjfN",
      "display_url" : "bit.ly\/1MvgjfN"
    } ]
  },
  "geo" : { },
  "id_str" : "648529058595217409",
  "text" : "Use clusterboot() in the fpc package to help assess the stability of clusters #rstats http:\/\/t.co\/tXQ9GIvRXz",
  "id" : 648529058595217409,
  "created_at" : "2015-09-28 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/Ey7YTqgnCB",
      "expanded_url" : "http:\/\/bit.ly\/vJweOk",
      "display_url" : "bit.ly\/vJweOk"
    } ]
  },
  "geo" : { },
  "id_str" : "647441929471459328",
  "text" : "match(x,y) Match returns a vector of the positions of 1st matches of x in y: http:\/\/t.co\/Ey7YTqgnCB #rstats",
  "id" : 647441929471459328,
  "created_at" : "2015-09-25 16:05:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/8UA91KUIcp",
      "expanded_url" : "http:\/\/bit.ly\/peyKzm",
      "display_url" : "bit.ly\/peyKzm"
    } ]
  },
  "geo" : { },
  "id_str" : "647079545300983809",
  "text" : "The \"file\" argument to data import functions like read.table can be a URL, to read data from the Web. http:\/\/t.co\/8UA91KUIcp #rstats",
  "id" : 647079545300983809,
  "created_at" : "2015-09-24 16:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/k289ChZfQH",
      "expanded_url" : "http:\/\/bit.ly\/LiAcJX",
      "display_url" : "bit.ly\/LiAcJX"
    } ]
  },
  "geo" : { },
  "id_str" : "646717184379592705",
  "text" : "A collection of tips for R beginners: http:\/\/t.co\/k289ChZfQH #rstats",
  "id" : 646717184379592705,
  "created_at" : "2015-09-23 16:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/wOM3RHe4gM",
      "expanded_url" : "http:\/\/bit.ly\/1KxiIHl",
      "display_url" : "bit.ly\/1KxiIHl"
    } ]
  },
  "geo" : { },
  "id_str" : "646354768072450048",
  "text" : "Use getSymbols() from the quantmod package to fetch \"OHLC\" stock data from multiple sources http:\/\/t.co\/wOM3RHe4gM #rstats",
  "id" : 646354768072450048,
  "created_at" : "2015-09-22 16:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/SUVuSXnRIj",
      "expanded_url" : "http:\/\/bit.ly\/1NBlFHU",
      "display_url" : "bit.ly\/1NBlFHU"
    } ]
  },
  "geo" : { },
  "id_str" : "645992492303843328",
  "text" : "Try the rattle package for a GUI based introduction to machine learning using R http:\/\/t.co\/SUVuSXnRIj #rstats",
  "id" : 645992492303843328,
  "created_at" : "2015-09-21 16:06:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/T8k8qDQT5a",
      "expanded_url" : "http:\/\/bit.ly\/1LPuYlO",
      "display_url" : "bit.ly\/1LPuYlO"
    } ]
  },
  "geo" : { },
  "id_str" : "644957964906954752",
  "text" : "R working vocabulary from Hadley Wickham http:\/\/t.co\/T8k8qDQT5a #rstats",
  "id" : 644957964906954752,
  "created_at" : "2015-09-18 19:35:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/u3VfhOv91N",
      "expanded_url" : "http:\/\/bit.ly\/pRciwj",
      "display_url" : "bit.ly\/pRciwj"
    } ]
  },
  "geo" : { },
  "id_str" : "644542907358310400",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: http:\/\/t.co\/u3VfhOv91N #rstats",
  "id" : 644542907358310400,
  "created_at" : "2015-09-17 16:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/PsQsNJuId4",
      "expanded_url" : "http:\/\/bit.ly\/1N7PgIE",
      "display_url" : "bit.ly\/1N7PgIE"
    } ]
  },
  "geo" : { },
  "id_str" : "644180522122506240",
  "text" : "Visual illusions R fun http:\/\/t.co\/PsQsNJuId4 #rstats",
  "id" : 644180522122506240,
  "created_at" : "2015-09-16 16:06:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/290B5xPTuC",
      "expanded_url" : "http:\/\/bit.ly\/1a7LJHv",
      "display_url" : "bit.ly\/1a7LJHv"
    } ]
  },
  "geo" : { },
  "id_str" : "643818096533327872",
  "text" : "Get an overview of documentation for an installed package: help(package=\"&lt;package-name&gt;\") #rstats http:\/\/t.co\/290B5xPTuC",
  "id" : 643818096533327872,
  "created_at" : "2015-09-15 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/NfZEsMZw2K",
      "expanded_url" : "http:\/\/bit.ly\/1XqJS8w",
      "display_url" : "bit.ly\/1XqJS8w"
    } ]
  },
  "geo" : { },
  "id_str" : "643455720244015104",
  "text" : "foo &lt;- capture.output( bar &lt;- suppressWarnings( \u007Bprint( \"hello, world\" ); warning(\"eeek\"  )\u007D ) ) http:\/\/t.co\/NfZEsMZw2K #rstats",
  "id" : 643455720244015104,
  "created_at" : "2015-09-14 16:06:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hadoop",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Yy6Iph3i7b",
      "expanded_url" : "http:\/\/bit.ly\/qCEtn7",
      "display_url" : "bit.ly\/qCEtn7"
    } ]
  },
  "geo" : { },
  "id_str" : "642368615287816192",
  "text" : "Write map-reduce tasks for big data in #Hadoop with the rmr package: http:\/\/t.co\/Yy6Iph3i7b #rstats",
  "id" : 642368615287816192,
  "created_at" : "2015-09-11 16:06:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/VpAfPfosFo",
      "expanded_url" : "http:\/\/bit.ly\/ywEk5w",
      "display_url" : "bit.ly\/ywEk5w"
    } ]
  },
  "geo" : { },
  "id_str" : "642006182060818432",
  "text" : "Qualification and validation of R for 21CFR11 compliance and use in FDA clinical trials: http:\/\/t.co\/VpAfPfosFo #rstats",
  "id" : 642006182060818432,
  "created_at" : "2015-09-10 16:06:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/7SxDLmSOWp",
      "expanded_url" : "http:\/\/bit.ly\/1JHnNLD",
      "display_url" : "bit.ly\/1JHnNLD"
    } ]
  },
  "geo" : { },
  "id_str" : "641643837295882240",
  "text" : "Use the dygraph() function in the package \u007Bdygraphs\u007D for interactive, javascript-based time series plots http:\/\/t.co\/7SxDLmSOWp #rstats",
  "id" : 641643837295882240,
  "created_at" : "2015-09-09 16:06:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Dr9u8pnhcI",
      "expanded_url" : "http:\/\/bit.ly\/N8Uzpr",
      "display_url" : "bit.ly\/N8Uzpr"
    } ]
  },
  "geo" : { },
  "id_str" : "641281416580464640",
  "text" : "Two-sample T tests and permutation tests in #rstats: http:\/\/t.co\/Dr9u8pnhcI",
  "id" : 641281416580464640,
  "created_at" : "2015-09-08 16:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/7SxDLmSOWp",
      "expanded_url" : "http:\/\/bit.ly\/1JHnNLD",
      "display_url" : "bit.ly\/1JHnNLD"
    } ]
  },
  "geo" : { },
  "id_str" : "640919062181249025",
  "text" : "Plot ellipse for confidence region: plot(ellipse(0.8),type=\"l\") In package \u007Bellipse\u007D http:\/\/t.co\/7SxDLmSOWp #rstats",
  "id" : 640919062181249025,
  "created_at" : "2015-09-07 16:06:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DsJpvmbkFK",
      "expanded_url" : "http:\/\/bit.ly\/If5SJP",
      "display_url" : "bit.ly\/If5SJP"
    } ]
  },
  "geo" : { },
  "id_str" : "639831929777487872",
  "text" : "Search R-help mailing list archives, help pages, vignettes and task views with RSiteSearch: http:\/\/t.co\/DsJpvmbkFK #rstats",
  "id" : 639831929777487872,
  "created_at" : "2015-09-04 16:06:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ziFsVNdGe5",
      "expanded_url" : "http:\/\/bit.ly\/Lbt65p",
      "display_url" : "bit.ly\/Lbt65p"
    } ]
  },
  "geo" : { },
  "id_str" : "639469606910984192",
  "text" : "New to R? Try the \"sample session\" in the Introduction to R Manual for a 10-min tour: http:\/\/t.co\/ziFsVNdGe5 #rstats",
  "id" : 639469606910984192,
  "created_at" : "2015-09-03 16:06:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Stednick",
      "screen_name" : "zachstednick",
      "indices" : [ 97, 110 ],
      "id_str" : "90293570",
      "id" : 90293570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/RrVtcozhF2",
      "expanded_url" : "http:\/\/bit.ly\/163DWYo",
      "display_url" : "bit.ly\/163DWYo"
    } ]
  },
  "geo" : { },
  "id_str" : "639107065076666368",
  "text" : "Tutorial on lattice graphics, from the National Park Service http:\/\/t.co\/RrVtcozhF2 #rstats (via @zachstednick)",
  "id" : 639107065076666368,
  "created_at" : "2015-09-02 16:06:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/qZ2FGVmCat",
      "expanded_url" : "http:\/\/bit.ly\/1Eo7cNy",
      "display_url" : "bit.ly\/1Eo7cNy"
    } ]
  },
  "geo" : { },
  "id_str" : "638744674795167744",
  "text" : "x[duplicated(x)] determines the dublicated elements in a vector x  http:\/\/t.co\/qZ2FGVmCat #rstats",
  "id" : 638744674795167744,
  "created_at" : "2015-09-01 16:06:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]