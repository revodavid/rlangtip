Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/LluVC6NNib",
      "expanded_url" : "http:\/\/bit.ly\/1Rv3jq3",
      "display_url" : "bit.ly\/1Rv3jq3"
    } ]
  },
  "geo" : { },
  "id_str" : "737675592334737409",
  "text" : "Guide to density esttimation in R from Deng and Wickham https:\/\/t.co\/LluVC6NNib #rstats",
  "id" : 737675592334737409,
  "created_at" : "2016-05-31 16:02:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/bwNuBHGxjX",
      "expanded_url" : "http:\/\/bit.ly\/1sSb4Cm",
      "display_url" : "bit.ly\/1sSb4Cm"
    } ]
  },
  "geo" : { },
  "id_str" : "737313994013347840",
  "text" : "logspline() \u007Blogspline\u007D fits a density using splines to approximate the log-density https:\/\/t.co\/bwNuBHGxjX #rstats",
  "id" : 737313994013347840,
  "created_at" : "2016-05-30 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/hBUDNfrEme",
      "expanded_url" : "http:\/\/bit.ly\/1U6OA6b",
      "display_url" : "bit.ly\/1U6OA6b"
    } ]
  },
  "geo" : { },
  "id_str" : "736226868517556224",
  "text" : "Compute row sums of a matrix, M, with apply(M, 1, sum) #rstats https:\/\/t.co\/hBUDNfrEme",
  "id" : 736226868517556224,
  "created_at" : "2016-05-27 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/PVl91v5VmI",
      "expanded_url" : "http:\/\/journal.r-project.org\/",
      "display_url" : "journal.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "735864488642121729",
  "text" : "Keep up with R by reading the R Journal: https:\/\/t.co\/PVl91v5VmI #rstats",
  "id" : 735864488642121729,
  "created_at" : "2016-05-26 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/APjc72eM8P",
      "expanded_url" : "http:\/\/bit.ly\/1s3BIaI",
      "display_url" : "bit.ly\/1s3BIaI"
    } ]
  },
  "geo" : { },
  "id_str" : "735502096347369472",
  "text" : "Use sink() https:\/\/t.co\/APjc72eM8P to direct R's output to a file. #rstats",
  "id" : 735502096347369472,
  "created_at" : "2016-05-25 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/e918xeQuwT",
      "expanded_url" : "http:\/\/bit.ly\/1OHRBIx",
      "display_url" : "bit.ly\/1OHRBIx"
    } ]
  },
  "geo" : { },
  "id_str" : "735139702710341633",
  "text" : "glmnet https:\/\/t.co\/e918xeQuwT fits the entire lasso or elastic-net regularization path for linear models. #rstats",
  "id" : 735139702710341633,
  "created_at" : "2016-05-24 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/iX6IQaFclx",
      "expanded_url" : "http:\/\/bit.ly\/1SuNTo9",
      "display_url" : "bit.ly\/1SuNTo9"
    } ]
  },
  "geo" : { },
  "id_str" : "734777276424933377",
  "text" : "Look here: https:\/\/t.co\/iX6IQaFclx for the R Markdown Cheat Sheet #rstats",
  "id" : 734777276424933377,
  "created_at" : "2016-05-23 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/BYAqXAlox7",
      "expanded_url" : "http:\/\/bit.ly\/1XpqxoR",
      "display_url" : "bit.ly\/1XpqxoR"
    } ]
  },
  "geo" : { },
  "id_str" : "733690166196441088",
  "text" : "To tell what version of package foo you're running, you can call packageDescription(foo)$Version #rstats https:\/\/t.co\/BYAqXAlox7",
  "id" : 733690166196441088,
  "created_at" : "2016-05-20 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/nl4UnvcMa9",
      "expanded_url" : "http:\/\/bit.ly\/MArWaE",
      "display_url" : "bit.ly\/MArWaE"
    } ]
  },
  "geo" : { },
  "id_str" : "733327771401883648",
  "text" : "For an illuminating discussion of R formulas from the National Park Service see https:\/\/t.co\/nl4UnvcMa9 #rstats",
  "id" : 733327771401883648,
  "created_at" : "2016-05-19 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/iSN7lJ00T3",
      "expanded_url" : "http:\/\/bit.ly\/1UZksPe",
      "display_url" : "bit.ly\/1UZksPe"
    } ]
  },
  "geo" : { },
  "id_str" : "732965402238652416",
  "text" : "You can plot a function object to create a chart of its equation, e.g. plot(dnorm, xlim=c(-4,4)) #rstats https:\/\/t.co\/iSN7lJ00T3",
  "id" : 732965402238652416,
  "created_at" : "2016-05-18 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/zOwJOKMXL3",
      "expanded_url" : "http:\/\/bit.ly\/1UZjUJ4",
      "display_url" : "bit.ly\/1UZjUJ4"
    } ]
  },
  "geo" : { },
  "id_str" : "732602999214739456",
  "text" : "svd() \u007Bbase\u007D will compute the singular value decomposition of a matrix https:\/\/t.co\/zOwJOKMXL3 #rstats",
  "id" : 732602999214739456,
  "created_at" : "2016-05-17 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/x8vT1CKx8Z",
      "expanded_url" : "http:\/\/bit.ly\/1TL7oYB",
      "display_url" : "bit.ly\/1TL7oYB"
    } ]
  },
  "geo" : { },
  "id_str" : "732240586086993920",
  "text" : "Get the upper triangular elements of a matrix: M[upper.tri(M,diag=TRUE)] https:\/\/t.co\/x8vT1CKx8Z #rstats",
  "id" : 732240586086993920,
  "created_at" : "2016-05-16 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/wjpek8WV3J",
      "expanded_url" : "http:\/\/bit.ly\/1SSWTq3",
      "display_url" : "bit.ly\/1SSWTq3"
    } ]
  },
  "geo" : { },
  "id_str" : "731153449530867712",
  "text" : "The Quick-R guide to Resampling Statistics in R: https:\/\/t.co\/wjpek8WV3J #rstats",
  "id" : 731153449530867712,
  "created_at" : "2016-05-13 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/3g2kxlT0F0",
      "expanded_url" : "http:\/\/bit.ly\/1UlUSni",
      "display_url" : "bit.ly\/1UlUSni"
    } ]
  },
  "geo" : { },
  "id_str" : "730791068799774720",
  "text" : "Create Tufte style graphics in R https:\/\/t.co\/3g2kxlT0F0 #rstats",
  "id" : 730791068799774720,
  "created_at" : "2016-05-12 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/pIg6G5Cow7",
      "expanded_url" : "http:\/\/bit.ly\/ytcsHj",
      "display_url" : "bit.ly\/ytcsHj"
    } ]
  },
  "geo" : { },
  "id_str" : "730428653742477312",
  "text" : "List of R packages for the analysis of medical images: https:\/\/t.co\/pIg6G5Cow7 #rstats",
  "id" : 730428653742477312,
  "created_at" : "2016-05-11 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/MVgfNEixmr",
      "expanded_url" : "http:\/\/bit.ly\/24CoaRy",
      "display_url" : "bit.ly\/24CoaRy"
    } ]
  },
  "geo" : { },
  "id_str" : "730066285762072576",
  "text" : "Use gbm() \u007Bgbm\u007D to fit generalized boosted regression models https:\/\/t.co\/MVgfNEixmr #rstats",
  "id" : 730066285762072576,
  "created_at" : "2016-05-10 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/6Dodt70S0Z",
      "expanded_url" : "http:\/\/bit.ly\/27189Xq",
      "display_url" : "bit.ly\/27189Xq"
    } ]
  },
  "geo" : { },
  "id_str" : "729703861645152256",
  "text" : "biplot() \u007Bstats\u007D will plot principal components: biplot(princomp(USArrests)) https:\/\/t.co\/6Dodt70S0Z #rstats",
  "id" : 729703861645152256,
  "created_at" : "2016-05-09 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/JQTUD0Zqzn",
      "expanded_url" : "http:\/\/bit.ly\/1VW6G1f",
      "display_url" : "bit.ly\/1VW6G1f"
    } ]
  },
  "geo" : { },
  "id_str" : "728616719103692801",
  "text" : "Cumulative multiplication: x &lt;- 1:5; Reduce(\"*\",x) Reduce\u007Bbase] can do much more. https:\/\/t.co\/JQTUD0Zqzn #rstats",
  "id" : 728616719103692801,
  "created_at" : "2016-05-06 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/KWmZ4p4HbV",
      "expanded_url" : "http:\/\/bit.ly\/1SUwIRF",
      "display_url" : "bit.ly\/1SUwIRF"
    } ]
  },
  "geo" : { },
  "id_str" : "728254333872185347",
  "text" : "Find rational approximations using continued fractions: x &lt;- rnorm(4); library(MASS); fractions(x) https:\/\/t.co\/KWmZ4p4HbV #rstats",
  "id" : 728254333872185347,
  "created_at" : "2016-05-05 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/f02MDJFXAi",
      "expanded_url" : "http:\/\/bit.ly\/189ffrl",
      "display_url" : "bit.ly\/189ffrl"
    } ]
  },
  "geo" : { },
  "id_str" : "727891950658048001",
  "text" : "#rstats Find your R home directory from the command line with Sys.getenv(\"R_Home\") https:\/\/t.co\/f02MDJFXAi",
  "id" : 727891950658048001,
  "created_at" : "2016-05-04 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/5VntNlhknU",
      "expanded_url" : "http:\/\/bit.ly\/yoyRNm",
      "display_url" : "bit.ly\/yoyRNm"
    } ]
  },
  "geo" : { },
  "id_str" : "727529599215783937",
  "text" : "How many people do you need to gather to assure a 95% probability of a shared birthday: qbirthday(0.95) #rstats https:\/\/t.co\/5VntNlhknU",
  "id" : 727529599215783937,
  "created_at" : "2016-05-03 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/fn1qER1vbw",
      "expanded_url" : "http:\/\/bit.ly\/1kn3A0n",
      "display_url" : "bit.ly\/1kn3A0n"
    } ]
  },
  "geo" : { },
  "id_str" : "727167184829599745",
  "text" : "An online Introduction to R with some R history, linear models, glm and more #rstats https:\/\/t.co\/fn1qER1vbw",
  "id" : 727167184829599745,
  "created_at" : "2016-05-02 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]