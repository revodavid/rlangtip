Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395945006965735425",
  "text" : "find() tells what package a function came from.",
  "id" : 395945006965735425,
  "created_at" : "2013-10-31 16:07:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ib6qeBD1WW",
      "expanded_url" : "http:\/\/bit.ly\/rDGhlU",
      "display_url" : "bit.ly\/rDGhlU"
    } ]
  },
  "geo" : { },
  "id_str" : "395582694668926976",
  "text" : "List of R debugging tips: http:\/\/t.co\/ib6qeBD1WW #rstats",
  "id" : 395582694668926976,
  "created_at" : "2013-10-30 16:07:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/JwhFCVBP8B",
      "expanded_url" : "http:\/\/bit.ly\/rIMpZa",
      "display_url" : "bit.ly\/rIMpZa"
    } ]
  },
  "geo" : { },
  "id_str" : "395220318694154240",
  "text" : "The \"round\" function uses the \"round-to-even\" rule. round(3.5) and round(4.5) are both 4 http:\/\/t.co\/JwhFCVBP8B #rstats",
  "id" : 395220318694154240,
  "created_at" : "2013-10-29 16:07:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/GL5wCtFFVs",
      "expanded_url" : "http:\/\/bit.ly\/pxeDBp",
      "display_url" : "bit.ly\/pxeDBp"
    } ]
  },
  "geo" : { },
  "id_str" : "394857751861809153",
  "text" : "Download and install new packages from the R command line with the install.packages function: http:\/\/t.co\/GL5wCtFFVs #rstats",
  "id" : 394857751861809153,
  "created_at" : "2013-10-28 16:06:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/TkwBLJpkmP",
      "expanded_url" : "http:\/\/ow.ly\/pXXgI",
      "display_url" : "ow.ly\/pXXgI"
    } ]
  },
  "geo" : { },
  "id_str" : "393770471122288640",
  "text" : "Use str(obj) to display the components of any object in human-readable format. http:\/\/t.co\/TkwBLJpkmP #rstats",
  "id" : 393770471122288640,
  "created_at" : "2013-10-25 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/nYsflC1uAz",
      "expanded_url" : "http:\/\/bit.ly\/qjhWGI",
      "display_url" : "bit.ly\/qjhWGI"
    } ]
  },
  "geo" : { },
  "id_str" : "393408652667002880",
  "text" : "In R, NA represents missing values. To check for NA's, use the is.na function, not the == operator http:\/\/t.co\/nYsflC1uAz #rstats",
  "id" : 393408652667002880,
  "created_at" : "2013-10-24 16:08:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/K19KZXyhQG",
      "expanded_url" : "http:\/\/bit.ly\/Svpkai",
      "display_url" : "bit.ly\/Svpkai"
    } ]
  },
  "geo" : { },
  "id_str" : "393046509832663040",
  "text" : "Visualize a 3-D surface with the persp function: http:\/\/t.co\/K19KZXyhQG #rstats",
  "id" : 393046509832663040,
  "created_at" : "2013-10-23 16:09:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/2GTMP1kkyb",
      "expanded_url" : "http:\/\/bit.ly\/PG2UmB",
      "display_url" : "bit.ly\/PG2UmB"
    } ]
  },
  "geo" : { },
  "id_str" : "392683912956481536",
  "text" : "Convert a numeric vector to a factor with \"cut\", e.g. cut(rnorm(100),3,c(\"Low\",\"Med\",\"High\")) #rstats http:\/\/t.co\/2GTMP1kkyb",
  "id" : 392683912956481536,
  "created_at" : "2013-10-22 16:08:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/V7EXwzkn85",
      "expanded_url" : "http:\/\/bit.ly\/Sppip1",
      "display_url" : "bit.ly\/Sppip1"
    } ]
  },
  "geo" : { },
  "id_str" : "392321031748464640",
  "text" : "Compare the speed of several R expressions with the benchmark function: http:\/\/t.co\/V7EXwzkn85 #rstats",
  "id" : 392321031748464640,
  "created_at" : "2013-10-21 16:06:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/lzKj4ZVoBQ",
      "expanded_url" : "http:\/\/bit.ly\/1caN5AN",
      "display_url" : "bit.ly\/1caN5AN"
    } ]
  },
  "geo" : { },
  "id_str" : "391234235497197569",
  "text" : "#rstats Compare 2 R objects using compare(obj1,obj2) in the compare package http:\/\/t.co\/lzKj4ZVoBQ",
  "id" : 391234235497197569,
  "created_at" : "2013-10-18 16:08:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ua5VdqOCvE",
      "expanded_url" : "http:\/\/bit.ly\/Qs64Kj",
      "display_url" : "bit.ly\/Qs64Kj"
    } ]
  },
  "geo" : { },
  "id_str" : "390871319006699521",
  "text" : "The ddply function (in package plyr) makes aggregating rows of data (e.g. medians by group) simpler: http:\/\/t.co\/ua5VdqOCvE #rstats",
  "id" : 390871319006699521,
  "created_at" : "2013-10-17 16:05:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/cKjvobXrUz",
      "expanded_url" : "http:\/\/bit.ly\/OET7Ri",
      "display_url" : "bit.ly\/OET7Ri"
    } ]
  },
  "geo" : { },
  "id_str" : "390524258482683904",
  "text" : "Use the integrate function to calculate the area under a curve: http:\/\/t.co\/cKjvobXrUz #rstats",
  "id" : 390524258482683904,
  "created_at" : "2013-10-16 17:06:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark the Graph",
      "screen_name" : "Mark_Graph",
      "indices" : [ 45, 56 ],
      "id_str" : "522124915",
      "id" : 522124915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Sf8VcuGgG0",
      "expanded_url" : "http:\/\/bit.ly\/UzCoCj",
      "display_url" : "bit.ly\/UzCoCj"
    } ]
  },
  "geo" : { },
  "id_str" : "390131363565010944",
  "text" : "Cheat sheet on working with factors in R (by @Mark_Graph): http:\/\/t.co\/Sf8VcuGgG0 #rstats",
  "id" : 390131363565010944,
  "created_at" : "2013-10-15 15:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GwlXtLYhup",
      "expanded_url" : "http:\/\/bit.ly\/18WaGnv",
      "display_url" : "bit.ly\/18WaGnv"
    } ]
  },
  "geo" : { },
  "id_str" : "389784177480306689",
  "text" : "#rstats Get variable name y into plot title without quotes: plot(x,y,main=paste(\"x vs \", deparse(substitute(y)))) http:\/\/t.co\/GwlXtLYhup",
  "id" : 389784177480306689,
  "created_at" : "2013-10-14 16:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noam Ross",
      "screen_name" : "noamross",
      "indices" : [ 128, 137 ],
      "id_str" : "97582853",
      "id" : 97582853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/BQkuLSIcnP",
      "expanded_url" : "http:\/\/bit.ly\/PxLttn",
      "display_url" : "bit.ly\/PxLttn"
    } ]
  },
  "geo" : { },
  "id_str" : "388681844923072512",
  "text" : "A progress bar that shows only in the console: if(interactive) \u007Bpb &lt;- txtProgressBar(\u2026)\u007D #rstats http:\/\/t.co\/BQkuLSIcnP (via @noamross)",
  "id" : 388681844923072512,
  "created_at" : "2013-10-11 15:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/pQ0FlBqPFd",
      "expanded_url" : "http:\/\/bit.ly\/Pq3v0n",
      "display_url" : "bit.ly\/Pq3v0n"
    } ]
  },
  "geo" : { },
  "id_str" : "388334558405726208",
  "text" : "How to calculate Prob(X &gt; Y) where X and Y are Gamma distributed: http:\/\/t.co\/pQ0FlBqPFd #rstats",
  "id" : 388334558405726208,
  "created_at" : "2013-10-10 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/p039xNpZUE",
      "expanded_url" : "http:\/\/bit.ly\/SAFtuh",
      "display_url" : "bit.ly\/SAFtuh"
    } ]
  },
  "geo" : { },
  "id_str" : "387972197190737920",
  "text" : "Customize your R environment with these suggestions for your .Rprofile: http:\/\/t.co\/p039xNpZUE #rstats",
  "id" : 387972197190737920,
  "created_at" : "2013-10-09 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/95Ib4J5HpK",
      "expanded_url" : "http:\/\/bit.ly\/1dYFk2m",
      "display_url" : "bit.ly\/1dYFk2m"
    } ]
  },
  "geo" : { },
  "id_str" : "387609832465113088",
  "text" : "Use object.size() to estimate the amount of memory an R object is consuming #rstats http:\/\/t.co\/95Ib4J5HpK",
  "id" : 387609832465113088,
  "created_at" : "2013-10-08 16:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Ai8PrrpnRn",
      "expanded_url" : "http:\/\/bit.ly\/1eNXbes",
      "display_url" : "bit.ly\/1eNXbes"
    } ]
  },
  "geo" : { },
  "id_str" : "387247407068889088",
  "text" : "#rstats Use rpart:::summary.rpart to look at the code in the hidden method summary.rpart (from Ecostudies) http:\/\/t.co\/Ai8PrrpnRn",
  "id" : 387247407068889088,
  "created_at" : "2013-10-07 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/e2BVCE2yDs",
      "expanded_url" : "http:\/\/bit.ly\/RE2H6l",
      "display_url" : "bit.ly\/RE2H6l"
    } ]
  },
  "geo" : { },
  "id_str" : "385797905145401344",
  "text" : "Use \"deriv\" to create a function that returns the derivative and hessian of a symbolic expression: http:\/\/t.co\/e2BVCE2yDs #rstats",
  "id" : 385797905145401344,
  "created_at" : "2013-10-03 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/BpaoQmObAY",
      "expanded_url" : "http:\/\/bit.ly\/TNcLO8",
      "display_url" : "bit.ly\/TNcLO8"
    } ]
  },
  "geo" : { },
  "id_str" : "385435749199675392",
  "text" : "Find the list of changes in the forthcoming release of R (R-devel) here: http:\/\/t.co\/BpaoQmObAY #rstats",
  "id" : 385435749199675392,
  "created_at" : "2013-10-02 16:06:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/2Ks501yFIq",
      "expanded_url" : "http:\/\/bit.ly\/TN15uC",
      "display_url" : "bit.ly\/TN15uC"
    } ]
  },
  "geo" : { },
  "id_str" : "385073391243632640",
  "text" : "How R finds variables used in statistical models: http:\/\/t.co\/2Ks501yFIq #rstats",
  "id" : 385073391243632640,
  "created_at" : "2013-10-01 16:07:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]