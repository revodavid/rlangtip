Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/S3L4zSAiwt",
      "expanded_url" : "http:\/\/bit.ly\/1iNxJsW",
      "display_url" : "bit.ly\/1iNxJsW"
    } ]
  },
  "geo" : { },
  "id_str" : "483642560532217856",
  "text" : "Some tips on using R to talk to Twitter from Raffael Vogler http:\/\/t.co\/S3L4zSAiwt #rstats",
  "id" : 483642560532217856,
  "created_at" : "2014-06-30 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Hua3ThsQgz",
      "expanded_url" : "http:\/\/bit.ly\/1dYFk2m",
      "display_url" : "bit.ly\/1dYFk2m"
    } ]
  },
  "geo" : { },
  "id_str" : "482192922335801344",
  "text" : "Use object.size() to estimate the amount of memory an R object is consuming #rstats http:\/\/t.co\/Hua3ThsQgz",
  "id" : 482192922335801344,
  "created_at" : "2014-06-26 16:05:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/7ZBX7s1dTq",
      "expanded_url" : "http:\/\/bit.ly\/1rd8cJF",
      "display_url" : "bit.ly\/1rd8cJF"
    } ]
  },
  "geo" : { },
  "id_str" : "481830556536020994",
  "text" : "Type objects() at the console to see what variables, funcions and data sets you have defined http:\/\/t.co\/7ZBX7s1dTq #rstats",
  "id" : 481830556536020994,
  "created_at" : "2014-06-25 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/jJRmUyz2Fp",
      "expanded_url" : "http:\/\/bit.ly\/n4V3sw",
      "display_url" : "bit.ly\/n4V3sw"
    } ]
  },
  "geo" : { },
  "id_str" : "481468168863768577",
  "text" : "Look here (http:\/\/t.co\/jJRmUyz2Fp) for a fairly comprehensive list of R #rstats resources.",
  "id" : 481468168863768577,
  "created_at" : "2014-06-24 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/L31BIOw0es",
      "expanded_url" : "http:\/\/bit.ly\/1lDnbNz",
      "display_url" : "bit.ly\/1lDnbNz"
    } ]
  },
  "geo" : { },
  "id_str" : "481105847184285696",
  "text" : "x &lt;- R.version$version.string assigna a character string containing the version of R you are running http:\/\/t.co\/L31BIOw0es #rstats",
  "id" : 481105847184285696,
  "created_at" : "2014-06-23 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/xaUyGEnMrU",
      "expanded_url" : "http:\/\/bit.ly\/1mSyJYG",
      "display_url" : "bit.ly\/1mSyJYG"
    } ]
  },
  "geo" : { },
  "id_str" : "480017679517253632",
  "text" : "Compute or estimate the condition number of a matrix: kappa(M) http:\/\/t.co\/xaUyGEnMrU #rstats",
  "id" : 480017679517253632,
  "created_at" : "2014-06-20 16:01:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/gi3quxQvIA",
      "expanded_url" : "http:\/\/bit.ly\/zrvgHJ",
      "display_url" : "bit.ly\/zrvgHJ"
    } ]
  },
  "geo" : { },
  "id_str" : "479641113922260992",
  "text" : "Use the xtable package to convert a table or matrix to HTML: print(xtable(X), type=\"html\") #rstats http:\/\/t.co\/gi3quxQvIA",
  "id" : 479641113922260992,
  "created_at" : "2014-06-19 15:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UlwKmIiegv",
      "expanded_url" : "http:\/\/bit.ly\/zIdY6J",
      "display_url" : "bit.ly\/zIdY6J"
    } ]
  },
  "geo" : { },
  "id_str" : "479278709107859457",
  "text" : "The lubridate package simplifies operations on dates and times: http:\/\/t.co\/UlwKmIiegv #rstats",
  "id" : 479278709107859457,
  "created_at" : "2014-06-18 15:05:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Kj32bIf8Tg",
      "expanded_url" : "http:\/\/bit.ly\/1p2yZa6",
      "display_url" : "bit.ly\/1p2yZa6"
    } ]
  },
  "geo" : { },
  "id_str" : "478931510855479296",
  "text" : "Generate a sequence of dates: seq(as.Date(\"2000\/1\/1\"), as.Date(\"2014\/1\/1\"), \"years\") http:\/\/t.co\/Kj32bIf8Tg #rstats",
  "id" : 478931510855479296,
  "created_at" : "2014-06-17 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/g08FL9752B",
      "expanded_url" : "http:\/\/bit.ly\/1psl2FW",
      "display_url" : "bit.ly\/1psl2FW"
    } ]
  },
  "geo" : { },
  "id_str" : "478569113884065793",
  "text" : "Get the current date with Sys.Date() and the time with Sys.time() http:\/\/t.co\/g08FL9752B #rstats",
  "id" : 478569113884065793,
  "created_at" : "2014-06-16 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/8ukEqHibfM",
      "expanded_url" : "http:\/\/bit.ly\/x9UdLI",
      "display_url" : "bit.ly\/x9UdLI"
    } ]
  },
  "geo" : { },
  "id_str" : "477481914916282368",
  "text" : "sample(x) randomly shuffles the elements of a vector or list x #rstats http:\/\/t.co\/8ukEqHibfM",
  "id" : 477481914916282368,
  "created_at" : "2014-06-13 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/cn6u485ii7",
      "expanded_url" : "http:\/\/bit.ly\/n2rmBo",
      "display_url" : "bit.ly\/n2rmBo"
    } ]
  },
  "geo" : { },
  "id_str" : "477119530662383616",
  "text" : "Reserved words that can't be used as object names: if, while, for, next, TRUE, and several others listed at http:\/\/t.co\/cn6u485ii7 #rstats",
  "id" : 477119530662383616,
  "created_at" : "2014-06-12 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/GlYC9BpM0e",
      "expanded_url" : "http:\/\/bit.ly\/1lcbZps",
      "display_url" : "bit.ly\/1lcbZps"
    } ]
  },
  "geo" : { },
  "id_str" : "476757125939855361",
  "text" : "RevoJoe's updated list of data sets: http:\/\/t.co\/GlYC9BpM0e #rstats",
  "id" : 476757125939855361,
  "created_at" : "2014-06-11 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/wYhELSJcLd",
      "expanded_url" : "http:\/\/bit.ly\/1tPdef9",
      "display_url" : "bit.ly\/1tPdef9"
    } ]
  },
  "geo" : { },
  "id_str" : "476394756919267329",
  "text" : "\"An Introduction to Statistical Learning\" : (James et.al.) is full of R code and free to download http:\/\/t.co\/wYhELSJcLd #rstats",
  "id" : 476394756919267329,
  "created_at" : "2014-06-10 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/NXBOnbYYzq",
      "expanded_url" : "http:\/\/bit.ly\/1q2m60u",
      "display_url" : "bit.ly\/1q2m60u"
    } ]
  },
  "geo" : { },
  "id_str" : "476032330562543616",
  "text" : "Try glm2() \u007Bglm2\u007D if your GLM model is having convergence problems http:\/\/t.co\/NXBOnbYYzq #rstats",
  "id" : 476032330562543616,
  "created_at" : "2014-06-09 16:05:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/GjZKd0BMAU",
      "expanded_url" : "http:\/\/bit.ly\/1jBROMQ",
      "display_url" : "bit.ly\/1jBROMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "474945193536671744",
  "text" : "Nice short list of useful R functions from Alastair Sanderson http:\/\/t.co\/GjZKd0BMAU #rstats",
  "id" : 474945193536671744,
  "created_at" : "2014-06-06 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/tvVCF1C68L",
      "expanded_url" : "http:\/\/bit.ly\/p6epvV",
      "display_url" : "bit.ly\/p6epvV"
    } ]
  },
  "geo" : { },
  "id_str" : "474582787555852288",
  "text" : "Yes, you can return more than one value from a function: use a list! return(list(val1, val2, val3)) #rstats http:\/\/t.co\/tvVCF1C68L",
  "id" : 474582787555852288,
  "created_at" : "2014-06-05 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/IWMumTn9uY",
      "expanded_url" : "http:\/\/bit.ly\/RMvSYr",
      "display_url" : "bit.ly\/RMvSYr"
    } ]
  },
  "geo" : { },
  "id_str" : "474219592681021440",
  "text" : "as.data.frame(installed.packages()[,c(1,3)],row.names=F) : list of installed packages with version http:\/\/t.co\/IWMumTn9uY #rstats",
  "id" : 474219592681021440,
  "created_at" : "2014-06-04 16:02:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/iBwNxBFEhc",
      "expanded_url" : "http:\/\/bit.ly\/1hGXhlB",
      "display_url" : "bit.ly\/1hGXhlB"
    } ]
  },
  "geo" : { },
  "id_str" : "473858076635045888",
  "text" : "Run help file examples for a particular function using the 'example' function: example(plot) or example(lm) http:\/\/t.co\/iBwNxBFEhc #rstats",
  "id" : 473858076635045888,
  "created_at" : "2014-06-03 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/sKkhpKYCej",
      "expanded_url" : "http:\/\/bit.ly\/1kRRZZ5",
      "display_url" : "bit.ly\/1kRRZZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "473495668313829376",
  "text" : "Type ?regex in the console to get the R manual on regular expressions http:\/\/t.co\/sKkhpKYCej #rstats",
  "id" : 473495668313829376,
  "created_at" : "2014-06-02 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]