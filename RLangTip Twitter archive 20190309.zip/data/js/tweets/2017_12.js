Grailbird.data.tweets_2017_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/7Chv84UWK5",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.4.3\/topics\/curve",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "946787903128076291",
  "text" : "You can plot a function object to create a chart of its equation, e.g. plot(dnorm, xlim=c(-4,4)) https:\/\/t.co\/7Chv84UWK5 #rstats",
  "id" : 946787903128076291,
  "created_at" : "2017-12-29 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 60, 74 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/xVePGioIiP",
      "expanded_url" : "http:\/\/adv-r.had.co.nz\/",
      "display_url" : "adv-r.had.co.nz"
    } ]
  },
  "geo" : { },
  "id_str" : "946425514549321728",
  "text" : "Improve your R coding skills with Advanced R Programming by @hadleywickham https:\/\/t.co\/xVePGioIiP #rstats",
  "id" : 946425514549321728,
  "created_at" : "2017-12-28 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/0CEc5OAT9Q",
      "expanded_url" : "https:\/\/www.r-bloggers.com\/r-na-vs-null\/",
      "display_url" : "r-bloggers.com\/r-na-vs-null\/"
    } ]
  },
  "geo" : { },
  "id_str" : "946063123626127361",
  "text" : "is.na() tests for missing (NA) values. is.null() tests for NULL values. https:\/\/t.co\/0CEc5OAT9Q #rstats",
  "id" : 946063123626127361,
  "created_at" : "2017-12-27 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/aYX45hhara",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/MASS\/versions\/7.3-47\/topics\/boxcox",
      "display_url" : "rdocumentation.org\/packages\/MASS\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "945700748695953409",
  "text" : "The Box-Cox transformation is a useful technique for transforming data to be more Normal https:\/\/t.co\/aYX45hhara #rstats",
  "id" : 945700748695953409,
  "created_at" : "2017-12-26 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RLangTip\/status\/945338355402924032\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/c7d1IniVS2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DRBUlAtVQAYcds8.jpg",
      "id_str" : "941345316942462982",
      "id" : 941345316942462982,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DRBUlAtVQAYcds8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 378
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/c7d1IniVS2"
    } ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ZIoo75dwti",
      "expanded_url" : "https:\/\/www.data-imaginist.com\/2016\/data-driven-x-mas-card\/",
      "display_url" : "data-imaginist.com\/2016\/data-driv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "945338355402924032",
  "text" : "A data-driven Christmas card animation https:\/\/t.co\/ZIoo75dwti #rstats https:\/\/t.co\/c7d1IniVS2",
  "id" : 945338355402924032,
  "created_at" : "2017-12-25 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944251203482877952",
  "text" : "Don't expect any CRAN package updates or new releases until after January 3. The CRAN system is currently offline for maintenance.",
  "id" : 944251203482877952,
  "created_at" : "2017-12-22 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/I6XX6LnVH4",
      "expanded_url" : "http:\/\/livefreeordichotomize.com\/2017\/09\/28\/r-release-names\/",
      "display_url" : "livefreeordichotomize.com\/2017\/09\/28\/r-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943888798722637824",
  "text" : "The story behind R release names like \"Very Secure Dishes\" https:\/\/t.co\/I6XX6LnVH4 #rstats",
  "id" : 943888798722637824,
  "created_at" : "2017-12-21 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/3kLYEBfMB9",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/Control",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943526414476763136",
  "text" : "The \"break\" statement immediately exits from a \"for\" or \"while\" loop: https:\/\/t.co\/3kLYEBfMB9 #rstats",
  "id" : 943526414476763136,
  "created_at" : "2017-12-20 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/iGWxotz0B5",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2015\/09\/interpolation-and-smoothing-functions-in-base-r.html",
      "display_url" : "blog.revolutionanalytics.com\/2015\/09\/interp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943164022769074177",
  "text" : "Interpolation and smoothing functions in base R: https:\/\/t.co\/iGWxotz0B5 #rstats",
  "id" : 943164022769074177,
  "created_at" : "2017-12-19 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vMf5US5z3H",
      "expanded_url" : "https:\/\/www.statmethods.net\/stats\/anova.html",
      "display_url" : "statmethods.net\/stats\/anova.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "942801651144028165",
  "text" : "One line, Two Way Factorial Design ANOVA: fit &lt;- aov(y ~ A + B + A:B, data=mydataframe) https:\/\/t.co\/vMf5US5z3H #rstats",
  "id" : 942801651144028165,
  "created_at" : "2017-12-18 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/hwD5nIbCzm",
      "expanded_url" : "https:\/\/github.com\/milesmcbain\/datapasta",
      "display_url" : "github.com\/milesmcbain\/da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "941714488029364230",
  "text" : "Use the datapasta package to easily cut-and-paste tables from web pages into R objects https:\/\/t.co\/hwD5nIbCzm #rstats",
  "id" : 941714488029364230,
  "created_at" : "2017-12-15 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/zj6EOVVh2c",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/R_(programming_language)",
      "display_url" : "en.wikipedia.org\/wiki\/R_(progra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "941352081495015424",
  "text" : "There is a Wikipedia page for R at https:\/\/t.co\/zj6EOVVh2c #rstats",
  "id" : 941352081495015424,
  "created_at" : "2017-12-14 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "940989698519875584",
  "text" : "R indexes arrays from 1 like Fortran, not from 0 like C or Python #rstats",
  "id" : 940989698519875584,
  "created_at" : "2017-12-13 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/KftIxns6zA",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/beginner-tips\/",
      "display_url" : "blog.revolutionanalytics.com\/beginner-tips\/"
    } ]
  },
  "geo" : { },
  "id_str" : "940627309345869824",
  "text" : "A collection of tips for R beginners: https:\/\/t.co\/KftIxns6zA #rstats",
  "id" : 940627309345869824,
  "created_at" : "2017-12-12 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/lSjtG9nmPW",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2009\/02\/how-to-choose-a-random-number-in-r.html",
      "display_url" : "blog.revolutionanalytics.com\/2009\/02\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940340423087632384",
  "text" : "How to generate random numbers in R: https:\/\/t.co\/lSjtG9nmPW #rstats",
  "id" : 940340423087632384,
  "created_at" : "2017-12-11 22:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/K6RkhtUYrV",
      "expanded_url" : "https:\/\/cran.r-project.org\/mirmon_report.html",
      "display_url" : "cran.r-project.org\/mirmon_report.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "939177764371931136",
  "text" : "Check availability status of CRAN mirrors: https:\/\/t.co\/K6RkhtUYrV #rstats",
  "id" : 939177764371931136,
  "created_at" : "2017-12-08 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938815370990940160",
  "text" : "Don't forget about the \"car\" and \"MASS\" packages when looking for sample data: data(package=c(\"MASS\",\"car\")) #rstats",
  "id" : 938815370990940160,
  "created_at" : "2017-12-07 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/YHL1EKtUNa",
      "expanded_url" : "https:\/\/mran.microsoft.com\/timemachine\/",
      "display_url" : "mran.microsoft.com\/timemachine\/"
    } ]
  },
  "geo" : { },
  "id_str" : "938452989613871104",
  "text" : "Explore R packages from the past with the CRAN Time Machine https:\/\/t.co\/YHL1EKtUNa #rstats",
  "id" : 938452989613871104,
  "created_at" : "2017-12-06 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RLangTip\/status\/938090600624046081\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/6FB7AA4Yyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP1AUf2VQAAq22k.jpg",
      "id_str" : "935975018453876736",
      "id" : 935975018453876736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP1AUf2VQAAq22k.jpg",
      "sizes" : [ {
        "h" : 366,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 472
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/6FB7AA4Yyc"
    } ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938090600624046081",
  "text" : "Generate a \"\"Secret Santa\" giving list from a vector of names:\np &lt;- sample(team)\ncbind(santa=p, recipient=c(tail(p,-1),p[1]))\n#rstats https:\/\/t.co\/6FB7AA4Yyc",
  "id" : 938090600624046081,
  "created_at" : "2017-12-05 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jJquMHZzg6",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/survival\/versions\/2.41-2\/topics\/survreg",
      "display_url" : "rdocumentation.org\/packages\/survi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937728210556653568",
  "text" : "The survreg() function in the survival package fits parametric, survival regression models https:\/\/t.co\/jJquMHZzg6 #rstats",
  "id" : 937728210556653568,
  "created_at" : "2017-12-04 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/V4km7KhJDf",
      "expanded_url" : "https:\/\/rweekly.org\/",
      "display_url" : "rweekly.org"
    } ]
  },
  "geo" : { },
  "id_str" : "936641061736157184",
  "text" : "R Weekly: a weekly bulletin of curated R-related blog posts https:\/\/t.co\/V4km7KhJDf #rstats",
  "id" : 936641061736157184,
  "created_at" : "2017-12-01 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]