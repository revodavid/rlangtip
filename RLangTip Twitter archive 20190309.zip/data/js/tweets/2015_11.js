Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/BNCRfE3c7C",
      "expanded_url" : "http:\/\/bit.ly\/1Q3BbNP",
      "display_url" : "bit.ly\/1Q3BbNP"
    } ]
  },
  "geo" : { },
  "id_str" : "671374665433133056",
  "text" : "IQR(x,type=n) n = 1,2,\u20269 in \u007Bstats\u007Dcomputes the interquartile range using 1 of 9 different algorithms https:\/\/t.co\/BNCRfE3c7C #rstats",
  "id" : 671374665433133056,
  "created_at" : "2015-11-30 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/IbkeFgkCx2",
      "expanded_url" : "http:\/\/bit.ly\/17B9nuP",
      "display_url" : "bit.ly\/17B9nuP"
    } ]
  },
  "geo" : { },
  "id_str" : "670287488003411968",
  "text" : "Fit a Bayesian regression model: mod &lt;- MCMCregress(formula,data) https:\/\/t.co\/IbkeFgkCx2 #rstats",
  "id" : 670287488003411968,
  "created_at" : "2015-11-27 17:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/MgAFj6eVGY",
      "expanded_url" : "http:\/\/bit.ly\/KpZ9SP",
      "display_url" : "bit.ly\/KpZ9SP"
    } ]
  },
  "geo" : { },
  "id_str" : "669925216378843136",
  "text" : "For a comparison of lapply(), Map() and do.call(): https:\/\/t.co\/MgAFj6eVGY #rstats",
  "id" : 669925216378843136,
  "created_at" : "2015-11-26 17:06:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/cYHSy44TY9",
      "expanded_url" : "http:\/\/bit.ly\/1LqZiQm",
      "display_url" : "bit.ly\/1LqZiQm"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/icHUmsNPuk",
      "expanded_url" : "http:\/\/bit.ly\/1Hd3195",
      "display_url" : "bit.ly\/1Hd3195"
    } ]
  },
  "geo" : { },
  "id_str" : "669562784225599492",
  "text" : "tapply() \u007Bbase\u007D https:\/\/t.co\/cYHSy44TY9 applies a function to each non-empty group in a \"ragged\" array eg: https:\/\/t.co\/icHUmsNPuk #rstats",
  "id" : 669562784225599492,
  "created_at" : "2015-11-25 17:06:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ofU12a3Jux",
      "expanded_url" : "http:\/\/bit.ly\/1T4d5Ti",
      "display_url" : "bit.ly\/1T4d5Ti"
    } ]
  },
  "geo" : { },
  "id_str" : "669200348112920577",
  "text" : "Use gl() in \u007Bbase\u007D to generate factors by a pattern. Eg: gl(2, 8, labels = c(\"M\", \"F\")) https:\/\/t.co\/ofU12a3Jux #rstats",
  "id" : 669200348112920577,
  "created_at" : "2015-11-24 17:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/YC9SzZyee0",
      "expanded_url" : "http:\/\/bit.ly\/uG6J1C",
      "display_url" : "bit.ly\/uG6J1C"
    } ]
  },
  "geo" : { },
  "id_str" : "668837904626679809",
  "text" : "The holiday function in the timeDate package looks up holiday dates, e.g. holiday(2016,\"USThanksgivingDay\") https:\/\/t.co\/YC9SzZyee0 #rstats",
  "id" : 668837904626679809,
  "created_at" : "2015-11-23 17:05:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iBartomeus",
      "screen_name" : "ibartomeus",
      "indices" : [ 122, 133 ],
      "id_str" : "14226594",
      "id" : 14226594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/5Zq3Un8MWr",
      "expanded_url" : "http:\/\/bit.ly\/QTueDq",
      "display_url" : "bit.ly\/QTueDq"
    } ]
  },
  "geo" : { },
  "id_str" : "667750787322376192",
  "text" : "Select only rows of a data frame without any missing values: df[complete.cases(df),] #rstats https:\/\/t.co\/5Zq3Un8MWr (via @ibartomeus)",
  "id" : 667750787322376192,
  "created_at" : "2015-11-20 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/ib6qeBD1WW",
      "expanded_url" : "http:\/\/bit.ly\/rDGhlU",
      "display_url" : "bit.ly\/rDGhlU"
    } ]
  },
  "geo" : { },
  "id_str" : "667388395862278145",
  "text" : "List of R debugging tips: https:\/\/t.co\/ib6qeBD1WW #rstats",
  "id" : 667388395862278145,
  "created_at" : "2015-11-19 17:06:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/YgMmwekW1u",
      "expanded_url" : "http:\/\/bit.ly\/20RH85M",
      "display_url" : "bit.ly\/20RH85M"
    } ]
  },
  "geo" : { },
  "id_str" : "667026038703194114",
  "text" : "cumprod(x) in \u007Bbase\u007D returns a vector containing the cumulative products of the vector x https:\/\/t.co\/YgMmwekW1u #rstats",
  "id" : 667026038703194114,
  "created_at" : "2015-11-18 17:06:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/DnmNUJZ6vF",
      "expanded_url" : "http:\/\/bit.ly\/1cv5USI",
      "display_url" : "bit.ly\/1cv5USI"
    } ]
  },
  "geo" : { },
  "id_str" : "666663604406587392",
  "text" : "#rstats Get eigenvalues and eigenvectors in R with eigen(matrix) https:\/\/t.co\/DnmNUJZ6vF",
  "id" : 666663604406587392,
  "created_at" : "2015-11-17 17:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/YgMmwekW1u",
      "expanded_url" : "http:\/\/bit.ly\/20RH85M",
      "display_url" : "bit.ly\/20RH85M"
    } ]
  },
  "geo" : { },
  "id_str" : "666301181975728128",
  "text" : "The survreg() function in the survival package fits parametric, survival regression models. https:\/\/t.co\/YgMmwekW1u #rstats",
  "id" : 666301181975728128,
  "created_at" : "2015-11-16 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/omr1ryFo2i",
      "expanded_url" : "http:\/\/bit.ly\/17x6MPn",
      "display_url" : "bit.ly\/17x6MPn"
    } ]
  },
  "geo" : { },
  "id_str" : "665214138159931392",
  "text" : "optim() in the stats package is a general purpose optimization function #rstats https:\/\/t.co\/omr1ryFo2i",
  "id" : 665214138159931392,
  "created_at" : "2015-11-13 17:06:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/J8BvyBZvjc",
      "expanded_url" : "http:\/\/bit.ly\/17zAXL5",
      "display_url" : "bit.ly\/17zAXL5"
    } ]
  },
  "geo" : { },
  "id_str" : "664851822750887936",
  "text" : "Look at options under help(par) to customize plot() #rstats https:\/\/t.co\/J8BvyBZvjc",
  "id" : 664851822750887936,
  "created_at" : "2015-11-12 17:06:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/WLcz3DHDB0",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "664489492150136832",
  "text" : "NA's have special handling for logical comparisons. NA &amp; FALSE is always FALSE, NA | TRUE is TRUE. https:\/\/t.co\/WLcz3DHDB0 #rstats",
  "id" : 664489492150136832,
  "created_at" : "2015-11-11 17:06:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/yMBRT30QcY",
      "expanded_url" : "http:\/\/www.jstatsoft.org\/index",
      "display_url" : "jstatsoft.org\/index"
    } ]
  },
  "geo" : { },
  "id_str" : "664126938420781056",
  "text" : "For some really good #rstats reading have a look at the Journal of Statistical Software https:\/\/t.co\/yMBRT30QcY",
  "id" : 664126938420781056,
  "created_at" : "2015-11-10 17:06:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/6YnhMO0BMm",
      "expanded_url" : "http:\/\/bit.ly\/1Q8UgiV",
      "display_url" : "bit.ly\/1Q8UgiV"
    } ]
  },
  "geo" : { },
  "id_str" : "663764490861809666",
  "text" : "Want to fit a generalized additive model to a large data set? Try the bam() function in the mgcv package https:\/\/t.co\/6YnhMO0BMm #rstats",
  "id" : 663764490861809666,
  "created_at" : "2015-11-09 17:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/2FCHIuiAME",
      "expanded_url" : "http:\/\/bit.ly\/qRgbld",
      "display_url" : "bit.ly\/qRgbld"
    } ]
  },
  "geo" : { },
  "id_str" : "662677514364526592",
  "text" : "Run an R script from the command line in batch mode with R CMD BATCH: https:\/\/t.co\/2FCHIuiAME #rstats",
  "id" : 662677514364526592,
  "created_at" : "2015-11-06 17:06:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/BpaoQmObAY",
      "expanded_url" : "http:\/\/bit.ly\/TNcLO8",
      "display_url" : "bit.ly\/TNcLO8"
    } ]
  },
  "geo" : { },
  "id_str" : "662315137571926018",
  "text" : "Find the list of changes in the forthcoming release of R (R-devel) here: https:\/\/t.co\/BpaoQmObAY #rstats",
  "id" : 662315137571926018,
  "created_at" : "2015-11-05 17:06:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VGkPfZPeOP",
      "expanded_url" : "http:\/\/bit.ly\/20gnVdv",
      "display_url" : "bit.ly\/20gnVdv"
    } ]
  },
  "geo" : { },
  "id_str" : "661952758149455872",
  "text" : "getVignetteInfo() in the \u007Btools\u007D package will provide information on installed vignettes. https:\/\/t.co\/VGkPfZPeOP #rstats",
  "id" : 661952758149455872,
  "created_at" : "2015-11-04 17:06:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/TfliNWcKRf",
      "expanded_url" : "http:\/\/bit.ly\/1hTVsEf",
      "display_url" : "bit.ly\/1hTVsEf"
    } ]
  },
  "geo" : { },
  "id_str" : "661590310158512128",
  "text" : "Find the amount of memory allocated to R with memory.limit() #rstats https:\/\/t.co\/TfliNWcKRf",
  "id" : 661590310158512128,
  "created_at" : "2015-11-03 17:06:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/5QyrIxO8Ur",
      "expanded_url" : "http:\/\/bit.ly\/1SdrV9o",
      "display_url" : "bit.ly\/1SdrV9o"
    } ]
  },
  "geo" : { },
  "id_str" : "661227756278140928",
  "text" : "Fit a nonlinear mixed-effects model with function nlme() in the \u007Bnlme\u007D package https:\/\/t.co\/5QyrIxO8Ur #rstats",
  "id" : 661227756278140928,
  "created_at" : "2015-11-02 17:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]