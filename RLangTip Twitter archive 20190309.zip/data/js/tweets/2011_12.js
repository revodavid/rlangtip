Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/oRXTNAON",
      "expanded_url" : "http:\/\/bit.ly\/mVysYe",
      "display_url" : "bit.ly\/mVysYe"
    } ]
  },
  "geo" : { },
  "id_str" : "152781188820512770",
  "text" : "List of R functions and packages for finance and risk management: http:\/\/t.co\/oRXTNAON #rstats",
  "id" : 152781188820512770,
  "created_at" : "2011-12-30 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/6VlqdqpV",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "152418799457542145",
  "text" : "which(x &gt; 0) returns the locations of positive elements in numeric vector x http:\/\/t.co\/6VlqdqpV #rstats",
  "id" : 152418799457542145,
  "created_at" : "2011-12-29 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/u38srKVu",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "152056430357250048",
  "text" : "To create the list of every possible combination of levels in multiple factors, use expand.grid: http:\/\/t.co\/u38srKVu #rstats",
  "id" : 152056430357250048,
  "created_at" : "2011-12-28 16:00:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151339644850671617",
  "geo" : { },
  "id_str" : "151730578318819329",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog Thanks for the tip!",
  "id" : 151730578318819329,
  "in_reply_to_status_id" : 151339644850671617,
  "created_at" : "2011-12-27 18:26:03 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/VXGDzsIN",
      "expanded_url" : "http:\/\/bit.ly\/srEahw",
      "display_url" : "bit.ly\/srEahw"
    } ]
  },
  "geo" : { },
  "id_str" : "151694030122655744",
  "text" : "Moving data between R and Excel via the Windows clipboard: http:\/\/t.co\/VXGDzsIN #rstats",
  "id" : 151694030122655744,
  "created_at" : "2011-12-27 16:00:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/gB5T3dF6",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "151331688365035520",
  "text" : "Create a file called .Rprofile of commands to run each time R starts. Good for setting options, etc. Example: http:\/\/t.co\/gB5T3dF6 #rstats",
  "id" : 151331688365035520,
  "created_at" : "2011-12-26 16:01:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151328949484519424",
  "text" : "Continuing this week: the best of RLangTip. Send tip suggestions to RLangTip@revolutionanalytics.com for inclusion in this stream in 2012.",
  "id" : 151328949484519424,
  "created_at" : "2011-12-26 15:50:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/OxF8xA5A",
      "expanded_url" : "http:\/\/bit.ly\/rRPlYw",
      "display_url" : "bit.ly\/rRPlYw"
    } ]
  },
  "geo" : { },
  "id_str" : "150244861122068480",
  "text" : "What is the most useful R trick? Answers on StackOverflow: http:\/\/t.co\/OxF8xA5A #rstats",
  "id" : 150244861122068480,
  "created_at" : "2011-12-23 16:02:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/XMnJGH2v",
      "expanded_url" : "http:\/\/bit.ly\/auoC65",
      "display_url" : "bit.ly\/auoC65"
    } ]
  },
  "geo" : { },
  "id_str" : "149882103553732609",
  "text" : "log1p(x) computes log(1 + x). Why is such a function necessary? http:\/\/t.co\/XMnJGH2v #rstats",
  "id" : 149882103553732609,
  "created_at" : "2011-12-22 16:00:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/UpixjGR7",
      "expanded_url" : "http:\/\/bit.ly\/rkawJQ",
      "display_url" : "bit.ly\/rkawJQ"
    } ]
  },
  "geo" : { },
  "id_str" : "149519990419238912",
  "text" : "R for programmers coming from other languages http:\/\/t.co\/UpixjGR7 #rstats",
  "id" : 149519990419238912,
  "created_at" : "2011-12-21 16:01:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/irkPBz9d",
      "expanded_url" : "http:\/\/bit.ly\/rOOucD",
      "display_url" : "bit.ly\/rOOucD"
    } ]
  },
  "geo" : { },
  "id_str" : "149157577408774144",
  "text" : "Generate a LaTeX table from an R variable: http:\/\/t.co\/irkPBz9d #rstats",
  "id" : 149157577408774144,
  "created_at" : "2011-12-20 16:01:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/2AP3f78n",
      "expanded_url" : "http:\/\/bit.ly\/t2OR0K",
      "display_url" : "bit.ly\/t2OR0K"
    } ]
  },
  "geo" : { },
  "id_str" : "148828868252409856",
  "text" : "To speed an R function, use cmpfun to byte-compile it: http:\/\/t.co\/2AP3f78n #rstats",
  "id" : 148828868252409856,
  "created_at" : "2011-12-19 18:15:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/0u0Sg2v8",
      "expanded_url" : "http:\/\/rseek.org\/",
      "display_url" : "rseek.org"
    } ]
  },
  "geo" : { },
  "id_str" : "148795199299141632",
  "text" : "R-specific web search http:\/\/t.co\/0u0Sg2v8 #rstats",
  "id" : 148795199299141632,
  "created_at" : "2011-12-19 16:01:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148792264934694912",
  "text" : "This week: the best R Language tips. Got your own #rstats tips? Send 'em to RLangTip@revolutionanalytics.com for inclusion in this stream.",
  "id" : 148792264934694912,
  "created_at" : "2011-12-19 15:50:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147769319747629056",
  "text" : "Starting Monday: the best of R Language Tips. Three weeks of the most popular tips from the last 6 months.",
  "id" : 147769319747629056,
  "created_at" : "2011-12-16 20:05:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAS",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "SPSS",
      "indices" : [ 72, 77 ]
    }, {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/XluxHGjO",
      "expanded_url" : "http:\/\/bit.ly\/qyjWr0",
      "display_url" : "bit.ly\/qyjWr0"
    } ]
  },
  "geo" : { },
  "id_str" : "147708106598645760",
  "text" : "R scripts for reading data from files, with equivalent code in #SAS and #SPSS: http:\/\/t.co\/XluxHGjO #rstats",
  "id" : 147708106598645760,
  "created_at" : "2011-12-16 16:02:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/6PNGphia",
      "expanded_url" : "http:\/\/bit.ly\/rDGhlU",
      "display_url" : "bit.ly\/rDGhlU"
    } ]
  },
  "geo" : { },
  "id_str" : "147345670871842817",
  "text" : "List of R debugging tips: http:\/\/t.co\/6PNGphia #rstats",
  "id" : 147345670871842817,
  "created_at" : "2011-12-15 16:02:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146983341340626945",
  "text" : "options(repos=\"http:\/\/cran.revolutionanalytics.com\") [or your local mirror] in .Rprofile prevents #rstats prompting on package install",
  "id" : 146983341340626945,
  "created_at" : "2011-12-14 16:02:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/yNXQn4sK",
      "expanded_url" : "http:\/\/bit.ly\/t0Bi1Y",
      "display_url" : "bit.ly\/t0Bi1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "146635212904865792",
  "text" : "ifelse(b,u,v) where b is a boolean expression, is a vectorized if-then-else construct: http:\/\/t.co\/yNXQn4sK #rstats",
  "id" : 146635212904865792,
  "created_at" : "2011-12-13 16:58:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/ZR72PjcA",
      "expanded_url" : "http:\/\/bit.ly\/qnRaaf",
      "display_url" : "bit.ly\/qnRaaf"
    } ]
  },
  "geo" : { },
  "id_str" : "146258556788817920",
  "text" : "List of R functions and packages for Optimization and Mathematical Programming: http:\/\/t.co\/ZR72PjcA #rstats",
  "id" : 146258556788817920,
  "created_at" : "2011-12-12 16:02:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/T8LkbtaD",
      "expanded_url" : "http:\/\/bit.ly\/unTY2g",
      "display_url" : "bit.ly\/unTY2g"
    } ]
  },
  "geo" : { },
  "id_str" : "145171083774017536",
  "text" : "Google's style guide for writing maintainable R code: http:\/\/t.co\/T8LkbtaD #rstats",
  "id" : 145171083774017536,
  "created_at" : "2011-12-09 16:00:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/cnRpIMn9",
      "expanded_url" : "http:\/\/bit.ly\/u6tXtb",
      "display_url" : "bit.ly\/u6tXtb"
    } ]
  },
  "geo" : { },
  "id_str" : "144808740133142528",
  "text" : "In scripts, wrap code in local(\u007B \u007D) to prevent temporary variables overwriting global data: http:\/\/t.co\/cnRpIMn9 #rstats",
  "id" : 144808740133142528,
  "created_at" : "2011-12-08 16:01:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/SEMXKbyA",
      "expanded_url" : "http:\/\/bit.ly\/n5mCJZ",
      "display_url" : "bit.ly\/n5mCJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "144446316540473344",
  "text" : "Use data(package=\"foo\") to see a list of data sets included in package foo: http:\/\/t.co\/SEMXKbyA #rstats",
  "id" : 144446316540473344,
  "created_at" : "2011-12-07 16:01:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/gB5T3dF6",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "144083896626192384",
  "text" : "Type ?Startup for a description of R's initialization process and how to configure it: http:\/\/t.co\/gB5T3dF6 #rstats",
  "id" : 144083896626192384,
  "created_at" : "2011-12-06 16:00:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/42BtJeYm",
      "expanded_url" : "http:\/\/bit.ly\/ohYFt3",
      "display_url" : "bit.ly\/ohYFt3"
    } ]
  },
  "geo" : { },
  "id_str" : "143721554830823425",
  "text" : "List of R functions and packages for graphic displays, dynamic graphics, graphic devices and visualization: http:\/\/t.co\/42BtJeYm #rstats",
  "id" : 143721554830823425,
  "created_at" : "2011-12-05 16:01:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/ec5DeK5p",
      "expanded_url" : "http:\/\/bit.ly\/uuhyit",
      "display_url" : "bit.ly\/uuhyit"
    } ]
  },
  "geo" : { },
  "id_str" : "142634333834973184",
  "text" : "Use the rasterimage function to insert images (imported from GIFs, etc) into an R chart: http:\/\/t.co\/ec5DeK5p #rstats",
  "id" : 142634333834973184,
  "created_at" : "2011-12-02 16:00:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 0, 14 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141920306615959552",
  "geo" : { },
  "id_str" : "142317152584736768",
  "in_reply_to_user_id" : 69133574,
  "text" : "@hadleywickham Good point - that will be the topic of a future tip. Thanks! ^DS",
  "id" : 142317152584736768,
  "in_reply_to_status_id" : 141920306615959552,
  "created_at" : "2011-12-01 19:00:27 +0000",
  "in_reply_to_screen_name" : "hadleywickham",
  "in_reply_to_user_id_str" : "69133574",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/OvQAVp0Q",
      "expanded_url" : "http:\/\/bit.ly\/sxv5Hx",
      "display_url" : "bit.ly\/sxv5Hx"
    } ]
  },
  "geo" : { },
  "id_str" : "142271960867540994",
  "text" : "file.path is a fast, platform-independent function to create paths to filenames http:\/\/t.co\/OvQAVp0Q #rstats",
  "id" : 142271960867540994,
  "created_at" : "2011-12-01 16:00:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]