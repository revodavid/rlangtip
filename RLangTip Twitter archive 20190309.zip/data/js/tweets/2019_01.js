Grailbird.data.tweets_2019_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/9nS5haVQqB",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/sort",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1091018270428168192",
  "text" : "Sort a vector into decreasing order:\n   sort(x,decreasing=TRUE) #rstats \nhttps:\/\/t.co\/9nS5haVQqB",
  "id" : 1091018270428168192,
  "created_at" : "2019-01-31 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/HpKz5Y8z1W",
      "expanded_url" : "http:\/\/www.birchbison.ca\/blog\/sending-email-from-outlook-in-r",
      "display_url" : "birchbison.ca\/blog\/sending-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1090655890888224769",
  "text" : "How to generate Outlook email notifications from R: https:\/\/t.co\/HpKz5Y8z1W #rstats",
  "id" : 1090655890888224769,
  "created_at" : "2019-01-30 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 171, 178 ]
    } ],
    "urls" : [ {
      "indices" : [ 147, 170 ],
      "url" : "https:\/\/t.co\/RC47MqRS0s",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/Hydrology.html",
      "display_url" : "cran.r-project.org\/web\/views\/Hydr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1090293498987905024",
  "text" : "Hydrology Data and Modeling, a CRAN task view listing packages for the analysis of movement, distribution and quality of water and water resources https:\/\/t.co\/RC47MqRS0s #rstats",
  "id" : 1090293498987905024,
  "created_at" : "2019-01-29 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Mkpf3DNaIT",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/topics\/head",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1089931112493662210",
  "text" : "tail(x, n) shows the last n elements of x if n is positive, all but the first |n| elements if n is negative https:\/\/t.co\/Mkpf3DNaIT #rstats",
  "id" : 1089931112493662210,
  "created_at" : "2019-01-28 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/iD4W9q8XtK",
      "expanded_url" : "http:\/\/rfunction.com\/archives\/2633",
      "display_url" : "rfunction.com\/archives\/2633"
    } ]
  },
  "geo" : { },
  "id_str" : "1088843949370793984",
  "text" : "Get started debugging by adding a browser() call to your function https:\/\/t.co\/iD4W9q8XtK #rstats",
  "id" : 1088843949370793984,
  "created_at" : "2019-01-25 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Machlis",
      "screen_name" : "sharon000",
      "indices" : [ 51, 61 ],
      "id_str" : "10915042",
      "id" : 10915042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 147, 154 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/TWwsVRPRvJ",
      "expanded_url" : "https:\/\/smach.github.io\/R4JournalismBook\/HowDoI.html",
      "display_url" : "smach.github.io\/R4JournalismBo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1088481557327896576",
  "text" : "\"How do I?...\": 200 R idioms for common tasks from @sharon000, author of Practical R for Mass Communication and Journalism https:\/\/t.co\/TWwsVRPRvJ #rstats",
  "id" : 1088481557327896576,
  "created_at" : "2019-01-24 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/GyXO2AThXJ",
      "expanded_url" : "https:\/\/www.edx.org\/course\/introduction-r-data-science-microsoft-dat204x-5",
      "display_url" : "edx.org\/course\/introdu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1088119172297515008",
  "text" : "A free, 4-week online course for beginners: \"Introduction to R for Data Science\" https:\/\/t.co\/GyXO2AThXJ #rstats",
  "id" : 1088119172297515008,
  "created_at" : "2019-01-23 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/QFNOQtBXnp",
      "expanded_url" : "https:\/\/ggplot2.tidyverse.org\/reference\/",
      "display_url" : "ggplot2.tidyverse.org\/reference\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1087756784180154369",
  "text" : "Online help for the ggplot2 graphics package https:\/\/t.co\/QFNOQtBXnp #rstats",
  "id" : 1087756784180154369,
  "created_at" : "2019-01-22 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/WbgkaKYtlB",
      "expanded_url" : "https:\/\/www.quandl.com\/tools\/r",
      "display_url" : "quandl.com\/tools\/r"
    } ]
  },
  "geo" : { },
  "id_str" : "1087394396297822211",
  "text" : "Get financial data and more from Quandl with R https:\/\/t.co\/WbgkaKYtlB #rstats",
  "id" : 1087394396297822211,
  "created_at" : "2019-01-21 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/TRFP0IcGCN",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/kappa",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1086307232214642688",
  "text" : "Compute or estimate the condition number of a matrix: \nkappa(M) \nhttps:\/\/t.co\/TRFP0IcGCN #rstats",
  "id" : 1086307232214642688,
  "created_at" : "2019-01-18 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 180, 187 ]
    } ],
    "urls" : [ {
      "indices" : [ 156, 179 ],
      "url" : "https:\/\/t.co\/w1Y2Zq8IV7",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/survival\/topics\/coxph",
      "display_url" : "rdocumentation.org\/packages\/survi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1085944842142703617",
  "text" : "Got duration data, but some of the events are incomplete? Fit a Cox Proportional Hazards Regression Model with the coxph() function in the survival package https:\/\/t.co\/w1Y2Zq8IV7 #rstats",
  "id" : 1085944842142703617,
  "created_at" : "2019-01-17 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/yqcpAIisUX",
      "expanded_url" : "https:\/\/docs.microsoft.com\/machine-learning-server\/install\/machine-learning-server-in-the-cloud?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/machine-learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1085582454545661952",
  "text" : "How to use R in an Azure VM with Microsoft ML Server: https:\/\/t.co\/yqcpAIisUX #rstats",
  "id" : 1085582454545661952,
  "created_at" : "2019-01-16 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/kXGgJ96yMO",
      "expanded_url" : "https:\/\/remotes.r-lib.org\/",
      "display_url" : "remotes.r-lib.org"
    } ]
  },
  "geo" : { },
  "id_str" : "1085220066789076993",
  "text" : "Lightweight, dependency-free package for installing R packages from Github, etc: remotes https:\/\/t.co\/kXGgJ96yMO #rstats",
  "id" : 1085220066789076993,
  "created_at" : "2019-01-15 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/2EOWOSpQOs",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/topics\/filter",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1084857678692679680",
  "text" : "Calculate running 30-day means of daily values in vector x: filter(x,rep(1\/30,30)) #rstats\nhttps:\/\/t.co\/2EOWOSpQOs",
  "id" : 1084857678692679680,
  "created_at" : "2019-01-14 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/nDWQWzPfeD",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/Extract",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1083770513837613056",
  "text" : "Leave out the mth column of a data frame: \ndF[,-m] \nhttps:\/\/t.co\/nDWQWzPfeD #rstats",
  "id" : 1083770513837613056,
  "created_at" : "2019-01-11 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/zocRloA965",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/fpc\/topics\/clusterboot",
      "display_url" : "rdocumentation.org\/packages\/fpc\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1083408126936793094",
  "text" : "Use clusterboot() in the fpc package to help assess the stability of cluster classifications #rstats https:\/\/t.co\/zocRloA965",
  "id" : 1083408126936793094,
  "created_at" : "2019-01-10 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/lSZ4hb7if2",
      "expanded_url" : "https:\/\/docs.microsoft.com\/azure\/architecture\/reference-architectures\/ai\/realtime-scoring-r?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/azure\/architec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1083045740727939073",
  "text" : "An architecture for deploying real-time predictive models trained with R: https:\/\/t.co\/lSZ4hb7if2  #rstats",
  "id" : 1083045740727939073,
  "created_at" : "2019-01-09 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/nTd47fVFqY",
      "expanded_url" : "https:\/\/cran.rstudio.com\/web\/packages\/showtext\/vignettes\/introduction.html",
      "display_url" : "cran.rstudio.com\/web\/packages\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1082683349385297921",
  "text" : "This vignette for the showtext package explains how to display non-standard fonts in R graphics https:\/\/t.co\/nTd47fVFqY #rstats",
  "id" : 1082683349385297921,
  "created_at" : "2019-01-08 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/5lQKfkZlkC",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/sets",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1082320961637154816",
  "text" : "Use setdiff(x,y) to find the values that appear in x but not in y https:\/\/t.co\/5lQKfkZlkC #rstats",
  "id" : 1082320961637154816,
  "created_at" : "2019-01-07 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Robinson",
      "screen_name" : "drob",
      "indices" : [ 98, 103 ],
      "id_str" : "46245868",
      "id" : 46245868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/R6RtKci8nB",
      "expanded_url" : "https:\/\/gumroad.com\/l\/empirical-bayes",
      "display_url" : "gumroad.com\/l\/empirical-ba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1081233800519127040",
  "text" : "Introduction to Empirical Bayes: Examples from Baseball Statistics, a name-your-own-price book by @drob #rstats https:\/\/t.co\/R6RtKci8nB",
  "id" : 1081233800519127040,
  "created_at" : "2019-01-04 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/nYvB5xXK0i",
      "expanded_url" : "https:\/\/tidyrisk.org\/",
      "display_url" : "tidyrisk.org"
    } ]
  },
  "geo" : { },
  "id_str" : "1080871409499422720",
  "text" : "A suite of R packages for quantitative risk management in finance: https:\/\/t.co\/nYvB5xXK0i #rstats",
  "id" : 1080871409499422720,
  "created_at" : "2019-01-03 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 149, 156 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/3xmZS4XMQg",
      "expanded_url" : "http:\/\/as.Date",
      "display_url" : "as.Date"
    }, {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3xmZS4XMQg",
      "expanded_url" : "http:\/\/as.Date",
      "display_url" : "as.Date"
    }, {
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/hWzcw2tFHq",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/seq.Date",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1080475135411437569",
  "text" : "Generate a sequence of dates: \n\nseq(https:\/\/t.co\/3xmZS4XMQg(\"2000\/1\/1\"),\n    https:\/\/t.co\/3xmZS4XMQg(\"2019\/1\/1\"), \"years\") \n\nhttps:\/\/t.co\/hWzcw2tFHq #rstats",
  "id" : 1080475135411437569,
  "created_at" : "2019-01-02 14:45:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/3LrfnJhEi9",
      "expanded_url" : "https:\/\/jumpingrivers.github.io\/meetingsR\/r-user-groups.html",
      "display_url" : "jumpingrivers.github.io\/meetingsR\/r-us\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1080146633671593986",
  "text" : "New YeaR's resolution: Join a local R user group: https:\/\/t.co\/3LrfnJhEi9 #rstats",
  "id" : 1080146633671593986,
  "created_at" : "2019-01-01 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]