Grailbird.data.tweets_2018_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/UtrP8sqKe4",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/topics\/demo",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1078697084428009472",
  "text" : "Try demo('graphics') ... and type demo() to see other demos available in attached packages https:\/\/t.co\/UtrP8sqKe4 #rstats",
  "id" : 1078697084428009472,
  "created_at" : "2018-12-28 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 139, 146 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/hljYdPNL6D",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/MASS\/topics\/write.matrix",
      "display_url" : "rdocumentation.org\/packages\/MASS\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1078334697359302656",
  "text" : "write.matrix(M) in the built-in \"MASS\" package will print out a matrix, M, without the row and column index labels https:\/\/t.co\/hljYdPNL6D #rstats",
  "id" : 1078334697359302656,
  "created_at" : "2018-12-27 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077972306700443653",
  "text" : "getOption(\"defaultPackages\") lists the packages (in addition to base) loaded at startup #rstats",
  "id" : 1077972306700443653,
  "created_at" : "2018-12-26 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/YqHkfyIRAx",
      "expanded_url" : "https:\/\/cran.r-project.org\/package=animation",
      "display_url" : "cran.r-project.org\/package=animat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077609921473056769",
  "text" : "Seasons Greetings!\n\nlibrary(animation)\ndemo(\"Xmas\") \n\nhttps:\/\/t.co\/YqHkfyIRAx #rstats",
  "id" : 1077609921473056769,
  "created_at" : "2018-12-25 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/zV9k3g9Np5",
      "expanded_url" : "https:\/\/stackoverflow.com\/questions\/19618584\/how-to-show-sample-error-bars-in-the-legend-in-r",
      "display_url" : "stackoverflow.com\/questions\/1961\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077247541144543233",
  "text" : "Plot sample with error bars and color coded legend https:\/\/t.co\/zV9k3g9Np5 #rstats",
  "id" : 1077247541144543233,
  "created_at" : "2018-12-24 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/EsZsJhiFXk",
      "expanded_url" : "https:\/\/cloud.r-project.org\/doc\/manuals\/r-release\/R-intro.html",
      "display_url" : "cloud.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076160371696775169",
  "text" : "The official \"Introduction to R\" manual, updated with every R release https:\/\/t.co\/EsZsJhiFXk #rstats",
  "id" : 1076160371696775169,
  "created_at" : "2018-12-21 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/usvgdAWkqy",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/rle",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075797988323188736",
  "text" : "rle(x) (\"run-length encoding\") computes the lengths of runs of equal values in a vector https:\/\/t.co\/usvgdAWkqy #rstats",
  "id" : 1075797988323188736,
  "created_at" : "2018-12-20 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/CXszLDsSBb",
      "expanded_url" : "https:\/\/docs.microsoft.com\/azure\/batch\/tutorial-r-doazureparallel?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/azure\/batch\/tu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075435594761687040",
  "text" : "Tutorial: Run a parallel R simulation in an Azure cluster with the doAzureParallel package https:\/\/t.co\/CXszLDsSBb #rstats",
  "id" : 1075435594761687040,
  "created_at" : "2018-12-19 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/nDWQWA6QDd",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/topics\/Extract",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075073204140630018",
  "text" : "To select a column from a matrix and keep it as a column matrix, not a vector: X[,1,drop=FALSE] https:\/\/t.co\/nDWQWA6QDd #rstats",
  "id" : 1075073204140630018,
  "created_at" : "2018-12-18 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/lSjtG9nmPW",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2009\/02\/how-to-choose-a-random-number-in-r.html",
      "display_url" : "blog.revolutionanalytics.com\/2009\/02\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074710816476127232",
  "text" : "How to generate random numbers in R: https:\/\/t.co\/lSjtG9nmPW #rstats",
  "id" : 1074710816476127232,
  "created_at" : "2018-12-17 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 144, 151 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/NZr8ZLFosi",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/scan",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073623652531363843",
  "text" : "The scan() function is useful for reading short sequences of data into a vector or list from the console or from a file https:\/\/t.co\/NZr8ZLFosi #rstats",
  "id" : 1073623652531363843,
  "created_at" : "2018-12-14 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/dWkX91R5tA",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/datasets\/versions\/3.5.1",
      "display_url" : "rdocumentation.org\/packages\/datas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073261264552517632",
  "text" : "Index of datasets included with R https:\/\/t.co\/dWkX91R5tA #rstats",
  "id" : 1073261264552517632,
  "created_at" : "2018-12-13 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Uyop4Hy9xE",
      "expanded_url" : "https:\/\/cloud.r-project.org\/web\/packages\/AzureRMR\/vignettes\/intro.html",
      "display_url" : "cloud.r-project.org\/web\/packages\/A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072898882860793858",
  "text" : "Introduction to AzureRMR, a package for managing Azure resources from R https:\/\/t.co\/Uyop4Hy9xE #rstats",
  "id" : 1072898882860793858,
  "created_at" : "2018-12-12 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 138, 145 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/SHC2ebopl5",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/readr\/versions\/1.2.1\/topics\/parse_datetime",
      "display_url" : "rdocumentation.org\/packages\/readr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072536488930406401",
  "text" : "Use readr::parse_datetime to convert text representations of dates and times (e.g. \"4:30 PM\") to a POSIXct vector https:\/\/t.co\/SHC2ebopl5 #rstats",
  "id" : 1072536488930406401,
  "created_at" : "2018-12-11 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/yUQyBXfBY3",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Round",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072174107209408513",
  "text" : "The \"round\" function uses the \"round-to-even\" rule. round(3.5) and round(4.5) are both 4 https:\/\/t.co\/yUQyBXfBY3 #rstats",
  "id" : 1072174107209408513,
  "created_at" : "2018-12-10 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/22zNlMOw8E",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/.Machine",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1071086937363095557",
  "text" : "Find the smallest positive floating-point number x such 1 + x != 1 on your computer with the variable .Machine https:\/\/t.co\/22zNlMOw8E #rstats",
  "id" : 1071086937363095557,
  "created_at" : "2018-12-07 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/zGPJ4FNvCF",
      "expanded_url" : "https:\/\/cloud.r-project.org\/doc\/contrib\/Faraway-PRA.pdf",
      "display_url" : "cloud.r-project.org\/doc\/contrib\/Fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070724549371682818",
  "text" : "Free text: \"Practical Regression and ANOVA with R\": https:\/\/t.co\/zGPJ4FNvCF #rstats",
  "id" : 1070724549371682818,
  "created_at" : "2018-12-06 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/2IPtgm0giE",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/visualstudio\/rtvs\/?view=vs-2017&WT.mc_id=RLangtip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/en-us\/visualst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070362166702702597",
  "text" : "RTVS is a free extension for Visual Studio for R programming and debugging https:\/\/t.co\/2IPtgm0giE #rstats",
  "id" : 1070362166702702597,
  "created_at" : "2018-12-05 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/GA58cjmGXj",
      "expanded_url" : "https:\/\/github.com\/thomasp85\/gganimate\/wiki",
      "display_url" : "github.com\/thomasp85\/ggan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069999778182950913",
  "text" : "If you want to create animated charts, check out this overview of the gganimate package with lots of examples https:\/\/t.co\/GA58cjmGXj #rstats",
  "id" : 1069999778182950913,
  "created_at" : "2018-12-04 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/KXQRExKwfH",
      "expanded_url" : "https:\/\/www.r-project.org\/doc\/R-FDA.pdf",
      "display_url" : "r-project.org\/doc\/R-FDA.pdf"
    } ]
  },
  "geo" : { },
  "id_str" : "1069637392498335744",
  "text" : "Guidance for use of #rstats in regulated clinical trial environments (incl. for FDA): https:\/\/t.co\/KXQRExKwfH #rstats",
  "id" : 1069637392498335744,
  "created_at" : "2018-12-03 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]