Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/ngiokhZeEl",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2011\/10\/putting-the-r-in-halloween.html",
      "display_url" : "blog.revolutionanalytics.com\/2011\/10\/puttin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793120365027483648",
  "text" : "Create a Halloween card with #rstats: https:\/\/t.co\/ngiokhZeEl",
  "id" : 793120365027483648,
  "created_at" : "2016-10-31 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/8XQf5oi0E6",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.3.1\/topics\/polygon",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792037180130471938",
  "text" : "polygon(x,y) will draw a polygon whose vertices are given by the vectors x and y https:\/\/t.co\/8XQf5oi0E6 #rstats",
  "id" : 792037180130471938,
  "created_at" : "2016-10-28 16:15:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/PVhanoSKBO",
      "expanded_url" : "http:\/\/hilite.me\/",
      "display_url" : "hilite.me"
    } ]
  },
  "geo" : { },
  "id_str" : "791670796892540928",
  "text" : "Simple source code beautifier for HTML blog posts etc. Choose \"S\" for #rstats code https:\/\/t.co\/PVhanoSKBO",
  "id" : 791670796892540928,
  "created_at" : "2016-10-27 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RTVS",
      "screen_name" : "RT4VS",
      "indices" : [ 30, 36 ],
      "id_str" : "706175863113428992",
      "id" : 706175863113428992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/rjiYAhs7tK",
      "expanded_url" : "https:\/\/microsoft.github.io\/RTVS-docs\/sqlserver.html",
      "display_url" : "microsoft.github.io\/RTVS-docs\/sqls\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791308408280330240",
  "text" : "Use R Tools for Visual Studio @RT4VS to write R code as a SQL Server 2016 stored procedure https:\/\/t.co\/rjiYAhs7tK #rstats",
  "id" : 791308408280330240,
  "created_at" : "2016-10-26 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/UEJIjr9JAi",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/jitter",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790946023480983552",
  "text" : "Use jitter(x) \u007Bbase\u007D to add some noise to your data. Very useful for dealing with overplotting. #rstats https:\/\/t.co\/UEJIjr9JAi",
  "id" : 790946023480983552,
  "created_at" : "2016-10-25 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger D. Peng",
      "screen_name" : "rdpeng",
      "indices" : [ 49, 56 ],
      "id_str" : "9308212",
      "id" : 9308212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/FNb2d2vgFd",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2012\/12\/coursera-videos.html",
      "display_url" : "blog.revolutionanalytics.com\/2012\/12\/course\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790583633224409090",
  "text" : "A ten-hour video introduction to R, presented by @rdpeng https:\/\/t.co\/FNb2d2vgFd #rstats",
  "id" : 790583633224409090,
  "created_at" : "2016-10-24 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/Vp5kHZ2Zys",
      "expanded_url" : "http:\/\/bit.ly\/ISiZD6",
      "display_url" : "bit.ly\/ISiZD6"
    } ]
  },
  "geo" : { },
  "id_str" : "789496485121519616",
  "text" : "Browse the archive of R tips at https:\/\/t.co\/Vp5kHZ2Zys #rstats",
  "id" : 789496485121519616,
  "created_at" : "2016-10-21 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/FL2A6hGcyj",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Special",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "789134087122452480",
  "text" : "choose(n, r) returns the binomial coefficient; lchoose(n, r), the logarithm of the binomial coefficient https:\/\/t.co\/FL2A6hGcyj #rstats",
  "id" : 789134087122452480,
  "created_at" : "2016-10-20 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/hzG9NCmNnO",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/foreach\/versions\/1.4.3\/topics\/foreach",
      "display_url" : "rdocumentation.org\/packages\/forea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788771697860247553",
  "text" : "Use the foreach function can to speed up loops by running iterations in parallel on multi-core machines: https:\/\/t.co\/hzG9NCmNnO #rstats",
  "id" : 788771697860247553,
  "created_at" : "2016-10-19 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/lH6atLV5NO",
      "expanded_url" : "https:\/\/cloud.r-project.org",
      "display_url" : "cloud.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "788409317275922433",
  "text" : "Download R from https:\/\/t.co\/lH6atLV5NO. It automatically chooses a fast, nearby mirror for you. #rstats",
  "id" : 788409317275922433,
  "created_at" : "2016-10-18 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/yUQyBXfBY3",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Round",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788046922619682818",
  "text" : "The \"round\" function uses the \"round-to-even\" rule. round(3.5) and round(4.5) are both 4 https:\/\/t.co\/yUQyBXfBY3 #rstats",
  "id" : 788046922619682818,
  "created_at" : "2016-10-17 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/63lEe5ZyP2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/NumericConstants",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786959753729679360",
  "text" : "You can use hexadecimal numbers in R by starting with 0x, eg 0xDEADBEEF https:\/\/t.co\/63lEe5ZyP2 #rstats",
  "id" : 786959753729679360,
  "created_at" : "2016-10-14 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/IMPVrin60K",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/NaturalLanguageProcessing.html",
      "display_url" : "cran.r-project.org\/web\/views\/Natu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786597376567963649",
  "text" : "List of R functions and packages for text analysis and natural language processing: https:\/\/t.co\/IMPVrin60K #rstats",
  "id" : 786597376567963649,
  "created_at" : "2016-10-13 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/OboWsyZ4ro",
      "expanded_url" : "http:\/\/www.johndcook.com\/blog\/r_excel_clipboard\/",
      "display_url" : "johndcook.com\/blog\/r_excel_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786234988236795905",
  "text" : "Move data between R and Excel via the Windows clipboard: https:\/\/t.co\/OboWsyZ4ro #rstats",
  "id" : 786234988236795905,
  "created_at" : "2016-10-12 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/jxcKF2OgtL",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/SASxport\/",
      "display_url" : "mran.microsoft.com\/package\/SASxpo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785872598429163520",
  "text" : "Use the SASxport package to read\/write data in the XPORT file format (req by FDA for clinical submissions) https:\/\/t.co\/jxcKF2OgtL #rstats",
  "id" : 785872598429163520,
  "created_at" : "2016-10-11 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785510204267831297",
  "text" : "The arrow assignment operator works in both directions. This is valid #rstats syntax: x &lt;- value -&gt; y",
  "id" : 785510204267831297,
  "created_at" : "2016-10-10 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/ZwULkZqpQc",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/compiler\/versions\/3.3.1\/topics\/compile",
      "display_url" : "rdocumentation.org\/packages\/compi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784423056907218944",
  "text" : "To speed up an R function, use cmpfun to byte-compile it: https:\/\/t.co\/ZwULkZqpQc #rstats",
  "id" : 784423056907218944,
  "created_at" : "2016-10-07 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/8AvIWZOgWQ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/paste",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784060663501058048",
  "text" : "The paste0 function concatenates strings back-to-back, without any separating characters https:\/\/t.co\/8AvIWZOgWQ #rstats",
  "id" : 784060663501058048,
  "created_at" : "2016-10-06 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/AMzfaXPpjC",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/scaler-getting-started",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783698283713527808",
  "text" : "Getting stated with RevoScaleR: package of big-data functions in Microsoft R Client &amp; Server https:\/\/t.co\/AMzfaXPpjC #rstats",
  "id" : 783698283713527808,
  "created_at" : "2016-10-05 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/o9GENQGju3",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/ggmap\/versions\/2.6.1\/topics\/geocode",
      "display_url" : "rdocumentation.org\/packages\/ggmap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783340910255886336",
  "text" : "Convert addresses to latitude\/longitude and plot them on a map with the ggmap package https:\/\/t.co\/o9GENQGju3 #rstats",
  "id" : 783340910255886336,
  "created_at" : "2016-10-04 16:20:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/tNBB7XP2Dg",
      "expanded_url" : "http:\/\/www.johndcook.com\/blog\/2008\/10\/23\/five-kinds-of-r-language-subscripts\/",
      "display_url" : "johndcook.com\/blog\/2008\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782973490852835329",
  "text" : "Five ways to subscript data in R https:\/\/t.co\/tNBB7XP2Dg #rstats",
  "id" : 782973490852835329,
  "created_at" : "2016-10-03 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]