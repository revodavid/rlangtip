Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ZdrX4MbsLf",
      "expanded_url" : "http:\/\/ow.ly\/TM00s",
      "display_url" : "ow.ly\/TM00s"
    } ]
  },
  "geo" : { },
  "id_str" : "660125636443418624",
  "text" : "Use str(obj) to display the components of any object in human-readable format. https:\/\/t.co\/ZdrX4MbsLf #rstats",
  "id" : 660125636443418624,
  "created_at" : "2015-10-30 16:06:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ua5VdqOCvE",
      "expanded_url" : "http:\/\/bit.ly\/Qs64Kj",
      "display_url" : "bit.ly\/Qs64Kj"
    } ]
  },
  "geo" : { },
  "id_str" : "659763201509314560",
  "text" : "The ddply function (in package plyr) makes aggregating rows of data (e.g. medians by group) simpler: https:\/\/t.co\/ua5VdqOCvE #rstats",
  "id" : 659763201509314560,
  "created_at" : "2015-10-29 16:06:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/p039xNpZUE",
      "expanded_url" : "http:\/\/bit.ly\/SAFtuh",
      "display_url" : "bit.ly\/SAFtuh"
    } ]
  },
  "geo" : { },
  "id_str" : "659400755204521984",
  "text" : "Customize your R environment with these suggestions for your .Rprofile: https:\/\/t.co\/p039xNpZUE #rstats",
  "id" : 659400755204521984,
  "created_at" : "2015-10-28 16:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/3u7UdbtS3r",
      "expanded_url" : "http:\/\/bit.ly\/1OMCKAT",
      "display_url" : "bit.ly\/1OMCKAT"
    } ]
  },
  "geo" : { },
  "id_str" : "659038352595886081",
  "text" : "smooth.spline(x,y) in the stats package will fit a cubic smoothing spline to your data. https:\/\/t.co\/3u7UdbtS3r #rstats",
  "id" : 659038352595886081,
  "created_at" : "2015-10-27 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ohjuwniU5x",
      "expanded_url" : "http:\/\/bit.ly\/1LLkbHd",
      "display_url" : "bit.ly\/1LLkbHd"
    } ]
  },
  "geo" : { },
  "id_str" : "658675998964228096",
  "text" : "confint() in the MASS package will compute confidence intervals for glm models https:\/\/t.co\/ohjuwniU5x #rstats",
  "id" : 658675998964228096,
  "created_at" : "2015-10-26 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/P5Vn5lgSrN",
      "expanded_url" : "https:\/\/github.com\/mrzool\/letter-boilerplate",
      "display_url" : "github.com\/mrzool\/letter-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658646104788086784",
  "text" : "Generate letters from markdown through LaTeX\nhttps:\/\/t.co\/P5Vn5lgSrN",
  "id" : 658646104788086784,
  "created_at" : "2015-10-26 14:07:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 129, 152 ],
      "url" : "https:\/\/t.co\/29fzj1Z058",
      "expanded_url" : "http:\/\/bit.ly\/1xLK5TX",
      "display_url" : "bit.ly\/1xLK5TX"
    } ]
  },
  "geo" : { },
  "id_str" : "657588938920587264",
  "text" : "The operator &lt;&lt;- does global assignment. If you think you need &lt;&lt;-, think again. -- Patrick Burns, The R Inferno p35 https:\/\/t.co\/29fzj1Z058",
  "id" : 657588938920587264,
  "created_at" : "2015-10-23 16:06:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HYALRrPVqi",
      "expanded_url" : "http:\/\/bit.ly\/1rE5Hlg",
      "display_url" : "bit.ly\/1rE5Hlg"
    } ]
  },
  "geo" : { },
  "id_str" : "657226437607452672",
  "text" : "Use the function factor() to encode a variable as a \"factor\" or categorical variable. https:\/\/t.co\/HYALRrPVqi #rstats",
  "id" : 657226437607452672,
  "created_at" : "2015-10-22 16:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/nCXHIbJRPZ",
      "expanded_url" : "http:\/\/bit.ly\/1Pn3Nm4",
      "display_url" : "bit.ly\/1Pn3Nm4"
    } ]
  },
  "geo" : { },
  "id_str" : "656864096080515072",
  "text" : "Consider train() in the \u007Bcaret\u007D package to trian and tune your machine learning models https:\/\/t.co\/nCXHIbJRPZ #rstats",
  "id" : 656864096080515072,
  "created_at" : "2015-10-21 16:06:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/FPvDSWjmh4",
      "expanded_url" : "http:\/\/bit.ly\/1GKzca5",
      "display_url" : "bit.ly\/1GKzca5"
    } ]
  },
  "geo" : { },
  "id_str" : "656501700455452673",
  "text" : "Use cat() to show what your code is doing eg: cat(\"iteration = \", iter &lt;- iter + 1, \"\\n\") https:\/\/t.co\/FPvDSWjmh4 #rstats",
  "id" : 656501700455452673,
  "created_at" : "2015-10-20 16:06:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/aRjdgpzRBX",
      "expanded_url" : "http:\/\/bit.ly\/1jI8Znv",
      "display_url" : "bit.ly\/1jI8Znv"
    } ]
  },
  "geo" : { },
  "id_str" : "656139273800962048",
  "text" : "Be sure to bookmark the R Language Definition page: http:\/\/t.co\/aRjdgpzRBX #rstats",
  "id" : 656139273800962048,
  "created_at" : "2015-10-19 16:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/3dbyKEEA9U",
      "expanded_url" : "http:\/\/bit.ly\/17saavu",
      "display_url" : "bit.ly\/17saavu"
    } ]
  },
  "geo" : { },
  "id_str" : "655052136502398976",
  "text" : "Find out what files are in your working directory with dir(), also list.files()  #rstats http:\/\/t.co\/3dbyKEEA9U",
  "id" : 655052136502398976,
  "created_at" : "2015-10-16 16:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 60, 70 ],
      "id_str" : "17522755",
      "id" : 17522755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/XKNV33hG58",
      "expanded_url" : "http:\/\/bit.ly\/OV6lDY",
      "display_url" : "bit.ly\/OV6lDY"
    } ]
  },
  "geo" : { },
  "id_str" : "654689749739794435",
  "text" : "Regular expressions in R http:\/\/t.co\/XKNV33hG58 #rstats (by @johndcook)",
  "id" : 654689749739794435,
  "created_at" : "2015-10-15 16:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/3tED1rEWqS",
      "expanded_url" : "http:\/\/bit.ly\/1jTGzr2",
      "display_url" : "bit.ly\/1jTGzr2"
    } ]
  },
  "geo" : { },
  "id_str" : "654327342777679872",
  "text" : "The function diana() \u007Bcluster\u007D computes a divisive hierarchial cluster of a data set. http:\/\/t.co\/3tED1rEWqS #rstats",
  "id" : 654327342777679872,
  "created_at" : "2015-10-14 16:06:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/BfZRIO526y",
      "expanded_url" : "http:\/\/bit.ly\/NmbZye",
      "display_url" : "bit.ly\/NmbZye"
    } ]
  },
  "geo" : { },
  "id_str" : "653964927254810624",
  "text" : "Convert a design matrix (indicator matrix) back into a factor variable: http:\/\/t.co\/BfZRIO526y #rstats (via @therealprotonk)",
  "id" : 653964927254810624,
  "created_at" : "2015-10-13 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/grzP5aCFP4",
      "expanded_url" : "http:\/\/bit.ly\/1ZlT3rO",
      "display_url" : "bit.ly\/1ZlT3rO"
    } ]
  },
  "geo" : { },
  "id_str" : "653602492580818944",
  "text" : "The function dpih() \u007BKernSmooth\u007D uses the direct plug-in methodology to select the bin width of a histogram. http:\/\/t.co\/grzP5aCFP4 #rstats",
  "id" : 653602492580818944,
  "created_at" : "2015-10-12 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/u3VfhOv91N",
      "expanded_url" : "http:\/\/bit.ly\/pRciwj",
      "display_url" : "bit.ly\/pRciwj"
    } ]
  },
  "geo" : { },
  "id_str" : "652515448601362433",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: http:\/\/t.co\/u3VfhOv91N #rstats",
  "id" : 652515448601362433,
  "created_at" : "2015-10-09 16:06:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/whT3RtWJdf",
      "expanded_url" : "http:\/\/bit.ly\/rgwKt9",
      "display_url" : "bit.ly\/rgwKt9"
    } ]
  },
  "geo" : { },
  "id_str" : "652152984860692481",
  "text" : "Use lsf.str(\"package:foo\") to see a list all the functions in package foo: http:\/\/t.co\/whT3RtWJdf #rstats",
  "id" : 652152984860692481,
  "created_at" : "2015-10-08 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/FeBgUkIqW2",
      "expanded_url" : "http:\/\/bit.ly\/14rinAX",
      "display_url" : "bit.ly\/14rinAX"
    } ]
  },
  "geo" : { },
  "id_str" : "651790597892763648",
  "text" : "#rstats Get a list of the arguments for a function: formals(func) http:\/\/t.co\/FeBgUkIqW2",
  "id" : 651790597892763648,
  "created_at" : "2015-10-07 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/MCNO3cwW38",
      "expanded_url" : "http:\/\/bit.ly\/1QPPeVC",
      "display_url" : "bit.ly\/1QPPeVC"
    } ]
  },
  "geo" : { },
  "id_str" : "651428214603186176",
  "text" : "rm(list=ls()) will remove almost everything from your working environment. Be careful! Be sure! http:\/\/t.co\/MCNO3cwW38 #rstats",
  "id" : 651428214603186176,
  "created_at" : "2015-10-06 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/kv6j4s9972",
      "expanded_url" : "http:\/\/bit.ly\/1Odifge",
      "display_url" : "bit.ly\/1Odifge"
    } ]
  },
  "geo" : { },
  "id_str" : "651065767480459264",
  "text" : "The Cauchy distribution has no Expectation! Use rcauchy() to generate pseudorandom samples. http:\/\/t.co\/kv6j4s9972 #stats",
  "id" : 651065767480459264,
  "created_at" : "2015-10-05 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/8hNMrJ9OQS",
      "expanded_url" : "http:\/\/bit.ly\/N1IVBw",
      "display_url" : "bit.ly\/N1IVBw"
    } ]
  },
  "geo" : { },
  "id_str" : "649978640017543169",
  "text" : "How to use the ifelse function to dichotomize a variable [video]: http:\/\/t.co\/8hNMrJ9OQS #rstats",
  "id" : 649978640017543169,
  "created_at" : "2015-10-02 16:05:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 76, 90 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/8uCZsUx4s8",
      "expanded_url" : "http:\/\/bit.ly\/ZElzlW",
      "display_url" : "bit.ly\/ZElzlW"
    } ]
  },
  "geo" : { },
  "id_str" : "649616331533328384",
  "text" : "How-do-you-you-determine-the-namespace-of-a-function http:\/\/t.co\/8uCZsUx4s8 @joshua_ulrich",
  "id" : 649616331533328384,
  "created_at" : "2015-10-01 16:06:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]