Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/GUhxRps0",
      "expanded_url" : "http:\/\/bit.ly\/qqUXhc",
      "display_url" : "bit.ly\/qqUXhc"
    } ]
  },
  "geo" : { },
  "id_str" : "131022841608024064",
  "text" : "List of R functions and packages to support reproducible research: http:\/\/t.co\/GUhxRps0 #rstats",
  "id" : 131022841608024064,
  "created_at" : "2011-10-31 15:00:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/gB5T3dF6",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "129935646604275712",
  "text" : "Create a file called .Rprofile of commands to run each time R starts. Good for setting options, etc. Example: http:\/\/t.co\/gB5T3dF6 #rstats",
  "id" : 129935646604275712,
  "created_at" : "2011-10-28 15:00:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/tj1Cubhm",
      "expanded_url" : "http:\/\/bit.ly\/vlOimZ",
      "display_url" : "bit.ly\/vlOimZ"
    } ]
  },
  "geo" : { },
  "id_str" : "129573245501440000",
  "text" : "Public data sets available online to use with R: http:\/\/t.co\/tj1Cubhm #rstats",
  "id" : 129573245501440000,
  "created_at" : "2011-10-27 15:00:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129210886668812290",
  "text" : "Collecting results in a loop? Pre-allocate a vector res=rep(0,N) and assign res[i]=val. Avoid extending in the loop: res=c(res,val) #rstats",
  "id" : 129210886668812290,
  "created_at" : "2011-10-26 15:00:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/cDDs63vc",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "128848761567985666",
  "text" : "NA's have special handling for logical comparisons. NA & FALSE is always FALSE, NA | TRUE is TRUE. http:\/\/t.co\/cDDs63vc #rstats",
  "id" : 128848761567985666,
  "created_at" : "2011-10-25 15:01:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/8PKUOt4s",
      "expanded_url" : "http:\/\/bit.ly\/nFTz0V",
      "display_url" : "bit.ly\/nFTz0V"
    } ]
  },
  "geo" : { },
  "id_str" : "128486159490875392",
  "text" : "List of R functions and packages for Machine Learning & Statistical Learning: http:\/\/t.co\/8PKUOt4s #rstats",
  "id" : 128486159490875392,
  "created_at" : "2011-10-24 15:01:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/6Tb64u3N",
      "expanded_url" : "http:\/\/bit.ly\/n2rmBo",
      "display_url" : "bit.ly\/n2rmBo"
    } ]
  },
  "geo" : { },
  "id_str" : "127398933524787201",
  "text" : "Reserved words that can't be used as object names: if, while, for, next, TRUE, and several others listed at http:\/\/t.co\/6Tb64u3N #rstats",
  "id" : 127398933524787201,
  "created_at" : "2011-10-21 15:00:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/wXKq4EMx",
      "expanded_url" : "http:\/\/bit.ly\/nLuDqT",
      "display_url" : "bit.ly\/nLuDqT"
    } ]
  },
  "geo" : { },
  "id_str" : "127036535311826945",
  "text" : "Download and install the latest versions of your R packages with the updates.packages() function: http:\/\/t.co\/wXKq4EMx #rstats",
  "id" : 127036535311826945,
  "created_at" : "2011-10-20 15:00:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/hanMx0EC",
      "expanded_url" : "http:\/\/bit.ly\/o0z4Mh",
      "display_url" : "bit.ly\/o0z4Mh"
    } ]
  },
  "geo" : { },
  "id_str" : "126674192732127232",
  "text" : "The standard random number generator in R is the Mersenne Twister, but other RNGs are available: http:\/\/t.co\/hanMx0EC #rstats",
  "id" : 126674192732127232,
  "created_at" : "2011-10-19 15:00:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 0, 14 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126319585061376000",
  "geo" : { },
  "id_str" : "126333422787502080",
  "in_reply_to_user_id" : 69133574,
  "text" : "@hadleywickham Thanks. The double slash was there (and here: \\ ) but it got eaten in the delivery process.",
  "id" : 126333422787502080,
  "in_reply_to_status_id" : 126319585061376000,
  "created_at" : "2011-10-18 16:26:49 +0000",
  "in_reply_to_screen_name" : "hadleywickham",
  "in_reply_to_user_id_str" : "69133574",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notanrstatstip",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126326499971317760",
  "text" : "(Last tweet corrected. If you want to include slash-escape codes in a Tweet, don't use HootSuite. #notanrstatstip.)",
  "id" : 126326499971317760,
  "created_at" : "2011-10-18 15:59:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126325844795858945",
  "text" : "To include a quote character in a string, use \\\" (see ?Quotes for a list of other special chars). Use \\\\ for a single backslash. #rstats",
  "id" : 126325844795858945,
  "created_at" : "2011-10-18 15:56:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/AvOr2ke9",
      "expanded_url" : "http:\/\/bit.ly\/r8OL7C",
      "display_url" : "bit.ly\/r8OL7C"
    } ]
  },
  "geo" : { },
  "id_str" : "125949462010019841",
  "text" : "List of R functions and packages for Bayesian inference: http:\/\/t.co\/AvOr2ke9 #rstats",
  "id" : 125949462010019841,
  "created_at" : "2011-10-17 15:01:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Polley",
      "screen_name" : "ecpolley",
      "indices" : [ 3, 12 ],
      "id_str" : "15086683",
      "id" : 15086683
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 14, 23 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124901602854309889",
  "text" : "RT @ecpolley: @RLangTip Also avoid:\nT &lt;- FALSE\nF &lt;- TRUE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "124862290519531520",
    "geo" : { },
    "id_str" : "124863014125060096",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip Also avoid:\nT &lt;- FALSE\nF &lt;- TRUE",
    "id" : 124863014125060096,
    "in_reply_to_status_id" : 124862290519531520,
    "created_at" : "2011-10-14 15:03:57 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Eric Polley",
      "screen_name" : "ecpolley",
      "protected" : false,
      "id_str" : "15086683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3635984730\/6d462dee6cf1ccaa98a6c7f712bcd54e_normal.jpeg",
      "id" : 15086683,
      "verified" : false
    }
  },
  "id" : 124901602854309889,
  "created_at" : "2011-10-14 17:37:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124862290519531520",
  "text" : "Just because you *can* redefine built-in functions in R doesn't mean it's a good idea. Avoid function names like c, t, sum etc. #rstats",
  "id" : 124862290519531520,
  "created_at" : "2011-10-14 15:01:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/CYTgWtxD",
      "expanded_url" : "http:\/\/bit.ly\/nx2QWZ",
      "display_url" : "bit.ly\/nx2QWZ"
    } ]
  },
  "geo" : { },
  "id_str" : "124523478194995200",
  "text" : "For highest-quality R graphics on the web, use the SVG device (but doesn't work with older browsers). http:\/\/t.co\/CYTgWtxD #rstats",
  "id" : 124523478194995200,
  "created_at" : "2011-10-13 16:34:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/tFXsiJZi",
      "expanded_url" : "http:\/\/bit.ly\/pxeDBp",
      "display_url" : "bit.ly\/pxeDBp"
    } ]
  },
  "geo" : { },
  "id_str" : "124137412334075904",
  "text" : "Download and install new packages from the R command line with the install.packages function: http:\/\/t.co\/tFXsiJZi #rstats",
  "id" : 124137412334075904,
  "created_at" : "2011-10-12 15:00:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/VUgtPaNt",
      "expanded_url" : "http:\/\/bit.ly\/pRciwj",
      "display_url" : "bit.ly\/pRciwj"
    } ]
  },
  "geo" : { },
  "id_str" : "123775068458336257",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: http:\/\/t.co\/VUgtPaNt #rstats",
  "id" : 123775068458336257,
  "created_at" : "2011-10-11 15:00:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/gpdzBUJg",
      "expanded_url" : "http:\/\/bit.ly\/pe0KO2",
      "display_url" : "bit.ly\/pe0KO2"
    } ]
  },
  "geo" : { },
  "id_str" : "123412767515484161",
  "text" : "List of R functions and packages for clinical trial design, monitoring and analysis: http:\/\/t.co\/gpdzBUJg #rstats",
  "id" : 123412767515484161,
  "created_at" : "2011-10-10 15:01:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/vvCrYcaH",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "122325500411641857",
  "text" : "Negative indexes remove elements from a vector. x[-1] is x without the first element. http:\/\/t.co\/vvCrYcaH #rstats",
  "id" : 122325500411641857,
  "created_at" : "2011-10-07 15:00:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hadoop",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/7bh1faFf",
      "expanded_url" : "http:\/\/bit.ly\/qCEtn7",
      "display_url" : "bit.ly\/qCEtn7"
    } ]
  },
  "geo" : { },
  "id_str" : "121963125019918337",
  "text" : "Write map-reduce tasks for big data in #Hadoop with the rmr package: http:\/\/t.co\/7bh1faFf #rstats",
  "id" : 121963125019918337,
  "created_at" : "2011-10-06 15:00:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/YPa1pyKI",
      "expanded_url" : "http:\/\/bit.ly\/orRZFu",
      "display_url" : "bit.ly\/orRZFu"
    }, {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/dgrleOzH",
      "expanded_url" : "http:\/\/bit.ly\/oMhDcj",
      "display_url" : "bit.ly\/oMhDcj"
    } ]
  },
  "geo" : { },
  "id_str" : "121600729008971777",
  "text" : "Automated variable selection for regressions: \"step\" http:\/\/t.co\/YPa1pyKI and \"leaps\" http:\/\/t.co\/dgrleOzH #rstats",
  "id" : 121600729008971777,
  "created_at" : "2011-10-05 15:00:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121238325028847617",
  "text" : "In R scripts that access files, use relative (not absolute) file names to make the script portable. #rstats",
  "id" : 121238325028847617,
  "created_at" : "2011-10-04 15:00:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/oRXTNAON",
      "expanded_url" : "http:\/\/bit.ly\/mVysYe",
      "display_url" : "bit.ly\/mVysYe"
    } ]
  },
  "geo" : { },
  "id_str" : "120876007896006657",
  "text" : "List of R functions and packages for finance and risk management: http:\/\/t.co\/oRXTNAON #rstats",
  "id" : 120876007896006657,
  "created_at" : "2011-10-03 15:01:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]