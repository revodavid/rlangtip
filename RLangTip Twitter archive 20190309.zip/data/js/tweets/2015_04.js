Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dJ0bNe884s",
      "expanded_url" : "http:\/\/bit.ly\/Hft5M9",
      "display_url" : "bit.ly\/Hft5M9"
    } ]
  },
  "geo" : { },
  "id_str" : "593808443095527425",
  "text" : "Avoid namespace clashes! Use :: to specify an object within a specific package, e.g. MASS::mvnorm #rstats http:\/\/t.co\/dJ0bNe884s",
  "id" : 593808443095527425,
  "created_at" : "2015-04-30 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iBartomeus",
      "screen_name" : "ibartomeus",
      "indices" : [ 124, 135 ],
      "id_str" : "14226594",
      "id" : 14226594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/XfJiBVDTY1",
      "expanded_url" : "http:\/\/bit.ly\/18DAoic",
      "display_url" : "bit.ly\/18DAoic"
    } ]
  },
  "geo" : { },
  "id_str" : "593447334798823424",
  "text" : "Avoid extrapolating beyond the data, use clip to draw the abline just in the data region #rstats http:\/\/t.co\/XfJiBVDTY1 via @ibartomeus",
  "id" : 593447334798823424,
  "created_at" : "2015-04-29 16:10:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/y2wIwwHDl4",
      "expanded_url" : "http:\/\/bit.ly\/1bFdTOA",
      "display_url" : "bit.ly\/1bFdTOA"
    } ]
  },
  "geo" : { },
  "id_str" : "593083696984502272",
  "text" : "Use the MRAN site to explore CRAN Task Views http:\/\/t.co\/y2wIwwHDl4 #rstats",
  "id" : 593083696984502272,
  "created_at" : "2015-04-28 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/RzBdakFiid",
      "expanded_url" : "http:\/\/bit.ly\/1Hh6z7d",
      "display_url" : "bit.ly\/1Hh6z7d"
    } ]
  },
  "geo" : { },
  "id_str" : "592721305604087808",
  "text" : "The tmaps package lets you display statistical data on geographical maps http:\/\/t.co\/RzBdakFiid #rstats",
  "id" : 592721305604087808,
  "created_at" : "2015-04-27 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/mlDqeKxdEY",
      "expanded_url" : "http:\/\/bit.ly\/1InEnhE",
      "display_url" : "bit.ly\/1InEnhE"
    } ]
  },
  "geo" : { },
  "id_str" : "591634142783221760",
  "text" : "boot(data,statistic,R) in the \u007Bboot\u007D package will generate R bootstrap replicates of a statistic http:\/\/t.co\/mlDqeKxdEY #rstats",
  "id" : 591634142783221760,
  "created_at" : "2015-04-24 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/0szOOQm86B",
      "expanded_url" : "http:\/\/bit.ly\/1Oo8HKU",
      "display_url" : "bit.ly\/1Oo8HKU"
    } ]
  },
  "geo" : { },
  "id_str" : "591271710806114304",
  "text" : "heatmap.2() \u007Bgplots\u007D provides extensions to R's basic heatmap() \u007Bstats\u007D with better parameter control http:\/\/t.co\/0szOOQm86B #rstats",
  "id" : 591271710806114304,
  "created_at" : "2015-04-23 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/qdyy6wIWgL",
      "expanded_url" : "http:\/\/bit.ly\/19xCFYK",
      "display_url" : "bit.ly\/19xCFYK"
    } ]
  },
  "geo" : { },
  "id_str" : "590909398974865408",
  "text" : "The difference between complete.cases() and na.omit() #rstats http:\/\/t.co\/qdyy6wIWgL",
  "id" : 590909398974865408,
  "created_at" : "2015-04-22 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/umd26QdTue",
      "expanded_url" : "http:\/\/bit.ly\/1G2dZJY",
      "display_url" : "bit.ly\/1G2dZJY"
    } ]
  },
  "geo" : { },
  "id_str" : "590531197551378432",
  "text" : "The miniCRAN package lets you create a repository with an internally consistent set of packages. http:\/\/t.co\/umd26QdTue #rstats",
  "id" : 590531197551378432,
  "created_at" : "2015-04-21 15:03:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/eMQAdiIIs2",
      "expanded_url" : "http:\/\/www.rstats.nyc\/",
      "display_url" : "rstats.nyc"
    } ]
  },
  "geo" : { },
  "id_str" : "590188309776859138",
  "text" : "#Rstats NYC R conference starts Friday http:\/\/t.co\/eMQAdiIIs2",
  "id" : 590188309776859138,
  "created_at" : "2015-04-20 16:20:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/8PJy35d8t8",
      "expanded_url" : "http:\/\/bit.ly\/1yCXVP8",
      "display_url" : "bit.ly\/1yCXVP8"
    } ]
  },
  "geo" : { },
  "id_str" : "590184660833017856",
  "text" : "Check out the tools in the dplyr package for working with data frames. http:\/\/t.co\/8PJy35d8t8 #rstats",
  "id" : 590184660833017856,
  "created_at" : "2015-04-20 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 34, 41 ]
    }, {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ChgU6DYxqK",
      "expanded_url" : "http:\/\/bit.ly\/QL8NSF",
      "display_url" : "bit.ly\/QL8NSF"
    } ]
  },
  "geo" : { },
  "id_str" : "589097421784883200",
  "text" : "Use ggplot2 'Themes' to draw your #rstats charts in the style of publications like \"The Economist\": http:\/\/t.co\/ChgU6DYxqK #rstats",
  "id" : 589097421784883200,
  "created_at" : "2015-04-17 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikhail Popov",
      "screen_name" : "bearloga",
      "indices" : [ 113, 122 ],
      "id_str" : "36133587",
      "id" : 36133587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588735046137294848",
  "text" : "The arrow assignment operator works in both directions. This is valid #rstats syntax: x &lt;- value -&gt; y (via @bearloga)",
  "id" : 588735046137294848,
  "created_at" : "2015-04-16 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/vY4yQw1IlF",
      "expanded_url" : "http:\/\/bit.ly\/H9znwZ",
      "display_url" : "bit.ly\/H9znwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "588372671102115840",
  "text" : "In an #rstats function, return the list of arguments supplied in the call with: as.list(match.call())[-1] http:\/\/t.co\/vY4yQw1IlF",
  "id" : 588372671102115840,
  "created_at" : "2015-04-15 16:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/kILxVJioKh",
      "expanded_url" : "http:\/\/bit.ly\/1NmaPHN",
      "display_url" : "bit.ly\/1NmaPHN"
    } ]
  },
  "geo" : { },
  "id_str" : "588010168207724544",
  "text" : "anova(model) will compute and print ANOVA tables for models fitted with lm() and glm(). #rstats http:\/\/t.co\/kILxVJioKh",
  "id" : 588010168207724544,
  "created_at" : "2015-04-14 16:05:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/74MrRhV6CX",
      "expanded_url" : "http:\/\/bit.ly\/1DtaE73",
      "display_url" : "bit.ly\/1DtaE73"
    } ]
  },
  "geo" : { },
  "id_str" : "587647839033020417",
  "text" : "Type par(no.readonly=TRUE) to get al list of all parameters that can be set in a subsequent call to par() #rstats http:\/\/t.co\/74MrRhV6CX",
  "id" : 587647839033020417,
  "created_at" : "2015-04-13 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/BikRtSgRKq",
      "expanded_url" : "http:\/\/bit.ly\/KglkJC",
      "display_url" : "bit.ly\/KglkJC"
    } ]
  },
  "geo" : { },
  "id_str" : "586560721762308096",
  "text" : "Use read.fwf to read a fixed-format data file (ASCII data without delimiters) into R: http:\/\/t.co\/BikRtSgRKq #rstats",
  "id" : 586560721762308096,
  "created_at" : "2015-04-10 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/fc1VxbZ0oZ",
      "expanded_url" : "http:\/\/bit.ly\/JwBzT5",
      "display_url" : "bit.ly\/JwBzT5"
    } ]
  },
  "geo" : { },
  "id_str" : "586183243273220096",
  "text" : "How to get data from databases, spreadsheets, binary files and APIs into #rstats. R data import\/export manual: http:\/\/t.co\/fc1VxbZ0oZ",
  "id" : 586183243273220096,
  "created_at" : "2015-04-09 15:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/NNqZweYWzc",
      "expanded_url" : "http:\/\/bit.ly\/FO6A1a",
      "display_url" : "bit.ly\/FO6A1a"
    } ]
  },
  "geo" : { },
  "id_str" : "585835867069087744",
  "text" : "To change where R exports files, use setwd() to change the current working directory first: http:\/\/t.co\/NNqZweYWzc #rstats",
  "id" : 585835867069087744,
  "created_at" : "2015-04-08 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/tPHYrVrUwR",
      "expanded_url" : "http:\/\/bit.ly\/1BMAxKQ",
      "display_url" : "bit.ly\/1BMAxKQ"
    } ]
  },
  "geo" : { },
  "id_str" : "585473550120783872",
  "text" : "Use mode(obj) to determint the storage mode of an object. #rstats http:\/\/t.co\/tPHYrVrUwR",
  "id" : 585473550120783872,
  "created_at" : "2015-04-07 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/tPHYrVrUwR",
      "expanded_url" : "http:\/\/bit.ly\/1BMAxKQ",
      "display_url" : "bit.ly\/1BMAxKQ"
    } ]
  },
  "geo" : { },
  "id_str" : "585111137957638145",
  "text" : "Try: tryCatch(expr,. . . , finally) for handling errors and warnings #rstats http:\/\/t.co\/tPHYrVrUwR",
  "id" : 585111137957638145,
  "created_at" : "2015-04-06 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/W1c7L6LIRJ",
      "expanded_url" : "http:\/\/bit.ly\/UDQtyf",
      "display_url" : "bit.ly\/UDQtyf"
    } ]
  },
  "geo" : { },
  "id_str" : "584023975967256576",
  "text" : "format(x, scientific=TRUE) prints numeric data in exponential format, so 0.0001 prints as 1e-04 http:\/\/t.co\/W1c7L6LIRJ",
  "id" : 584023975967256576,
  "created_at" : "2015-04-03 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/viVIoWfemJ",
      "expanded_url" : "http:\/\/bit.ly\/r6YJTu",
      "display_url" : "bit.ly\/r6YJTu"
    } ]
  },
  "geo" : { },
  "id_str" : "583661572888887298",
  "text" : "List of R functions and packages for Time Series Analysis: http:\/\/t.co\/viVIoWfemJ #rstats",
  "id" : 583661572888887298,
  "created_at" : "2015-04-02 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 96, 110 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/C9TkPixHtF",
      "expanded_url" : "http:\/\/bit.ly\/Xob3Rq",
      "display_url" : "bit.ly\/Xob3Rq"
    } ]
  },
  "geo" : { },
  "id_str" : "583299207282442240",
  "text" : "Tips on writing efficient #rstats code (from R co-creator R Ihaka): http:\/\/t.co\/C9TkPixHtF (via @hadleywickham)",
  "id" : 583299207282442240,
  "created_at" : "2015-04-01 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]