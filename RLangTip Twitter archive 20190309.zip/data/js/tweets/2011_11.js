Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 3, 17 ],
      "id_str" : "69133574",
      "id" : 69133574
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 19, 28 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141936240093171714",
  "text" : "RT @hadleywickham: @RLangTip seq_len useful here, and protects against N = 0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "141909576084762624",
    "geo" : { },
    "id_str" : "141920306615959552",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip seq_len useful here, and protects against N = 0",
    "id" : 141920306615959552,
    "in_reply_to_status_id" : 141909576084762624,
    "created_at" : "2011-11-30 16:43:32 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "protected" : false,
      "id_str" : "69133574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905186381995147264\/7zKAG5sY_normal.jpg",
      "id" : 69133574,
      "verified" : true
    }
  },
  "id" : 141936240093171714,
  "created_at" : "2011-11-30 17:46:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141909576084762624",
  "text" : "Syntax trap: The ':' operator has higher precedence than '-' so 0:N-1 evaluates to (0:N)-1, not 0:(N-1) like you probably wanted #rstats",
  "id" : 141909576084762624,
  "created_at" : "2011-11-30 16:00:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/tddFk1nt",
      "expanded_url" : "http:\/\/bit.ly\/tagjby",
      "display_url" : "bit.ly\/tagjby"
    } ]
  },
  "geo" : { },
  "id_str" : "141547184414932992",
  "text" : "A collection of 20+ free R cheat sheets: http:\/\/t.co\/tddFk1nt #rstats",
  "id" : 141547184414932992,
  "created_at" : "2011-11-29 16:00:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/zdnZc7Ds",
      "expanded_url" : "http:\/\/bit.ly\/r4KKw2",
      "display_url" : "bit.ly\/r4KKw2"
    } ]
  },
  "geo" : { },
  "id_str" : "141184816300294144",
  "text" : "List of R functions and packages related to Statistics for the Social Sciences: http:\/\/t.co\/zdnZc7Ds #rstats",
  "id" : 141184816300294144,
  "created_at" : "2011-11-28 16:00:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/pzAdcVUz",
      "expanded_url" : "http:\/\/bit.ly\/oCWgHq",
      "display_url" : "bit.ly\/oCWgHq"
    } ]
  },
  "geo" : { },
  "id_str" : "140097612689846272",
  "text" : "ggplot2 examples of bar charts, scatterplots, histograms, density plots and more: http:\/\/t.co\/pzAdcVUz #rstats",
  "id" : 140097612689846272,
  "created_at" : "2011-11-25 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/a6XCPBHm",
      "expanded_url" : "http:\/\/bit.ly\/uG6J1C",
      "display_url" : "bit.ly\/uG6J1C"
    } ]
  },
  "geo" : { },
  "id_str" : "139735286937698304",
  "text" : "The holiday function in the timeDate package looks up holiday dates, e.g. holiday(2011,\"USThanksgivingDay\") http:\/\/t.co\/a6XCPBHm #rstats",
  "id" : 139735286937698304,
  "created_at" : "2011-11-24 16:01:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/7YbvGPj2",
      "expanded_url" : "http:\/\/bit.ly\/vVAG8G",
      "display_url" : "bit.ly\/vVAG8G"
    } ]
  },
  "geo" : { },
  "id_str" : "139372835792621568",
  "text" : "Add options(error=utils::recover) to .Rprofile to make it easier to debug errors thrown by R functions: http:\/\/t.co\/7YbvGPj2 #rstats",
  "id" : 139372835792621568,
  "created_at" : "2011-11-23 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/yW2CC8qj",
      "expanded_url" : "http:\/\/bit.ly\/sXKxj8",
      "display_url" : "bit.ly\/sXKxj8"
    } ]
  },
  "geo" : { },
  "id_str" : "139010434761101313",
  "text" : "For precise formatting of numbers (e.g. consistent decimal places for tables), use formatC: http:\/\/t.co\/yW2CC8qj #rstats",
  "id" : 139010434761101313,
  "created_at" : "2011-11-22 16:00:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/7UPrB84G",
      "expanded_url" : "http:\/\/bit.ly\/oeWdui",
      "display_url" : "bit.ly\/oeWdui"
    } ]
  },
  "geo" : { },
  "id_str" : "138648092110102528",
  "text" : "List of R functions and packages for Computational Econometrics: http:\/\/t.co\/7UPrB84G #rstats",
  "id" : 138648092110102528,
  "created_at" : "2011-11-21 16:00:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/C4NR8GW8",
      "expanded_url" : "http:\/\/bit.ly\/rIMpZa",
      "display_url" : "bit.ly\/rIMpZa"
    } ]
  },
  "geo" : { },
  "id_str" : "137560897693556736",
  "text" : "The \"round\" function uses the \"round-to-even\" rule. round(3.5) and round(4.5) are both 4 http:\/\/t.co\/C4NR8GW8 #rstats",
  "id" : 137560897693556736,
  "created_at" : "2011-11-18 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/vp1nDqN3",
      "expanded_url" : "http:\/\/bit.ly\/vkHZxy",
      "display_url" : "bit.ly\/vkHZxy"
    } ]
  },
  "geo" : { },
  "id_str" : "137198501628088321",
  "text" : "The tryCatch function lets an R programmer respond to an error without crashing back to the interpreter: http:\/\/t.co\/vp1nDqN3 #rstats",
  "id" : 137198501628088321,
  "created_at" : "2011-11-17 16:00:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/qBJ2fdcq",
      "expanded_url" : "http:\/\/bit.ly\/s3u5Xe",
      "display_url" : "bit.ly\/s3u5Xe"
    } ]
  },
  "geo" : { },
  "id_str" : "136836120423055360",
  "text" : "is.finite(x) is a useful test for \"proper\" data: it returns FALSE for NA, NaN and Inf: http:\/\/t.co\/qBJ2fdcq #rstats",
  "id" : 136836120423055360,
  "created_at" : "2011-11-16 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/vvCrYcaH",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "136473722973466626",
  "text" : "To select a column from a matrix and keep it as a column matrix, not a vector: X[,1,drop=FALSE] http:\/\/t.co\/vvCrYcaH #rstats",
  "id" : 136473722973466626,
  "created_at" : "2011-11-15 16:00:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/i2SDTmZT",
      "expanded_url" : "http:\/\/bit.ly\/odhwGd",
      "display_url" : "bit.ly\/odhwGd"
    } ]
  },
  "geo" : { },
  "id_str" : "136111365076160512",
  "text" : "List of R functions and packages for Natural Language Processing: http:\/\/t.co\/i2SDTmZT #rstats",
  "id" : 136111365076160512,
  "created_at" : "2011-11-14 16:00:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/3HVR9FO4",
      "expanded_url" : "http:\/\/bit.ly\/uf2eFb",
      "display_url" : "bit.ly\/uf2eFb"
    } ]
  },
  "geo" : { },
  "id_str" : "135024281284386816",
  "text" : "There is a Wikipedia page for R at http:\/\/t.co\/3HVR9FO4 #rstats",
  "id" : 135024281284386816,
  "created_at" : "2011-11-11 16:01:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/sYGmssgX",
      "expanded_url" : "http:\/\/bit.ly\/qjhWGI",
      "display_url" : "bit.ly\/qjhWGI"
    } ]
  },
  "geo" : { },
  "id_str" : "134661815174045696",
  "text" : "In R, NA represents missing values. To check for NA's, use the is.na function, not the == operator http:\/\/t.co\/sYGmssgX #rstats",
  "id" : 134661815174045696,
  "created_at" : "2011-11-10 16:00:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/zy0xA5kg",
      "expanded_url" : "http:\/\/bit.ly\/oFfHWu",
      "display_url" : "bit.ly\/oFfHWu"
    } ]
  },
  "geo" : { },
  "id_str" : "134299390021083136",
  "text" : "The xmlToDataFrame function can extract data from structured XML documents http:\/\/t.co\/zy0xA5kg #rstats",
  "id" : 134299390021083136,
  "created_at" : "2011-11-09 16:00:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/wiGChMR5",
      "expanded_url" : "http:\/\/bit.ly\/qOmjEl",
      "display_url" : "bit.ly\/qOmjEl"
    } ]
  },
  "geo" : { },
  "id_str" : "133936990432403457",
  "text" : "R interprets literal numbers like 4 as floating-point; use 4L for the integer 4. http:\/\/t.co\/wiGChMR5 #rstats",
  "id" : 133936990432403457,
  "created_at" : "2011-11-08 16:00:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/UoMmZjVp",
      "expanded_url" : "http:\/\/bit.ly\/tmxyn2",
      "display_url" : "bit.ly\/tmxyn2"
    } ]
  },
  "geo" : { },
  "id_str" : "133658406421676032",
  "text" : "Search the R mailing list archives: http:\/\/t.co\/UoMmZjVp #rstats",
  "id" : 133658406421676032,
  "created_at" : "2011-11-07 21:33:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/VPFwFyVP",
      "expanded_url" : "http:\/\/bit.ly\/r6YJTu",
      "display_url" : "bit.ly\/r6YJTu"
    } ]
  },
  "geo" : { },
  "id_str" : "133574607268614145",
  "text" : "List of R functions and packages for Time Series Analysis: http:\/\/t.co\/VPFwFyVP #rstats",
  "id" : 133574607268614145,
  "created_at" : "2011-11-07 16:00:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132493724692389889",
  "text" : "When selecting from vectors, repeated indexes are allowed. x[c(1,1,2,2,3,3)] duplicates the first 3 elements of x #rstats",
  "id" : 132493724692389889,
  "created_at" : "2011-11-04 16:25:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/tbQFrIWx",
      "expanded_url" : "http:\/\/bit.ly\/pbemkM",
      "display_url" : "bit.ly\/pbemkM"
    } ]
  },
  "geo" : { },
  "id_str" : "132109959222673408",
  "text" : "options(stringsAsFactors=FALSE) will force R to always import character data as character objects: http:\/\/t.co\/tbQFrIWx #rstats",
  "id" : 132109959222673408,
  "created_at" : "2011-11-03 15:00:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAS",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "SPSS",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/YS9mrB7M",
      "expanded_url" : "http:\/\/bit.ly\/ttStw6",
      "display_url" : "bit.ly\/ttStw6"
    } ]
  },
  "geo" : { },
  "id_str" : "131747588834729986",
  "text" : "R equivalents for #SAS and #SPSS modules: http:\/\/t.co\/YS9mrB7M #rstats",
  "id" : 131747588834729986,
  "created_at" : "2011-11-02 15:00:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/zW4vsKbV",
      "expanded_url" : "http:\/\/bit.ly\/nEZQk2",
      "display_url" : "bit.ly\/nEZQk2"
    } ]
  },
  "geo" : { },
  "id_str" : "131385150717177856",
  "text" : "You can use Google Spreadsheets as a data editor, and import the data into R: http:\/\/t.co\/zW4vsKbV #rstats",
  "id" : 131385150717177856,
  "created_at" : "2011-11-01 15:00:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]