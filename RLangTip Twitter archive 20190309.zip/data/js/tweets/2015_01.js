Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/FtFWZkUswu",
      "expanded_url" : "http:\/\/bit.ly\/1Blj65J",
      "display_url" : "bit.ly\/1Blj65J"
    } ]
  },
  "geo" : { },
  "id_str" : "561208614250356736",
  "text" : "Use the args() function to get a quick reminder of a function's argument names: http:\/\/t.co\/FtFWZkUswu #rstats",
  "id" : 561208614250356736,
  "created_at" : "2015-01-30 17:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/spqYfsKY6a",
      "expanded_url" : "http:\/\/bit.ly\/1yNfbiw",
      "display_url" : "bit.ly\/1yNfbiw"
    } ]
  },
  "geo" : { },
  "id_str" : "560846199163744256",
  "text" : "%% is the integer modulus function. e.g. 12 %% 5 returns 2. http:\/\/t.co\/spqYfsKY6a #rstats",
  "id" : 560846199163744256,
  "created_at" : "2015-01-29 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/SOSvVyYQh4",
      "expanded_url" : "http:\/\/bit.ly\/1D0qGmf",
      "display_url" : "bit.ly\/1D0qGmf"
    } ]
  },
  "geo" : { },
  "id_str" : "560483799835115521",
  "text" : "Connect to the open-source SciDB array database with R's scidb package http:\/\/t.co\/SOSvVyYQh4 #rstats",
  "id" : 560483799835115521,
  "created_at" : "2015-01-28 17:05:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/d60nCa0a97",
      "expanded_url" : "http:\/\/bit.ly\/15E0EdZ",
      "display_url" : "bit.ly\/15E0EdZ"
    } ]
  },
  "geo" : { },
  "id_str" : "560121423487049728",
  "text" : "You can use the Rcpp package to convert simple R loops into fast C++ code: http:\/\/t.co\/d60nCa0a97 #rstats",
  "id" : 560121423487049728,
  "created_at" : "2015-01-27 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/2G87igp81d",
      "expanded_url" : "http:\/\/bit.ly\/1wt7JDr",
      "display_url" : "bit.ly\/1wt7JDr"
    } ]
  },
  "geo" : { },
  "id_str" : "559759049361985537",
  "text" : "Work with massive matrices using the bigmemory package http:\/\/t.co\/2G87igp81d #rstats",
  "id" : 559759049361985537,
  "created_at" : "2015-01-26 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/pTsm0O8DLd",
      "expanded_url" : "http:\/\/bit.ly\/x3iEmJ",
      "display_url" : "bit.ly\/x3iEmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "558671901510627329",
  "text" : "You can use hexadecimal literals in R, for example 0xDEADBEEF http:\/\/t.co\/pTsm0O8DLd #rstats",
  "id" : 558671901510627329,
  "created_at" : "2015-01-23 17:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/vHhDWNHWLd",
      "expanded_url" : "http:\/\/bit.ly\/1DLyCeo",
      "display_url" : "bit.ly\/1DLyCeo"
    } ]
  },
  "geo" : { },
  "id_str" : "558309485983576065",
  "text" : "The subset() function is a convenient way of selecting rows from a data frame: #rstats http:\/\/t.co\/vHhDWNHWLd",
  "id" : 558309485983576065,
  "created_at" : "2015-01-22 17:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/tlK4I3kahW",
      "expanded_url" : "http:\/\/ow.ly\/HsX77",
      "display_url" : "ow.ly\/HsX77"
    } ]
  },
  "geo" : { },
  "id_str" : "557947100739416065",
  "text" : "Use colSums to quickly calculate totals from the columns of a large matrix or table: http:\/\/t.co\/tlK4I3kahW #rstats",
  "id" : 557947100739416065,
  "created_at" : "2015-01-21 17:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/3lrgOKbOh9",
      "expanded_url" : "http:\/\/bit.ly\/1xbGb6Z",
      "display_url" : "bit.ly\/1xbGb6Z"
    } ]
  },
  "geo" : { },
  "id_str" : "557584708708864000",
  "text" : "lowess() \u007Bgplot\u007D lets you plot a lowess smoother for your data #rstats http:\/\/t.co\/3lrgOKbOh9",
  "id" : 557584708708864000,
  "created_at" : "2015-01-20 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/jtN4mSsYTh",
      "expanded_url" : "http:\/\/bit.ly\/1ytj8Hv",
      "display_url" : "bit.ly\/1ytj8Hv"
    } ]
  },
  "geo" : { },
  "id_str" : "557222319303966720",
  "text" : "The mclapply() function in the multicore  package is a parallelized version of lapply #rstats http:\/\/t.co\/jtN4mSsYTh",
  "id" : 557222319303966720,
  "created_at" : "2015-01-19 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/YvAPMIXIdo",
      "expanded_url" : "http:\/\/bit.ly\/1w68oe2",
      "display_url" : "bit.ly\/1w68oe2"
    } ]
  },
  "geo" : { },
  "id_str" : "556135170496282624",
  "text" : "#rstats Learn the basics for building an R package http:\/\/t.co\/YvAPMIXIdo",
  "id" : 556135170496282624,
  "created_at" : "2015-01-16 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/4rKmfUCokX",
      "expanded_url" : "http:\/\/bit.ly\/yGdRZ7",
      "display_url" : "bit.ly\/yGdRZ7"
    } ]
  },
  "geo" : { },
  "id_str" : "555772786942435329",
  "text" : "How to generate random numbers in R: http:\/\/t.co\/4rKmfUCokX #rstats",
  "id" : 555772786942435329,
  "created_at" : "2015-01-15 17:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/yCJEnyOoyk",
      "expanded_url" : "http:\/\/bit.ly\/pr0Fsj",
      "display_url" : "bit.ly\/pr0Fsj"
    } ]
  },
  "geo" : { },
  "id_str" : "555410425526120448",
  "text" : "Need to pass a whole bunch of arguments to a function, but want to select them in code? Use do.call http:\/\/t.co\/yCJEnyOoyk #rstats",
  "id" : 555410425526120448,
  "created_at" : "2015-01-14 17:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/PEoizX7g6N",
      "expanded_url" : "http:\/\/bit.ly\/yEaOO2",
      "display_url" : "bit.ly\/yEaOO2"
    } ]
  },
  "geo" : { },
  "id_str" : "555047994320773122",
  "text" : "A collection of free tutorials provided by R users: http:\/\/t.co\/PEoizX7g6N #rstats",
  "id" : 555047994320773122,
  "created_at" : "2015-01-13 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MUNTHhqEDB",
      "expanded_url" : "http:\/\/bit.ly\/1ASjFoA",
      "display_url" : "bit.ly\/1ASjFoA"
    } ]
  },
  "geo" : { },
  "id_str" : "554685606262218753",
  "text" : "#rstats Parameter pch in plot(x,y,pch=21) sets the plotting symbol. Look here: http:\/\/t.co\/MUNTHhqEDB for a list of symbols",
  "id" : 554685606262218753,
  "created_at" : "2015-01-12 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/vAIZ1kSTYm",
      "expanded_url" : "http:\/\/bit.ly\/x9UdLI",
      "display_url" : "bit.ly\/x9UdLI"
    } ]
  },
  "geo" : { },
  "id_str" : "553598476358283264",
  "text" : "Generate a random entry to a 56-ball, 6-draw lottery with R: sample(1:56,6) #rstats http:\/\/t.co\/vAIZ1kSTYm",
  "id" : 553598476358283264,
  "created_at" : "2015-01-09 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "finance",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/nk1LpgwhhN",
      "expanded_url" : "http:\/\/bit.ly\/1tw0BGf",
      "display_url" : "bit.ly\/1tw0BGf"
    } ]
  },
  "geo" : { },
  "id_str" : "553236094406656002",
  "text" : "xts: an R package for handling financial time series.  http:\/\/t.co\/nk1LpgwhhN #rstats #finance",
  "id" : 553236094406656002,
  "created_at" : "2015-01-08 17:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0NLlaBPoPv",
      "expanded_url" : "http:\/\/bit.ly\/yoyRNm",
      "display_url" : "bit.ly\/yoyRNm"
    } ]
  },
  "geo" : { },
  "id_str" : "552873718717116416",
  "text" : "How many people do you need to gather to assure a 95% probability of a shared birthday: qbirthday(0.95) #rstats http:\/\/t.co\/0NLlaBPoPv",
  "id" : 552873718717116416,
  "created_at" : "2015-01-07 17:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/XJZs5BWk0z",
      "expanded_url" : "http:\/\/bit.ly\/1zDOoBB",
      "display_url" : "bit.ly\/1zDOoBB"
    } ]
  },
  "geo" : { },
  "id_str" : "552511280033320960",
  "text" : "#rstats The function polyroot() \u007Bbase\u007D finds the zeros of a complex polynomial http:\/\/t.co\/XJZs5BWk0z",
  "id" : 552511280033320960,
  "created_at" : "2015-01-06 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Lj5PCiX3Om",
      "expanded_url" : "http:\/\/bit.ly\/1D8RjFQ",
      "display_url" : "bit.ly\/1D8RjFQ"
    } ]
  },
  "geo" : { },
  "id_str" : "552148899209961473",
  "text" : "#rstats Backtick,  ` , lets you get R's special functions into sapply eg sapply(1:5,`+`,3) Hadley Wickham, Advanced R http:\/\/t.co\/Lj5PCiX3Om",
  "id" : 552148899209961473,
  "created_at" : "2015-01-05 17:05:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/XxIfUUWEJC",
      "expanded_url" : "http:\/\/bit.ly\/16Ox3ip",
      "display_url" : "bit.ly\/16Ox3ip"
    } ]
  },
  "geo" : { },
  "id_str" : "551061711563014144",
  "text" : "#rstats The function dput() \u007Bbase\u007D writes an ASCII text representation of an R object to a file or connection. http:\/\/t.co\/XxIfUUWEJC",
  "id" : 551061711563014144,
  "created_at" : "2015-01-02 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/X7hMycXymY",
      "expanded_url" : "http:\/\/bit.ly\/oa5sx5",
      "display_url" : "bit.ly\/oa5sx5"
    } ]
  },
  "geo" : { },
  "id_str" : "550699286661722112",
  "text" : "#rstats New Year's resolution: Join a local R user group: http:\/\/t.co\/X7hMycXymY",
  "id" : 550699286661722112,
  "created_at" : "2015-01-01 17:05:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]