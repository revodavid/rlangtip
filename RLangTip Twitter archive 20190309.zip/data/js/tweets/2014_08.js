Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/4tY5di8cpp",
      "expanded_url" : "http:\/\/ow.ly\/5Wjq2",
      "display_url" : "ow.ly\/5Wjq2"
    } ]
  },
  "geo" : { },
  "id_str" : "505385792362250240",
  "text" : "Use the compactPDF function to make PDF files smaller: http:\/\/t.co\/4tY5di8cpp #rstats",
  "id" : 505385792362250240,
  "created_at" : "2014-08-29 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/LlfLIGQjT2",
      "expanded_url" : "http:\/\/bit.ly\/oWiUGe",
      "display_url" : "bit.ly\/oWiUGe"
    } ]
  },
  "geo" : { },
  "id_str" : "505023357860188161",
  "text" : "Five kinds of subscripts in R http:\/\/t.co\/LlfLIGQjT2 #rstats",
  "id" : 505023357860188161,
  "created_at" : "2014-08-28 16:05:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/N1sRm047j3",
      "expanded_url" : "http:\/\/bit.ly\/1v6g9oK",
      "display_url" : "bit.ly\/1v6g9oK"
    } ]
  },
  "geo" : { },
  "id_str" : "504660979247226880",
  "text" : "choose(n, r) returns the binomial coefficient(n, r). lchoose(n, r), the logarithm of the binomial coefficient http:\/\/t.co\/N1sRm047j3 #rstats",
  "id" : 504660979247226880,
  "created_at" : "2014-08-27 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/x3ZvC6c0ax",
      "expanded_url" : "http:\/\/bit.ly\/1npWhte",
      "display_url" : "bit.ly\/1npWhte"
    } ]
  },
  "geo" : { },
  "id_str" : "504298678220517378",
  "text" : "Use read.csv.sql() from the sqldf package http:\/\/t.co\/x3ZvC6c0ax to read a file into R filtering it with SQL statements. #rstats",
  "id" : 504298678220517378,
  "created_at" : "2014-08-26 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/ai7ElwwH3e",
      "expanded_url" : "http:\/\/bit.ly\/1lm0Fdj",
      "display_url" : "bit.ly\/1lm0Fdj"
    } ]
  },
  "geo" : { },
  "id_str" : "503936251985403904",
  "text" : "Try out the %&gt;% operator in the magrittr package http:\/\/t.co\/ai7ElwwH3e to avoid nested function calls. #rstats",
  "id" : 503936251985403904,
  "created_at" : "2014-08-25 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/vij42jAKd9",
      "expanded_url" : "http:\/\/bit.ly\/N8U0vZ",
      "display_url" : "bit.ly\/N8U0vZ"
    } ]
  },
  "geo" : { },
  "id_str" : "502849078909485056",
  "text" : "Video introduction to object-oriented programming in R with S3 classes (by @mensurationist): http:\/\/t.co\/vij42jAKd9 #rstats",
  "id" : 502849078909485056,
  "created_at" : "2014-08-22 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/JndgnltheS",
      "expanded_url" : "http:\/\/bit.ly\/PNsI3S",
      "display_url" : "bit.ly\/PNsI3S"
    } ]
  },
  "geo" : { },
  "id_str" : "502486650166214656",
  "text" : "Add row sums, columns sums and grand total to a table with addmargins(my.table) #rstats http:\/\/t.co\/JndgnltheS",
  "id" : 502486650166214656,
  "created_at" : "2014-08-21 16:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Bn3h3yOJxS",
      "expanded_url" : "http:\/\/bit.ly\/1sJIb8H",
      "display_url" : "bit.ly\/1sJIb8H"
    } ]
  },
  "geo" : { },
  "id_str" : "502124331217223680",
  "text" : "arima.sim() from \u007Bstats\u007D lets you simulate from an ARIMA model http:\/\/t.co\/Bn3h3yOJxS #rstats",
  "id" : 502124331217223680,
  "created_at" : "2014-08-20 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/jZF5Zqxloj",
      "expanded_url" : "http:\/\/bit.ly\/1phZU44",
      "display_url" : "bit.ly\/1phZU44"
    }, {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/SUEYfZf4un",
      "expanded_url" : "http:\/\/ggvis.rstudio.com\/",
      "display_url" : "ggvis.rstudio.com"
    } ]
  },
  "geo" : { },
  "id_str" : "501761894336978944",
  "text" : "Look at rggobi http:\/\/t.co\/jZF5Zqxloj and brand new ggvis http:\/\/t.co\/SUEYfZf4un for interactive graphics #rstats",
  "id" : 501761894336978944,
  "created_at" : "2014-08-19 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/sqyT02F8g2",
      "expanded_url" : "http:\/\/bit.ly\/P9MsKl",
      "display_url" : "bit.ly\/P9MsKl"
    } ]
  },
  "geo" : { },
  "id_str" : "500312340395749376",
  "text" : "Use prop.test to test whether incidences within groups are equal: http:\/\/t.co\/sqyT02F8g2 #rstats",
  "id" : 500312340395749376,
  "created_at" : "2014-08-15 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/uLuHnC7XAy",
      "expanded_url" : "http:\/\/bit.ly\/PENr8M",
      "display_url" : "bit.ly\/PENr8M"
    } ]
  },
  "geo" : { },
  "id_str" : "499949997652451328",
  "text" : "Trigonometric functions in R use radians. For example, cos(355) prints as -1 (and this is why: http:\/\/t.co\/uLuHnC7XAy ) #rstats",
  "id" : 499949997652451328,
  "created_at" : "2014-08-14 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/rS9V8oQ5js",
      "expanded_url" : "http:\/\/bit.ly\/V8UQDc",
      "display_url" : "bit.ly\/V8UQDc"
    }, {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/UOosiZGZn7",
      "expanded_url" : "http:\/\/bit.ly\/1oxAt9V",
      "display_url" : "bit.ly\/1oxAt9V"
    } ]
  },
  "geo" : { },
  "id_str" : "499587660621815808",
  "text" : "Two packages for wavelets: wavelets http:\/\/t.co\/rS9V8oQ5js and wavethresh http:\/\/t.co\/UOosiZGZn7 #rstats",
  "id" : 499587660621815808,
  "created_at" : "2014-08-13 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/xVePGipgFp",
      "expanded_url" : "http:\/\/adv-r.had.co.nz\/",
      "display_url" : "adv-r.had.co.nz"
    } ]
  },
  "geo" : { },
  "id_str" : "499225204732993537",
  "text" : "Get started with Advanced R programming http:\/\/t.co\/xVePGipgFp #rstats",
  "id" : 499225204732993537,
  "created_at" : "2014-08-12 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/9CgeIO85ly",
      "expanded_url" : "https:\/\/plot.ly\/r\/",
      "display_url" : "plot.ly\/r\/"
    } ]
  },
  "geo" : { },
  "id_str" : "498862811448365056",
  "text" : "The Plotly R API provides a nice way to plot and share R graph on the web using ggplot2 syntax https:\/\/t.co\/9CgeIO85ly #rstats",
  "id" : 498862811448365056,
  "created_at" : "2014-08-11 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/djUECUT79I",
      "expanded_url" : "http:\/\/bit.ly\/1sasTa9",
      "display_url" : "bit.ly\/1sasTa9"
    }, {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/j4Ue9vscKV",
      "expanded_url" : "http:\/\/bit.ly\/rkawJQ",
      "display_url" : "bit.ly\/rkawJQ"
    } ]
  },
  "geo" : { },
  "id_str" : "497775645070729216",
  "text" : "R for programmers coming from other languages http:\/\/t.co\/djUECUT79I and  http:\/\/t.co\/j4Ue9vscKV #rstats",
  "id" : 497775645070729216,
  "created_at" : "2014-08-08 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/3OuuyPYDW6",
      "expanded_url" : "http:\/\/bit.ly\/p8qFdV",
      "display_url" : "bit.ly\/p8qFdV"
    } ]
  },
  "geo" : { },
  "id_str" : "497413318932713472",
  "text" : "Use textConnection() to import data that's already stored in an R object (rather than a file): http:\/\/t.co\/3OuuyPYDW6 #rstats",
  "id" : 497413318932713472,
  "created_at" : "2014-08-07 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 129, 151 ],
      "url" : "http:\/\/t.co\/evEwXHoAcy",
      "expanded_url" : "http:\/\/bit.ly\/1xLK5TX",
      "display_url" : "bit.ly\/1xLK5TX"
    } ]
  },
  "geo" : { },
  "id_str" : "497050865367531520",
  "text" : "The operator &lt;&lt;- does global assignment. If you think you need &lt;&lt;-, think again. -- Patrick Burns, The R Inferno p35 http:\/\/t.co\/evEwXHoAcy",
  "id" : 497050865367531520,
  "created_at" : "2014-08-06 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/yT896CHv5B",
      "expanded_url" : "http:\/\/bit.ly\/1m6gijt",
      "display_url" : "bit.ly\/1m6gijt"
    } ]
  },
  "geo" : { },
  "id_str" : "496688458552074240",
  "text" : "A useful tutorial on producing simple R graphs from Frank McCown http:\/\/t.co\/yT896CHv5B #rstats",
  "id" : 496688458552074240,
  "created_at" : "2014-08-05 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/8FHupSEAD4",
      "expanded_url" : "http:\/\/bit.ly\/1rWYcYs",
      "display_url" : "bit.ly\/1rWYcYs"
    } ]
  },
  "geo" : { },
  "id_str" : "496325333491408897",
  "text" : "Use unname() to remove the names of an R object. #rstats http:\/\/t.co\/8FHupSEAD4",
  "id" : 496325333491408897,
  "created_at" : "2014-08-04 16:02:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/HYALRs84Eq",
      "expanded_url" : "http:\/\/bit.ly\/1rE5Hlg",
      "display_url" : "bit.ly\/1rE5Hlg"
    } ]
  },
  "geo" : { },
  "id_str" : "495223830747840512",
  "text" : "Use the function factor() to encode a variable as a \"factor\" or categorical variable.http:\/\/t.co\/HYALRs84Eq #rstats",
  "id" : 495223830747840512,
  "created_at" : "2014-08-01 15:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]