Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/zoyGBkozw7",
      "expanded_url" : "http:\/\/bit.ly\/J4Ax1X",
      "display_url" : "bit.ly\/J4Ax1X"
    } ]
  },
  "geo" : { },
  "id_str" : "329265316154732544",
  "text" : "List of R packages and functions for Cluster Analysis &amp; Finite Mixture Models: http:\/\/t.co\/zoyGBkozw7 #rstats",
  "id" : 329265316154732544,
  "created_at" : "2013-04-30 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/57VzXRChyH",
      "expanded_url" : "http:\/\/bit.ly\/Ilh5KH",
      "display_url" : "bit.ly\/Ilh5KH"
    } ]
  },
  "geo" : { },
  "id_str" : "328902821145608192",
  "text" : "Can't find a package binary on CRAN? Check its build status on all platforms here: http:\/\/t.co\/57VzXRChyH #rstats (via @PairachChamp)",
  "id" : 328902821145608192,
  "created_at" : "2013-04-29 16:05:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/DVQHdBiwEd",
      "expanded_url" : "http:\/\/bit.ly\/x4HV5i",
      "display_url" : "bit.ly\/x4HV5i"
    } ]
  },
  "geo" : { },
  "id_str" : "327815785483476992",
  "text" : "List of R functions and packages for visualization and analysis of multivariate data: http:\/\/t.co\/DVQHdBiwEd #rstats",
  "id" : 327815785483476992,
  "created_at" : "2013-04-26 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/jQv1aAlRti",
      "expanded_url" : "http:\/\/bit.ly\/I7rm0p",
      "display_url" : "bit.ly\/I7rm0p"
    } ]
  },
  "geo" : { },
  "id_str" : "327453305607450624",
  "text" : "Robust regression in R (PDF, Fox &amp; Weisberg): http:\/\/t.co\/jQv1aAlRti #rstats",
  "id" : 327453305607450624,
  "created_at" : "2013-04-25 16:05:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/OAvGSobjmX",
      "expanded_url" : "http:\/\/www.inside-r.org\/download",
      "display_url" : "inside-r.org\/download"
    } ]
  },
  "geo" : { },
  "id_str" : "327091019457912832",
  "text" : "Find the closest CRAN mirror to you at http:\/\/t.co\/OAvGSobjmX (it will be selected by default) #rstats",
  "id" : 327091019457912832,
  "created_at" : "2013-04-24 16:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/mUyl3JeFaV",
      "expanded_url" : "http:\/\/bit.ly\/I2UQ0v",
      "display_url" : "bit.ly\/I2UQ0v"
    } ]
  },
  "geo" : { },
  "id_str" : "326728646322712576",
  "text" : "Explore the capabilities of your installed R packages with browseVignettes() #rstats http:\/\/t.co\/mUyl3JeFaV",
  "id" : 326728646322712576,
  "created_at" : "2013-04-23 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basic Statistics",
      "screen_name" : "B_Stats",
      "indices" : [ 3, 11 ],
      "id_str" : "1064549726",
      "id" : 1064549726
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 70, 79 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326383018589687810",
  "text" : "RT @B_Stats: One tip per day on the R programming language.\n\nFollow : @RLangTip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 57, 66 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325927586356146176",
    "text" : "One tip per day on the R programming language.\n\nFollow : @RLangTip",
    "id" : 325927586356146176,
    "created_at" : "2013-04-21 11:02:46 +0000",
    "user" : {
      "name" : "Basic Statistics",
      "screen_name" : "B_Stats",
      "protected" : false,
      "id_str" : "1064549726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000322708582\/46bd8336a8b297958096af9ae47b8e61_normal.jpeg",
      "id" : 1064549726,
      "verified" : false
    }
  },
  "id" : 326383018589687810,
  "created_at" : "2013-04-22 17:12:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 77, 91 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/8uCZsUOFjG",
      "expanded_url" : "http:\/\/bit.ly\/ZElzlW",
      "display_url" : "bit.ly\/ZElzlW"
    } ]
  },
  "geo" : { },
  "id_str" : "326366224634220545",
  "text" : "How-do-you-you-determine-the-namespace-of-a-function? http:\/\/t.co\/8uCZsUOFjG @joshua_ulrich",
  "id" : 326366224634220545,
  "created_at" : "2013-04-22 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/uiCjBXqGKg",
      "expanded_url" : "http:\/\/bit.ly\/onqu7V",
      "display_url" : "bit.ly\/onqu7V"
    } ]
  },
  "geo" : { },
  "id_str" : "325278988136222720",
  "text" : "with(mydf, \u007B &lt;&lt;R code&gt;&gt; \u007D) is a cleaner way to use columns of a data frame in #rstats code. Examples: http:\/\/t.co\/uiCjBXqGKg",
  "id" : 325278988136222720,
  "created_at" : "2013-04-19 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/T0mQxISDH7",
      "expanded_url" : "http:\/\/bit.ly\/HGLpQF",
      "display_url" : "bit.ly\/HGLpQF"
    } ]
  },
  "geo" : { },
  "id_str" : "324916658269470720",
  "text" : "List of answers to common questions about R on StackOverflow: http:\/\/t.co\/T0mQxISDH7 #rstats",
  "id" : 324916658269470720,
  "created_at" : "2013-04-18 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dJ0bNdQwFS",
      "expanded_url" : "http:\/\/bit.ly\/Hft5M9",
      "display_url" : "bit.ly\/Hft5M9"
    } ]
  },
  "geo" : { },
  "id_str" : "324554244545982464",
  "text" : "Avoid namespace clashes! Use :: to specify an object within a specific package, e.g. MASS::mvnorm #rstats http:\/\/t.co\/dJ0bNdQwFS",
  "id" : 324554244545982464,
  "created_at" : "2013-04-17 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/hAGPymNrTQ",
      "expanded_url" : "http:\/\/bit.ly\/ILpoTs",
      "display_url" : "bit.ly\/ILpoTs"
    } ]
  },
  "geo" : { },
  "id_str" : "324191879128313858",
  "text" : "Merge two data frames with merge(df1, df2) for an inner join and merge(df1,df2,all=TRUE) for an outer join. #rstats http:\/\/t.co\/hAGPymNrTQ",
  "id" : 324191879128313858,
  "created_at" : "2013-04-16 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/MAxaA1EMH9",
      "expanded_url" : "http:\/\/bit.ly\/IfI9Zw",
      "display_url" : "bit.ly\/IfI9Zw"
    } ]
  },
  "geo" : { },
  "id_str" : "323829504986468352",
  "text" : "How to unshorten a bit.ly, t.co or other short URL with R: http:\/\/t.co\/MAxaA1EMH9 #rstats",
  "id" : 323829504986468352,
  "created_at" : "2013-04-15 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/FJYNPCzkRJ",
      "expanded_url" : "http:\/\/bit.ly\/IyE1Wa",
      "display_url" : "bit.ly\/IyE1Wa"
    } ]
  },
  "geo" : { },
  "id_str" : "322742315762458625",
  "text" : "Use the plyr package to easily sort a data frame by a column: arrange(df, desc(colname)) #rstats http:\/\/t.co\/FJYNPCzkRJ",
  "id" : 322742315762458625,
  "created_at" : "2013-04-12 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/p09MqFlGs2",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "322379963707842561",
  "text" : "search() displays the \"search list\" of packages where R searches for functions and other objects #rstats http:\/\/t.co\/p09MqFlGs2",
  "id" : 322379963707842561,
  "created_at" : "2013-04-11 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/cnBnfwXyW4",
      "expanded_url" : "http:\/\/bit.ly\/x0y4JC",
      "display_url" : "bit.ly\/x0y4JC"
    } ]
  },
  "geo" : { },
  "id_str" : "322198655132114944",
  "text" : "List of R packages for analysis of ecological and environmental data: http:\/\/t.co\/cnBnfwXyW4 #rstats",
  "id" : 322198655132114944,
  "created_at" : "2013-04-11 04:05:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/8qNErPxLWe",
      "expanded_url" : "http:\/\/bit.ly\/HDgsfu",
      "display_url" : "bit.ly\/HDgsfu"
    } ]
  },
  "geo" : { },
  "id_str" : "321655155915362307",
  "text" : "Use NROW\/NCOL instead of nrow\/ncol to treat vectors as 1-column matrices #rstats http:\/\/t.co\/8qNErPxLWe",
  "id" : 321655155915362307,
  "created_at" : "2013-04-09 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/t1BFHXqohi",
      "expanded_url" : "http:\/\/bit.ly\/yk582p",
      "display_url" : "bit.ly\/yk582p"
    } ]
  },
  "geo" : { },
  "id_str" : "321292877495939072",
  "text" : "List of R packages and functions for high-performance and parallel computing with R: http:\/\/t.co\/t1BFHXqohi #rstats",
  "id" : 321292877495939072,
  "created_at" : "2013-04-08 16:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/BCcgjkcsrg",
      "expanded_url" : "http:\/\/bit.ly\/H9pAae",
      "display_url" : "bit.ly\/H9pAae"
    } ]
  },
  "geo" : { },
  "id_str" : "320205567979319297",
  "text" : "Free e-book on multilevel modeling with #rstats using nlme and multilevel packages: http:\/\/t.co\/BCcgjkcsrg",
  "id" : 320205567979319297,
  "created_at" : "2013-04-05 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/FioGPKfO00",
      "expanded_url" : "http:\/\/bit.ly\/H9AbSs",
      "display_url" : "bit.ly\/H9AbSs"
    } ]
  },
  "geo" : { },
  "id_str" : "319843207699656704",
  "text" : "Use mapply to call a multi-argument function repeatedly, e.g. mapply(sample, list(1:56, 1:46), c(5,1)) #rstats http:\/\/t.co\/FioGPKfO00",
  "id" : 319843207699656704,
  "created_at" : "2013-04-04 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Allen",
      "screen_name" : "TrestleJeff",
      "indices" : [ 111, 123 ],
      "id_str" : "707254393",
      "id" : 707254393
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9xdd1kWv6i",
      "expanded_url" : "http:\/\/bit.ly\/100gwhr",
      "display_url" : "bit.ly\/100gwhr"
    } ]
  },
  "geo" : { },
  "id_str" : "319480810443010048",
  "text" : "Deleting a function from a package will surprise your users. Deprecate it instead: http:\/\/t.co\/9xdd1kWv6i (via @TrestleJeff) #rstats",
  "id" : 319480810443010048,
  "created_at" : "2013-04-03 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Patterson",
      "screen_name" : "M_T_Patterson",
      "indices" : [ 89, 103 ],
      "id_str" : "101678082",
      "id" : 101678082
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/tvZCsRq6IQ",
      "expanded_url" : "http:\/\/bit.ly\/Y21xrG",
      "display_url" : "bit.ly\/Y21xrG"
    } ]
  },
  "geo" : { },
  "id_str" : "319118410074189825",
  "text" : "Locate the largest number in a vector with which.max(mydata) http:\/\/t.co\/tvZCsRq6IQ (via @M_T_Patterson) #rstats",
  "id" : 319118410074189825,
  "created_at" : "2013-04-02 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/YUc3n1FKbS",
      "expanded_url" : "http:\/\/r.findata.org",
      "display_url" : "r.findata.org"
    } ]
  },
  "geo" : { },
  "id_str" : "318755963920334848",
  "text" : "Access Bloomberg data from R with the Rbbg package. Get it with install.packages(\"Rbbg\", repos = \"http:\/\/t.co\/YUc3n1FKbS\") #rstats",
  "id" : 318755963920334848,
  "created_at" : "2013-04-01 16:05:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]