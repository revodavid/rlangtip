Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/oZhMKCh31J",
      "expanded_url" : "http:\/\/bit.ly\/rOOucD",
      "display_url" : "bit.ly\/rOOucD"
    } ]
  },
  "geo" : { },
  "id_str" : "571355478388817920",
  "text" : "Generate a LaTeX table from an R variable: http:\/\/t.co\/oZhMKCh31J #rstats",
  "id" : 571355478388817920,
  "created_at" : "2015-02-27 17:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/XfNEVYhzhe",
      "expanded_url" : "http:\/\/bit.ly\/sxv5Hx",
      "display_url" : "bit.ly\/sxv5Hx"
    } ]
  },
  "geo" : { },
  "id_str" : "570993070067585025",
  "text" : "file.path is a fast, platform-independent function to create paths to filenames http:\/\/t.co\/XfNEVYhzhe #rstats",
  "id" : 570993070067585025,
  "created_at" : "2015-02-26 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Jlo5vLiEQp",
      "expanded_url" : "http:\/\/bit.ly\/rLysv3",
      "display_url" : "bit.ly\/rLysv3"
    } ]
  },
  "geo" : { },
  "id_str" : "570630719141220352",
  "text" : "How to source an R file from GitHub (or any other site via https): http:\/\/t.co\/Jlo5vLiEQp #rstats",
  "id" : 570630719141220352,
  "created_at" : "2015-02-25 17:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ERBtvPpQcg",
      "expanded_url" : "http:\/\/bit.ly\/17GkJjU",
      "display_url" : "bit.ly\/17GkJjU"
    } ]
  },
  "geo" : { },
  "id_str" : "570268316402626560",
  "text" : "Split x into groups defined by f where f is a factor or list: split(x,f) http:\/\/t.co\/ERBtvPpQcg #rstats",
  "id" : 570268316402626560,
  "created_at" : "2015-02-24 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/AxWRmJG1tV",
      "expanded_url" : "http:\/\/bit.ly\/1vonyl4",
      "display_url" : "bit.ly\/1vonyl4"
    } ]
  },
  "geo" : { },
  "id_str" : "569905937579950082",
  "text" : "To initialize an integer vector of length n: x &lt;- vector(mode = \"integer\", length = n) http:\/\/t.co\/AxWRmJG1tV #rstats",
  "id" : 569905937579950082,
  "created_at" : "2015-02-23 17:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/HgZO0jOahc",
      "expanded_url" : "http:\/\/rseek.org\/",
      "display_url" : "rseek.org"
    } ]
  },
  "geo" : { },
  "id_str" : "568818766924136448",
  "text" : "R-specific web search http:\/\/t.co\/HgZO0jOahc #rstats",
  "id" : 568818766924136448,
  "created_at" : "2015-02-20 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/lJIprDGZ3G",
      "expanded_url" : "http:\/\/bit.ly\/1A59qfa",
      "display_url" : "bit.ly\/1A59qfa"
    } ]
  },
  "geo" : { },
  "id_str" : "568456372637077505",
  "text" : "pack::fun will show the code for function, fun, in installed package, pack http:\/\/t.co\/lJIprDGZ3G #rstats",
  "id" : 568456372637077505,
  "created_at" : "2015-02-19 17:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/E9y1ofSCm2",
      "expanded_url" : "http:\/\/bit.ly\/1tq6oPl",
      "display_url" : "bit.ly\/1tq6oPl"
    } ]
  },
  "geo" : { },
  "id_str" : "568093965439918081",
  "text" : "The function typeof(x) \u007Bbase\u007D determines the internal type or storage mode of an R object. http:\/\/t.co\/E9y1ofSCm2 #rstats",
  "id" : 568093965439918081,
  "created_at" : "2015-02-18 17:05:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/UI53VcOLr6",
      "expanded_url" : "http:\/\/bit.ly\/1vJ4qhT",
      "display_url" : "bit.ly\/1vJ4qhT"
    } ]
  },
  "geo" : { },
  "id_str" : "567731594002444290",
  "text" : "Use pbapply \u007Bpbapply\u007D to add progress bars to apply functions. http:\/\/t.co\/UI53VcOLr6 #rstats",
  "id" : 567731594002444290,
  "created_at" : "2015-02-17 17:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/sQPvjCL9ki",
      "expanded_url" : "http:\/\/bit.ly\/1uR0niX",
      "display_url" : "bit.ly\/1uR0niX"
    } ]
  },
  "geo" : { },
  "id_str" : "567369196670316544",
  "text" : "Type ?\"?\" or ?Question at the command line to get help with help. http:\/\/t.co\/sQPvjCL9ki  #rstats",
  "id" : 567369196670316544,
  "created_at" : "2015-02-16 17:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Munroe",
      "screen_name" : "xkcd",
      "indices" : [ 88, 93 ],
      "id_str" : "21146468",
      "id" : 21146468
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/pMy5HDcwO6",
      "expanded_url" : "http:\/\/bit.ly\/IVg3F7",
      "display_url" : "bit.ly\/IVg3F7"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Tr5RSFzbsr",
      "expanded_url" : "http:\/\/xkcd.com\/1047\/",
      "display_url" : "xkcd.com\/1047\/"
    } ]
  },
  "geo" : { },
  "id_str" : "566282059627651073",
  "text" : "Jenny's constant in R: (7^(exp(1)-1\/exp(1))-9)*pi^2 #rstats http:\/\/t.co\/pMy5HDcwO6 (via @xkcd http:\/\/t.co\/Tr5RSFzbsr ) Happy V Day!",
  "id" : 566282059627651073,
  "created_at" : "2015-02-13 17:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/yiRZtJ1FtW",
      "expanded_url" : "http:\/\/bit.ly\/n5mCJZ",
      "display_url" : "bit.ly\/n5mCJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "565919644662636546",
  "text" : "Use data(package=\"foo\") to see a list of data sets included in package foo: http:\/\/t.co\/yiRZtJ1FtW #rstats",
  "id" : 565919644662636546,
  "created_at" : "2015-02-12 17:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Znwq4emE2r",
      "expanded_url" : "http:\/\/bit.ly\/1Kz9cjs",
      "display_url" : "bit.ly\/1Kz9cjs"
    } ]
  },
  "geo" : { },
  "id_str" : "565557291207098368",
  "text" : "getwd() returns the current working directory, the place where R reads and write files by default: http:\/\/t.co\/Znwq4emE2r #rstats",
  "id" : 565557291207098368,
  "created_at" : "2015-02-11 17:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/OS9zycxWIR",
      "expanded_url" : "http:\/\/bit.ly\/1DnLJBq",
      "display_url" : "bit.ly\/1DnLJBq"
    } ]
  },
  "geo" : { },
  "id_str" : "565194918235500544",
  "text" : "#rstats agnes\u007Bcluster\u007D is a clustering method that measures the amount of clustering structure found. http:\/\/t.co\/OS9zycxWIR",
  "id" : 565194918235500544,
  "created_at" : "2015-02-10 17:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/MQMag6JyMT",
      "expanded_url" : "http:\/\/bit.ly\/1FgdPxH",
      "display_url" : "bit.ly\/1FgdPxH"
    } ]
  },
  "geo" : { },
  "id_str" : "564832469317603328",
  "text" : "??keyword lets you do a keyword search at the console  http:\/\/t.co\/MQMag6JyMT #rstats",
  "id" : 564832469317603328,
  "created_at" : "2015-02-09 17:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/d2rGJGboVt",
      "expanded_url" : "http:\/\/bit.ly\/TT8Obs",
      "display_url" : "bit.ly\/TT8Obs"
    } ]
  },
  "geo" : { },
  "id_str" : "563745420200132608",
  "text" : "Functions and packages for the analysis of spatio-temporal data: http:\/\/t.co\/d2rGJGboVt #rstats",
  "id" : 563745420200132608,
  "created_at" : "2015-02-06 17:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/tB6yPEWXQD",
      "expanded_url" : "http:\/\/bit.ly\/Vg7rAZ",
      "display_url" : "bit.ly\/Vg7rAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "563382973165490176",
  "text" : "Test for two vectors being the same: if(identical(x,y)) \u007B ... \u007D. Also works for data frames, lists, etc. #rstats http:\/\/t.co\/tB6yPEWXQD",
  "id" : 563382973165490176,
  "created_at" : "2015-02-05 17:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/R9ItSr3cjU",
      "expanded_url" : "http:\/\/bit.ly\/18Cww3S",
      "display_url" : "bit.ly\/18Cww3S"
    } ]
  },
  "geo" : { },
  "id_str" : "563020613649190914",
  "text" : "auto.arima() \u007Bforecast\u007D will return the best ARIMA fit to a time series using a  AIC, AICc or BIC criterion http:\/\/t.co\/R9ItSr3cjU #rstats",
  "id" : 563020613649190914,
  "created_at" : "2015-02-04 17:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/vZxthLAwq4",
      "expanded_url" : "http:\/\/bit.ly\/1yZpwts",
      "display_url" : "bit.ly\/1yZpwts"
    } ]
  },
  "geo" : { },
  "id_str" : "562658159626833921",
  "text" : "log(x, b) returns the log of x base b. http:\/\/t.co\/vZxthLAwq4 #rstats",
  "id" : 562658159626833921,
  "created_at" : "2015-02-03 17:05:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/FtFWZkUswu",
      "expanded_url" : "http:\/\/bit.ly\/1Blj65J",
      "display_url" : "bit.ly\/1Blj65J"
    } ]
  },
  "geo" : { },
  "id_str" : "562295743491637248",
  "text" : "Use the args() function to get a quick reminder of a function's argument names: http:\/\/t.co\/FtFWZkUswu #rstats",
  "id" : 562295743491637248,
  "created_at" : "2015-02-02 17:05:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]