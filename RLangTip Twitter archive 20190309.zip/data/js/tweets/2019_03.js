Grailbird.data.tweets_2019_03 = 
[ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/JHkMGFzAF7",
      "expanded_url" : "http:\/\/rfunction.com\/archives\/2105",
      "display_url" : "rfunction.com\/archives\/2105"
    } ]
  },
  "geo" : { },
  "id_str" : "1104094432016715777",
  "text" : "Some examples of using get() to retrieve an R object by name using a character string: https:\/\/t.co\/JHkMGFzAF7 #rstats",
  "id" : 1104094432016715777,
  "created_at" : "2019-03-08 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/72npuPWyY4",
      "expanded_url" : "https:\/\/twitter.com\/CMastication\/status\/1093509987538821120",
      "display_url" : "twitter.com\/CMastication\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1103732043979124737",
  "text" : "Use skim_tee (in the skimr package) data to inspect data in a #rstats pipe chain: https:\/\/t.co\/72npuPWyY4",
  "id" : 1103732043979124737,
  "created_at" : "2019-03-07 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/wLVFx3ChDo",
      "expanded_url" : "https:\/\/blog.revolutionanalytics.com\/2018\/12\/azurecontainers.html",
      "display_url" : "blog.revolutionanalytics.com\/2018\/12\/azurec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1103369661440233472",
  "text" : "How to deploy R as a service in Azure with Kubernetes and the plumber package https:\/\/t.co\/wLVFx3ChDo #rstats",
  "id" : 1103369661440233472,
  "created_at" : "2019-03-06 19:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/V28ExP2Hnp",
      "expanded_url" : "https:\/\/www.infoworld.com\/article\/3331605\/r-language\/how-to-create-color-coded-calendars-in-r.html",
      "display_url" : "infoworld.com\/article\/333160\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1103007269485129728",
  "text" : "How to make color-coded calendars in R: https:\/\/t.co\/V28ExP2Hnp #rstats",
  "id" : 1103007269485129728,
  "created_at" : "2019-03-05 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1102644880524873728",
  "text" : "Just because you *can* redefine built-in functions in R doesn't mean it's a good idea. Avoid function names like c, t, sum etc. #rstats",
  "id" : 1102644880524873728,
  "created_at" : "2019-03-04 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claus Wilke",
      "screen_name" : "ClausWilke",
      "indices" : [ 13, 24 ],
      "id_str" : "1679260675",
      "id" : 1679260675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/lS8sIkVedS",
      "expanded_url" : "https:\/\/serialmentor.com\/dataviz\/",
      "display_url" : "serialmentor.com\/dataviz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1101557719553564673",
  "text" : "Free book by @ClausWilke: \"Fundamentals of Data Visualization\". R code linked in \"Technical Notes\" section. https:\/\/t.co\/lS8sIkVedS #rstats",
  "id" : 1101557719553564673,
  "created_at" : "2019-03-01 19:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]