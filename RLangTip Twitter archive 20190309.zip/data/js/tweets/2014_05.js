Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/8uqYP8hXUS",
      "expanded_url" : "http:\/\/bit.ly\/LEU8S0",
      "display_url" : "bit.ly\/LEU8S0"
    } ]
  },
  "geo" : { },
  "id_str" : "472408465504501760",
  "text" : "Concatenate elements of a vector to a single comma-separated string: paste(letters, collapse=\", \") #rstats http:\/\/t.co\/8uqYP8hXUS",
  "id" : 472408465504501760,
  "created_at" : "2014-05-30 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/Da7Db3kUic",
      "expanded_url" : "http:\/\/bit.ly\/1opEO26",
      "display_url" : "bit.ly\/1opEO26"
    } ]
  },
  "geo" : { },
  "id_str" : "472046119640653824",
  "text" : "Some nice R tutorials from Willian B. King http:\/\/t.co\/Da7Db3kUic #rstats",
  "id" : 472046119640653824,
  "created_at" : "2014-05-29 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/iFFBLrTSpT",
      "expanded_url" : "http:\/\/bit.ly\/1pkampQ",
      "display_url" : "bit.ly\/1pkampQ"
    } ]
  },
  "geo" : { },
  "id_str" : "471683681388875776",
  "text" : "Leave out the mth column of a data frame: dF[,-m]  http:\/\/t.co\/iFFBLrTSpT #rstats",
  "id" : 471683681388875776,
  "created_at" : "2014-05-28 16:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iFCoU27JfT",
      "expanded_url" : "http:\/\/bit.ly\/1jEUopG",
      "display_url" : "bit.ly\/1jEUopG"
    } ]
  },
  "geo" : { },
  "id_str" : "471321331733368832",
  "text" : "readHTMLTable(url,which=2) will read the 2nd table on the webpage specified by the url http:\/\/t.co\/iFCoU27JfT #rstats",
  "id" : 471321331733368832,
  "created_at" : "2014-05-27 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/iFFBLrTSpT",
      "expanded_url" : "http:\/\/bit.ly\/1pkampQ",
      "display_url" : "bit.ly\/1pkampQ"
    } ]
  },
  "geo" : { },
  "id_str" : "470958911139614720",
  "text" : "Indexing into a list: myList[[m]][n] will yield the nth element of the mth item in list myList #rstats http:\/\/t.co\/iFFBLrTSpT #rstats",
  "id" : 470958911139614720,
  "created_at" : "2014-05-26 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/yFBdboOvTS",
      "expanded_url" : "http:\/\/bit.ly\/xYZJ3s",
      "display_url" : "bit.ly\/xYZJ3s"
    } ]
  },
  "geo" : { },
  "id_str" : "469871753381302272",
  "text" : "List of R packages related to networks, graphs, Bayesian models, and flow diagrams: http:\/\/t.co\/yFBdboOvTS #rstats",
  "id" : 469871753381302272,
  "created_at" : "2014-05-23 16:05:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/o9HfhtModn",
      "expanded_url" : "http:\/\/bit.ly\/t1bNrg",
      "display_url" : "bit.ly\/t1bNrg"
    } ]
  },
  "geo" : { },
  "id_str" : "469509332846256129",
  "text" : "The polypath function can be used to add a vector-based shape or symbol to a chart: http:\/\/t.co\/o9HfhtModn #rstats",
  "id" : 469509332846256129,
  "created_at" : "2014-05-22 16:05:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7tYbIARk8M",
      "expanded_url" : "http:\/\/bit.ly\/qokamy",
      "display_url" : "bit.ly\/qokamy"
    } ]
  },
  "geo" : { },
  "id_str" : "469146952828190720",
  "text" : "Not sure why your R function threw an error? Use traceback() to find out where it occurred. http:\/\/t.co\/7tYbIARk8M #rstats",
  "id" : 469146952828190720,
  "created_at" : "2014-05-21 16:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/HKQhLvqk1B",
      "expanded_url" : "http:\/\/bit.ly\/PG1f0n",
      "display_url" : "bit.ly\/PG1f0n"
    } ]
  },
  "geo" : { },
  "id_str" : "468784611804602368",
  "text" : "Tutorial introduction to time series in #rstats: http:\/\/t.co\/HKQhLvqk1B (via @treycausey)",
  "id" : 468784611804602368,
  "created_at" : "2014-05-20 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/mtA7Qelpkn",
      "expanded_url" : "http:\/\/bit.ly\/N63GcJ",
      "display_url" : "bit.ly\/N63GcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "468422174697881601",
  "text" : "R functions and packages for differential equations: ODEs, SDEs, PDEs etc: http:\/\/t.co\/mtA7Qelpkn #rstats",
  "id" : 468422174697881601,
  "created_at" : "2014-05-19 16:05:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/I22xoikQor",
      "expanded_url" : "http:\/\/bit.ly\/t2OR0K",
      "display_url" : "bit.ly\/t2OR0K"
    } ]
  },
  "geo" : { },
  "id_str" : "467335053690015744",
  "text" : "To speed an R function, use cmpfun to byte-compile it: http:\/\/t.co\/I22xoikQor #rstats",
  "id" : 467335053690015744,
  "created_at" : "2014-05-16 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Thyc25QipX",
      "expanded_url" : "http:\/\/bit.ly\/14E9ulW",
      "display_url" : "bit.ly\/14E9ulW"
    } ]
  },
  "geo" : { },
  "id_str" : "466972631640866817",
  "text" : "If x is a matrix, vector or list then x[]&lt;-0 replaces all its values by 0. More uses of the empty bracket in #rstats: http:\/\/t.co\/Thyc25QipX",
  "id" : 466972631640866817,
  "created_at" : "2014-05-15 16:05:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hO5T71EOxU",
      "expanded_url" : "http:\/\/bit.ly\/1uL1iyk",
      "display_url" : "bit.ly\/1uL1iyk"
    } ]
  },
  "geo" : { },
  "id_str" : "466610228847706112",
  "text" : "A tutorial on how the mboost package can help you use gradient boosting to fit a prediction model http:\/\/t.co\/hO5T71EOxU #rstats",
  "id" : 466610228847706112,
  "created_at" : "2014-05-14 16:05:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/57VzXRCPVh",
      "expanded_url" : "http:\/\/bit.ly\/Ilh5KH",
      "display_url" : "bit.ly\/Ilh5KH"
    } ]
  },
  "geo" : { },
  "id_str" : "466247839103062016",
  "text" : "Can't find a package binary on CRAN? Check its build status on all platforms here: http:\/\/t.co\/57VzXRCPVh #rstats (via @PairachChamp)",
  "id" : 466247839103062016,
  "created_at" : "2014-05-13 16:05:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/8upLJ5HN7I",
      "expanded_url" : "http:\/\/bit.ly\/1nq0M6Z",
      "display_url" : "bit.ly\/1nq0M6Z"
    } ]
  },
  "geo" : { },
  "id_str" : "465885457050767360",
  "text" : "Do the bobyqa(minqa) for derivative free optimization http:\/\/t.co\/8upLJ5HN7I #rstats",
  "id" : 465885457050767360,
  "created_at" : "2014-05-12 16:05:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zLrjk9mk3L",
      "expanded_url" : "http:\/\/bit.ly\/1fXg5w9",
      "display_url" : "bit.ly\/1fXg5w9"
    } ]
  },
  "geo" : { },
  "id_str" : "464798313653735425",
  "text" : "The rmongodb package - an interface to the open-source, NoSQL MongoDB database. Great vignettes http:\/\/t.co\/zLrjk9mk3L #rstats",
  "id" : 464798313653735425,
  "created_at" : "2014-05-09 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fJEBpfPZKB",
      "expanded_url" : "http:\/\/bit.ly\/RdBfjx",
      "display_url" : "bit.ly\/RdBfjx"
    } ]
  },
  "geo" : { },
  "id_str" : "464435975348027392",
  "text" : "The RSQLite package embeds the SQLite DB engine in R - great way to get started with DBMs http:\/\/t.co\/fJEBpfPZKB #rstats",
  "id" : 464435975348027392,
  "created_at" : "2014-05-08 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/YjP3DSbQ6G",
      "expanded_url" : "http:\/\/bit.ly\/Rdz6V0",
      "display_url" : "bit.ly\/Rdz6V0"
    } ]
  },
  "geo" : { },
  "id_str" : "464073553994719233",
  "text" : "The sqldf package lets you do sql queries on an R dataframe http:\/\/t.co\/YjP3DSbQ6G #rstats",
  "id" : 464073553994719233,
  "created_at" : "2014-05-07 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/RnvSUlAhSA",
      "expanded_url" : "http:\/\/bit.ly\/1mnh6Wv",
      "display_url" : "bit.ly\/1mnh6Wv"
    } ]
  },
  "geo" : { },
  "id_str" : "463711150749016065",
  "text" : "The RMySQL package is a database interface and MySQL driver for R http:\/\/t.co\/RnvSUlAhSA #rstats",
  "id" : 463711150749016065,
  "created_at" : "2014-05-06 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/ZuKNDDeumn",
      "expanded_url" : "http:\/\/bit.ly\/PZosQF",
      "display_url" : "bit.ly\/PZosQF"
    } ]
  },
  "geo" : { },
  "id_str" : "463348837701402624",
  "text" : "The RODBC package provides access to SQL databases - Get started with the vignette http:\/\/t.co\/ZuKNDDeumn   #rstats",
  "id" : 463348837701402624,
  "created_at" : "2014-05-05 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/p09MqFmeOC",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "462261618236469249",
  "text" : "search() displays the \"search list\" of packages where R searches for functions and other objects #rstats http:\/\/t.co\/p09MqFmeOC",
  "id" : 462261618236469249,
  "created_at" : "2014-05-02 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/8qNErPykiO",
      "expanded_url" : "http:\/\/bit.ly\/HDgsfu",
      "display_url" : "bit.ly\/HDgsfu"
    } ]
  },
  "geo" : { },
  "id_str" : "461899285521780737",
  "text" : "Use NROW\/NCOL instead of nrow\/ncol to treat vectors as 1-column matrices #rstats http:\/\/t.co\/8qNErPykiO",
  "id" : 461899285521780737,
  "created_at" : "2014-05-01 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]