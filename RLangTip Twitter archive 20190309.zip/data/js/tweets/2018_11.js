Grailbird.data.tweets_2018_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/F1NlBgmmy4",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/any",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1068550222077292544",
  "text" : "Use any() and all() to test if any or all of a vector of logical conditions are true https:\/\/t.co\/F1NlBgmmy4 #rstats",
  "id" : 1068550222077292544,
  "created_at" : "2018-11-30 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/BcvnzloZjW",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.5.1\/topics\/par",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1068187838666035202",
  "text" : "Look at under help(par) for options you can use to customize plot() https:\/\/t.co\/BcvnzloZjW #rstats",
  "id" : 1068187838666035202,
  "created_at" : "2018-11-29 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/SNLCObhLVP",
      "expanded_url" : "https:\/\/docs.microsoft.com\/sql\/advanced-analytics\/r\/set-up-a-data-science-client?view=sql-server-2017&WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/sql\/advanced-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1067825447927336960",
  "text" : "How to set up a data science client for R development on SQL Server: https:\/\/t.co\/SNLCObhLVP #rstats",
  "id" : 1067825447927336960,
  "created_at" : "2018-11-28 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BufaNg8XPy",
      "expanded_url" : "https:\/\/chapmandu2.github.io\/post\/2018\/05\/26\/reproducible-data-science-environments-with-docker\/",
      "display_url" : "chapmandu2.github.io\/post\/2018\/05\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1067463064189001728",
  "text" : "A guide to making a reproducible data science environment with R and Docker https:\/\/t.co\/BufaNg8XPy #rstats",
  "id" : 1067463064189001728,
  "created_at" : "2018-11-27 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/C01aPfta04",
      "expanded_url" : "http:\/\/dirk.eddelbuettel.com\/code\/rcpp\/Rcpp-introduction.pdf",
      "display_url" : "dirk.eddelbuettel.com\/code\/rcpp\/Rcpp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1067100674658197505",
  "text" : "Introduction to Rcpp, an R module for integrating C and C++ code: https:\/\/t.co\/C01aPfta04 #rstats",
  "id" : 1067100674658197505,
  "created_at" : "2018-11-26 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Grolemund",
      "screen_name" : "StatGarrett",
      "indices" : [ 65, 77 ],
      "id_str" : "2499047479",
      "id" : 2499047479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/0z0wlNybxe",
      "expanded_url" : "https:\/\/rstudio-education.github.io\/hopr\/",
      "display_url" : "rstudio-education.github.io\/hopr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1066013518934106112",
  "text" : "Hands-On Programming with R, a book to teach programming in R by @StatGarrett, available in its entirety at https:\/\/t.co\/0z0wlNybxe #rstats",
  "id" : 1066013518934106112,
  "created_at" : "2018-11-23 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/mwKR3pncrd",
      "expanded_url" : "https:\/\/www.r-project.org\/contributors.html",
      "display_url" : "r-project.org\/contributors.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1065651119349792769",
  "text" : "Thanks to the R Core Group, for volunteering their time and expertise to create, improve and support R https:\/\/t.co\/mwKR3pncrd #rstats",
  "id" : 1065651119349792769,
  "created_at" : "2018-11-22 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/70XwjnPuAm",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/checkpoint\/",
      "display_url" : "mran.microsoft.com\/package\/checkp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1065288732738113536",
  "text" : "Use checkpoint(\"2018-11-21\") to make the current project always use today's package versions from now on https:\/\/t.co\/70XwjnPuAm #rstats",
  "id" : 1065288732738113536,
  "created_at" : "2018-11-21 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 198, 205 ]
    } ],
    "urls" : [ {
      "indices" : [ 174, 197 ],
      "url" : "https:\/\/t.co\/ySrUMUpwZE",
      "expanded_url" : "https:\/\/cloud.r-project.org\/package=httr&version=1.3.0",
      "display_url" : "cloud.r-project.org\/package=httr&v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1064926346973917184",
  "text" : "Download the source tarball for a specific version of a CRAN package by appending \n &amp;package=&lt;name&gt;&amp;version=&lt;version_no&gt;\nto the CRAN mirror URL. Example: https:\/\/t.co\/ySrUMUpwZE #rstats",
  "id" : 1064926346973917184,
  "created_at" : "2018-11-20 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "rstats",
      "indices" : [ 230, 237 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/yT3Yibjuvv",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/plot.lm",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    }, {
      "indices" : [ 206, 229 ],
      "url" : "https:\/\/t.co\/yT3Yibjuvv",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/plot.lm",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1064563958693093376",
  "text" : "par(mfrow=c(2,2)); plot(lm(y~x)) will produce 4 nice plots of the regression residuals https:\/\/t.co\/yT3Yibjuvv #rstats\npar(mfrow=c(2,2)); plot(lm(y~x)) will produce 4 nice plots of the regression residuals https:\/\/t.co\/yT3Yibjuvv #rstats",
  "id" : 1064563958693093376,
  "created_at" : "2018-11-19 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/EJ3uWs3jvW",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/MASS\/versions\/7.3-51.1\/topics\/Null",
      "display_url" : "rdocumentation.org\/packages\/MASS\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1063540965250482176",
  "text" : "Some #rstats Linear Algebra: For a matrix M, Null(M) \u007BMASS package\u007D finds a matrix giving a basis for the left null space https:\/\/t.co\/EJ3uWs3jvW",
  "id" : 1063540965250482176,
  "created_at" : "2018-11-16 21:15:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 193, 200 ]
    } ],
    "urls" : [ {
      "indices" : [ 169, 192 ],
      "url" : "https:\/\/t.co\/flxJjXU7RA",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/magrittr\/versions\/1.5\/topics\/%25%3C%3E%25",
      "display_url" : "rdocumentation.org\/packages\/magri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1063084213983801344",
  "text" : "You can use the %&lt;&gt;% operator (in the magrittr package) to update an object with a pipe. \n  a %&lt;&gt;% f %&gt;% g \nis the same as \n  a &lt;- a %&gt;% f %&gt;% g\nhttps:\/\/t.co\/flxJjXU7RA #rstats",
  "id" : 1063084213983801344,
  "created_at" : "2018-11-15 15:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/3VyMgFfb81",
      "expanded_url" : "https:\/\/docs.azuredatabricks.net\/spark\/latest\/sparkr\/rstudio.html",
      "display_url" : "docs.azuredatabricks.net\/spark\/latest\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1062752020296228864",
  "text" : "How to run RStudio on Azure Databricks https:\/\/t.co\/3VyMgFfb81 #rstats",
  "id" : 1062752020296228864,
  "created_at" : "2018-11-14 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/hoa06QsnJU",
      "expanded_url" : "http:\/\/jhudatascience.org\/chromebookdatascience\/",
      "display_url" : "jhudatascience.org\/chromebookdata\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1062389629528137728",
  "text" : "Chromebook Data Science, a free course on Data Science with R from the Johns Hopkins Data Science lab #rstats https:\/\/t.co\/hoa06QsnJU",
  "id" : 1062389629528137728,
  "created_at" : "2018-11-13 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 137, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RgnvmV1SRR",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/Logic",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1062027242862194689",
  "text" : "Use the || and &amp;&amp; operators when working with scalar booleans; use | and &amp; when working with vectors https:\/\/t.co\/RgnvmV1SRR #rstats",
  "id" : 1062027242862194689,
  "created_at" : "2018-11-12 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/zAsvbzBKZc",
      "expanded_url" : "http:\/\/yatani.jp\/HCIstats\/ANOVA\/",
      "display_url" : "yatani.jp\/HCIstats\/ANOVA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1060940082515865600",
  "text" : "Tutorial: Analysis of Variance (ANOVA) for comparing the means https:\/\/t.co\/zAsvbzBKZc #rstats",
  "id" : 1060940082515865600,
  "created_at" : "2018-11-09 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/vRT9V2vmby",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/mgcv\/versions\/1.8-25\/topics\/bam",
      "display_url" : "rdocumentation.org\/packages\/mgcv\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060577697061990400",
  "text" : "Want to fit a generalized additive model to a large data set? Try the bam() function in the mgcv package https:\/\/t.co\/vRT9V2vmby #rstats",
  "id" : 1060577697061990400,
  "created_at" : "2018-11-08 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/H5sLTDyNyl",
      "expanded_url" : "https:\/\/docs.microsoft.com\/azure\/azure-databricks\/connect-databricks-excel-python-r?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/azure\/azure-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060215306281410560",
  "text" : "How to connect to Azure Databricks from R https:\/\/t.co\/H5sLTDyNyl #rstats",
  "id" : 1060215306281410560,
  "created_at" : "2018-11-07 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 155, 162 ]
    } ],
    "urls" : [ {
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/A3BnxR6PcH",
      "expanded_url" : "https:\/\/github.com\/r-lib\/fs#comparison-vs-base-equivalents",
      "display_url" : "github.com\/r-lib\/fs#compa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059852914745921537",
  "text" : "The fs package provides a unified, consistent, and cross-platform set of function for interacting with files and directories in R: https:\/\/t.co\/A3BnxR6PcH #rstats",
  "id" : 1059852914745921537,
  "created_at" : "2018-11-06 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/4JTw63NUPm",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/R-data.html",
      "display_url" : "cran.r-project.org\/doc\/manuals\/R-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059490527186436098",
  "text" : "Info on getting data from databases, spreadsheets, binary files and APIs into #rstats, from the official R data import\/export manual: https:\/\/t.co\/4JTw63NUPm",
  "id" : 1059490527186436098,
  "created_at" : "2018-11-05 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 147, 154 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/yejvDrk4D9",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/nchar",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058388262371262466",
  "text" : "nchar(string) finds the length of a string, whereas length(string) finds the length of the vector containing the string(s) https:\/\/t.co\/yejvDrk4D9 #rstats",
  "id" : 1058388262371262466,
  "created_at" : "2018-11-02 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/V7a2xNRU4f",
      "expanded_url" : "http:\/\/adv-r.had.co.nz\/Data-structures.html",
      "display_url" : "adv-r.had.co.nz\/Data-structure\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058025880579010562",
  "text" : "Use is.atomic(v) NOT is.vector(v) to test if vector. Try:\n v=9; attr(v,\"A\") = \"attr\" \nSee Wickham, Advanced R https:\/\/t.co\/V7a2xNRU4f #rstats",
  "id" : 1058025880579010562,
  "created_at" : "2018-11-01 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]