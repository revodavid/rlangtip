Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/FDHDZSMTSA",
      "expanded_url" : "http:\/\/bit.ly\/1VJaIGu",
      "display_url" : "bit.ly\/1VJaIGu"
    } ]
  },
  "geo" : { },
  "id_str" : "704351907771498501",
  "text" : "alias(object) \u007Bstats\u007D will find linearly dependent terms in  linear models. https:\/\/t.co\/FDHDZSMTSA #rstats",
  "id" : 704351907771498501,
  "created_at" : "2016-02-29 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/tqV3bNhLP0",
      "expanded_url" : "http:\/\/bit.ly\/1PLCfFy",
      "display_url" : "bit.ly\/1PLCfFy"
    } ]
  },
  "geo" : { },
  "id_str" : "703148820243218432",
  "text" : "head(x, n) shows the first n elements of x if n is positive, all but the last |n| elements if n is negative. https:\/\/t.co\/tqV3bNhLP0 #rstats",
  "id" : 703148820243218432,
  "created_at" : "2016-02-26 09:25:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/IGSNgat7R0",
      "expanded_url" : "http:\/\/bit.ly\/1KZPGCA",
      "display_url" : "bit.ly\/1KZPGCA"
    } ]
  },
  "geo" : { },
  "id_str" : "702902411598422017",
  "text" : "rle(x) \u007Bbase\u007D computes the lengths of runs of equal values in a vector. https:\/\/t.co\/IGSNgat7R0 #rstats",
  "id" : 702902411598422017,
  "created_at" : "2016-02-25 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/290B5xPTuC",
      "expanded_url" : "http:\/\/bit.ly\/1a7LJHv",
      "display_url" : "bit.ly\/1a7LJHv"
    } ]
  },
  "geo" : { },
  "id_str" : "702539987594682368",
  "text" : "? is a shortcut for help(). ?? is a shortcut for help.search(). https:\/\/t.co\/290B5xPTuC #rstats",
  "id" : 702539987594682368,
  "created_at" : "2016-02-24 17:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/wyIRzEDEkQ",
      "expanded_url" : "http:\/\/bit.ly\/1oPY0el",
      "display_url" : "bit.ly\/1oPY0el"
    } ]
  },
  "geo" : { },
  "id_str" : "702177623380779008",
  "text" : "Use xtabs(formula,data) \u007Bstats\u007D to create a contingency table from cross-classifying factors. https:\/\/t.co\/wyIRzEDEkQ #rstats",
  "id" : 702177623380779008,
  "created_at" : "2016-02-23 17:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/0cJy25Sgtt",
      "expanded_url" : "http:\/\/bit.ly\/1KZFbzn",
      "display_url" : "bit.ly\/1KZFbzn"
    } ]
  },
  "geo" : { },
  "id_str" : "701815200631095296",
  "text" : "sessionInfo()$otherPkgs will print the details of non base R packages attached to your session. https:\/\/t.co\/0cJy25Sgtt #rstats",
  "id" : 701815200631095296,
  "created_at" : "2016-02-22 17:05:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/p09MqF45Au",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "700728097742708738",
  "text" : "search() is an easy way to find out what packages are loaded and available for use: https:\/\/t.co\/p09MqF45Au #rstats",
  "id" : 700728097742708738,
  "created_at" : "2016-02-19 17:06:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/yppChnYeJf",
      "expanded_url" : "http:\/\/bit.ly\/I3YiHQ",
      "display_url" : "bit.ly\/I3YiHQ"
    } ]
  },
  "geo" : { },
  "id_str" : "700365708694315008",
  "text" : "Change the direction of plot axis labels with las \u007B0,1,2,3\u007D e.g. plot(x,y,las=1) #rstats https:\/\/t.co\/yppChnYeJf",
  "id" : 700365708694315008,
  "created_at" : "2016-02-18 17:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/ynYLxA9vyk",
      "expanded_url" : "http:\/\/bit.ly\/1ob5Or6",
      "display_url" : "bit.ly\/1ob5Or6"
    } ]
  },
  "geo" : { },
  "id_str" : "700003296120086528",
  "text" : "polygon(x,y) \u007Bgraphics\u007D will draw a polygon whose vertices are given by the vectors x and y https:\/\/t.co\/ynYLxA9vyk #rstats",
  "id" : 700003296120086528,
  "created_at" : "2016-02-17 17:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/r0n3WqlCLR",
      "expanded_url" : "http:\/\/bit.ly\/1PRYBqe",
      "display_url" : "bit.ly\/1PRYBqe"
    } ]
  },
  "geo" : { },
  "id_str" : "699640893326946309",
  "text" : "nchar(sting) \u007Bbase] finds the length of a string https:\/\/t.co\/r0n3WqlCLR #rstats",
  "id" : 699640893326946309,
  "created_at" : "2016-02-16 17:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699278471537803265",
  "text" : "Get an overview of documentation for an installed package: help(package=\"&lt;package-name&gt;\") #rstats",
  "id" : 699278471537803265,
  "created_at" : "2016-02-15 17:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/lzKj4ZVoBQ",
      "expanded_url" : "http:\/\/bit.ly\/1caN5AN",
      "display_url" : "bit.ly\/1caN5AN"
    } ]
  },
  "geo" : { },
  "id_str" : "698191527630213121",
  "text" : "#rstats Compare 2 R objects using compare(obj1,obj2) in the compare package https:\/\/t.co\/lzKj4ZVoBQ",
  "id" : 698191527630213121,
  "created_at" : "2016-02-12 17:06:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark the Graph",
      "screen_name" : "Mark_Graph",
      "indices" : [ 37, 48 ],
      "id_str" : "522124915",
      "id" : 522124915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/KrppSw7z48",
      "expanded_url" : "http:\/\/bit.ly\/UzCoCj",
      "display_url" : "bit.ly\/UzCoCj"
    } ]
  },
  "geo" : { },
  "id_str" : "697829000610185220",
  "text" : "A collection of R \"cheet sheets\" (by @Mark_Graph): https:\/\/t.co\/KrppSw7z48 #rstats",
  "id" : 697829000610185220,
  "created_at" : "2016-02-11 17:06:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noam Ross",
      "screen_name" : "noamross",
      "indices" : [ 129, 138 ],
      "id_str" : "97582853",
      "id" : 97582853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/BQkuLSIcnP",
      "expanded_url" : "http:\/\/bit.ly\/PxLttn",
      "display_url" : "bit.ly\/PxLttn"
    } ]
  },
  "geo" : { },
  "id_str" : "697466650703036416",
  "text" : "A progress bar that shows only in the console: if(interactive) \u007Bpb &lt;- txtProgressBar(\u2026)\u007D #rstats https:\/\/t.co\/BQkuLSIcnP (via @noamross)",
  "id" : 697466650703036416,
  "created_at" : "2016-02-10 17:06:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/LBuyGM8E1n",
      "expanded_url" : "http:\/\/bit.ly\/1RahDJo",
      "display_url" : "bit.ly\/1RahDJo"
    } ]
  },
  "geo" : { },
  "id_str" : "697104230117728256",
  "text" : "vcov(obj) \u007Bstats\u007Dcalculates the Variance-Covariance matirx of a fitted model object. https:\/\/t.co\/LBuyGM8E1n #rstats",
  "id" : 697104230117728256,
  "created_at" : "2016-02-09 17:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/B8czfmTWyA",
      "expanded_url" : "http:\/\/bit.ly\/20epHcs",
      "display_url" : "bit.ly\/20epHcs"
    } ]
  },
  "geo" : { },
  "id_str" : "696741748454899712",
  "text" : "agnes() in \u007Bcluster\u007D implements 6 methods of agglomerative clustering. https:\/\/t.co\/B8czfmTWyA #rstats",
  "id" : 696741748454899712,
  "created_at" : "2016-02-08 17:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/9QEaittPdD",
      "expanded_url" : "http:\/\/bit.ly\/17EZMlU",
      "display_url" : "bit.ly\/17EZMlU"
    } ]
  },
  "geo" : { },
  "id_str" : "695654683826851840",
  "text" : "Get the unique values of a variable, x, with unique(x) #rstats https:\/\/t.co\/9QEaittPdD",
  "id" : 695654683826851840,
  "created_at" : "2016-02-05 17:06:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/UCn6G3wCZV",
      "expanded_url" : "http:\/\/bit.ly\/1dYFk2m",
      "display_url" : "bit.ly\/1dYFk2m"
    } ]
  },
  "geo" : { },
  "id_str" : "695292265523200000",
  "text" : "Use object.size() to estimate the amount of memory an R object is consuming #rstats https:\/\/t.co\/UCn6G3wCZV",
  "id" : 695292265523200000,
  "created_at" : "2016-02-04 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/mSCa72MmYl",
      "expanded_url" : "http:\/\/bit.ly\/VJt1wl",
      "display_url" : "bit.ly\/VJt1wl"
    } ]
  },
  "geo" : { },
  "id_str" : "694929885308022784",
  "text" : "Add a zero imaginary part to a number for complex arguments. sqrt(-1) returns NaN; sqrt(-1+0i) returns 1i #rstats https:\/\/t.co\/mSCa72MmYl",
  "id" : 694929885308022784,
  "created_at" : "2016-02-03 17:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/T3YJoyDCne",
      "expanded_url" : "http:\/\/bit.ly\/1WSc4iQ",
      "display_url" : "bit.ly\/1WSc4iQ"
    } ]
  },
  "geo" : { },
  "id_str" : "694567488617648128",
  "text" : "The function fromJSON() \u007BRJSONIO\u007D converts JSON content to R objects https:\/\/t.co\/T3YJoyDCne #rstats",
  "id" : 694567488617648128,
  "created_at" : "2016-02-02 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/g0v78W9UjS",
      "expanded_url" : "http:\/\/bit.ly\/1KKEpRt",
      "display_url" : "bit.ly\/1KKEpRt"
    } ]
  },
  "geo" : { },
  "id_str" : "694567488936361990",
  "text" : "Some #rstats Linear Algebra: For a matrix M, Null(M)  \u007BMASS\u007D finds a matrix giving a basis for the left null space https:\/\/t.co\/g0v78W9UjS",
  "id" : 694567488936361990,
  "created_at" : "2016-02-02 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]