Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/fGa6jfJTiN",
      "expanded_url" : "http:\/\/bit.ly\/1HjiwM8",
      "display_url" : "bit.ly\/1HjiwM8"
    } ]
  },
  "geo" : { },
  "id_str" : "615914150242459649",
  "text" : "Use setdiff(x,y) \u007Bbase\u007D to get the difference between 2 vectors http:\/\/t.co\/fGa6jfJTiN #rstats",
  "id" : 615914150242459649,
  "created_at" : "2015-06-30 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/6aY2IBd3qb",
      "expanded_url" : "http:\/\/bit.ly\/1LrHfOf",
      "display_url" : "bit.ly\/1LrHfOf"
    } ]
  },
  "geo" : { },
  "id_str" : "615551769129689088",
  "text" : "Look at the installr package to obtain package download counts from the RStudio CRAN logs  http:\/\/t.co\/6aY2IBd3qb #rstats",
  "id" : 615551769129689088,
  "created_at" : "2015-06-29 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/56Yvg6vJbk",
      "expanded_url" : "http:\/\/bit.ly\/LpJWCh",
      "display_url" : "bit.ly\/LpJWCh"
    } ]
  },
  "geo" : { },
  "id_str" : "614464610742206464",
  "text" : "Extracting data from PDFs with #rstats. Vector Image Processing http:\/\/t.co\/56Yvg6vJbk (PDF)",
  "id" : 614464610742206464,
  "created_at" : "2015-06-26 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/WLcz3DHDB0",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "614102224843730944",
  "text" : "Use the || and &amp;&amp; operators when working with scalar booleans; use | and &amp; when working with vectors #rstats http:\/\/t.co\/WLcz3DHDB0",
  "id" : 614102224843730944,
  "created_at" : "2015-06-25 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/mVRTne93K5",
      "expanded_url" : "http:\/\/bit.ly\/1H48G0L",
      "display_url" : "bit.ly\/1H48G0L"
    } ]
  },
  "geo" : { },
  "id_str" : "613739898609266689",
  "text" : "Get a confidence interval for the median of a vector x with wilcox.test(x)  http:\/\/t.co\/mVRTne93K5 #rstats cf(Teetor R CookbooK p206)",
  "id" : 613739898609266689,
  "created_at" : "2015-06-24 16:06:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/8ukEqHhDqe",
      "expanded_url" : "http:\/\/bit.ly\/x9UdLI",
      "display_url" : "bit.ly\/x9UdLI"
    } ]
  },
  "geo" : { },
  "id_str" : "613377555782103040",
  "text" : "sample(vec, n)  will randomly select elements n elements from a vector #rstats http:\/\/t.co\/8ukEqHhDqe",
  "id" : 613377555782103040,
  "created_at" : "2015-06-23 16:06:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/mVRTne93K5",
      "expanded_url" : "http:\/\/bit.ly\/1H48G0L",
      "display_url" : "bit.ly\/1H48G0L"
    } ]
  },
  "geo" : { },
  "id_str" : "613015143367241728",
  "text" : "available.packages() \u007Butils\u007D returns details about packages currently available on CRAN http:\/\/t.co\/mVRTne93K5 #rstats",
  "id" : 613015143367241728,
  "created_at" : "2015-06-22 16:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ovmeru5Q9n",
      "expanded_url" : "http:\/\/bit.ly\/AfpXZF",
      "display_url" : "bit.ly\/AfpXZF"
    } ]
  },
  "geo" : { },
  "id_str" : "611927893275463680",
  "text" : "How to credit R in a manuscript or article: citation(). Works for packages, too: citation(\"MASS\") #rstats http:\/\/t.co\/ovmeru5Q9n",
  "id" : 611927893275463680,
  "created_at" : "2015-06-19 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Dicds5lPIv",
      "expanded_url" : "http:\/\/bit.ly\/zBaVM4",
      "display_url" : "bit.ly\/zBaVM4"
    } ]
  },
  "geo" : { },
  "id_str" : "611567768090079232",
  "text" : "Use the RMySQL package to read data from MySQL into R using SQL queries: http:\/\/t.co\/Dicds5lPIv #rstats",
  "id" : 611567768090079232,
  "created_at" : "2015-06-18 16:14:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/PDvD5BUDfL",
      "expanded_url" : "http:\/\/bit.ly\/1JOPtPq",
      "display_url" : "bit.ly\/1JOPtPq"
    } ]
  },
  "geo" : { },
  "id_str" : "611203108836896768",
  "text" : "rotationForest() is a new ensemble classifier available in R http:\/\/t.co\/PDvD5BUDfL #rstats",
  "id" : 611203108836896768,
  "created_at" : "2015-06-17 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/NERjrgfTcJ",
      "expanded_url" : "http:\/\/bit.ly\/1QTroHu",
      "display_url" : "bit.ly\/1QTroHu"
    } ]
  },
  "geo" : { },
  "id_str" : "610840736762703872",
  "text" : "Correlated variables? Try principal components regression with the pca() function in the pls package http:\/\/t.co\/NERjrgfTcJ #rstats",
  "id" : 610840736762703872,
  "created_at" : "2015-06-16 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/WP9wR1JkTl",
      "expanded_url" : "http:\/\/bit.ly\/1IAfUXw",
      "display_url" : "bit.ly\/1IAfUXw"
    } ]
  },
  "geo" : { },
  "id_str" : "610478347232112640",
  "text" : "Try the leafletR package for creating interactive, javaScript based maps frpm R http:\/\/t.co\/WP9wR1JkTl #rstats",
  "id" : 610478347232112640,
  "created_at" : "2015-06-15 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/18mrk5iFFY",
      "expanded_url" : "http:\/\/bit.ly\/vzBAhQ",
      "display_url" : "bit.ly\/vzBAhQ"
    } ]
  },
  "geo" : { },
  "id_str" : "609391153792819203",
  "text" : "Robust function writing tip: use seq_len(N) instead of 1:N (it handles the N&lt;1 case appropriately): http:\/\/t.co\/18mrk5iFFY #rstats",
  "id" : 609391153792819203,
  "created_at" : "2015-06-12 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/BrpsXsmyOW",
      "expanded_url" : "http:\/\/bit.ly\/Jz3aVm",
      "display_url" : "bit.ly\/Jz3aVm"
    } ]
  },
  "geo" : { },
  "id_str" : "609028792020033537",
  "text" : "Convert a comma-separated string to a vector: strsplit(\"red,green,blue\",\",\")[[1]] #rstats http:\/\/t.co\/BrpsXsmyOW",
  "id" : 609028792020033537,
  "created_at" : "2015-06-11 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/WLcz3DHDB0",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "608666387108741120",
  "text" : "Efficiency tip: TRUE || (x &lt;-3) will never evaluate the right hand side. Using &amp;&amp; and || can save cycles #rstats http:\/\/t.co\/WLcz3DHDB0",
  "id" : 608666387108741120,
  "created_at" : "2015-06-10 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/1HXmHDzLBU",
      "expanded_url" : "http:\/\/bit.ly\/1IpNpyw",
      "display_url" : "bit.ly\/1IpNpyw"
    } ]
  },
  "geo" : { },
  "id_str" : "608304038845812736",
  "text" : "Read an HTML table from a website with readHTMLTable(url)  in the XML package http:\/\/t.co\/1HXmHDzLBU #stats",
  "id" : 608304038845812736,
  "created_at" : "2015-06-09 16:05:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/h7576eicyT",
      "expanded_url" : "http:\/\/bit.ly\/1Iie2CA",
      "display_url" : "bit.ly\/1Iie2CA"
    } ]
  },
  "geo" : { },
  "id_str" : "607941595388866560",
  "text" : "Hunt for an object in all loaded namespaces with getAnywhere(object) http:\/\/t.co\/h7576eicyT #rstats",
  "id" : 607941595388866560,
  "created_at" : "2015-06-08 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/r81zU9NSim",
      "expanded_url" : "http:\/\/bit.ly\/MO2agl",
      "display_url" : "bit.ly\/MO2agl"
    } ]
  },
  "geo" : { },
  "id_str" : "606854447587815425",
  "text" : "Check which packages you have installed with names(installed.packages()[,1]) http:\/\/t.co\/r81zU9NSim #rstats",
  "id" : 606854447587815425,
  "created_at" : "2015-06-05 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/YxKJPWQiTf",
      "expanded_url" : "http:\/\/bit.ly\/KETjbI",
      "display_url" : "bit.ly\/KETjbI"
    } ]
  },
  "geo" : { },
  "id_str" : "606492040382300160",
  "text" : "Index of datasets included with R: http:\/\/t.co\/YxKJPWQiTf #rstats",
  "id" : 606492040382300160,
  "created_at" : "2015-06-04 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/EVwQkMTOtC",
      "expanded_url" : "http:\/\/bit.ly\/xywuih",
      "display_url" : "bit.ly\/xywuih"
    } ]
  },
  "geo" : { },
  "id_str" : "606129688621268995",
  "text" : "In R scripts, use invisible() to prevent functions from generating unwanted output: http:\/\/t.co\/EVwQkMTOtC #rstats",
  "id" : 606129688621268995,
  "created_at" : "2015-06-03 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/IlYcd9MXzw",
      "expanded_url" : "http:\/\/bit.ly\/LpG9Vs",
      "display_url" : "bit.ly\/LpG9Vs"
    } ]
  },
  "geo" : { },
  "id_str" : "605767367382040576",
  "text" : "How to create interactive #rstats charts on the web with RGoogleVis: http:\/\/t.co\/IlYcd9MXzw #rstats",
  "id" : 605767367382040576,
  "created_at" : "2015-06-02 16:06:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/76o1fVFIk0",
      "expanded_url" : "http:\/\/bit.ly\/1HZpKon",
      "display_url" : "bit.ly\/1HZpKon"
    } ]
  },
  "geo" : { },
  "id_str" : "605404951804833792",
  "text" : "Spell check a file from R with aspell(file_name) http:\/\/t.co\/76o1fVFIk0 #rstats",
  "id" : 605404951804833792,
  "created_at" : "2015-06-01 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]