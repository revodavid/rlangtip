Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/x5d8lJtMcq",
      "expanded_url" : "http:\/\/bit.ly\/1rKRWkC",
      "display_url" : "bit.ly\/1rKRWkC"
    }, {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/SqYbtTYuHJ",
      "expanded_url" : "http:\/\/bit.ly\/1fsF1Lz",
      "display_url" : "bit.ly\/1fsF1Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "450665294747684864",
  "text" : "2 short tutorials for the reshape2 package: http:\/\/t.co\/x5d8lJtMcq and http:\/\/t.co\/SqYbtTYuHJ #rstats",
  "id" : 450665294747684864,
  "created_at" : "2014-03-31 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/I1U4VIBG8Z",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "447042075599843328",
  "text" : "Type ?Startup for a description of R's initialization process and how to configure it: http:\/\/t.co\/I1U4VIBG8Z #rstats",
  "id" : 447042075599843328,
  "created_at" : "2014-03-21 16:08:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5v002KuWWu",
      "expanded_url" : "http:\/\/bit.ly\/yUSrZr",
      "display_url" : "bit.ly\/yUSrZr"
    } ]
  },
  "geo" : { },
  "id_str" : "446678975415611392",
  "text" : "Install an R package directly from GitHub with devtools package: http:\/\/t.co\/5v002KuWWu #rstats",
  "id" : 446678975415611392,
  "created_at" : "2014-03-20 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/hcziWL5EPg",
      "expanded_url" : "http:\/\/bit.ly\/1hkfw0r",
      "display_url" : "bit.ly\/1hkfw0r"
    } ]
  },
  "geo" : { },
  "id_str" : "446316647788593152",
  "text" : "Sort a vector into decreasing order: sort(x,decreasing=TRUE) #rstats http:\/\/t.co\/hcziWL5EPg",
  "id" : 446316647788593152,
  "created_at" : "2014-03-19 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uiCjBXrf6Q",
      "expanded_url" : "http:\/\/bit.ly\/onqu7V",
      "display_url" : "bit.ly\/onqu7V"
    } ]
  },
  "geo" : { },
  "id_str" : "445954190947655680",
  "text" : "Use the with() function to write R code using variables in a data frame, without needing the $ syntax: #rstats http:\/\/t.co\/uiCjBXrf6Q",
  "id" : 445954190947655680,
  "created_at" : "2014-03-18 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/CA8FeH11eG",
      "expanded_url" : "http:\/\/bit.ly\/OqMe7G",
      "display_url" : "bit.ly\/OqMe7G"
    } ]
  },
  "geo" : { },
  "id_str" : "445591769787695105",
  "text" : "Use the stringr package to make life easier when working with strings. #rstats http:\/\/t.co\/CA8FeH11eG",
  "id" : 445591769787695105,
  "created_at" : "2014-03-17 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/6jff1ZiXWV",
      "expanded_url" : "http:\/\/bit.ly\/zCxy4H",
      "display_url" : "bit.ly\/zCxy4H"
    } ]
  },
  "geo" : { },
  "id_str" : "444504640374439936",
  "text" : "Constants built into #rstats: letters, months and pi: http:\/\/t.co\/6jff1ZiXWV",
  "id" : 444504640374439936,
  "created_at" : "2014-03-14 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2e4h2bw15B",
      "expanded_url" : "http:\/\/bit.ly\/woMnsV",
      "display_url" : "bit.ly\/woMnsV"
    } ]
  },
  "geo" : { },
  "id_str" : "444142212855922689",
  "text" : "Every row of a data frame has a unique label, which you can set or retrieve with row.names: http:\/\/t.co\/2e4h2bw15B #rstats",
  "id" : 444142212855922689,
  "created_at" : "2014-03-13 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/5NKEBWEKVS",
      "expanded_url" : "http:\/\/bit.ly\/1iiCxlg",
      "display_url" : "bit.ly\/1iiCxlg"
    } ]
  },
  "geo" : { },
  "id_str" : "443779821299318784",
  "text" : "Build sliders and other interactive controls with the manipulate package in RStudio #rstats http:\/\/t.co\/5NKEBWEKVS",
  "id" : 443779821299318784,
  "created_at" : "2014-03-12 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/CHvsXgppuI",
      "expanded_url" : "http:\/\/bit.ly\/1feunH1",
      "display_url" : "bit.ly\/1feunH1"
    } ]
  },
  "geo" : { },
  "id_str" : "443417460428251136",
  "text" : "Use readLines() to read a text file line by line #rstats http:\/\/t.co\/CHvsXgppuI",
  "id" : 443417460428251136,
  "created_at" : "2014-03-11 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/OjJ0GUuRAB",
      "expanded_url" : "http:\/\/bit.ly\/1cITKAZ",
      "display_url" : "bit.ly\/1cITKAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "443055028858023936",
  "text" : "Use the bayesglm() function of the arm package to perform a Bayesian logistic regression #rstats http:\/\/t.co\/OjJ0GUuRAB",
  "id" : 443055028858023936,
  "created_at" : "2014-03-10 16:05:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3cHPOGx5tQ",
      "expanded_url" : "http:\/\/bit.ly\/ZX3lPb",
      "display_url" : "bit.ly\/ZX3lPb"
    } ]
  },
  "geo" : { },
  "id_str" : "441983011404664832",
  "text" : "To tell what version of package foo you're running, you can call packageDescription(foo)$Version #rstats http:\/\/t.co\/3cHPOGx5tQ",
  "id" : 441983011404664832,
  "created_at" : "2014-03-07 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wAoK4jvmFN",
      "expanded_url" : "http:\/\/bit.ly\/XsdjaS",
      "display_url" : "bit.ly\/XsdjaS"
    } ]
  },
  "geo" : { },
  "id_str" : "441620729222950912",
  "text" : "Easily format numbers with fixed precision in strings with sprintf: http:\/\/t.co\/wAoK4jvmFN #rstats",
  "id" : 441620729222950912,
  "created_at" : "2014-03-06 17:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/P2GV6MVKDx",
      "expanded_url" : "http:\/\/bit.ly\/1mOItVP",
      "display_url" : "bit.ly\/1mOItVP"
    } ]
  },
  "geo" : { },
  "id_str" : "441258279227105281",
  "text" : "Use scale(x) to calculate the Z-scores of the entries in a numeric vector x,  http:\/\/t.co\/P2GV6MVKDx #rstats",
  "id" : 441258279227105281,
  "created_at" : "2014-03-05 17:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/7Fmd83VchX",
      "expanded_url" : "http:\/\/bit.ly\/1fwX3kr",
      "display_url" : "bit.ly\/1fwX3kr"
    } ]
  },
  "geo" : { },
  "id_str" : "440895925297614848",
  "text" : "Use combn(1:n,m) to find all combinations of the first n numbers taken m at a time. http:\/\/t.co\/7Fmd83VchX #rstats",
  "id" : 440895925297614848,
  "created_at" : "2014-03-04 17:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/nl4UnuVJ89",
      "expanded_url" : "http:\/\/bit.ly\/MArWaE",
      "display_url" : "bit.ly\/MArWaE"
    } ]
  },
  "geo" : { },
  "id_str" : "440533538656751616",
  "text" : "For an illuminating discussion of R formulas from the National Park Service see http:\/\/t.co\/nl4UnuVJ89 #rstats",
  "id" : 440533538656751616,
  "created_at" : "2014-03-03 17:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]