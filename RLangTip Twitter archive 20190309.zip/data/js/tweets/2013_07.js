Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/8hNMrJrpIq",
      "expanded_url" : "http:\/\/bit.ly\/N1IVBw",
      "display_url" : "bit.ly\/N1IVBw"
    } ]
  },
  "geo" : { },
  "id_str" : "362605403147739137",
  "text" : "How to use the ifelse function to dichotomize a variable [video]: http:\/\/t.co\/8hNMrJrpIq #rstats",
  "id" : 362605403147739137,
  "created_at" : "2013-07-31 16:07:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/0koTRpuxR9",
      "expanded_url" : "http:\/\/bit.ly\/M6msE6",
      "display_url" : "bit.ly\/M6msE6"
    } ]
  },
  "geo" : { },
  "id_str" : "362243588358275072",
  "text" : "Object names in R usually contain letters, numbers, periods and underscores, but other names are possible: http:\/\/t.co\/0koTRpuxR9 #rstats",
  "id" : 362243588358275072,
  "created_at" : "2013-07-30 16:09:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/dy0mU6kn1s",
      "expanded_url" : "http:\/\/bit.ly\/16kc9Ry",
      "display_url" : "bit.ly\/16kc9Ry"
    } ]
  },
  "geo" : { },
  "id_str" : "361880875538984961",
  "text" : "An R user's case for Emacs: \"Emacs has no learning curve\" (http:\/\/t.co\/dy0mU6kn1s) #rstats",
  "id" : 361880875538984961,
  "created_at" : "2013-07-29 16:08:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/czOWEjWoGg",
      "expanded_url" : "http:\/\/bit.ly\/pe0KO2",
      "display_url" : "bit.ly\/pe0KO2"
    } ]
  },
  "geo" : { },
  "id_str" : "360794366714982401",
  "text" : "List of R functions and packages for clinical trial design, monitoring and analysis: http:\/\/t.co\/czOWEjWoGg #rstats",
  "id" : 360794366714982401,
  "created_at" : "2013-07-26 16:10:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5CvqlTG0Yf",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "360432077595869187",
  "text" : "To select a column from a matrix and keep it as a column matrix, not a vector: X[,1,drop=FALSE] http:\/\/t.co\/5CvqlTG0Yf #rstats",
  "id" : 360432077595869187,
  "created_at" : "2013-07-25 16:11:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360069622118100992",
  "text" : "Just because you *can* redefine built-in functions in R doesn't mean it's a good idea. Avoid function names like c, t, sum etc. #rstats",
  "id" : 360069622118100992,
  "created_at" : "2013-07-24 16:11:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xfhxjmgyoR",
      "expanded_url" : "http:\/\/bit.ly\/odhwGd",
      "display_url" : "bit.ly\/odhwGd"
    } ]
  },
  "geo" : { },
  "id_str" : "359706980811681792",
  "text" : "List of R functions and packages for Natural Language Processing: http:\/\/t.co\/xfhxjmgyoR #rstats",
  "id" : 359706980811681792,
  "created_at" : "2013-07-23 16:10:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/cxY0YUlawP",
      "expanded_url" : "http:\/\/bit.ly\/qJoACW",
      "display_url" : "bit.ly\/qJoACW"
    } ]
  },
  "geo" : { },
  "id_str" : "359343828286709761",
  "text" : "The \"break\" statement immediately exits from a \"for\" or \"while\" loop: http:\/\/t.co\/cxY0YUlawP #rstats",
  "id" : 359343828286709761,
  "created_at" : "2013-07-22 16:06:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/SeYQCq71z2",
      "expanded_url" : "http:\/\/bit.ly\/zmXTHZ",
      "display_url" : "bit.ly\/zmXTHZ"
    } ]
  },
  "geo" : { },
  "id_str" : "358257009818210306",
  "text" : "List of R packages for survey design, missing value imputation, and official statistics: http:\/\/t.co\/SeYQCq71z2 #rstats",
  "id" : 358257009818210306,
  "created_at" : "2013-07-19 16:08:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357894385280618496",
  "text" : "read.table(\"clipboard\") can be a timesaver for quick copy-and-paste from spreadsheets into R #rstats",
  "id" : 357894385280618496,
  "created_at" : "2013-07-18 16:07:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/18mrk5Agxw",
      "expanded_url" : "http:\/\/bit.ly\/vzBAhQ",
      "display_url" : "bit.ly\/vzBAhQ"
    } ]
  },
  "geo" : { },
  "id_str" : "357533134599888896",
  "text" : "Robust function writing tip: use seq_len(N) instead of 1:N (it handles the N&lt;1 case appropriately): http:\/\/t.co\/18mrk5Agxw #rstats",
  "id" : 357533134599888896,
  "created_at" : "2013-07-17 16:11:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/pujVYiPTrS",
      "expanded_url" : "http:\/\/bit.ly\/1aqdw4e",
      "display_url" : "bit.ly\/1aqdw4e"
    }, {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/HnjAEi4XhF",
      "expanded_url" : "http:\/\/bit.ly\/1aqdARw",
      "display_url" : "bit.ly\/1aqdARw"
    } ]
  },
  "in_reply_to_status_id_str" : "357169559804981248",
  "geo" : { },
  "id_str" : "357184670737244161",
  "in_reply_to_user_id" : 295344317,
  "text" : "Sorry, bad link in that last tweet should be: http:\/\/t.co\/pujVYiPTrS . Package link: http:\/\/t.co\/HnjAEi4XhF",
  "id" : 357184670737244161,
  "in_reply_to_status_id" : 357169559804981248,
  "created_at" : "2013-07-16 17:07:16 +0000",
  "in_reply_to_screen_name" : "RLangTip",
  "in_reply_to_user_id_str" : "295344317",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/UUhhhls6tY",
      "expanded_url" : "http:\/\/bit.ly\/NrMKyM",
      "display_url" : "bit.ly\/NrMKyM"
    } ]
  },
  "geo" : { },
  "id_str" : "357169559804981248",
  "text" : "For complex optimization problems (e.g. mixed-integer programming), try the lpSolveAPI package: http:\/\/t.co\/UUhhhls6tY #rstats",
  "id" : 357169559804981248,
  "created_at" : "2013-07-16 16:07:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/BfZRINNqHY",
      "expanded_url" : "http:\/\/bit.ly\/NmbZye",
      "display_url" : "bit.ly\/NmbZye"
    } ]
  },
  "geo" : { },
  "id_str" : "356807587238383619",
  "text" : "Convert a design matrix (indicator matrix) back into a factor variable: http:\/\/t.co\/BfZRINNqHY #rstats (via @therealprotonk)",
  "id" : 356807587238383619,
  "created_at" : "2013-07-15 16:08:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/3N52bdlSPD",
      "expanded_url" : "http:\/\/bit.ly\/NmhrRE",
      "display_url" : "bit.ly\/NmhrRE"
    } ]
  },
  "geo" : { },
  "id_str" : "355719705002127361",
  "text" : "Use an existing SAS script to import an ASCII data file into R (without needing SAS): http:\/\/t.co\/3N52bdlSPD #rstats",
  "id" : 355719705002127361,
  "created_at" : "2013-07-12 16:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/AwVobbrr1o",
      "expanded_url" : "http:\/\/bit.ly\/Nmiq4e",
      "display_url" : "bit.ly\/Nmiq4e"
    } ]
  },
  "geo" : { },
  "id_str" : "355357436825186307",
  "text" : "To search for R-related FAQs on StackOverflow, precede your search query with [r] at http:\/\/t.co\/AwVobbrr1o #rstats",
  "id" : 355357436825186307,
  "created_at" : "2013-07-11 16:06:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/NHbyPLAD7Q",
      "expanded_url" : "http:\/\/bit.ly\/NcjzyZ",
      "display_url" : "bit.ly\/NcjzyZ"
    } ]
  },
  "geo" : { },
  "id_str" : "354994996111355904",
  "text" : "How to create animated graphics in R: http:\/\/t.co\/NHbyPLAD7Q (see p23) #rstats",
  "id" : 354994996111355904,
  "created_at" : "2013-07-10 16:06:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/G7dJbj5Mvl",
      "expanded_url" : "http:\/\/bit.ly\/RPbC3U",
      "display_url" : "bit.ly\/RPbC3U"
    } ]
  },
  "geo" : { },
  "id_str" : "354632800063852545",
  "text" : "Strip non-ASCII characters from a string with iconv(bad.text, to=\"ASCII\", sub=\"\") #rstats http:\/\/t.co\/G7dJbj5Mvl",
  "id" : 354632800063852545,
  "created_at" : "2013-07-09 16:07:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/WLcz3DZesy",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "354276967727640576",
  "text" : "Use the || and &amp;&amp; operators when working with scalar booleans; use | and &amp; when working with vectors #rstats http:\/\/t.co\/WLcz3DZesy",
  "id" : 354276967727640576,
  "created_at" : "2013-07-08 16:33:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/BrpsXs4Xqm",
      "expanded_url" : "http:\/\/bit.ly\/Jz3aVm",
      "display_url" : "bit.ly\/Jz3aVm"
    } ]
  },
  "geo" : { },
  "id_str" : "353183816791240705",
  "text" : "Convert a comma-separated string to a vector: strsplit(\"red,green,blue\",\",\")[[1]] #rstats http:\/\/t.co\/BrpsXs4Xqm",
  "id" : 353183816791240705,
  "created_at" : "2013-07-05 16:09:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 56, 66 ],
      "id_str" : "62183077",
      "id" : 62183077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/rJPtGfe8y2",
      "expanded_url" : "http:\/\/bit.ly\/NPG1Nz",
      "display_url" : "bit.ly\/NPG1Nz"
    } ]
  },
  "geo" : { },
  "id_str" : "352821372042493953",
  "text" : "R debugging tricks: http:\/\/t.co\/rJPtGfe8y2 #rstats (via @vsbuffalo)",
  "id" : 352821372042493953,
  "created_at" : "2013-07-04 16:09:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/uD33oNWZzL",
      "expanded_url" : "http:\/\/bit.ly\/unTY2g",
      "display_url" : "bit.ly\/unTY2g"
    } ]
  },
  "geo" : { },
  "id_str" : "352459179014893571",
  "text" : "Google's style guide for R programmers: http:\/\/t.co\/uD33oNWZzL #rstats",
  "id" : 352459179014893571,
  "created_at" : "2013-07-03 16:09:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/LaZjWvNkzC",
      "expanded_url" : "http:\/\/bit.ly\/MO2agl",
      "display_url" : "bit.ly\/MO2agl"
    } ]
  },
  "geo" : { },
  "id_str" : "352096495299862528",
  "text" : "Check which packages you have installed with names(installed.packages()[,1]) http:\/\/t.co\/LaZjWvNkzC #rstats",
  "id" : 352096495299862528,
  "created_at" : "2013-07-02 16:08:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/UeDVn4ADfy",
      "expanded_url" : "http:\/\/www.r-project.org",
      "display_url" : "r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "351736707281989632",
  "text" : "#rstats For an example of some slick plotting code click on the graphic at http:\/\/t.co\/UeDVn4ADfy",
  "id" : 351736707281989632,
  "created_at" : "2013-07-01 16:19:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]