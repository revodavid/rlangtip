Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/evbUBYlqMU",
      "expanded_url" : "http:\/\/bit.ly\/1awH5jp",
      "display_url" : "bit.ly\/1awH5jp"
    } ]
  },
  "geo" : { },
  "id_str" : "748548093143023616",
  "text" : "R For Dummies helps with regular expressions #rstats https:\/\/t.co\/evbUBYlqMU",
  "id" : 748548093143023616,
  "created_at" : "2016-06-30 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/ErFgWMBrgc",
      "expanded_url" : "http:\/\/Sys.Date",
      "display_url" : "Sys.Date"
    }, {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/fPb96GWKNY",
      "expanded_url" : "http:\/\/bit.ly\/28SDTHi",
      "display_url" : "bit.ly\/28SDTHi"
    } ]
  },
  "geo" : { },
  "id_str" : "748185668480868352",
  "text" : "Get the current date with https:\/\/t.co\/ErFgWMBrgc() and the time with Sys.time() #rstats https:\/\/t.co\/fPb96GWKNY",
  "id" : 748185668480868352,
  "created_at" : "2016-06-29 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747823285291880448",
  "text" : "Use the xtable package to convert a table or matrix to HTML: print(xtable(X), type=\"html\") #rstats",
  "id" : 747823285291880448,
  "created_at" : "2016-06-28 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/AJkYzBKrP3",
      "expanded_url" : "http:\/\/bit.ly\/28Ss8P1",
      "display_url" : "bit.ly\/28Ss8P1"
    } ]
  },
  "geo" : { },
  "id_str" : "747460873585836032",
  "text" : "List all tests in R: apropos(\"\\\\.test$\") https:\/\/t.co\/AJkYzBKrP3 #rstats",
  "id" : 747460873585836032,
  "created_at" : "2016-06-27 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/AKM0sMYxqx",
      "expanded_url" : "http:\/\/bit.ly\/1tB3s7I",
      "display_url" : "bit.ly\/1tB3s7I"
    } ]
  },
  "geo" : { },
  "id_str" : "746373740099960833",
  "text" : "Column of numbers read in as a factor? Convert it with as.numeric(as.character(df$num.col)) #rstats https:\/\/t.co\/AKM0sMYxqx",
  "id" : 746373740099960833,
  "created_at" : "2016-06-24 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/zoyGBkGaUH",
      "expanded_url" : "http:\/\/bit.ly\/J4Ax1X",
      "display_url" : "bit.ly\/J4Ax1X"
    } ]
  },
  "geo" : { },
  "id_str" : "746011351303217157",
  "text" : "List of R packages and functions for Cluster Analysis &amp; Finite Mixture Models: https:\/\/t.co\/zoyGBkGaUH #rstats",
  "id" : 746011351303217157,
  "created_at" : "2016-06-23 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/pH3rPI8fsP",
      "expanded_url" : "http:\/\/bit.ly\/1eNXbes",
      "display_url" : "bit.ly\/1eNXbes"
    } ]
  },
  "geo" : { },
  "id_str" : "745648984102961153",
  "text" : "#rstats Use rpart:::summary.rpart to look at the code in the hidden method summary.rpart (from Ecostudies) https:\/\/t.co\/pH3rPI8fsP",
  "id" : 745648984102961153,
  "created_at" : "2016-06-22 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/kkMLoZ1Vi7",
      "expanded_url" : "http:\/\/bit.ly\/1UFi4bU",
      "display_url" : "bit.ly\/1UFi4bU"
    } ]
  },
  "geo" : { },
  "id_str" : "745286573575507968",
  "text" : "abbreviate(x,n) \u007Bbase\u007D a vector of strings with unique abbreviations of minimal length n. https:\/\/t.co\/kkMLoZ1Vi7 #rstats",
  "id" : 745286573575507968,
  "created_at" : "2016-06-21 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/FRFNpMrugV",
      "expanded_url" : "http:\/\/bit.ly\/1UevHPD",
      "display_url" : "bit.ly\/1UevHPD"
    } ]
  },
  "geo" : { },
  "id_str" : "744924175870070785",
  "text" : "Package TTR contains EMA() (exponential moving average) and 8 other moving average functions https:\/\/t.co\/FRFNpMrugV #rstats",
  "id" : 744924175870070785,
  "created_at" : "2016-06-20 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/DddsaIenbe",
      "expanded_url" : "http:\/\/bit.ly\/1d8PYDV",
      "display_url" : "bit.ly\/1d8PYDV"
    } ]
  },
  "geo" : { },
  "id_str" : "743837024931688448",
  "text" : "#rstats An example of using R to confirm results of a JAMA paper from Kelly Black https:\/\/t.co\/DddsaIenbe",
  "id" : 743837024931688448,
  "created_at" : "2016-06-17 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YeMhYdVaEa",
      "expanded_url" : "http:\/\/bit.ly\/18piLBZ",
      "display_url" : "bit.ly\/18piLBZ"
    } ]
  },
  "geo" : { },
  "id_str" : "743474630892134400",
  "text" : "Barplot of counts: ggplot(df, aes(x, counts, fill= factorVar)) + geom_bar(stat=\"identity\", position=\"dodge\") #rstats https:\/\/t.co\/YeMhYdVaEa",
  "id" : 743474630892134400,
  "created_at" : "2016-06-16 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 115, 129 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/DIi53U22Rz",
      "expanded_url" : "http:\/\/bit.ly\/TqVLZ3",
      "display_url" : "bit.ly\/TqVLZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "743112265449283584",
  "text" : "If two packages define functions with the same name, use :: to call the one you want: https:\/\/t.co\/DIi53U22Rz (via @joshua_ulrich) #rstats",
  "id" : 743112265449283584,
  "created_at" : "2016-06-15 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/4UUlLXdd0a",
      "expanded_url" : "http:\/\/bit.ly\/28qtY3q",
      "display_url" : "bit.ly\/28qtY3q"
    } ]
  },
  "geo" : { },
  "id_str" : "742749892007886848",
  "text" : "seq(n1,n2,m) \u007Bbase\u007D will generate a sequence of numbers from n1 to n2 counting by m. https:\/\/t.co\/4UUlLXdd0a #stats",
  "id" : 742749892007886848,
  "created_at" : "2016-06-14 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/nr8kSWAmox",
      "expanded_url" : "http:\/\/bit.ly\/1ZEJbId",
      "display_url" : "bit.ly\/1ZEJbId"
    } ]
  },
  "geo" : { },
  "id_str" : "742387461117075460",
  "text" : "CrossTable() in \u007Bgmodels\u007D produces crosstabulations modeled after SAS's PROC FREQ https:\/\/t.co\/nr8kSWAmox #rstats",
  "id" : 742387461117075460,
  "created_at" : "2016-06-13 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/JgDtCE6qiU",
      "expanded_url" : "http:\/\/bit.ly\/1sUrvNT",
      "display_url" : "bit.ly\/1sUrvNT"
    } ]
  },
  "geo" : { },
  "id_str" : "741300316528840704",
  "text" : "You can create a local library by setting R_LIBS_USER in your .Renviron configuration file. https:\/\/t.co\/JgDtCE6qiU #rstats",
  "id" : 741300316528840704,
  "created_at" : "2016-06-10 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/lUPcNDOnrd",
      "expanded_url" : "http:\/\/bit.ly\/1sshY0I",
      "display_url" : "bit.ly\/1sshY0I"
    } ]
  },
  "geo" : { },
  "id_str" : "740937921612632064",
  "text" : "Use as.dendrogram() to prepare hierarchical clusters or trees for plotting #rstats https:\/\/t.co\/lUPcNDOnrd",
  "id" : 740937921612632064,
  "created_at" : "2016-06-09 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/fsquzv5Y8T",
      "expanded_url" : "http:\/\/bit.ly\/25FzJey",
      "display_url" : "bit.ly\/25FzJey"
    } ]
  },
  "geo" : { },
  "id_str" : "740575536636891136",
  "text" : "Use head() to quickly check the first few rows\/elements of a large data frame, vector, list, etc.  #rstats https:\/\/t.co\/fsquzv5Y8T",
  "id" : 740575536636891136,
  "created_at" : "2016-06-08 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/tEnyCXMhqv",
      "expanded_url" : "http:\/\/bit.ly\/1sshVBY",
      "display_url" : "bit.ly\/1sshVBY"
    } ]
  },
  "geo" : { },
  "id_str" : "740213143973076992",
  "text" : "file.path() in \u007Bbase\u007D construct the path to a file from components in a platform-independent way.https:\/\/t.co\/tEnyCXMhqv #rstats",
  "id" : 740213143973076992,
  "created_at" : "2016-06-07 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/y9Q85ZnTKt",
      "expanded_url" : "http:\/\/bit.ly\/1U03tKw",
      "display_url" : "bit.ly\/1U03tKw"
    } ]
  },
  "geo" : { },
  "id_str" : "739850718631321600",
  "text" : "clusterApply() in \u007Bparallel\u007D is a parallel version of apply() that uses clusters https:\/\/t.co\/y9Q85ZnTKt #rstats",
  "id" : 739850718631321600,
  "created_at" : "2016-06-06 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/1nU5lTlnsv",
      "expanded_url" : "http:\/\/bit.ly\/tmxyn2",
      "display_url" : "bit.ly\/tmxyn2"
    } ]
  },
  "geo" : { },
  "id_str" : "738763597657047040",
  "text" : "Search the R mailing list archives: https:\/\/t.co\/1nU5lTlnsv #rstats",
  "id" : 738763597657047040,
  "created_at" : "2016-06-03 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/SeYQCqoCXC",
      "expanded_url" : "http:\/\/bit.ly\/zmXTHZ",
      "display_url" : "bit.ly\/zmXTHZ"
    } ]
  },
  "geo" : { },
  "id_str" : "738401207220310018",
  "text" : "List of R packages for survey design and official statistics: https:\/\/t.co\/SeYQCqoCXC #rstats",
  "id" : 738401207220310018,
  "created_at" : "2016-06-02 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/p4CtPrcqjA",
      "expanded_url" : "http:\/\/bit.ly\/IlFfpk",
      "display_url" : "bit.ly\/IlFfpk"
    } ]
  },
  "geo" : { },
  "id_str" : "738038822169128961",
  "text" : "Side by side comparisons of analysis tasks done in SAS and R: https:\/\/t.co\/p4CtPrcqjA #rstats",
  "id" : 738038822169128961,
  "created_at" : "2016-06-01 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]