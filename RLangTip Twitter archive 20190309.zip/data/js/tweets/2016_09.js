Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/zj6EOVVh2c",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/R_(programming_language)",
      "display_url" : "en.wikipedia.org\/wiki\/R_(progra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781886340828831744",
  "text" : "There is a Wikipedia page for R at https:\/\/t.co\/zj6EOVVh2c #rstats",
  "id" : 781886340828831744,
  "created_at" : "2016-09-30 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Silkey \u269C\uFE0F\u270C\uD83C\uDFFB",
      "screen_name" : "filler",
      "indices" : [ 3, 10 ],
      "id_str" : "10076322",
      "id" : 10076322
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/filler\/status\/781175066742534144\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Ybru09YVOC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdKk-gUMAANxKM.jpg",
      "id_str" : "781175059486355456",
      "id" : 781175059486355456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdKk-gUMAANxKM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 509
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Ybru09YVOC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781677172977078272",
  "text" : "RT @filler: Ah, finally got my Emacs setup just how I like it. https:\/\/t.co\/Ybru09YVOC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/filler\/status\/781175066742534144\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/Ybru09YVOC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdKk-gUMAANxKM.jpg",
        "id_str" : "781175059486355456",
        "id" : 781175059486355456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdKk-gUMAANxKM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 509
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Ybru09YVOC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781175066742534144",
    "text" : "Ah, finally got my Emacs setup just how I like it. https:\/\/t.co\/Ybru09YVOC",
    "id" : 781175066742534144,
    "created_at" : "2016-09-28 16:53:44 +0000",
    "user" : {
      "name" : "Nick Silkey \u269C\uFE0F\u270C\uD83C\uDFFB",
      "screen_name" : "filler",
      "protected" : false,
      "id_str" : "10076322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750829607868207104\/jbHK4Wey_normal.jpg",
      "id" : 10076322,
      "verified" : false
    }
  },
  "id" : 781677172977078272,
  "created_at" : "2016-09-30 02:08:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/YnyGgQltmw",
      "expanded_url" : "http:\/\/vis.supstat.com\/2013\/04\/mathematical-annotation-in-r\/",
      "display_url" : "vis.supstat.com\/2013\/04\/mathem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781523954024390656",
  "text" : "You can include mathematical equations in R charts. Cheat sheet of math symbols you can use: https:\/\/t.co\/YnyGgQltmw #rstats",
  "id" : 781523954024390656,
  "created_at" : "2016-09-29 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/saIRT8ihiZ",
      "expanded_url" : "https:\/\/mran.microsoft.com\/web\/packages\/AzureML\/vignettes\/getting_started.html",
      "display_url" : "mran.microsoft.com\/web\/packages\/A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781161581279191040",
  "text" : "Publish R functions to the cloud as a Web service with the AzureML package https:\/\/t.co\/saIRT8ihiZ #rstats",
  "id" : 781161581279191040,
  "created_at" : "2016-09-28 16:00:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780799203064766464",
  "text" : "Use \\n to embed a newline within a string, e.g. cat(\"Line 1\\nLine 2\") #rstats",
  "id" : 780799203064766464,
  "created_at" : "2016-09-27 16:00:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/mFQdIEoP6A",
      "expanded_url" : "https:\/\/github.com\/hadley\/tidyverse",
      "display_url" : "github.com\/hadley\/tidyver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780436813508784128",
  "text" : "tidyverse: a collection of essential packages for working with data in R https:\/\/t.co\/mFQdIEoP6A #rstats",
  "id" : 780436813508784128,
  "created_at" : "2016-09-26 16:00:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/3blsgcuO90",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/kronecker",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779349634862854144",
  "text" : "A %x% B calculates the kronecker product of matrices A and B https:\/\/t.co\/3blsgcuO90 #rstats",
  "id" : 779349634862854144,
  "created_at" : "2016-09-23 16:00:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/SxhmG7oFP1",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/Rmpfr\/versions\/0.6-0\/topics\/pmax",
      "display_url" : "rdocumentation.org\/packages\/Rmpfr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778987268706938880",
  "text" : "pmin(x,y) and pmax(z,w) return the elementwise smallest\/largest values of their arguments https:\/\/t.co\/SxhmG7oFP1 #rstats",
  "id" : 778987268706938880,
  "created_at" : "2016-09-22 16:00:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pOwX3xIbVX",
      "expanded_url" : "https:\/\/azure.microsoft.com\/en-us\/documentation\/articles\/machine-learning-data-science-provision-vm\/",
      "display_url" : "azure.microsoft.com\/en-us\/document\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778624880979738624",
  "text" : "The Data Science Virtual Machine includes R, Python, Rattle and other data science tools https:\/\/t.co\/pOwX3xIbVX #rstats",
  "id" : 778624880979738624,
  "created_at" : "2016-09-21 16:00:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/HMcCQNKa0j",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/datasets\/versions\/3.3.1",
      "display_url" : "rdocumentation.org\/packages\/datas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778262498659045376",
  "text" : "Index of datasets included with R https:\/\/t.co\/HMcCQNKa0j #rstats",
  "id" : 778262498659045376,
  "created_at" : "2016-09-20 16:00:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "arrrr",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/4tTrr0FF3I",
      "expanded_url" : "https:\/\/rud.is\/b\/2013\/09\/19\/animated-irl-pirate-attacks-in-r\/",
      "display_url" : "rud.is\/b\/2013\/09\/19\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777900212786343937",
  "text" : "How to create an animated map of pirate attacks with R https:\/\/t.co\/4tTrr0FF3I #rstats #arrrr",
  "id" : 777900212786343937,
  "created_at" : "2016-09-19 16:00:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/0NSADXUEd8",
      "expanded_url" : "http:\/\/vis.supstat.com\/2013\/03\/make-visual-illusions-in-r\/",
      "display_url" : "vis.supstat.com\/2013\/03\/make-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776812917689679872",
  "text" : "Optical illusions made with R https:\/\/t.co\/0NSADXUEd8 #rstats",
  "id" : 776812917689679872,
  "created_at" : "2016-09-16 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrodieG",
      "screen_name" : "BrodieGaslam",
      "indices" : [ 93, 106 ],
      "id_str" : "2427666512",
      "id" : 2427666512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/amL6jnb1IO",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/28840038\/evaluation-of-reverse-polish-notation-in-r\/28841611#28841611",
      "display_url" : "stackoverflow.com\/questions\/2884\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776450542595825665",
  "text" : "Reverse Polish notation calculator in 12 lines of R code https:\/\/t.co\/amL6jnb1IO #rstats via @BrodieGaslam",
  "id" : 776450542595825665,
  "created_at" : "2016-09-15 16:00:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/YHL1EKLvEI",
      "expanded_url" : "https:\/\/mran.microsoft.com\/timemachine\/",
      "display_url" : "mran.microsoft.com\/timemachine\/"
    } ]
  },
  "geo" : { },
  "id_str" : "776088140461125632",
  "text" : "Explore R packages from the past with the CRAN Time Machine https:\/\/t.co\/YHL1EKLvEI #rstats",
  "id" : 776088140461125632,
  "created_at" : "2016-09-14 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/l4AaMuxpEl",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Constants",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775725785319481344",
  "text" : "Constants built into #rstats: letters, months and pi: https:\/\/t.co\/l4AaMuxpEl",
  "id" : 775725785319481344,
  "created_at" : "2016-09-13 16:00:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/4v4NUZ96AP",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.1\/topics\/object.size",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775363400016605184",
  "text" : "Use object.size() to estimate the amount of memory an R object is consuming https:\/\/t.co\/4v4NUZ96AP #rstats",
  "id" : 775363400016605184,
  "created_at" : "2016-09-12 16:00:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/YpAmH9YqN3",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.1\/topics\/citation",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774276206099243009",
  "text" : "How to credit R in a manuscript or article: citation(). Works for packages, too: citation(\"MASS\") https:\/\/t.co\/YpAmH9YqN3 #rstats",
  "id" : 774276206099243009,
  "created_at" : "2016-09-09 16:00:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/9jFFUNRSwE",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/viridis\/",
      "display_url" : "mran.microsoft.com\/package\/viridi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773913831621795840",
  "text" : "Create perceptive color-blind-safe scales for heatmap charts with the viridis package https:\/\/t.co\/9jFFUNRSwE #rstats",
  "id" : 773913831621795840,
  "created_at" : "2016-09-08 16:00:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rtats",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/6mj8zSetv1",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/07\/microsoft-r-client.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/07\/micros\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773551437435383808",
  "text" : "The free Microsoft R Client distribution includes the RevoScaleR package for analysis of out-of-memory data https:\/\/t.co\/6mj8zSetv1 #rtats",
  "id" : 773551437435383808,
  "created_at" : "2016-09-07 16:00:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/t7cFs1VRuL",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/lubridate\/vignettes\/lubridate.html",
      "display_url" : "cran.r-project.org\/web\/packages\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773189068842606592",
  "text" : "Use the lubridate package to easily manipulate dates, times and time zones https:\/\/t.co\/t7cFs1VRuL #rstats",
  "id" : 773189068842606592,
  "created_at" : "2016-09-06 16:00:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9sXtzmYiSw",
      "expanded_url" : "http:\/\/ess.r-project.org\/",
      "display_url" : "ess.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "772826713193533442",
  "text" : "ESS (Emacs Speaks Statistics) is a popular add-on for working with R inside Emacs. https:\/\/t.co\/9sXtzmYiSw #rstats",
  "id" : 772826713193533442,
  "created_at" : "2016-09-05 16:00:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/VhgDgqO0eJ",
      "expanded_url" : "https:\/\/mran.microsoft.com\/web\/packages\/fortunes\/vignettes\/fortunes.pdf",
      "display_url" : "mran.microsoft.com\/web\/packages\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771739480390668289",
  "text" : "Collected wisdom from the R mailing list archives, via the fortunes package https:\/\/t.co\/VhgDgqO0eJ #rstats",
  "id" : 771739480390668289,
  "created_at" : "2016-09-02 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WVP7RcKX2S",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/",
      "display_url" : "cran.r-project.org\/web\/views\/"
    } ]
  },
  "geo" : { },
  "id_str" : "771377108991905792",
  "text" : "CRAN task views list R packages by topic area (Bayesian, Finance, Web Technologies etc) https:\/\/t.co\/WVP7RcKX2S #rstats",
  "id" : 771377108991905792,
  "created_at" : "2016-09-01 16:00:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]