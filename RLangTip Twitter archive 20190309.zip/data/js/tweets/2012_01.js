Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/mZdDZCJE",
      "expanded_url" : "http:\/\/bit.ly\/vzBAhQ",
      "display_url" : "bit.ly\/vzBAhQ"
    } ]
  },
  "geo" : { },
  "id_str" : "164422808913444864",
  "text" : "Robust function writing tip: use seq_len(N) instead of 1:N (it handles the N&lt;1 case appropriately): http:\/\/t.co\/mZdDZCJE #rstats",
  "id" : 164422808913444864,
  "created_at" : "2012-01-31 19:00:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/OM5duD90",
      "expanded_url" : "http:\/\/bit.ly\/wGWFiD",
      "display_url" : "bit.ly\/wGWFiD"
    } ]
  },
  "geo" : { },
  "id_str" : "164032808594063360",
  "text" : "Train support vector machines in R with the \"svm\" function from the e1071 package: http:\/\/t.co\/OM5duD90 #rstats",
  "id" : 164032808594063360,
  "created_at" : "2012-01-30 17:10:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 19, 33 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162986252197560320",
  "text" : "A handy alias (via @hadleywickham) for #rstats to prevent saving or loading workspaces: R --no-save --no-restore-data --quiet",
  "id" : 162986252197560320,
  "created_at" : "2012-01-27 19:52:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162640798075191297",
  "text" : "Filter list elems that match a condition: id&lt;-sapply(mylist, function(e) test(e)); mylist[id] # Replace \"test\" with any T\/F expr #rstats",
  "id" : 162640798075191297,
  "created_at" : "2012-01-26 20:59:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162261927211433984",
  "text" : "The # character introduces comments in R. Everything after the # character to end-of-line is ignored by the interpreter. #rstats",
  "id" : 162261927211433984,
  "created_at" : "2012-01-25 19:53:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/O4xamQqt",
      "expanded_url" : "http:\/\/bit.ly\/qJoACW",
      "display_url" : "bit.ly\/qJoACW"
    } ]
  },
  "geo" : { },
  "id_str" : "161891027421118465",
  "text" : "The \"break\" statement immediately exits from a \"for\" or \"while\" loop: http:\/\/t.co\/O4xamQqt #rstats",
  "id" : 161891027421118465,
  "created_at" : "2012-01-24 19:20:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161478607418556416",
  "text" : "To debug warnings, options(warn=2) converts warnings into errors #rstats",
  "id" : 161478607418556416,
  "created_at" : "2012-01-23 16:01:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/oLGhs0P7",
      "expanded_url" : "http:\/\/bit.ly\/rLysv3",
      "display_url" : "bit.ly\/rLysv3"
    } ]
  },
  "geo" : { },
  "id_str" : "160391435160530945",
  "text" : "How to source an R file from GitHub (or any other site via https): http:\/\/t.co\/oLGhs0P7 #rstats",
  "id" : 160391435160530945,
  "created_at" : "2012-01-20 16:01:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/4ErL8ohG",
      "expanded_url" : "http:\/\/bit.ly\/t1bNrg",
      "display_url" : "bit.ly\/t1bNrg"
    } ]
  },
  "geo" : { },
  "id_str" : "160029021701275648",
  "text" : "The polypath function can be used to add a vector-based shape or symbol to a chart: http:\/\/t.co\/4ErL8ohG #rstats",
  "id" : 160029021701275648,
  "created_at" : "2012-01-19 16:01:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159666648226349057",
  "text" : "Efficiency tip: When selecting from a data frame, df$a[1] is much faster than df[1,\"a\"] #rstats",
  "id" : 159666648226349057,
  "created_at" : "2012-01-18 16:01:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAS",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "SPSS",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/0mGibnBr",
      "expanded_url" : "http:\/\/bit.ly\/prkVA2",
      "display_url" : "bit.ly\/prkVA2"
    } ]
  },
  "geo" : { },
  "id_str" : "159304231839469569",
  "text" : "R scripts for managing and processing data, with equivalent code in #SAS and #SPSS: http:\/\/t.co\/0mGibnBr #rstats",
  "id" : 159304231839469569,
  "created_at" : "2012-01-17 16:01:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/H7sTDilv",
      "expanded_url" : "http:\/\/bit.ly\/zCxy4H",
      "display_url" : "bit.ly\/zCxy4H"
    } ]
  },
  "geo" : { },
  "id_str" : "158992458884186114",
  "text" : "Constants built into #rstats: letters, months and pi: http:\/\/t.co\/H7sTDilv",
  "id" : 158992458884186114,
  "created_at" : "2012-01-16 19:22:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157894321130053632",
  "text" : "x$name and x[[\"name\"]] are equivalent, but the latter is a more robust programming style ($ uses partial matching) #rstats",
  "id" : 157894321130053632,
  "created_at" : "2012-01-13 18:38:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/JP8gjAFZ",
      "expanded_url" : "http:\/\/bit.ly\/xbz2dH",
      "display_url" : "bit.ly\/xbz2dH"
    } ]
  },
  "geo" : { },
  "id_str" : "157501290648322048",
  "text" : "Need to put R output in a book or paper? Use options(width=60) to limit output to a narrow column. http:\/\/t.co\/JP8gjAFZ #rstats",
  "id" : 157501290648322048,
  "created_at" : "2012-01-12 16:36:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/5gA2IyZJ",
      "expanded_url" : "http:\/\/bit.ly\/AE2djP",
      "display_url" : "bit.ly\/AE2djP"
    } ]
  },
  "geo" : { },
  "id_str" : "157129855304077313",
  "text" : "Try demo('graphics') ... and type demo() to see other demos available in attached packages. http:\/\/t.co\/5gA2IyZJ #rstats",
  "id" : 157129855304077313,
  "created_at" : "2012-01-11 16:00:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/Ny924y3p",
      "expanded_url" : "http:\/\/bit.ly\/x3iEmJ",
      "display_url" : "bit.ly\/x3iEmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "156765447587508225",
  "text" : "You can use hexadecimal literals in R, for example 0xDEADBEEF http:\/\/t.co\/Ny924y3p #rstats",
  "id" : 156765447587508225,
  "created_at" : "2012-01-10 15:52:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 79, 93 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/e2K2cGFw",
      "expanded_url" : "http:\/\/bit.ly\/ugAi3M",
      "display_url" : "bit.ly\/ugAi3M"
    } ]
  },
  "geo" : { },
  "id_str" : "156432002772500480",
  "text" : "Sync Rprofile across multiple machines with Dropbox: http:\/\/t.co\/e2K2cGFw (h\/t @genetics_blog) #rstats",
  "id" : 156432002772500480,
  "created_at" : "2012-01-09 17:47:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155379410491539456",
  "text" : "Starting Monday -- fresh R Language Tips. Thanks to all who sent in tip suggestions to RLangTip@revolutionanalytics.com.",
  "id" : 155379410491539456,
  "created_at" : "2012-01-06 20:05:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/tj1Cubhm",
      "expanded_url" : "http:\/\/bit.ly\/vlOimZ",
      "display_url" : "bit.ly\/vlOimZ"
    } ]
  },
  "geo" : { },
  "id_str" : "155317981960880129",
  "text" : "Public data sets available online to use with R: http:\/\/t.co\/tj1Cubhm #rstats",
  "id" : 155317981960880129,
  "created_at" : "2012-01-06 16:01:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/8PKUOt4s",
      "expanded_url" : "http:\/\/bit.ly\/nFTz0V",
      "display_url" : "bit.ly\/nFTz0V"
    } ]
  },
  "geo" : { },
  "id_str" : "154955563917246464",
  "text" : "List of R functions and packages for Machine Learning & Statistical Learning: http:\/\/t.co\/8PKUOt4s #rstats",
  "id" : 154955563917246464,
  "created_at" : "2012-01-05 16:01:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/CYTgWtxD",
      "expanded_url" : "http:\/\/bit.ly\/nx2QWZ",
      "display_url" : "bit.ly\/nx2QWZ"
    } ]
  },
  "geo" : { },
  "id_str" : "154593151787614209",
  "text" : "For highest-quality R graphics on the web, use the SVG device (but doesn't work with older browsers). http:\/\/t.co\/CYTgWtxD #rstats",
  "id" : 154593151787614209,
  "created_at" : "2012-01-04 16:00:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/VUgtPaNt",
      "expanded_url" : "http:\/\/bit.ly\/pRciwj",
      "display_url" : "bit.ly\/pRciwj"
    } ]
  },
  "geo" : { },
  "id_str" : "154230740123516928",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: http:\/\/t.co\/VUgtPaNt #rstats",
  "id" : 154230740123516928,
  "created_at" : "2012-01-03 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hadoop",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/7bh1faFf",
      "expanded_url" : "http:\/\/bit.ly\/qCEtn7",
      "display_url" : "bit.ly\/qCEtn7"
    } ]
  },
  "geo" : { },
  "id_str" : "153868356179607552",
  "text" : "Write map-reduce tasks for big data in #Hadoop with the rmr package: http:\/\/t.co\/7bh1faFf #rstats",
  "id" : 153868356179607552,
  "created_at" : "2012-01-02 16:00:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153866929625505792",
  "text" : "This is the final week of Best Of RLangTip. Tip suggestions welcome at RLangTip@revolutionanalytics.com. Fresh tips resume next week.",
  "id" : 153866929625505792,
  "created_at" : "2012-01-02 15:55:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]