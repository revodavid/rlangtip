Grailbird.data.tweets_2017_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/O2EWUBOgDq",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/gbm\/",
      "display_url" : "mran.microsoft.com\/package\/gbm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "857987782911737856",
  "text" : "Use the gbm package to fit generalized boosted regression models https:\/\/t.co\/O2EWUBOgDq #rstats",
  "id" : 857987782911737856,
  "created_at" : "2017-04-28 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/oARzwK0dU1",
      "expanded_url" : "http:\/\/www.dummies.com\/programming\/r\/how-to-use-regular-expressions-in-r\/",
      "display_url" : "dummies.com\/programming\/r\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857625400213504005",
  "text" : "R For Dummies helps with regular expressions #rstats https:\/\/t.co\/oARzwK0dU1",
  "id" : 857625400213504005,
  "created_at" : "2017-04-27 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/nRjEq7poBb",
      "expanded_url" : "https:\/\/www.microsoft.com\/en-us\/cloud-platform\/r-server-resources",
      "display_url" : "microsoft.com\/en-us\/cloud-pl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857263003565084672",
  "text" : "Resources for getting started with Microsoft R Server https:\/\/t.co\/nRjEq7poBb #rstats",
  "id" : 857263003565084672,
  "created_at" : "2017-04-26 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/dBDCUfssba",
      "expanded_url" : "http:\/\/gallery.htmlwidgets.org\/",
      "display_url" : "gallery.htmlwidgets.org"
    } ]
  },
  "geo" : { },
  "id_str" : "856950770427719680",
  "text" : "Find interactive charts you can create with R at the htmlwidgets gallery https:\/\/t.co\/dBDCUfssba #rstats",
  "id" : 856950770427719680,
  "created_at" : "2017-04-25 19:19:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/cRulFWwBRn",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.3.3\/topics\/par",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856538229000081412",
  "text" : "For base graphics, par(mfrow=c(m,n)) will divide a graphics window into a grid of m x n plots https:\/\/t.co\/cRulFWwBRn #rstats",
  "id" : 856538229000081412,
  "created_at" : "2017-04-24 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/keSpENJeBx",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.3\/topics\/cor.test",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "855451063071023104",
  "text" : "cor.test(x,y) will test if the correlation between paired values in x and y is statistically significant https:\/\/t.co\/keSpENJeBx #rstats",
  "id" : 855451063071023104,
  "created_at" : "2017-04-21 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855088676874932225",
  "text" : "Yes, you can return more than one value from a function: use a list! return(list(val1, val2, val3)) #rstats",
  "id" : 855088676874932225,
  "created_at" : "2017-04-20 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/1VNpGC19aR",
      "expanded_url" : "http:\/\/aka.ms\/dsvm\/handout",
      "display_url" : "aka.ms\/dsvm\/handout"
    } ]
  },
  "geo" : { },
  "id_str" : "854726285976895488",
  "text" : "A two-page handout with info on the Azure Data Science Virtual Machine (includes #rstats) https:\/\/t.co\/1VNpGC19aR",
  "id" : 854726285976895488,
  "created_at" : "2017-04-19 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/jzD0fW0xV8",
      "expanded_url" : "http:\/\/www.ggplot2-exts.org\/",
      "display_url" : "ggplot2-exts.org"
    } ]
  },
  "geo" : { },
  "id_str" : "854363917694496769",
  "text" : "Find extensions for the ggplot2 graphics system at https:\/\/t.co\/jzD0fW0xV8 #rstats",
  "id" : 854363917694496769,
  "created_at" : "2017-04-18 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/LyUvq0XDGC",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/odbc\/",
      "display_url" : "mran.microsoft.com\/package\/odbc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "854013594761035778",
  "text" : "Use the odbc package to download data from ODBC-compliant databases into R https:\/\/t.co\/LyUvq0XDGC #rstats",
  "id" : 854013594761035778,
  "created_at" : "2017-04-17 16:48:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/jziNmWPccT",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.3\/topics\/kruskal.test",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852914367783895040",
  "text" : "kruskal.test(list(x,y)) performs the  Kruskal-Wallis Rank Sum Test to compare the distributions of x and y https:\/\/t.co\/jziNmWPccT  #stats",
  "id" : 852914367783895040,
  "created_at" : "2017-04-14 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/5f6v6VLlBS",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/magrittr\/",
      "display_url" : "mran.microsoft.com\/package\/magrit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852551969252265984",
  "text" : "Try out the %&gt;% operator in the magrittr package https:\/\/t.co\/5f6v6VLlBS to avoid nested function calls #rstats",
  "id" : 852551969252265984,
  "created_at" : "2017-04-13 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/9utKiVM3he",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.3\/topics\/dput",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8sFxO2ypKi",
      "expanded_url" : "http:\/\/bit.ly\/NOuduT",
      "display_url" : "bit.ly\/NOuduT"
    } ]
  },
  "geo" : { },
  "id_str" : "852189577116762112",
  "text" : "Use dput to archive an R object to a file; load into another R session with dget https:\/\/t.co\/9utKiVM3he https:\/\/t.co\/8sFxO2ypKi #rstats",
  "id" : 852189577116762112,
  "created_at" : "2017-04-12 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/3KFYLmvsoR",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/readr\/versions\/1.1.0\/topics\/parse_number",
      "display_url" : "rdocumentation.org\/packages\/readr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851827196603678721",
  "text" : "For int'l number formats: parse_number(\"123.456,789\", locale=locale(grouping_mark=\".\", decimal_mark=\",\")) #rstats https:\/\/t.co\/3KFYLmvsoR",
  "id" : 851827196603678721,
  "created_at" : "2017-04-11 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/KXQRExKwfH",
      "expanded_url" : "https:\/\/www.r-project.org\/doc\/R-FDA.pdf",
      "display_url" : "r-project.org\/doc\/R-FDA.pdf"
    } ]
  },
  "geo" : { },
  "id_str" : "851464800400019457",
  "text" : "Qualification and validation of R for 21CFR11 compliance and use in FDA clinical trials: https:\/\/t.co\/KXQRExKwfH\u00A0#rstats",
  "id" : 851464800400019457,
  "created_at" : "2017-04-10 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/xmpl1sNABM",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.3\/topics\/help",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850377633804177408",
  "text" : "Get an overview of documentation for an installed package: help(package=\"&lt;package-name&gt;\")\u00A0#rstats\u00A0https:\/\/t.co\/xmpl1sNABM",
  "id" : 850377633804177408,
  "created_at" : "2017-04-07 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/zIly8LSday",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/caret\/versions\/6.0-73\/topics\/train",
      "display_url" : "rdocumentation.org\/packages\/caret\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850015243111727104",
  "text" : "Use train() in the caret package to evaluate models over a grid of tuning parameters https:\/\/t.co\/zIly8LSday #rstats",
  "id" : 850015243111727104,
  "created_at" : "2017-04-06 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels Berglund",
      "screen_name" : "nielsberglund",
      "indices" : [ 61, 75 ],
      "id_str" : "57372793",
      "id" : 57372793
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/rYYctQ9jQk",
      "expanded_url" : "http:\/\/www.nielsberglund.com\/2017\/03\/04\/microsoft-sql-server-2016-r-services-installation",
      "display_url" : "nielsberglund.com\/2017\/03\/04\/mic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849652874908909568",
  "text" : "How to install and enable R Services for SQL Server 2016, by @nielsberglund https:\/\/t.co\/rYYctQ9jQk #rstats",
  "id" : 849652874908909568,
  "created_at" : "2017-04-05 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/37e0Tz4T8o",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/rgeolocate\/",
      "display_url" : "mran.microsoft.com\/package\/rgeolo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849290481343225858",
  "text" : "Find the geographic location of an IP address with the rgeolocate package https:\/\/t.co\/37e0Tz4T8o #rstats",
  "id" : 849290481343225858,
  "created_at" : "2017-04-04 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/u9vDSmOeXb",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/all.equal",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848928081557454848",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: https:\/\/t.co\/u9vDSmOeXb #rstats",
  "id" : 848928081557454848,
  "created_at" : "2017-04-03 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "easteregg",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "848203314877448193",
  "text" : "If you have an active trans-temporal internet connection, you can use ???? for extra help, e.g. ????t.test #rstats #easteregg",
  "id" : 848203314877448193,
  "created_at" : "2017-04-01 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]