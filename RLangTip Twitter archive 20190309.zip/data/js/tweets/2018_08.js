Grailbird.data.tweets_2018_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/tNBB7Y6E1Q",
      "expanded_url" : "http:\/\/www.johndcook.com\/blog\/2008\/10\/23\/five-kinds-of-r-language-subscripts\/",
      "display_url" : "johndcook.com\/blog\/2008\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1035557827148955654",
  "text" : "Five ways to subscript data in R https:\/\/t.co\/tNBB7Y6E1Q #rstats",
  "id" : 1035557827148955654,
  "created_at" : "2018-08-31 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1035195439119654912",
  "text" : "Review and update selected packages to the latest version: update.packages(ask=\"graphics\")  #rstats",
  "id" : 1035195439119654912,
  "created_at" : "2018-08-30 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels Berglund",
      "screen_name" : "nielsberglund",
      "indices" : [ 70, 84 ],
      "id_str" : "57372793",
      "id" : 57372793
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/cl6FacvYas",
      "expanded_url" : "http:\/\/www.nielsberglund.com\/2018\/06\/23\/installing-r-packages-in-sql-server-machine-learning-services---i\/",
      "display_url" : "nielsberglund.com\/2018\/06\/23\/ins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1034833052269203456",
  "text" : "Installing R Packages in SQL Server ML Services, a tutorial series by @nielsberglund https:\/\/t.co\/cl6FacvYas #rstats",
  "id" : 1034833052269203456,
  "created_at" : "2018-08-29 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/qjSFVzjJVa",
      "expanded_url" : "https:\/\/www.datacamp.com\/community\/tutorials\/installing-R-windows-mac-ubuntu",
      "display_url" : "datacamp.com\/community\/tuto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1034470664508506117",
  "text" : "How to install R with multi-core acceleration, RStudio and tidyverse on Windows, Mac and Ubuntu https:\/\/t.co\/qjSFVzjJVa #rstats",
  "id" : 1034470664508506117,
  "created_at" : "2018-08-28 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/ycPbnIj93y",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.4.0\/topics\/par",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1034108277674725376",
  "text" : "In base graphics, change the direction of plot axis labels with las.  \n  plot(x,y,las=2)  \nmakes all labels perpendicular to the axis #rstats https:\/\/t.co\/ycPbnIj93y",
  "id" : 1034108277674725376,
  "created_at" : "2018-08-27 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/rPryoPckBF",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/options",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1033021115923193858",
  "text" : "Need to put R output in a book or paper? Use options(width=60) to limit output to a narrow column. https:\/\/t.co\/rPryoPckBF #rstats",
  "id" : 1033021115923193858,
  "created_at" : "2018-08-24 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/ant2hTPCsc",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/lower.tri",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1032658726379913216",
  "text" : "Get the upper triangular elements of a matrix: M[upper.tri(M,diag=TRUE)] https:\/\/t.co\/ant2hTPCsc #rstats",
  "id" : 1032658726379913216,
  "created_at" : "2018-08-23 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kirstie shackell",
      "screen_name" : "JumpingRivers",
      "indices" : [ 60, 74 ],
      "id_str" : "151910719",
      "id" : 151910719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/zs2uuTXoDW",
      "expanded_url" : "https:\/\/github.com\/ThinkR-open\/companies-using-r\/blob\/master\/README.md",
      "display_url" : "github.com\/ThinkR-open\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1032356738580791297",
  "text" : "A list of companies, officials and NGOs using R, curated by @jumpingrivers https:\/\/t.co\/zs2uuTXoDW #rstats",
  "id" : 1032356738580791297,
  "created_at" : "2018-08-22 20:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/AM1AExyhgD",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/xtable",
      "display_url" : "rdocumentation.org\/packages\/xtable"
    } ]
  },
  "geo" : { },
  "id_str" : "1031571563726991361",
  "text" : "Use the xtable package to convert a table or matrix to HTML: print(xtable(X), type=\"html\") https:\/\/t.co\/AM1AExyhgD #rstats",
  "id" : 1031571563726991361,
  "created_at" : "2018-08-20 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/t7cFs1VRuL",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/lubridate\/vignettes\/lubridate.html",
      "display_url" : "cran.r-project.org\/web\/packages\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1030484396757811200",
  "text" : "Use the lubridate package to easily manipulate dates, times and time zones https:\/\/t.co\/t7cFs1VRuL #rstats",
  "id" : 1030484396757811200,
  "created_at" : "2018-08-17 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fjrS6zq2Gy",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/methods\/versions\/3.5.1\/topics\/Methods_Details",
      "display_url" : "rdocumentation.org\/packages\/metho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1030122014059593728",
  "text" : "Advanced documentation on how S4 methods work in R https:\/\/t.co\/fjrS6zq2Gy #rstats",
  "id" : 1030122014059593728,
  "created_at" : "2018-08-16 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/dDA6yZ2ZJr",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/sql\/advanced-analytics\/tutorials\/sqldev-in-database-r-for-sql-developers?view=sql-server-2017&WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/en-us\/sql\/adva\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1029759623857750017",
  "text" : "Tutorial: Learn in-database analytics using R in SQL Server https:\/\/t.co\/dDA6yZ2ZJr #rstats",
  "id" : 1029759623857750017,
  "created_at" : "2018-08-15 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 142, 149 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/9QvIqsSPht",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/rlang",
      "display_url" : "rdocumentation.org\/packages\/rlang"
    } ]
  },
  "geo" : { },
  "id_str" : "1029397234201374721",
  "text" : "Useful operator from the rlang package: \n  a %||% b %||% c \nreturns the first of the objects a, b, c that is not NULL https:\/\/t.co\/9QvIqsSPht #rstats",
  "id" : 1029397234201374721,
  "created_at" : "2018-08-14 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/g7WR97QEbH",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-lang.html#Operators",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1029034849372262401",
  "text" : "The list of R operators: https:\/\/t.co\/g7WR97QEbH #rstats",
  "id" : 1029034849372262401,
  "created_at" : "2018-08-13 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/HL37rwufk5",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.1\/topics\/apropos",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1027947688938024960",
  "text" : "Use apropos() to find a function or variable when you can only remember part of its name https:\/\/t.co\/HL37rwufk5 #rstats",
  "id" : 1027947688938024960,
  "created_at" : "2018-08-10 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/HFJHyE6d3Q",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/density",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1027585300552286208",
  "text" : "Compute a kernel density estimate of a variable's distribution with density(x) https:\/\/t.co\/HFJHyE6d3Q #rstats",
  "id" : 1027585300552286208,
  "created_at" : "2018-08-09 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/fb1HFTvQcB",
      "expanded_url" : "https:\/\/cda.ms\/zj",
      "display_url" : "cda.ms\/zj"
    } ]
  },
  "geo" : { },
  "id_str" : "1027222911613063169",
  "text" : "How to use R packages with the online Power BI service https:\/\/t.co\/fb1HFTvQcB #rstats",
  "id" : 1027222911613063169,
  "created_at" : "2018-08-08 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/xPq9DFMrrr",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/complete.cases",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1026860524510670854",
  "text" : "Count the number of rows in a data frame that have missing values with sum(!complete.cases(dF)) https:\/\/t.co\/xPq9DFMrrr #rstats",
  "id" : 1026860524510670854,
  "created_at" : "2018-08-07 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1026498131368837126",
  "text" : "Print numbers as currency in a 6-character wide field: sprintf(\"$%6.2f\",mean(LifeCycleSavings$sr))",
  "id" : 1026498131368837126,
  "created_at" : "2018-08-06 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/R5jqllgn1o",
      "expanded_url" : "https:\/\/stackoverflow.com\/questions\/39137110\/what-does-the-following-object-is-masked-from-packagexxx-mean",
      "display_url" : "stackoverflow.com\/questions\/3913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1025410977280319488",
  "text" : "If two packages define functions with the same name, use :: to call the one you want: https:\/\/t.co\/R5jqllgn1o #rstats",
  "id" : 1025410977280319488,
  "created_at" : "2018-08-03 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R Consortium",
      "screen_name" : "RConsortium",
      "indices" : [ 69, 81 ],
      "id_str" : "3318844765",
      "id" : 3318844765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Bzw3um72hX",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UC_R5smHVXRYGhZYDJsnXTwg\/videos",
      "display_url" : "youtube.com\/channel\/UC_R5s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1025048586831228928",
  "text" : "Watch the keynotes, talks and tutorials from the user!2018 (courtesy @RConsortium) https:\/\/t.co\/Bzw3um72hX #rstats",
  "id" : 1025048586831228928,
  "created_at" : "2018-08-02 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 148, 155 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/pEWR5Xdc8t",
      "expanded_url" : "https:\/\/msropendata.com\/",
      "display_url" : "msropendata.com"
    } ]
  },
  "geo" : { },
  "id_str" : "1024686190857924608",
  "text" : "Open data sets, curated by Microsoft Research for computer vision, NLP and scientific analysis, available for download from https:\/\/t.co\/pEWR5Xdc8t #rstats",
  "id" : 1024686190857924608,
  "created_at" : "2018-08-01 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]