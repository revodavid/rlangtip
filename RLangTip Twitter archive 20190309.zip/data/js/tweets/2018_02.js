Grailbird.data.tweets_2018_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 56, 70 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/v50xg5lClS",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nERXS3ssntw",
      "display_url" : "youtube.com\/watch?v=nERXS3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968893579690098689",
  "text" : "A five-minute explanation of tidy evaluation in R, from @hadleywickham https:\/\/t.co\/v50xg5lClS #rstats",
  "id" : 968893579690098689,
  "created_at" : "2018-02-28 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JW3P1tUlKM",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/cumsum",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "968531176624451586",
  "text" : "cummax(x) returns a vector whose ith element is the maximum of the first i elements of x. cf cumsum, cumprod #rstats https:\/\/t.co\/JW3P1tUlKM",
  "id" : 968531176624451586,
  "created_at" : "2018-02-27 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "968168803736711168",
  "text" : "Be aware: the $ operator uses partial matching. mylist$el returns the contents of mylist$element if there's no exact match #rstats",
  "id" : 968168803736711168,
  "created_at" : "2018-02-26 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YZBZBD4P4C",
      "expanded_url" : "https:\/\/rmarkdown.rstudio.com\/lesson-15.html",
      "display_url" : "rmarkdown.rstudio.com\/lesson-15.html"
    } ]
  },
  "geo" : { },
  "id_str" : "967081637988139008",
  "text" : "R Markdown Cheat Sheet https:\/\/t.co\/YZBZBD4P4C #rstats",
  "id" : 967081637988139008,
  "created_at" : "2018-02-23 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/BLIkFO85la",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/colSums",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "966719234360430592",
  "text" : "You can compute row sums of a matrix M with apply(M, 1, sum) ... but rowSums(x) is faster https:\/\/t.co\/BLIkFO85la #rstats",
  "id" : 966719234360430592,
  "created_at" : "2018-02-22 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/DYDwlaybsa",
      "expanded_url" : "http:\/\/cda.ms\/6s",
      "display_url" : "cda.ms\/6s"
    } ]
  },
  "geo" : { },
  "id_str" : "966361752605687809",
  "text" : "List of functions included in the MicrosoftML package https:\/\/t.co\/DYDwlaybsa #rstats",
  "id" : 966361752605687809,
  "created_at" : "2018-02-21 17:19:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/0UjIhBizwf",
      "expanded_url" : "https:\/\/stackoverflow.com\/q\/39137110\/154039",
      "display_url" : "stackoverflow.com\/q\/39137110\/154\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "965994469911744512",
  "text" : "If two packages define functions with the same name, use :: to call the one you want: https:\/\/t.co\/0UjIhBizwf #rstats",
  "id" : 965994469911744512,
  "created_at" : "2018-02-20 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/kiZeredENS",
      "expanded_url" : "https:\/\/CRAN.R-project.org\/view=Graphics",
      "display_url" : "CRAN.R-project.org\/view=Graphics"
    } ]
  },
  "geo" : { },
  "id_str" : "965632074240557056",
  "text" : "List of R functions and packages for graphic displays, dynamic graphics, graphic devices and visualization: https:\/\/t.co\/kiZeredENS #rstats",
  "id" : 965632074240557056,
  "created_at" : "2018-02-19 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/AeRu4XgIzG",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/function",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "964544928695988224",
  "text" : "return() is a function, so there must be parentheses around the value being returned https:\/\/t.co\/AeRu4XgIzG #rstats",
  "id" : 964544928695988224,
  "created_at" : "2018-02-16 17:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/itXZmi23Bd",
      "expanded_url" : "https:\/\/mran.microsoft.com\/spotlight",
      "display_url" : "mran.microsoft.com\/spotlight"
    } ]
  },
  "geo" : { },
  "id_str" : "964182535763841030",
  "text" : "A curated list of some recently-released and updated R packages: https:\/\/t.co\/itXZmi23Bd #rstats",
  "id" : 964182535763841030,
  "created_at" : "2018-02-15 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/xkqaPu9h6f",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/RXKCD\/versions\/1.7-7\/topics\/getXKCD",
      "display_url" : "rdocumentation.org\/packages\/RXKCD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963820132643450880",
  "text" : "Cheer yourself up in R with getXKCD(which=\"random\",html=TRUE) https:\/\/t.co\/xkqaPu9h6f #rstats",
  "id" : 963820132643450880,
  "created_at" : "2018-02-14 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/EJMCA61cBL",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/apropos",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "963457753560723456",
  "text" : "find() tells what package a function came from. e.g. find(\"find\") https:\/\/t.co\/EJMCA61cBL #rstats",
  "id" : 963457753560723456,
  "created_at" : "2018-02-13 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/7RCBW2tEl2",
      "expanded_url" : "http:\/\/haven.tidyverse.org\/",
      "display_url" : "haven.tidyverse.org"
    } ]
  },
  "geo" : { },
  "id_str" : "963095359365857281",
  "text" : "Read SAS, SPSS and Stata data files into R with the haven package https:\/\/t.co\/7RCBW2tEl2 #rstats",
  "id" : 963095359365857281,
  "created_at" : "2018-02-12 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/9ZMWk4sXQy",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/methods",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "962008199950929920",
  "text" : "Use methods(class='lm') to list all the special operations available on \"lm\" regression objects https:\/\/t.co\/9ZMWk4sXQy #rstats",
  "id" : 962008199950929920,
  "created_at" : "2018-02-09 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/AswA7KKYRC",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/sink",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "961645806326616069",
  "text" : "Use sink() to direct R's output to a file https:\/\/t.co\/AswA7KKYRC #rstats",
  "id" : 961645806326616069,
  "created_at" : "2018-02-08 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/0Mnn4FyQsK",
      "expanded_url" : "http:\/\/cda.ms\/8z",
      "display_url" : "cda.ms\/8z"
    } ]
  },
  "geo" : { },
  "id_str" : "961283426530873344",
  "text" : "Quick-start tutorial on using R in Azure Machine Learning Studio https:\/\/t.co\/0Mnn4FyQsK #rstats",
  "id" : 961283426530873344,
  "created_at" : "2018-02-07 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/AHCLtpGR1P",
      "expanded_url" : "http:\/\/fg2re.sellorm.com\/",
      "display_url" : "fg2re.sellorm.com"
    } ]
  },
  "geo" : { },
  "id_str" : "960921036224163840",
  "text" : "A Field Guide to the R Ecosystem: https:\/\/t.co\/AHCLtpGR1P #rstats",
  "id" : 960921036224163840,
  "created_at" : "2018-02-06 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/OL20boKzwu",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/eigen",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "960558649360908289",
  "text" : "Get eigenvalues and eigenvectors in R with eigen(mymatrix) https:\/\/t.co\/OL20boKzwu #rstats",
  "id" : 960558649360908289,
  "created_at" : "2018-02-05 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/rv5z08EOgr",
      "expanded_url" : "https:\/\/www.rstudio.com\/products\/rstudio\/",
      "display_url" : "rstudio.com\/products\/rstud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "959471483570368512",
  "text" : "RStudio: a complete, open-source interactive development environment for R https:\/\/t.co\/rv5z08EOgr #rstats",
  "id" : 959471483570368512,
  "created_at" : "2018-02-02 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/2AqkpF8Frn",
      "expanded_url" : "https:\/\/www.statmethods.net\/stats\/resampling.html",
      "display_url" : "statmethods.net\/stats\/resampli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "959109103472619520",
  "text" : "The Quick-R guide to Resampling Statistics in R: https:\/\/t.co\/2AqkpF8Frn #rstats",
  "id" : 959109103472619520,
  "created_at" : "2018-02-01 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]