Grailbird.data.tweets_2018_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Navarro",
      "screen_name" : "djnavarro",
      "indices" : [ 84, 94 ],
      "id_str" : "108899342",
      "id" : 108899342
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/4OBLyeajCw",
      "expanded_url" : "http:\/\/compcogscisydney.org\/learning-statistics-with-r\/",
      "display_url" : "compcogscisydney.org\/learning-stati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1024323811737513992",
  "text" : "\"Learning Statistics with R\", course notes for teaching R to Psychology students by @djnavarro https:\/\/t.co\/4OBLyeajCw #rstats",
  "id" : 1024323811737513992,
  "created_at" : "2018-07-31 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/vqSp0eIyNK",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/MedicalImaging.html",
      "display_url" : "cran.r-project.org\/web\/views\/Medi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1023961417429524482",
  "text" : "List of R packages for the analysis of medical images: https:\/\/t.co\/vqSp0eIyNK #rstats",
  "id" : 1023961417429524482,
  "created_at" : "2018-07-30 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/7jP7YCeeN4",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/deviance",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1022874259025276929",
  "text" : "deviance(fit) returns the deviance of a fitted model object https:\/\/t.co\/7jP7YCeeN4 #rstats",
  "id" : 1022874259025276929,
  "created_at" : "2018-07-27 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/maopCvY23h",
      "expanded_url" : "http:\/\/www.gastonsanchez.com\/r4strings\/index.html",
      "display_url" : "gastonsanchez.com\/r4strings\/inde\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1022511875492401152",
  "text" : "Handling Strings with R, a free e-book: https:\/\/t.co\/maopCvY23h #rstats",
  "id" : 1022511875492401152,
  "created_at" : "2018-07-26 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/RZVjBM0qgL",
      "expanded_url" : "https:\/\/cda.ms\/zk",
      "display_url" : "cda.ms\/zk"
    } ]
  },
  "geo" : { },
  "id_str" : "1022149477124075520",
  "text" : "How to use R to create custom visualizations in Power BI Service https:\/\/t.co\/RZVjBM0qgL #rstats",
  "id" : 1022149477124075520,
  "created_at" : "2018-07-25 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/roxxjU88As",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.1\/topics\/str",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1021787088210014208",
  "text" : "Use str(obj) to display the components of any object in human-readable format https:\/\/t.co\/roxxjU88As #rstats",
  "id" : 1021787088210014208,
  "created_at" : "2018-07-24 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/2wWoqJZN7O",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/deriv",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1021424707415883776",
  "text" : "Use \"deriv\" to create a function that returns the derivative and hessian of an algebraic expression: https:\/\/t.co\/2wWoqJZN7O #rstats",
  "id" : 1021424707415883776,
  "created_at" : "2018-07-23 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 145, 152 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/sqRolnCCzc",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/substitute",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1020337537011863552",
  "text" : "Use 'substitute' to include the variable's name in a plot title, e.g.: hist(var,main=substitute(paste(\"Dist of \", var))) https:\/\/t.co\/sqRolnCCzc #rstats",
  "id" : 1020337537011863552,
  "created_at" : "2018-07-20 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/1jvQte1pda",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/alias",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1019975159925665794",
  "text" : "alias(lm_object) will find linearly dependent terms in analysis of variance models https:\/\/t.co\/1jvQte1pda #rstats",
  "id" : 1019975159925665794,
  "created_at" : "2018-07-19 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 147, 154 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/PaDJXjljia",
      "expanded_url" : "https:\/\/cda.ms\/zd",
      "display_url" : "cda.ms\/zd"
    } ]
  },
  "geo" : { },
  "id_str" : "1019612764958932992",
  "text" : "The Data Science Virtual Machine is an Azure instance preinstalled with Microsoft R, Rstudio, Rattle, Tensorflow and more: https:\/\/t.co\/PaDJXjljia #rstats",
  "id" : 1019612764958932992,
  "created_at" : "2018-07-18 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/tCLOgSs2mN",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/dplyr\/versions\/0.7.6\/topics\/sample",
      "display_url" : "rdocumentation.org\/packages\/dplyr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1019250375738527744",
  "text" : "Use sample_n (in the dplyr package) to select random rows from a data frame or tbl https:\/\/t.co\/tCLOgSs2mN #rstats",
  "id" : 1019250375738527744,
  "created_at" : "2018-07-17 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/8TS7j3p17S",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/all.equal",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1018887993271115776",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: https:\/\/t.co\/8TS7j3p17S #rstats",
  "id" : 1018887993271115776,
  "created_at" : "2018-07-16 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/l8dMyKvuRK",
      "expanded_url" : "http:\/\/www.endmemo.com\/program\/R\/tapply.php",
      "display_url" : "endmemo.com\/program\/R\/tapp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1017800832144805889",
  "text" : "tapply(x, groups) applies a function to each non-empty group in a \"ragged\" array. Example: https:\/\/t.co\/l8dMyKvuRK #rstats",
  "id" : 1017800832144805889,
  "created_at" : "2018-07-13 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/CTGSo8qXQm",
      "expanded_url" : "http:\/\/www.r-bloggers.com\/",
      "display_url" : "r-bloggers.com"
    } ]
  },
  "geo" : { },
  "id_str" : "1017438438528651264",
  "text" : "Over 750 people who blog about R https:\/\/t.co\/CTGSo8qXQm #rstats",
  "id" : 1017438438528651264,
  "created_at" : "2018-07-12 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/3blsgcuO90",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/kronecker",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1017076050092625920",
  "text" : "A %x% B calculates the kronecker product of matrices A and B https:\/\/t.co\/3blsgcuO90 #rstats",
  "id" : 1017076050092625920,
  "created_at" : "2018-07-11 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erich Neuwirth",
      "screen_name" : "neuwirthe",
      "indices" : [ 61, 71 ],
      "id_str" : "57048572",
      "id" : 57048572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1016713670469017601",
  "text" : "You can define your own operators in R #rstats. Example (via @neuwirthe):\n\n`%divisible_by%` &lt;- function(x,y) x %% y == 0\n\n6 %divisible_by% 3\n6 %divisible_by% 4",
  "id" : 1016713670469017601,
  "created_at" : "2018-07-10 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/0KHTTuLF8I",
      "expanded_url" : "http:\/\/sas-and-r.blogspot.com\/",
      "display_url" : "sas-and-r.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "1016351272847400960",
  "text" : "Side by side comparisons of analysis tasks done in SAS and R: https:\/\/t.co\/0KHTTuLF8I #rstats",
  "id" : 1016351272847400960,
  "created_at" : "2018-07-09 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/ckj3lpaduv",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-lang.html#Indexing-by-vectors",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1015264119635808256",
  "text" : "Efficiency tip: When selecting from a data frame, df$a[1] is much faster than df[1,\"a\"] #rstats https:\/\/t.co\/ckj3lpaduv #rstats",
  "id" : 1015264119635808256,
  "created_at" : "2018-07-06 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/F6c1TOFERV",
      "expanded_url" : "https:\/\/www.edx.org\/course\/analyzing-big-data-microsoft-r-server-microsoft-dat213x#",
      "display_url" : "edx.org\/course\/analyzi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1014901725705236480",
  "text" : "Free self-paced edX course: Analyzing Big Data with Microsoft R Server https:\/\/t.co\/F6c1TOFERV! #rstats",
  "id" : 1014901725705236480,
  "created_at" : "2018-07-05 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/wbiGuzs7xU",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/maps\/versions\/3.3.0\/topics\/usa",
      "display_url" : "rdocumentation.org\/packages\/maps\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1014539336308715520",
  "text" : "Draw a map of the United States with R: \n  library(maps)\n  map('usa') \n#rstats https:\/\/t.co\/wbiGuzs7xU",
  "id" : 1014539336308715520,
  "created_at" : "2018-07-04 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/LDbeg9XDnG",
      "expanded_url" : "http:\/\/www.brodrigues.co\/blog\/2018-06-10-scraping_pdfs\/",
      "display_url" : "brodrigues.co\/blog\/2018-06-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1014176950296989696",
  "text" : "Extract data from tables in PDF documents with the pdftools package https:\/\/t.co\/LDbeg9XDnG #rstats",
  "id" : 1014176950296989696,
  "created_at" : "2018-07-03 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1013814566235660289",
  "text" : "Display information about your R session including R version, platform and attached packages with sessionInfo() #rstats",
  "id" : 1013814566235660289,
  "created_at" : "2018-07-02 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]