Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/RwCUgqcd",
      "expanded_url" : "http:\/\/bit.ly\/x4HV5i",
      "display_url" : "bit.ly\/x4HV5i"
    } ]
  },
  "geo" : { },
  "id_str" : "196978365842997248",
  "text" : "List of R functions and packages for visualization and analysis of multivariate data: http:\/\/t.co\/RwCUgqcd #rstats",
  "id" : 196978365842997248,
  "created_at" : "2012-04-30 15:04:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/yGa82UNr",
      "expanded_url" : "http:\/\/bit.ly\/I2UQ0v",
      "display_url" : "bit.ly\/I2UQ0v"
    } ]
  },
  "geo" : { },
  "id_str" : "195890947085713410",
  "text" : "Explore the capabilities of your installed R packages with browseVignettes() #rstats http:\/\/t.co\/yGa82UNr",
  "id" : 195890947085713410,
  "created_at" : "2012-04-27 15:03:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/nCirfqYl",
      "expanded_url" : "http:\/\/bit.ly\/HGLpQF",
      "display_url" : "bit.ly\/HGLpQF"
    } ]
  },
  "geo" : { },
  "id_str" : "195576450169057280",
  "text" : "List of answers to common questions about R on StackOverflow: http:\/\/t.co\/nCirfqYl #rstats",
  "id" : 195576450169057280,
  "created_at" : "2012-04-26 18:13:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195165800812912642",
  "text" : "Avoid namespace clashes! Use :: to specify an object within a specific package, e.g. MASS::mvnorm #rstats ttp:\/\/bit.ly\/Hft5M9",
  "id" : 195165800812912642,
  "created_at" : "2012-04-25 15:02:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/H5pBr9xg",
      "expanded_url" : "http:\/\/bit.ly\/ILpoTs",
      "display_url" : "bit.ly\/ILpoTs"
    } ]
  },
  "geo" : { },
  "id_str" : "194803436473171968",
  "text" : "Merge two data frames with merge(df1, df2) for an inner join and merge(df1,df2,all=TRUE) for an outer join. #rstats http:\/\/t.co\/H5pBr9xg",
  "id" : 194803436473171968,
  "created_at" : "2012-04-24 15:02:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/etg7VFb1",
      "expanded_url" : "http:\/\/bit.ly\/xCHKY8",
      "display_url" : "bit.ly\/xCHKY8"
    } ]
  },
  "geo" : { },
  "id_str" : "194441172826075136",
  "text" : "List of R packages for psychometrics (measurement of human characteristics): http:\/\/t.co\/etg7VFb1 #rstats",
  "id" : 194441172826075136,
  "created_at" : "2012-04-23 15:02:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/y0FaBaRJ",
      "expanded_url" : "http:\/\/bit.ly\/IfI9Zw",
      "display_url" : "bit.ly\/IfI9Zw"
    } ]
  },
  "geo" : { },
  "id_str" : "193354112547561472",
  "text" : "How to unshorten a bit.ly, t.co or other short URL with R: http:\/\/t.co\/y0FaBaRJ #rstats",
  "id" : 193354112547561472,
  "created_at" : "2012-04-20 15:03:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/ZtILBT2r",
      "expanded_url" : "http:\/\/bit.ly\/IyE1Wa",
      "display_url" : "bit.ly\/IyE1Wa"
    } ]
  },
  "geo" : { },
  "id_str" : "192991861143638016",
  "text" : "Use the plyr package to easily sort a data frame by a column: arrange(df, desc(colname)) #rstats http:\/\/t.co\/ZtILBT2r",
  "id" : 192991861143638016,
  "created_at" : "2012-04-19 15:03:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/avQtrtsC",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "192629153298784256",
  "text" : "search() displays the \"search list\" of packages where R searches for functions and other objects #rstats http:\/\/t.co\/avQtrtsC",
  "id" : 192629153298784256,
  "created_at" : "2012-04-18 15:02:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/BxSanRe0",
      "expanded_url" : "http:\/\/bit.ly\/x0y4JC",
      "display_url" : "bit.ly\/x0y4JC"
    } ]
  },
  "geo" : { },
  "id_str" : "191904454193319938",
  "text" : "List of R packages for analysis of ecological and environmental data: http:\/\/t.co\/BxSanRe0 #rstats",
  "id" : 191904454193319938,
  "created_at" : "2012-04-16 15:02:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/vAGwh02h",
      "expanded_url" : "http:\/\/bit.ly\/H9BMYq",
      "display_url" : "bit.ly\/H9BMYq"
    } ]
  },
  "geo" : { },
  "id_str" : "190817209826820100",
  "text" : "A list of funny Easter eggs in R packages: http:\/\/t.co\/vAGwh02h #rstats",
  "id" : 190817209826820100,
  "created_at" : "2012-04-13 15:02:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/NTAPla2O",
      "expanded_url" : "http:\/\/bit.ly\/HDgsfu",
      "display_url" : "bit.ly\/HDgsfu"
    } ]
  },
  "geo" : { },
  "id_str" : "190483891608494080",
  "text" : "Use NROW\/NCOL instead of nrow\/ncol to treat vectors as 1-column matrices #rstats http:\/\/t.co\/NTAPla2O",
  "id" : 190483891608494080,
  "created_at" : "2012-04-12 16:57:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/sWTIHQuH",
      "expanded_url" : "http:\/\/bit.ly\/IS1LDg",
      "display_url" : "bit.ly\/IS1LDg"
    } ]
  },
  "geo" : { },
  "id_str" : "190189815071907841",
  "text" : "Use \\n to embed a newline within a string, e.g. cat(\"Line 1\\nLine 2\") #rstats http:\/\/t.co\/sWTIHQuH",
  "id" : 190189815071907841,
  "created_at" : "2012-04-11 21:29:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Cugxn2Ni",
      "expanded_url" : "http:\/\/bit.ly\/yk582p",
      "display_url" : "bit.ly\/yk582p"
    } ]
  },
  "geo" : { },
  "id_str" : "189729982392713216",
  "text" : "List of R packages and functions for high-performance and parallel computing with R: http:\/\/t.co\/Cugxn2Ni #rstats",
  "id" : 189729982392713216,
  "created_at" : "2012-04-10 15:02:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189397692215074816",
  "text" : "If x is a list, then x[2] &lt;- NULL removes the second element, whereas x[2] &lt;- list(NULL) replaces it with NULL. #rstats",
  "id" : 189397692215074816,
  "created_at" : "2012-04-09 17:01:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/EN7MJU9k",
      "expanded_url" : "http:\/\/bit.ly\/H9C2Xp",
      "display_url" : "bit.ly\/H9C2Xp"
    } ]
  },
  "geo" : { },
  "id_str" : "188280356741451777",
  "text" : "How to calculate the date of Easter in R: require(timeDate); Easter(2012) #rstats http:\/\/t.co\/EN7MJU9k",
  "id" : 188280356741451777,
  "created_at" : "2012-04-06 15:01:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/srslQ5le",
      "expanded_url" : "http:\/\/bit.ly\/H8SSce",
      "display_url" : "bit.ly\/H8SSce"
    } ]
  },
  "geo" : { },
  "id_str" : "187917935094935552",
  "text" : "You can plot a function object to create a chart of its equation, e.g. plot(dnorm, xlim=c(-4,4)) # rstats http:\/\/t.co\/srslQ5le",
  "id" : 187917935094935552,
  "created_at" : "2012-04-05 15:01:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/d5xuMa9Q",
      "expanded_url" : "http:\/\/bit.ly\/H9pAae",
      "display_url" : "bit.ly\/H9pAae"
    } ]
  },
  "geo" : { },
  "id_str" : "187555592322285569",
  "text" : "Free e-book on multilevel modeling with #rstats using nlme and multilevel packages: http:\/\/t.co\/d5xuMa9Q",
  "id" : 187555592322285569,
  "created_at" : "2012-04-04 15:01:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/p3n0VTbO",
      "expanded_url" : "http:\/\/bit.ly\/H9AbSs",
      "display_url" : "bit.ly\/H9AbSs"
    } ]
  },
  "geo" : { },
  "id_str" : "187193190917472256",
  "text" : "Use mapply to call a multi-argument function repeatedly, e.g. mapply(sample, list(1:56, 1:46), c(5,1)) #rstats http:\/\/t.co\/p3n0VTbO",
  "id" : 187193190917472256,
  "created_at" : "2012-04-03 15:01:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/JXv4E65r",
      "expanded_url" : "http:\/\/bit.ly\/wp6kZo",
      "display_url" : "bit.ly\/wp6kZo"
    } ]
  },
  "geo" : { },
  "id_str" : "186830849499611136",
  "text" : "List of R packages for the analysis of pharmacokinetic (drug dose\/response) data: http:\/\/t.co\/JXv4E65r #rstats",
  "id" : 186830849499611136,
  "created_at" : "2012-04-02 15:02:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/AXu9zErJ",
      "expanded_url" : "http:\/\/bit.ly\/znTcEd",
      "display_url" : "bit.ly\/znTcEd"
    } ]
  },
  "geo" : { },
  "id_str" : "186468354360483841",
  "text" : "The \"lottopredictor\" R package uses a Poisson (d'Avril) model to select winning lottery numbers http:\/\/t.co\/AXu9zErJ #rstats",
  "id" : 186468354360483841,
  "created_at" : "2012-04-01 15:01:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]