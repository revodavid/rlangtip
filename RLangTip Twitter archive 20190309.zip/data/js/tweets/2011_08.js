Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/JINHZR1",
      "expanded_url" : "http:\/\/bit.ly\/n60XJM",
      "display_url" : "bit.ly\/n60XJM"
    } ]
  },
  "geo" : { },
  "id_str" : "108917100004909056",
  "text" : "Search for #rstats on Twitter for conversations about R: http:\/\/t.co\/JINHZR1",
  "id" : 108917100004909056,
  "created_at" : "2011-08-31 15:00:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/9RXUQXJ",
      "expanded_url" : "http:\/\/bit.ly\/oSevHz",
      "display_url" : "bit.ly\/oSevHz"
    } ]
  },
  "geo" : { },
  "id_str" : "108554725120675840",
  "text" : "Use sqldf to select rows from a data frame using SQL syntax: http:\/\/t.co\/9RXUQXJ  #rstats",
  "id" : 108554725120675840,
  "created_at" : "2011-08-30 15:00:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108192312605163520",
  "text" : "Search for a function in base R or any CRAN package at www.inside-r.org\/search  #rstats",
  "id" : 108192312605163520,
  "created_at" : "2011-08-29 15:00:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/tyWKIme",
      "expanded_url" : "http:\/\/bit.ly\/qPEhsk",
      "display_url" : "bit.ly\/qPEhsk"
    } ]
  },
  "geo" : { },
  "id_str" : "107105149339697152",
  "text" : "Use the subset() function to select rows and columns from a data frame, based on the data it contains: http:\/\/t.co\/tyWKIme  #rstats",
  "id" : 107105149339697152,
  "created_at" : "2011-08-26 15:00:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/AdqjfAr",
      "expanded_url" : "http:\/\/bit.ly\/pzIdlb",
      "display_url" : "bit.ly\/pzIdlb"
    } ]
  },
  "geo" : { },
  "id_str" : "106742748505321473",
  "text" : "Use the transform() function to add a new column to a data frame, using the data from existing columns: http:\/\/t.co\/AdqjfAr  #rstats",
  "id" : 106742748505321473,
  "created_at" : "2011-08-25 15:00:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/suGl3Bn",
      "expanded_url" : "http:\/\/bit.ly\/pM20DY",
      "display_url" : "bit.ly\/pM20DY"
    } ]
  },
  "geo" : { },
  "id_str" : "106380360761360385",
  "text" : "The foreach function can be used to speed up loops by running in parallel on multi-core machines: http:\/\/t.co\/suGl3Bn  #rstats",
  "id" : 106380360761360385,
  "created_at" : "2011-08-24 15:00:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/jEgltyk",
      "expanded_url" : "http:\/\/bit.ly\/onqu7V",
      "display_url" : "bit.ly\/onqu7V"
    } ]
  },
  "geo" : { },
  "id_str" : "106017974619607040",
  "text" : "Use the with() function to write R code using variables in a data frame, without needing the $ syntax: http:\/\/t.co\/jEgltyk  #rstats",
  "id" : 106017974619607040,
  "created_at" : "2011-08-23 15:00:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105655584744931329",
  "text" : "If you've having trouble using a variable name with odd characters (like $, ! or space), wrap it in back quotes: `odd-name` #rstats",
  "id" : 105655584744931329,
  "created_at" : "2011-08-22 15:00:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/93Wrkkx",
      "expanded_url" : "http:\/\/bit.ly\/peyKzm",
      "display_url" : "bit.ly\/peyKzm"
    } ]
  },
  "geo" : { },
  "id_str" : "104568423404683267",
  "text" : "The \"file\" argument to data import functions like read.table can be a URL, to read data from the Web. http:\/\/t.co\/93Wrkkx  #rstats",
  "id" : 104568423404683267,
  "created_at" : "2011-08-19 15:00:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104206025703432193",
  "text" : "Use head() to quickly check the first few rows\/elements of a large data frame, vector, list, etc. http:\/\/ow.ly\/6248S  #rstats",
  "id" : 104206025703432193,
  "created_at" : "2011-08-18 15:00:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103843630640406529",
  "text" : "Use str(obj) to display the components of any object in human-readable format. http:\/\/ow.ly\/6244Q  #rstats",
  "id" : 103843630640406529,
  "created_at" : "2011-08-17 15:00:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/9rUPYQF",
      "expanded_url" : "http:\/\/bit.ly\/o3CFC3",
      "display_url" : "bit.ly\/o3CFC3"
    } ]
  },
  "geo" : { },
  "id_str" : "103481213951549441",
  "text" : "To convert dates\/times from one timezone to another, use format() on a POSIXct object. Details: http:\/\/t.co\/9rUPYQF  #rstats",
  "id" : 103481213951549441,
  "created_at" : "2011-08-16 15:00:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103118849028784129",
  "text" : "To speed an R function, use cmpfun to byte-compile it: http:\/\/ow.ly\/623XZ  #rstats",
  "id" : 103118849028784129,
  "created_at" : "2011-08-15 15:00:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102031709855424512",
  "text" : "Don't know the full name of the function you need?  You can perform a fuzzy search with the apropos function: apropos(\"summary\") #rstats",
  "id" : 102031709855424512,
  "created_at" : "2011-08-12 15:00:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101669605369577472",
  "text" : "Run help file examples for a particular function using the 'example' function:  example(plot)  or example(lm) #rstats",
  "id" : 101669605369577472,
  "created_at" : "2011-08-11 15:01:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101322047266881536",
  "text" : "Do you think we should include the #rstats hashtag in our daily R tweet-tips?",
  "id" : 101322047266881536,
  "created_at" : "2011-08-10 16:00:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101306917799997440",
  "text" : "Type ?Syntax to learn the precedence of operators in the R language: http:\/\/ow.ly\/5Wjwd #rstats",
  "id" : 101306917799997440,
  "created_at" : "2011-08-10 15:00:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100944532681666561",
  "text" : "Use colSums to quickly calculate totals from the columns of a large matrix or table: http:\/\/ow.ly\/5WjmS #rstats",
  "id" : 100944532681666561,
  "created_at" : "2011-08-09 15:00:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100582150021197824",
  "text" : "Use the compactPDF function to make PDF files smaller:  http:\/\/ow.ly\/5Wjq2 #rstats",
  "id" : 100582150021197824,
  "created_at" : "2011-08-08 15:00:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 14, 24 ],
      "id_str" : "17522755",
      "id" : 17522755
    }, {
      "name" : "inside-R Community",
      "screen_name" : "inside_R",
      "indices" : [ 85, 94 ],
      "id_str" : "130570965",
      "id" : 130570965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99538081702608897",
  "text" : "Big Thanks to @JohnDCook for his great work on this Twitter account. The team behind @inside_R will continue to send out daily #rstats tips.",
  "id" : 99538081702608897,
  "created_at" : "2011-08-05 17:51:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 10, 19 ],
      "id_str" : "295344317",
      "id" : 295344317
    }, {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 67, 77 ],
      "id_str" : "17522755",
      "id" : 17522755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99489863618928640",
  "text" : "Next week @RLangTip continues in better hands. I'm signing out. -- @JohnDCook http:\/\/ow.ly\/5Tk9H",
  "id" : 99489863618928640,
  "created_at" : "2011-08-05 14:40:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Myles White",
      "screen_name" : "johnmyleswhite",
      "indices" : [ 50, 65 ],
      "id_str" : "15379361",
      "id" : 15379361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99483587207905280",
  "text" : "Higher-order functions in R http:\/\/ow.ly\/5UKju by @johnmyleswhite",
  "id" : 99483587207905280,
  "created_at" : "2011-08-05 14:15:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeromy Anglim",
      "screen_name" : "JeromyAnglim",
      "indices" : [ 64, 77 ],
      "id_str" : "32311190",
      "id" : 32311190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99192974717616128",
  "text" : "Learning R for Researchers in Psychology http:\/\/ow.ly\/5UKmX  by @JeromyAnglim",
  "id" : 99192974717616128,
  "created_at" : "2011-08-04 19:00:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rstats",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99174009995919361",
  "text" : "RT @Shreyu86: Faster file reading in #Rstats http:\/\/bit.ly\/oJboy8 via R-bloggers.com",
  "id" : 99174009995919361,
  "created_at" : "2011-08-04 17:45:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99142572974419968",
  "text" : "Running R on Amazon EC2 http:\/\/ow.ly\/5UKhz",
  "id" : 99142572974419968,
  "created_at" : "2011-08-04 15:40:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99127475577176066",
  "text" : "In Emacs, you can embed R code in org-mode files analogous to the way Sweave lets you embed R in LaTeX.",
  "id" : 99127475577176066,
  "created_at" : "2011-08-04 14:40:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 45, 59 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99107343282876416",
  "text" : "Advanced R development http:\/\/ow.ly\/5UKow by @hadleywickham",
  "id" : 99107343282876416,
  "created_at" : "2011-08-04 13:20:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98952379134771200",
  "text" : "The Art of R Programming by Norman Matloff http:\/\/ow.ly\/5UKg6",
  "id" : 98952379134771200,
  "created_at" : "2011-08-04 03:04:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98857635541041152",
  "text" : "Moving data between R and Excel http:\/\/ow.ly\/5Uxns",
  "id" : 98857635541041152,
  "created_at" : "2011-08-03 20:47:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98765090412691456",
  "text" : "Evaluate a buffer of R code in ESS (Emacs Speaks Statistics): C-c C-b",
  "id" : 98765090412691456,
  "created_at" : "2011-08-03 14:40:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 10, 19 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98468220771639297",
  "text" : "Next week @RLangTip changes hands http:\/\/ow.ly\/5SX62",
  "id" : 98468220771639297,
  "created_at" : "2011-08-02 19:00:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98402696847048705",
  "text" : "R for programmers coming from other languages http:\/\/bit.ly\/rkawJQ",
  "id" : 98402696847048705,
  "created_at" : "2011-08-02 14:40:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]