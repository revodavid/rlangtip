Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/RkFAy2af3w",
      "expanded_url" : "http:\/\/bit.ly\/KETjbI",
      "display_url" : "bit.ly\/KETjbI"
    } ]
  },
  "geo" : { },
  "id_str" : "350631431933935620",
  "text" : "Index of datasets included with R: http:\/\/t.co\/RkFAy2af3w #rstats",
  "id" : 350631431933935620,
  "created_at" : "2013-06-28 15:07:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/LrZlNeEhFS",
      "expanded_url" : "http:\/\/bit.ly\/OrT9bX",
      "display_url" : "bit.ly\/OrT9bX"
    } ]
  },
  "geo" : { },
  "id_str" : "350284811694391297",
  "text" : "To speed up your R code, use Rprof() to turn on profiling, and summaryRprof() to find the slow parts: http:\/\/t.co\/LrZlNeEhFS #rstats",
  "id" : 350284811694391297,
  "created_at" : "2013-06-27 16:09:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/WLcz3DZesy",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "349921534002991105",
  "text" : "Efficiency tip: TRUE || (x &lt;-3) will never evaluate the right hand side. Using &amp;&amp; and || can save cycles #rstats http:\/\/t.co\/WLcz3DZesy",
  "id" : 349921534002991105,
  "created_at" : "2013-06-26 16:06:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/56Yvg6Nk2S",
      "expanded_url" : "http:\/\/bit.ly\/LpJWCh",
      "display_url" : "bit.ly\/LpJWCh"
    } ]
  },
  "geo" : { },
  "id_str" : "349740172319014912",
  "text" : "Extracting data from PDFs with #rstats. Vector Image Processing http:\/\/t.co\/56Yvg6Nk2S (PDF)",
  "id" : 349740172319014912,
  "created_at" : "2013-06-26 04:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/0VP7aTfL6c",
      "expanded_url" : "http:\/\/bit.ly\/LpJ0Of",
      "display_url" : "bit.ly\/LpJ0Of"
    } ]
  },
  "geo" : { },
  "id_str" : "349197279032385537",
  "text" : "Random input testing with R: http:\/\/t.co\/0VP7aTfL6c (PDF) #rstats",
  "id" : 349197279032385537,
  "created_at" : "2013-06-24 16:08:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Y6uSsH8dPh",
      "expanded_url" : "http:\/\/bit.ly\/n2rmBo",
      "display_url" : "bit.ly\/n2rmBo"
    } ]
  },
  "geo" : { },
  "id_str" : "348110454633148416",
  "text" : "Reserved words that can't be used as object names: if, while, for, next, TRUE, and several others listed at http:\/\/t.co\/Y6uSsH8dPh #rstats",
  "id" : 348110454633148416,
  "created_at" : "2013-06-21 16:09:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/EVwQkNbpla",
      "expanded_url" : "http:\/\/bit.ly\/xywuih",
      "display_url" : "bit.ly\/xywuih"
    } ]
  },
  "geo" : { },
  "id_str" : "347747743927783426",
  "text" : "In R scripts, use invisible() to prevent functions from generating unwanted output: http:\/\/t.co\/EVwQkNbpla #rstats",
  "id" : 347747743927783426,
  "created_at" : "2013-06-20 16:08:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/gi3quy7yKA",
      "expanded_url" : "http:\/\/bit.ly\/zrvgHJ",
      "display_url" : "bit.ly\/zrvgHJ"
    } ]
  },
  "geo" : { },
  "id_str" : "347384885452877825",
  "text" : "Use the xtable package to convert a table or matrix to HTML: print(xtable(X), type=\"html\") #rstats http:\/\/t.co\/gi3quy7yKA",
  "id" : 347384885452877825,
  "created_at" : "2013-06-19 16:06:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ovmertOeKN",
      "expanded_url" : "http:\/\/bit.ly\/AfpXZF",
      "display_url" : "bit.ly\/AfpXZF"
    } ]
  },
  "geo" : { },
  "id_str" : "347022470068449280",
  "text" : "How to credit R in a manuscript or article: citation(). Works for packages, too: citation(\"MASS\") #rstats http:\/\/t.co\/ovmertOeKN",
  "id" : 347022470068449280,
  "created_at" : "2013-06-18 16:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/8ukEqHzehM",
      "expanded_url" : "http:\/\/bit.ly\/x9UdLI",
      "display_url" : "bit.ly\/x9UdLI"
    } ]
  },
  "geo" : { },
  "id_str" : "346660160258834433",
  "text" : "sample(x) randomly shuffles the elements of a vector or list x #rstats http:\/\/t.co\/8ukEqHzehM",
  "id" : 346660160258834433,
  "created_at" : "2013-06-17 16:06:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/RK88VNIwmk",
      "expanded_url" : "http:\/\/bit.ly\/nFTz0V",
      "display_url" : "bit.ly\/nFTz0V"
    } ]
  },
  "geo" : { },
  "id_str" : "345572925727993856",
  "text" : "List of R functions and packages for Machine Learning &amp; Statistical Learning: http:\/\/t.co\/RK88VNIwmk #rstats",
  "id" : 345572925727993856,
  "created_at" : "2013-06-14 16:06:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/u3VfhOdxDd",
      "expanded_url" : "http:\/\/bit.ly\/pRciwj",
      "display_url" : "bit.ly\/pRciwj"
    } ]
  },
  "geo" : { },
  "id_str" : "345210615859666944",
  "text" : "Comparing floating-point numbers with == is unwise. Use all.equal to avoid errors from rounding: http:\/\/t.co\/u3VfhOdxDd #rstats",
  "id" : 345210615859666944,
  "created_at" : "2013-06-13 16:06:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/0lEzQzD9II",
      "expanded_url" : "http:\/\/bit.ly\/wIGrFC",
      "display_url" : "bit.ly\/wIGrFC"
    } ]
  },
  "geo" : { },
  "id_str" : "344848232049938433",
  "text" : "A single index can be used to select from a matrix. For example, X[row(X)==col(X)] is the same as diag(X) #rstats http:\/\/t.co\/0lEzQzD9II",
  "id" : 344848232049938433,
  "created_at" : "2013-06-12 16:06:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/hSaYhheU2y",
      "expanded_url" : "http:\/\/bit.ly\/LpG9Vs",
      "display_url" : "bit.ly\/LpG9Vs"
    } ]
  },
  "geo" : { },
  "id_str" : "344485725686878208",
  "text" : "How to create interactive #rstats charts on the web with RGoogleVis: http:\/\/t.co\/hSaYhheU2y (PDF)",
  "id" : 344485725686878208,
  "created_at" : "2013-06-11 16:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/GSvxfmWGJ0",
      "expanded_url" : "http:\/\/bit.ly\/Lpx9Q7",
      "display_url" : "bit.ly\/Lpx9Q7"
    } ]
  },
  "geo" : { },
  "id_str" : "344123553819553794",
  "text" : "How to create or catch warnings and errors in R code: http:\/\/t.co\/GSvxfmWGJ0 #rstats",
  "id" : 344123553819553794,
  "created_at" : "2013-06-10 16:07:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/yGpMNsdPET",
      "expanded_url" : "http:\/\/bit.ly\/zBaVM4",
      "display_url" : "bit.ly\/zBaVM4"
    } ]
  },
  "geo" : { },
  "id_str" : "343036298422001665",
  "text" : "Use the RMySQL package to read data from MySQL into R using SQL queries: http:\/\/t.co\/yGpMNsdPET #rstats",
  "id" : 343036298422001665,
  "created_at" : "2013-06-07 16:06:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342673979628195840",
  "text" : "Get an overview of documentation for an installed package: help(package=\"&lt;package-name&gt;\") #rstats",
  "id" : 342673979628195840,
  "created_at" : "2013-06-06 16:06:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/k289CigQIf",
      "expanded_url" : "http:\/\/bit.ly\/LiAcJX",
      "display_url" : "bit.ly\/LiAcJX"
    } ]
  },
  "geo" : { },
  "id_str" : "342311409159401472",
  "text" : "A collection of tips for R beginners: http:\/\/t.co\/k289CigQIf #rstats",
  "id" : 342311409159401472,
  "created_at" : "2013-06-05 16:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/mBey9MKe1s",
      "expanded_url" : "http:\/\/bit.ly\/LCS4L1",
      "display_url" : "bit.ly\/LCS4L1"
    } ]
  },
  "geo" : { },
  "id_str" : "341949051899625474",
  "text" : "Tutorial: Analysis of Variance (ANOVA) for comparing the means http:\/\/t.co\/mBey9MKe1s #rstats",
  "id" : 341949051899625474,
  "created_at" : "2013-06-04 16:06:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5xJmW6A72w",
      "expanded_url" : "http:\/\/bit.ly\/16wTl6t",
      "display_url" : "bit.ly\/16wTl6t"
    } ]
  },
  "geo" : { },
  "id_str" : "341586666403815424",
  "text" : "Read a .csv file from a website into a data frame: fp &lt;- file.path(\"URL\",\"filename.csv\"); df &lt;- read.csv(fp) http:\/\/t.co\/5xJmW6A72w",
  "id" : 341586666403815424,
  "created_at" : "2013-06-03 16:06:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]