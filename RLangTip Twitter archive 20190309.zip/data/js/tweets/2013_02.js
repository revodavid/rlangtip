Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yrsoM1zQdW",
      "expanded_url" : "http:\/\/bit.ly\/H8SSce",
      "display_url" : "bit.ly\/H8SSce"
    } ]
  },
  "geo" : { },
  "id_str" : "307153000202375169",
  "text" : "You can plot a function object to create a chart of its equation, e.g. plot(dnorm, xlim=c(-4,4)) #rstats http:\/\/t.co\/yrsoM1zQdW",
  "id" : 307153000202375169,
  "created_at" : "2013-02-28 15:39:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/zLsPhyZlS7",
      "expanded_url" : "http:\/\/bit.ly\/IS1LDg",
      "display_url" : "bit.ly\/IS1LDg"
    } ]
  },
  "geo" : { },
  "id_str" : "306805974352658433",
  "text" : "Use \\n to embed a newline within a string, e.g. cat(\"Line 1\\nLine 2\") #rstats http:\/\/t.co\/zLsPhyZlS7",
  "id" : 306805974352658433,
  "created_at" : "2013-02-27 16:40:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/EFnRQge68n",
      "expanded_url" : "http:\/\/bit.ly\/we8tgt",
      "display_url" : "bit.ly\/we8tgt"
    } ]
  },
  "geo" : { },
  "id_str" : "306452527891763200",
  "text" : "Calculate running 30-day means of values in vector x: filter(x,rep(1\/30,30)) #rstats http:\/\/t.co\/EFnRQge68n",
  "id" : 306452527891763200,
  "created_at" : "2013-02-26 17:15:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5v002KuozU",
      "expanded_url" : "http:\/\/bit.ly\/yUSrZr",
      "display_url" : "bit.ly\/yUSrZr"
    } ]
  },
  "geo" : { },
  "id_str" : "306066882136518657",
  "text" : "Install an R package directly from GitHub with devtools package: http:\/\/t.co\/5v002KuozU #rstats",
  "id" : 306066882136518657,
  "created_at" : "2013-02-25 15:43:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sirisha sunkara",
      "screen_name" : "sirishasun",
      "indices" : [ 3, 14 ],
      "id_str" : "133996641",
      "id" : 133996641
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 16, 25 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305087619493142528",
  "text" : "RT @sirishasun: @RLangTip identical(x,y) a better solution than all.equal(x,y), where x and y are floating point numbers, to test for eq ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "305013856592355329",
    "geo" : { },
    "id_str" : "305060801067245569",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip identical(x,y) a better solution than all.equal(x,y), where x and y are floating point numbers, to test for equality?",
    "id" : 305060801067245569,
    "in_reply_to_status_id" : 305013856592355329,
    "created_at" : "2013-02-22 21:05:37 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "sirisha sunkara",
      "screen_name" : "sirishasun",
      "protected" : false,
      "id_str" : "133996641",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_normal.png",
      "id" : 133996641,
      "verified" : false
    }
  },
  "id" : 305087619493142528,
  "created_at" : "2013-02-22 22:52:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/v8L5JSpn32",
      "expanded_url" : "http:\/\/bit.ly\/yPYjn5",
      "display_url" : "bit.ly\/yPYjn5"
    } ]
  },
  "geo" : { },
  "id_str" : "305013856592355329",
  "text" : "Some common pitfalls when working with floating-point numbers in #rstats: http:\/\/t.co\/v8L5JSpn32",
  "id" : 305013856592355329,
  "created_at" : "2013-02-22 17:59:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/5KVNzWGa3f",
      "expanded_url" : "http:\/\/bit.ly\/srEahw",
      "display_url" : "bit.ly\/srEahw"
    } ]
  },
  "geo" : { },
  "id_str" : "304626623418884097",
  "text" : "Moving data between R and Excel via the Windows clipboard: http:\/\/t.co\/5KVNzWGa3f #rstats",
  "id" : 304626623418884097,
  "created_at" : "2013-02-21 16:20:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/cAqxeQhJ",
      "expanded_url" : "http:\/\/bit.ly\/UDQtyf",
      "display_url" : "bit.ly\/UDQtyf"
    } ]
  },
  "geo" : { },
  "id_str" : "304274579411574784",
  "text" : "format(x, scientific=TRUE) prints numeric data in exponential format, so 0.0001 prints as 1e-04 http:\/\/t.co\/cAqxeQhJ",
  "id" : 304274579411574784,
  "created_at" : "2013-02-20 17:01:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/HMiouisl",
      "expanded_url" : "http:\/\/bit.ly\/zhOVTI",
      "display_url" : "bit.ly\/zhOVTI"
    } ]
  },
  "geo" : { },
  "id_str" : "303913689008984064",
  "text" : "List of R functions and packages for robust statistics: http:\/\/t.co\/HMiouisl #rstats",
  "id" : 303913689008984064,
  "created_at" : "2013-02-19 17:07:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/oUppfAZL",
      "expanded_url" : "http:\/\/bit.ly\/yEaOO2",
      "display_url" : "bit.ly\/yEaOO2"
    } ]
  },
  "geo" : { },
  "id_str" : "303555848150609922",
  "text" : "A collection of free tutorials provided by R users: http:\/\/t.co\/oUppfAZL #rstats",
  "id" : 303555848150609922,
  "created_at" : "2013-02-18 17:25:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/u38nUaMk",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "302458244750786560",
  "text" : "Create a deck of cards in #rstats: expand.grid(rank=c(\"A\",2:10,\"J\",\"Q\",\"K\"),suit=c(\"S\",\"H\",\"D\",\"C\")) # http:\/\/t.co\/u38nUaMk",
  "id" : 302458244750786560,
  "created_at" : "2013-02-15 16:43:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/AIrImq3Q",
      "expanded_url" : "http:\/\/bit.ly\/ywEk5w",
      "display_url" : "bit.ly\/ywEk5w"
    } ]
  },
  "geo" : { },
  "id_str" : "302146738792316928",
  "text" : "Guidance for use of #rstats in regulated clinical trial environments (incl. for FDA): http:\/\/t.co\/AIrImq3Q",
  "id" : 302146738792316928,
  "created_at" : "2013-02-14 20:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Burns",
      "screen_name" : "burnsstat",
      "indices" : [ 3, 13 ],
      "id_str" : "1068157430",
      "id" : 1068157430
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 15, 24 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/eyh75BSK",
      "expanded_url" : "http:\/\/bit.ly\/WgqYRo",
      "display_url" : "bit.ly\/WgqYRo"
    } ]
  },
  "geo" : { },
  "id_str" : "301431638779383810",
  "text" : "RT @burnsstat: @RLangTip Otherwise you are in Circle 2 of 'The R Inferno' http:\/\/t.co\/eyh75BSK #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/eyh75BSK",
        "expanded_url" : "http:\/\/bit.ly\/WgqYRo",
        "display_url" : "bit.ly\/WgqYRo"
      } ]
    },
    "in_reply_to_status_id_str" : "301388457174003712",
    "geo" : { },
    "id_str" : "301429276245385216",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip Otherwise you are in Circle 2 of 'The R Inferno' http:\/\/t.co\/eyh75BSK #rstats",
    "id" : 301429276245385216,
    "in_reply_to_status_id" : 301388457174003712,
    "created_at" : "2013-02-12 20:35:14 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Patrick Burns",
      "screen_name" : "burnsstat",
      "protected" : false,
      "id_str" : "1068157430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3077450292\/76c28f3987691f1877bc54ba0111940d_normal.png",
      "id" : 1068157430,
      "verified" : false
    }
  },
  "id" : 301431638779383810,
  "created_at" : "2013-02-12 20:44:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301388457174003712",
  "text" : "Collecting results in a loop? Pre-allocate a vector res=rep(0,N) and assign res[i]=val. Avoid extending in the loop: res=c(res,val) #rstats",
  "id" : 301388457174003712,
  "created_at" : "2013-02-12 17:53:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/2AOYHwZd",
      "expanded_url" : "http:\/\/bit.ly\/t2OR0K",
      "display_url" : "bit.ly\/t2OR0K"
    } ]
  },
  "geo" : { },
  "id_str" : "301023295371874305",
  "text" : "To speed an R function, use cmpfun to byte-compile it: http:\/\/t.co\/2AOYHwZd #rstats",
  "id" : 301023295371874305,
  "created_at" : "2013-02-11 17:42:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Burns",
      "screen_name" : "burnsstat",
      "indices" : [ 128, 138 ],
      "id_str" : "1068157430",
      "id" : 1068157430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/mmjfNaWD",
      "expanded_url" : "http:\/\/bit.ly\/14EaAxX",
      "display_url" : "bit.ly\/14EaAxX"
    } ]
  },
  "geo" : { },
  "id_str" : "299921029948649473",
  "text" : "Use the ... syntax to pass arguments to a subfunction. Use this to simplify complex #rstats functions http:\/\/t.co\/mmjfNaWD (via @burnsstat)",
  "id" : 299921029948649473,
  "created_at" : "2013-02-08 16:42:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/ylavxFqF",
      "expanded_url" : "http:\/\/bit.ly\/14E9ulW",
      "display_url" : "bit.ly\/14E9ulW"
    } ]
  },
  "geo" : { },
  "id_str" : "299552378682761216",
  "text" : "If x is a matrix, vector or list then x[]&lt;-0 replaces all its values by 0. More uses of the empty bracket in #rstats: http:\/\/t.co\/ylavxFqF",
  "id" : 299552378682761216,
  "created_at" : "2013-02-07 16:17:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikhail Popov",
      "screen_name" : "bearloga",
      "indices" : [ 113, 122 ],
      "id_str" : "36133587",
      "id" : 36133587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299191931391590400",
  "text" : "The arrow assignment operator works in both directions. This is valid #rstats syntax: x &lt;- value -&gt; y (via @bearloga)",
  "id" : 299191931391590400,
  "created_at" : "2013-02-06 16:24:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/cnRlbcdZ",
      "expanded_url" : "http:\/\/bit.ly\/u6tXtb",
      "display_url" : "bit.ly\/u6tXtb"
    } ]
  },
  "geo" : { },
  "id_str" : "298834185999753216",
  "text" : "In scripts, wrap code in local(\u007B \u007D) to prevent temporary variables overwriting global data: http:\/\/t.co\/cnRlbcdZ #rstats",
  "id" : 298834185999753216,
  "created_at" : "2013-02-05 16:43:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/rxi7ZzUC",
      "expanded_url" : "http:\/\/bit.ly\/LEU8S0",
      "display_url" : "bit.ly\/LEU8S0"
    } ]
  },
  "geo" : { },
  "id_str" : "298479806817898497",
  "text" : "The paste0 function concatenates strings back-to-back, without any separating characters http:\/\/t.co\/rxi7ZzUC #rstats",
  "id" : 298479806817898497,
  "created_at" : "2013-02-04 17:15:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/p4eIzhKs",
      "expanded_url" : "http:\/\/bit.ly\/VAy6rT",
      "display_url" : "bit.ly\/VAy6rT"
    } ]
  },
  "geo" : { },
  "id_str" : "297380897957748736",
  "text" : "Flowchart with useful resources for learning R (especially for survey analysis): http:\/\/t.co\/p4eIzhKs #rstats",
  "id" : 297380897957748736,
  "created_at" : "2013-02-01 16:28:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/saJhX6w3",
      "expanded_url" : "http:\/\/bit.ly\/TT8Obs",
      "display_url" : "bit.ly\/TT8Obs"
    } ]
  },
  "geo" : { },
  "id_str" : "297377106386628608",
  "text" : "Functions and packages for the analysis of spatio-temporal data: http:\/\/t.co\/saJhX6w3 #rstats",
  "id" : 297377106386628608,
  "created_at" : "2013-02-01 16:13:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]