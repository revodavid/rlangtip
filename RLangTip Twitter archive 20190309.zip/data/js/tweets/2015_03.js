Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/j5WhOXlcsg",
      "expanded_url" : "http:\/\/bit.ly\/1H7hlei",
      "display_url" : "bit.ly\/1H7hlei"
    } ]
  },
  "geo" : { },
  "id_str" : "582936120067039232",
  "text" : "Compare t-distribution with qnorm(.975) as df increases qt(.975, df = c(10,100,1000,10000)) http:\/\/t.co\/j5WhOXlcsg #rstats",
  "id" : 582936120067039232,
  "created_at" : "2015-03-31 16:02:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/KmfLMQ1CXC",
      "expanded_url" : "http:\/\/bit.ly\/195cFKC",
      "display_url" : "bit.ly\/195cFKC"
    } ]
  },
  "geo" : { },
  "id_str" : "582574420973228032",
  "text" : "To read a fixed width file: data &lt;- read.fwf(\"file\", widths=c(w1, w2, w3 . . . wn)) http:\/\/t.co\/KmfLMQ1CXC #rstats",
  "id" : 582574420973228032,
  "created_at" : "2015-03-30 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/iHT2iE4Osj",
      "expanded_url" : "http:\/\/bit.ly\/1MRy7li",
      "display_url" : "bit.ly\/1MRy7li"
    } ]
  },
  "geo" : { },
  "id_str" : "581487279186800640",
  "text" : "Some R help for MatLab users http:\/\/t.co\/iHT2iE4Osj #rstats",
  "id" : 581487279186800640,
  "created_at" : "2015-03-27 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/eR3AHj2CpC",
      "expanded_url" : "http:\/\/bit.ly\/1CFA17g",
      "display_url" : "bit.ly\/1CFA17g"
    } ]
  },
  "geo" : { },
  "id_str" : "581124900204711936",
  "text" : "Use rpois(n,lambda) to generate n random draws from a poisson distribution with rate lambda http:\/\/t.co\/eR3AHj2CpC #rstats",
  "id" : 581124900204711936,
  "created_at" : "2015-03-26 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/DqXjju5bht",
      "expanded_url" : "http:\/\/bit.ly\/1BXQbVW",
      "display_url" : "bit.ly\/1BXQbVW"
    } ]
  },
  "geo" : { },
  "id_str" : "580762465866260480",
  "text" : "apropos(\"lm\") will find all objects in your search path with \"lm\" in the name http:\/\/t.co\/DqXjju5bht #rstats",
  "id" : 580762465866260480,
  "created_at" : "2015-03-25 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Xt5b3CgDuY",
      "expanded_url" : "http:\/\/bit.ly\/1bk9Ma5",
      "display_url" : "bit.ly\/1bk9Ma5"
    } ]
  },
  "geo" : { },
  "id_str" : "580400147483492352",
  "text" : "is.na() tests for missing (NA) values. is.null() tests for NULL values. http:\/\/t.co\/Xt5b3CgDuY #rstats",
  "id" : 580400147483492352,
  "created_at" : "2015-03-24 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/CvC4jHb9w1",
      "expanded_url" : "http:\/\/bit.ly\/1ARqjIs",
      "display_url" : "bit.ly\/1ARqjIs"
    } ]
  },
  "geo" : { },
  "id_str" : "580037678999162880",
  "text" : "Use saveRDS(obj,\"myfile\") and readRDS(obj,\"myfile\") to save \/ read an R object to \/ from a file. http:\/\/t.co\/CvC4jHb9w1 #rstats",
  "id" : 580037678999162880,
  "created_at" : "2015-03-23 16:05:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/XcE5Sh99rA",
      "expanded_url" : "http:\/\/bit.ly\/H9C2Xp",
      "display_url" : "bit.ly\/H9C2Xp"
    } ]
  },
  "geo" : { },
  "id_str" : "578950521643515907",
  "text" : "How to calculate the date of Easter in R: library(timeDate); Easter(2015) #rstats http:\/\/t.co\/XcE5Sh99rA",
  "id" : 578950521643515907,
  "created_at" : "2015-03-20 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/2SFWyh91jj",
      "expanded_url" : "http:\/\/bit.ly\/RDGBB8",
      "display_url" : "bit.ly\/RDGBB8"
    } ]
  },
  "geo" : { },
  "id_str" : "578573000242544640",
  "text" : "Use model.matrix to convert factors into binary indicator columns in a matrix: http:\/\/t.co\/2SFWyh91jj #rstats",
  "id" : 578573000242544640,
  "created_at" : "2015-03-19 15:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/2OXkjNqeH0",
      "expanded_url" : "http:\/\/bit.ly\/1EHrlgs",
      "display_url" : "bit.ly\/1EHrlgs"
    } ]
  },
  "geo" : { },
  "id_str" : "578225760655294464",
  "text" : "Add a vertical or horizontal line to a base graphics plot with abline(v=x) or abline(h=y) http:\/\/t.co\/2OXkjNqeH0 #rstats",
  "id" : 578225760655294464,
  "created_at" : "2015-03-18 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/fpaFMZoZfI",
      "expanded_url" : "http:\/\/bit.ly\/18HfUHI",
      "display_url" : "bit.ly\/18HfUHI"
    } ]
  },
  "geo" : { },
  "id_str" : "577863367756521472",
  "text" : "In a \"for loop\": for(var in seq) expr, seq can be any vector. e.g. seq&lt;-c(100,12,1000)  http:\/\/t.co\/fpaFMZoZfI #rstats",
  "id" : 577863367756521472,
  "created_at" : "2015-03-17 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/AltLOChywI",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "577501012342251520",
  "text" : "To create the list of every possible combination of levels in multiple factors, use expand.grid: http:\/\/t.co\/AltLOChywI #rstats",
  "id" : 577501012342251520,
  "created_at" : "2015-03-16 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/OUM9gMPac7",
      "expanded_url" : "http:\/\/bit.ly\/1BfsUyv",
      "display_url" : "bit.ly\/1BfsUyv"
    } ]
  },
  "geo" : { },
  "id_str" : "576413808912130048",
  "text" : "Tomorrow, use package Rmpfr ro get pi to 3321 bits of precision (Pi &lt;- Const(\"pi\", 1000 *log2(10))) http:\/\/t.co\/OUM9gMPac7 #rstats",
  "id" : 576413808912130048,
  "created_at" : "2015-03-13 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/pgP0kNQmGp",
      "expanded_url" : "http:\/\/bit.ly\/N8snbL",
      "display_url" : "bit.ly\/N8snbL"
    } ]
  },
  "geo" : { },
  "id_str" : "576051419956019200",
  "text" : "You can use the readHTMLTable function to scrape data from a Web page: http:\/\/t.co\/pgP0kNQmGp #rstats",
  "id" : 576051419956019200,
  "created_at" : "2015-03-12 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/uiCjBXIi8Q",
      "expanded_url" : "http:\/\/bit.ly\/onqu7V",
      "display_url" : "bit.ly\/onqu7V"
    } ]
  },
  "geo" : { },
  "id_str" : "575689017527824384",
  "text" : "with(mydf, \u007B &lt;&lt;R code&gt;&gt; \u007D) is a cleaner way to use columns of a data frame in #rstats code. Examples: http:\/\/t.co\/uiCjBXIi8Q",
  "id" : 575689017527824384,
  "created_at" : "2015-03-11 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Ey7YTqgnCB",
      "expanded_url" : "http:\/\/bit.ly\/vJweOk",
      "display_url" : "bit.ly\/vJweOk"
    } ]
  },
  "geo" : { },
  "id_str" : "575326679041720320",
  "text" : "x %in% y returns a Boolean vector answering whether each component of x can be found in y: http:\/\/t.co\/Ey7YTqgnCB #rstats",
  "id" : 575326679041720320,
  "created_at" : "2015-03-10 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/vqBQB3OaRh",
      "expanded_url" : "http:\/\/bit.ly\/1MfaAdE",
      "display_url" : "bit.ly\/1MfaAdE"
    } ]
  },
  "geo" : { },
  "id_str" : "574964285648080896",
  "text" : "Use any() and all() \u007Bbase\u007D to test if any or all of a vector of logical conditions are true. http:\/\/t.co\/vqBQB3OaRh #stats",
  "id" : 574964285648080896,
  "created_at" : "2015-03-09 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ksg6wmZY52",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "573892195599646720",
  "text" : "Create a file called .Rprofile of commands to run each time R starts. Good for setting options, etc. Example: http:\/\/t.co\/ksg6wmZY52 #rstats",
  "id" : 573892195599646720,
  "created_at" : "2015-03-06 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/8HrLRIGKnL",
      "expanded_url" : "http:\/\/bit.ly\/GA096H",
      "display_url" : "bit.ly\/GA096H"
    } ]
  },
  "geo" : { },
  "id_str" : "573529879066583040",
  "text" : "See demo(plotmath) for examples of mathematics (exponents, greek symbols etc) in #rstats plots http:\/\/t.co\/8HrLRIGKnL",
  "id" : 573529879066583040,
  "created_at" : "2015-03-05 17:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573167440982634496",
  "text" : "To get help on some R operators, use quotes, e.g. ?\"%*%, ?\"if\", ?\"!\" etc. If in doubt, add quotes. #rstats",
  "id" : 573167440982634496,
  "created_at" : "2015-03-04 17:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LZKoKygLJ1",
      "expanded_url" : "http:\/\/bit.ly\/1rx2jYu",
      "display_url" : "bit.ly\/1rx2jYu"
    } ]
  },
  "geo" : { },
  "id_str" : "572805066475884544",
  "text" : "The number of bits in the mantissa of R double precision numbers: .Machine$double.digits (53) http:\/\/t.co\/LZKoKygLJ1 #rstats",
  "id" : 572805066475884544,
  "created_at" : "2015-03-03 17:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/OwLDIAFFwO",
      "expanded_url" : "http:\/\/bit.ly\/1G1jR8E",
      "display_url" : "bit.ly\/1G1jR8E"
    } ]
  },
  "geo" : { },
  "id_str" : "572442619659354112",
  "text" : "Determine whether two integers m and n are relatively prime or coprime with coprime(m,n) #rstats http:\/\/t.co\/OwLDIAFFwO",
  "id" : 572442619659354112,
  "created_at" : "2015-03-02 17:05:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]