Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/y0rMygRHM0",
      "expanded_url" : "http:\/\/bit.ly\/uf2eFb",
      "display_url" : "bit.ly\/uf2eFb"
    } ]
  },
  "geo" : { },
  "id_str" : "406469337114247168",
  "text" : "There is a Wikipedia page for R at http:\/\/t.co\/y0rMygRHM0 #rstats",
  "id" : 406469337114247168,
  "created_at" : "2013-11-29 17:06:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/9CpvckT0EG",
      "expanded_url" : "http:\/\/bit.ly\/PF2nXj",
      "display_url" : "bit.ly\/PF2nXj"
    } ]
  },
  "geo" : { },
  "id_str" : "406106981666394112",
  "text" : "Print a human-readable version of a matrix: write.table(format(X), row.names=F, col.names=F, quote=F) #rstats http:\/\/t.co\/9CpvckT0EG",
  "id" : 406106981666394112,
  "created_at" : "2013-11-28 17:07:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/z28q6A3pk9",
      "expanded_url" : "http:\/\/bit.ly\/17B9nuP",
      "display_url" : "bit.ly\/17B9nuP"
    } ]
  },
  "geo" : { },
  "id_str" : "405744628512874496",
  "text" : "Fit a Bayesian regression model: mod &lt;- MCMCregress(formula,data) http:\/\/t.co\/z28q6A3pk9 #rstats",
  "id" : 405744628512874496,
  "created_at" : "2013-11-27 17:07:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/yItAVeb8hU",
      "expanded_url" : "http:\/\/bit.ly\/IkF5m6",
      "display_url" : "bit.ly\/IkF5m6"
    } ]
  },
  "geo" : { },
  "id_str" : "405382307559002112",
  "text" : "Get information about your R session: sessionInfo() http:\/\/t.co\/yItAVeb8hU #rstats",
  "id" : 405382307559002112,
  "created_at" : "2013-11-26 17:07:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/mtC0Kq6E2v",
      "expanded_url" : "http:\/\/bit.ly\/KpZ9SP",
      "display_url" : "bit.ly\/KpZ9SP"
    } ]
  },
  "geo" : { },
  "id_str" : "405019656681164800",
  "text" : "For a comparison of lapply(), Map() and do.call(): http:\/\/t.co\/mtC0Kq6E2v #rstats",
  "id" : 405019656681164800,
  "created_at" : "2013-11-25 17:06:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/YC9SzZyee0",
      "expanded_url" : "http:\/\/bit.ly\/uG6J1C",
      "display_url" : "bit.ly\/uG6J1C"
    } ]
  },
  "geo" : { },
  "id_str" : "403932810387681282",
  "text" : "The holiday function in the timeDate package looks up holiday dates, e.g. holiday(2012,\"USThanksgivingDay\") http:\/\/t.co\/YC9SzZyee0 #rstats",
  "id" : 403932810387681282,
  "created_at" : "2013-11-22 17:07:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/98VOviIVct",
      "expanded_url" : "http:\/\/bit.ly\/vkHZxy",
      "display_url" : "bit.ly\/vkHZxy"
    } ]
  },
  "geo" : { },
  "id_str" : "403570211779264512",
  "text" : "The tryCatch function lets an R programmer respond to an error without crashing back to the interpreter: http:\/\/t.co\/98VOviIVct #rstats",
  "id" : 403570211779264512,
  "created_at" : "2013-11-21 17:06:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iBartomeus",
      "screen_name" : "ibartomeus",
      "indices" : [ 121, 132 ],
      "id_str" : "14226594",
      "id" : 14226594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Nog5kol4e1",
      "expanded_url" : "http:\/\/bit.ly\/QTueDq",
      "display_url" : "bit.ly\/QTueDq"
    } ]
  },
  "geo" : { },
  "id_str" : "403207989634805760",
  "text" : "Select only rows of a data frame without any missing values: df[complete.cases(df),] #rstats http:\/\/t.co\/Nog5kol4e1 (via @ibartomeus)",
  "id" : 403207989634805760,
  "created_at" : "2013-11-20 17:07:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/UtD8fBhZoz",
      "expanded_url" : "http:\/\/bit.ly\/17x6MPn",
      "display_url" : "bit.ly\/17x6MPn"
    } ]
  },
  "geo" : { },
  "id_str" : "402845496987107328",
  "text" : "optim() in the stats package is a general purpose optimization function #rstats http:\/\/t.co\/UtD8fBhZoz",
  "id" : 402845496987107328,
  "created_at" : "2013-11-19 17:07:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/J8BvyBZvjc",
      "expanded_url" : "http:\/\/bit.ly\/17zAXL5",
      "display_url" : "bit.ly\/17zAXL5"
    } ]
  },
  "geo" : { },
  "id_str" : "402482999608238080",
  "text" : "Look at options under help(par) to customize plot() #rstats http:\/\/t.co\/J8BvyBZvjc",
  "id" : 402482999608238080,
  "created_at" : "2013-11-18 17:06:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/eAdojS8HgG",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "401396330473730048",
  "text" : "NA's have special handling for logical comparisons. NA &amp; FALSE is always FALSE, NA | TRUE is TRUE. http:\/\/t.co\/eAdojS8HgG #rstats",
  "id" : 401396330473730048,
  "created_at" : "2013-11-15 17:08:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/4QAszZwO8M",
      "expanded_url" : "http:\/\/bit.ly\/rfMShP",
      "display_url" : "bit.ly\/rfMShP"
    } ]
  },
  "geo" : { },
  "id_str" : "401033899058688000",
  "text" : "For reproducible simulations, use set.seed to start the random number sequence from a fixed point http:\/\/t.co\/4QAszZwO8M #rstats",
  "id" : 401033899058688000,
  "created_at" : "2013-11-14 17:08:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/RDFSsjp35Q",
      "expanded_url" : "http:\/\/bit.ly\/1awt2J7",
      "display_url" : "bit.ly\/1awt2J7"
    } ]
  },
  "geo" : { },
  "id_str" : "400671736313937920",
  "text" : "Calculate the differences between every nth value of a vector x with diff(x,n) #rstats http:\/\/t.co\/RDFSsjp35Q",
  "id" : 400671736313937920,
  "created_at" : "2013-11-13 17:09:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/LZ29DawO0b",
      "expanded_url" : "http:\/\/bit.ly\/1hTVsEf",
      "display_url" : "bit.ly\/1hTVsEf"
    } ]
  },
  "geo" : { },
  "id_str" : "400309034815094784",
  "text" : "Find the amount of memory allocated to R with memory.limit() #rstats http:\/\/t.co\/LZ29DawO0b",
  "id" : 400309034815094784,
  "created_at" : "2013-11-12 17:08:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/2CcMXv53et",
      "expanded_url" : "http:\/\/overapi.com\/r\/",
      "display_url" : "overapi.com\/r\/"
    } ]
  },
  "geo" : { },
  "id_str" : "399946674472513536",
  "text" : "#rstats A collection R crib sheets and popular commands http:\/\/t.co\/2CcMXv53et",
  "id" : 399946674472513536,
  "created_at" : "2013-11-11 17:08:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/5PNbQGl0xO",
      "expanded_url" : "http:\/\/bit.ly\/1h71inM",
      "display_url" : "bit.ly\/1h71inM"
    } ]
  },
  "geo" : { },
  "id_str" : "398859585114886144",
  "text" : "#rstats Back up your work frequently by running save.image() from the console http:\/\/t.co\/5PNbQGl0xO",
  "id" : 398859585114886144,
  "created_at" : "2013-11-08 17:08:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/PGqo2tpjuC",
      "expanded_url" : "http:\/\/bit.ly\/s3u5Xe",
      "display_url" : "bit.ly\/s3u5Xe"
    } ]
  },
  "geo" : { },
  "id_str" : "398497825803476992",
  "text" : "is.finite(x) is a useful test for \"proper\" data: it returns FALSE for NA, NaN and Inf: http:\/\/t.co\/PGqo2tpjuC #rstats",
  "id" : 398497825803476992,
  "created_at" : "2013-11-07 17:11:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/1nU5lTlnsv",
      "expanded_url" : "http:\/\/bit.ly\/tmxyn2",
      "display_url" : "bit.ly\/tmxyn2"
    } ]
  },
  "geo" : { },
  "id_str" : "398089001128972288",
  "text" : "Search the R mailing list archives: http:\/\/t.co\/1nU5lTlnsv #rstats",
  "id" : 398089001128972288,
  "created_at" : "2013-11-06 14:06:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "R",
      "indices" : [ 50, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/fKybMHU80S",
      "expanded_url" : "http:\/\/bit.ly\/1aA0XGH",
      "display_url" : "bit.ly\/1aA0XGH"
    } ]
  },
  "geo" : { },
  "id_str" : "397771859422609408",
  "text" : "Is your data managed well? Try Managing Data with #R http:\/\/t.co\/fKybMHU80S",
  "id" : 397771859422609408,
  "created_at" : "2013-11-05 17:06:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/IOsx5DrXQ7",
      "expanded_url" : "http:\/\/bit.ly\/tagjby",
      "display_url" : "bit.ly\/tagjby"
    } ]
  },
  "geo" : { },
  "id_str" : "397756863561097216",
  "text" : "A collection of 20+ free R cheat sheets: http:\/\/t.co\/IOsx5DrXQ7 #rstats",
  "id" : 397756863561097216,
  "created_at" : "2013-11-05 16:06:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/DnmNUJZ6vF",
      "expanded_url" : "http:\/\/bit.ly\/1cv5USI",
      "display_url" : "bit.ly\/1cv5USI"
    } ]
  },
  "geo" : { },
  "id_str" : "397409570035105792",
  "text" : "#rstats Get eigenvalues and eigenvectors in R with eigen(matrix) http:\/\/t.co\/DnmNUJZ6vF",
  "id" : 397409570035105792,
  "created_at" : "2013-11-04 17:06:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/gkqxsIbtEu",
      "expanded_url" : "http:\/\/bit.ly\/17pf8vS",
      "display_url" : "bit.ly\/17pf8vS"
    } ]
  },
  "geo" : { },
  "id_str" : "396307448480661504",
  "text" : "Plot sample with error bars and color coded legend http:\/\/t.co\/gkqxsIbtEu #rstats",
  "id" : 396307448480661504,
  "created_at" : "2013-11-01 16:07:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]