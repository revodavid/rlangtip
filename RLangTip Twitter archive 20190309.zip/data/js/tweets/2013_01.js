Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/wQQIGPir",
      "expanded_url" : "http:\/\/bit.ly\/oIZqS4",
      "display_url" : "bit.ly\/oIZqS4"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/2W30W5xa",
      "expanded_url" : "http:\/\/bit.ly\/qVaFKO",
      "display_url" : "bit.ly\/qVaFKO"
    } ]
  },
  "geo" : { },
  "id_str" : "297029619213811713",
  "text" : "Use sink http:\/\/t.co\/wQQIGPir to direct R's output to a file, or use capture.output http:\/\/t.co\/2W30W5xa to save it in an object #rstats",
  "id" : 297029619213811713,
  "created_at" : "2013-01-31 17:12:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/GUhtjPr6",
      "expanded_url" : "http:\/\/bit.ly\/qqUXhc",
      "display_url" : "bit.ly\/qqUXhc"
    } ]
  },
  "geo" : { },
  "id_str" : "296669781510193152",
  "text" : "List of R functions and packages to support reproducible research: http:\/\/t.co\/GUhtjPr6 #rstats",
  "id" : 296669781510193152,
  "created_at" : "2013-01-30 17:22:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/wXKlx4LD",
      "expanded_url" : "http:\/\/bit.ly\/nLuDqT",
      "display_url" : "bit.ly\/nLuDqT"
    } ]
  },
  "geo" : { },
  "id_str" : "296325393445695489",
  "text" : "Download and install the latest versions of your R packages with the updates.packages() function: http:\/\/t.co\/wXKlx4LD #rstats",
  "id" : 296325393445695489,
  "created_at" : "2013-01-29 18:34:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/SYnHD3RL",
      "expanded_url" : "http:\/\/bit.ly\/10CB8vJ",
      "display_url" : "bit.ly\/10CB8vJ"
    } ]
  },
  "geo" : { },
  "id_str" : "295946078761652224",
  "text" : "The corner function in the BurnsMisc package is a convenient way to view a small part of a data frame http:\/\/t.co\/SYnHD3RL #rstats",
  "id" : 295946078761652224,
  "created_at" : "2013-01-28 17:26:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Chappel",
      "screen_name" : "kbethany",
      "indices" : [ 47, 56 ],
      "id_str" : "17771293",
      "id" : 17771293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/YCRZujJT",
      "expanded_url" : "http:\/\/bit.ly\/UnI6Fx",
      "display_url" : "bit.ly\/UnI6Fx"
    } ]
  },
  "geo" : { },
  "id_str" : "294852342543704064",
  "text" : "Free text on regression and ANOVA with R: (via @kbethany) http:\/\/t.co\/YCRZujJT #rstats",
  "id" : 294852342543704064,
  "created_at" : "2013-01-25 17:00:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slawa Rokicki",
      "screen_name" : "slawarokicki",
      "indices" : [ 69, 82 ],
      "id_str" : "926807978",
      "id" : 926807978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/BcYFVN1Z",
      "expanded_url" : "http:\/\/bit.ly\/VLGCFf",
      "display_url" : "bit.ly\/VLGCFf"
    } ]
  },
  "geo" : { },
  "id_str" : "294473453631840256",
  "text" : "Making sense of R's error messages when working with data frames (by @slawarokicki): http:\/\/t.co\/BcYFVN1Z #rstats",
  "id" : 294473453631840256,
  "created_at" : "2013-01-24 15:55:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thanos Papaoikonomou",
      "screen_name" : "erwtokritos",
      "indices" : [ 56, 68 ],
      "id_str" : "20789946",
      "id" : 20789946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/Jffdjaz6",
      "expanded_url" : "http:\/\/bit.ly\/VLxPTH",
      "display_url" : "bit.ly\/VLxPTH"
    } ]
  },
  "geo" : { },
  "id_str" : "294130299791605760",
  "text" : "Tips on managing memory in R: http:\/\/t.co\/Jffdjaz6 (via @erwtokritos) #rstats",
  "id" : 294130299791605760,
  "created_at" : "2013-01-23 17:11:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/hanHZqvs",
      "expanded_url" : "http:\/\/bit.ly\/o0z4Mh",
      "display_url" : "bit.ly\/o0z4Mh"
    } ]
  },
  "geo" : { },
  "id_str" : "293771724187652096",
  "text" : "The standard random number generator in R is the Mersenne Twister, but other RNGs are available: http:\/\/t.co\/hanHZqvs #rstats",
  "id" : 293771724187652096,
  "created_at" : "2013-01-22 17:26:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/A9W0dWyK",
      "expanded_url" : "http:\/\/bit.ly\/pbhQWd",
      "display_url" : "bit.ly\/pbhQWd"
    } ]
  },
  "geo" : { },
  "id_str" : "293391921139838976",
  "text" : "For tables in R like those from SAS's PROC FREQ, use CrossTable from the gmodels package: http:\/\/t.co\/A9W0dWyK #rstats",
  "id" : 293391921139838976,
  "created_at" : "2013-01-21 16:17:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Fischetti",
      "screen_name" : "tonyfischetti",
      "indices" : [ 123, 137 ],
      "id_str" : "99390322",
      "id" : 99390322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/HikyOYY2",
      "expanded_url" : "http:\/\/bit.ly\/W0zvcd",
      "display_url" : "bit.ly\/W0zvcd"
    } ]
  },
  "geo" : { },
  "id_str" : "292331030768132097",
  "text" : "Convert addresses to latitude\/longitude and plot them on a map with the geoCode package: http:\/\/t.co\/HikyOYY2 #rstats (via @tonyfischetti)",
  "id" : 292331030768132097,
  "created_at" : "2013-01-18 18:02:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAS",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "SPSS",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/W3vg16jO",
      "expanded_url" : "http:\/\/bit.ly\/11BYwhL",
      "display_url" : "bit.ly\/11BYwhL"
    } ]
  },
  "geo" : { },
  "id_str" : "291951171441160192",
  "text" : "R scripts for managing and processing data, with equivalent code in #SAS and #SPSS: http:\/\/t.co\/W3vg16jO #rstats",
  "id" : 291951171441160192,
  "created_at" : "2013-01-17 16:52:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thanos Papaoikonomou",
      "screen_name" : "erwtokritos",
      "indices" : [ 106, 118 ],
      "id_str" : "20789946",
      "id" : 20789946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/74vviBo7",
      "expanded_url" : "http:\/\/bit.ly\/UpZfgq",
      "display_url" : "bit.ly\/UpZfgq"
    } ]
  },
  "geo" : { },
  "id_str" : "291591463849050113",
  "text" : "Explanations of lexical scope, function closures and environments in R: http:\/\/t.co\/74vviBo7 #rstats (via @erwtokritos)",
  "id" : 291591463849050113,
  "created_at" : "2013-01-16 17:03:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/6FY3TYuf",
      "expanded_url" : "http:\/\/bit.ly\/Vg7rAZ",
      "display_url" : "bit.ly\/Vg7rAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "291235648004833281",
  "text" : "Test for two vectors being the same: if(identical(x,y)) \u007B ... \u007D. Also works for data frames, lists, etc. #rstats http:\/\/t.co\/6FY3TYuf",
  "id" : 291235648004833281,
  "created_at" : "2013-01-15 17:29:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/lnS7Admz",
      "expanded_url" : "http:\/\/bit.ly\/pOBXUl",
      "display_url" : "bit.ly\/pOBXUl"
    } ]
  },
  "geo" : { },
  "id_str" : "290869519184969728",
  "text" : "Many #rstats packages have \"\"vignette\"\" examples: use vignette() to see which installed packages have them: http:\/\/t.co\/lnS7Admz",
  "id" : 290869519184969728,
  "created_at" : "2013-01-14 17:14:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/zdnUExCy",
      "expanded_url" : "http:\/\/bit.ly\/r4KKw2",
      "display_url" : "bit.ly\/r4KKw2"
    } ]
  },
  "geo" : { },
  "id_str" : "289781069740392448",
  "text" : "List of R functions and packages related to Statistics for the Social Sciences: http:\/\/t.co\/zdnUExCy #rstats",
  "id" : 289781069740392448,
  "created_at" : "2013-01-11 17:09:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/JP8bM0wP",
      "expanded_url" : "http:\/\/bit.ly\/xbz2dH",
      "display_url" : "bit.ly\/xbz2dH"
    } ]
  },
  "geo" : { },
  "id_str" : "289413264734048256",
  "text" : "Need to put R output in a book or paper? Use options(width=60) to limit output to a narrow column. http:\/\/t.co\/JP8bM0wP #rstats",
  "id" : 289413264734048256,
  "created_at" : "2013-01-10 16:47:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/N7folntS",
      "expanded_url" : "http:\/\/bit.ly\/U4vAte",
      "display_url" : "bit.ly\/U4vAte"
    } ]
  },
  "geo" : { },
  "id_str" : "289048644664041472",
  "text" : "cummax(x) returns a vector whose ith element is the maximum of the first i elements of x. cf cumsum, cumprod #rstats http:\/\/t.co\/N7folntS",
  "id" : 289048644664041472,
  "created_at" : "2013-01-09 16:39:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Evans",
      "screen_name" : "ThomasEvans",
      "indices" : [ 86, 98 ],
      "id_str" : "16922298",
      "id" : 16922298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/sIRwS7t1",
      "expanded_url" : "http:\/\/bit.ly\/VGhPTg",
      "display_url" : "bit.ly\/VGhPTg"
    } ]
  },
  "geo" : { },
  "id_str" : "288705671636078593",
  "text" : "When to use: apply vs lappy vs sapply vs mapply ... http:\/\/t.co\/sIRwS7t1 #rstats (via @ThomasEvans)",
  "id" : 288705671636078593,
  "created_at" : "2013-01-08 17:56:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/xB3aujnV",
      "expanded_url" : "http:\/\/bit.ly\/zIdY6J",
      "display_url" : "bit.ly\/zIdY6J"
    } ]
  },
  "geo" : { },
  "id_str" : "288317931425779713",
  "text" : "Use the lubridate package to easily manipulate dates, times and time zones: http:\/\/t.co\/xB3aujnV #rstats (via @ranmath_vaidya)",
  "id" : 288317931425779713,
  "created_at" : "2013-01-07 16:15:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/xaj8NouG",
      "expanded_url" : "http:\/\/bit.ly\/133L4T3",
      "display_url" : "bit.ly\/133L4T3"
    } ]
  },
  "geo" : { },
  "id_str" : "287242230538833921",
  "text" : "Learn R through baseball with sab-R-metrics: http:\/\/t.co\/xaj8NouG #rstats",
  "id" : 287242230538833921,
  "created_at" : "2013-01-04 17:00:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/e2JXF6EC",
      "expanded_url" : "http:\/\/bit.ly\/ugAi3M",
      "display_url" : "bit.ly\/ugAi3M"
    } ]
  },
  "geo" : { },
  "id_str" : "286885305401880576",
  "text" : "Sync Rprofile across multiple machines with Dropbox: http:\/\/t.co\/e2JXF6EC #rstats",
  "id" : 286885305401880576,
  "created_at" : "2013-01-03 17:22:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 61, 70 ],
      "id_str" : "352053266",
      "id" : 352053266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/uQXiSF6W",
      "expanded_url" : "http:\/\/bit.ly\/THqRxl",
      "display_url" : "bit.ly\/THqRxl"
    } ]
  },
  "geo" : { },
  "id_str" : "286519477426872320",
  "text" : "Free course on Computing for Data Analysis with #rstats from @coursera starts today: http:\/\/t.co\/uQXiSF6W",
  "id" : 286519477426872320,
  "created_at" : "2013-01-02 17:09:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]