Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/B8T2xMzKsB",
      "expanded_url" : "http:\/\/bit.ly\/IqTdbe",
      "display_url" : "bit.ly\/IqTdbe"
    } ]
  },
  "geo" : { },
  "id_str" : "726080040811810816",
  "text" : "List the row\/col indices of matrix x, from largest to smallest: cbind(row(x)[order(-x)],col(x)[order(-x)]) #rstats https:\/\/t.co\/B8T2xMzKsB",
  "id" : 726080040811810816,
  "created_at" : "2016-04-29 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Evans",
      "screen_name" : "ThomasEvans",
      "indices" : [ 89, 101 ],
      "id_str" : "16922298",
      "id" : 16922298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/a0syqlJ2nh",
      "expanded_url" : "http:\/\/bit.ly\/VGhPTg",
      "display_url" : "bit.ly\/VGhPTg"
    } ]
  },
  "geo" : { },
  "id_str" : "725717657765421056",
  "text" : "When to use: apply vs lappy vs sapply vs mapply ... https:\/\/t.co\/a0syqlJ2nh #rstats (via @ThomasEvans)",
  "id" : 725717657765421056,
  "created_at" : "2016-04-28 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PqMTA9jPby",
      "expanded_url" : "http:\/\/bit.ly\/U4vAte",
      "display_url" : "bit.ly\/U4vAte"
    } ]
  },
  "geo" : { },
  "id_str" : "725355288900022273",
  "text" : "cummax(x) returns a vector whose ith element is the maximum of the first i elements of x. cf cumsum, cumprod #rstats https:\/\/t.co\/PqMTA9jPby",
  "id" : 725355288900022273,
  "created_at" : "2016-04-27 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/SiXzP9Azo1",
      "expanded_url" : "http:\/\/bit.ly\/1MO02a4",
      "display_url" : "bit.ly\/1MO02a4"
    }, {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/XuhovwOfug",
      "expanded_url" : "http:\/\/bit.ly\/1n6iwii",
      "display_url" : "bit.ly\/1n6iwii"
    } ]
  },
  "geo" : { },
  "id_str" : "724992871443619840",
  "text" : "Looking for health data? Try WHO package https:\/\/t.co\/SiXzP9Azo1 for World Health Organization data https:\/\/t.co\/XuhovwOfug #rstats",
  "id" : 724992871443619840,
  "created_at" : "2016-04-26 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/nV8n6ERXpB",
      "expanded_url" : "http:\/\/bit.ly\/1MNZfGe",
      "display_url" : "bit.ly\/1MNZfGe"
    } ]
  },
  "geo" : { },
  "id_str" : "724630462552018944",
  "text" : "New to R? install.packages(\"Rtutor\"); library(RtutoR); launch_tutorial() for a basic R tutorial https:\/\/t.co\/nV8n6ERXpB #rstats",
  "id" : 724630462552018944,
  "created_at" : "2016-04-25 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/npd5TM91kN",
      "expanded_url" : "http:\/\/bit.ly\/NcjwTL",
      "display_url" : "bit.ly\/NcjwTL"
    } ]
  },
  "geo" : { },
  "id_str" : "723543338016751616",
  "text" : "How to include non-standard fonts (Chinese, Cyrillic, CM Math etc) in PDF\/Postscript charts: https:\/\/t.co\/npd5TM91kN (p41) #rstats",
  "id" : 723543338016751616,
  "created_at" : "2016-04-22 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/MsJLmezUOv",
      "expanded_url" : "http:\/\/bit.ly\/xbz2dH",
      "display_url" : "bit.ly\/xbz2dH"
    } ]
  },
  "geo" : { },
  "id_str" : "723180927707418626",
  "text" : "Need to put R output in a book or paper? Use options(width=60) to limit output to a narrow column. https:\/\/t.co\/MsJLmezUOv #rstats",
  "id" : 723180927707418626,
  "created_at" : "2016-04-21 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/zOWRnaqjuC",
      "expanded_url" : "http:\/\/bit.ly\/rfMShP",
      "display_url" : "bit.ly\/rfMShP"
    } ]
  },
  "geo" : { },
  "id_str" : "722818555025211392",
  "text" : "For reproducible simulations, use set.seed to start the random number sequence from a fixed point https:\/\/t.co\/zOWRnaqjuC #rstats",
  "id" : 722818555025211392,
  "created_at" : "2016-04-20 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/72EUHSYqhC",
      "expanded_url" : "http:\/\/bit.ly\/1TWY1tp",
      "display_url" : "bit.ly\/1TWY1tp"
    } ]
  },
  "geo" : { },
  "id_str" : "722456197857677312",
  "text" : "A stellar guide to mathematical annotation in R: https:\/\/t.co\/72EUHSYqhC #rstats",
  "id" : 722456197857677312,
  "created_at" : "2016-04-19 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/tZfc0LeCum",
      "expanded_url" : "http:\/\/bit.ly\/1Ne3wCw",
      "display_url" : "bit.ly\/1Ne3wCw"
    } ]
  },
  "geo" : { },
  "id_str" : "722093744850341888",
  "text" : "Whats the difference between :: and ::: ?  https:\/\/t.co\/tZfc0LeCum #rstats",
  "id" : 722093744850341888,
  "created_at" : "2016-04-18 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/mpfS1zxhez",
      "expanded_url" : "http:\/\/bit.ly\/1SWGhvV",
      "display_url" : "bit.ly\/1SWGhvV"
    } ]
  },
  "geo" : { },
  "id_str" : "721006614963167232",
  "text" : "Cheer yourself up with R: getXKCD(which=\"random\",html=TRUE) https:\/\/t.co\/mpfS1zxhez #rstats",
  "id" : 721006614963167232,
  "created_at" : "2016-04-15 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/f02MDJFXAi",
      "expanded_url" : "http:\/\/bit.ly\/189ffrl",
      "display_url" : "bit.ly\/189ffrl"
    } ]
  },
  "geo" : { },
  "id_str" : "720644223284998144",
  "text" : "#rstats Find your R home directory from the command line with Sys.getenv(\"R_Home\") https:\/\/t.co\/f02MDJFXAi",
  "id" : 720644223284998144,
  "created_at" : "2016-04-14 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portfolio Probe",
      "screen_name" : "portfolioprobe",
      "indices" : [ 67, 82 ],
      "id_str" : "177229649",
      "id" : 177229649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/P2MEx27j5q",
      "expanded_url" : "http:\/\/bit.ly\/N8U7HQ",
      "display_url" : "bit.ly\/N8U7HQ"
    } ]
  },
  "geo" : { },
  "id_str" : "720281827827552256",
  "text" : "The difference between the order and rank functions in #rstats (by @portfolioprobe): https:\/\/t.co\/P2MEx27j5q",
  "id" : 720281827827552256,
  "created_at" : "2016-04-13 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/5zOCaZg7da",
      "expanded_url" : "http:\/\/bit.ly\/1S2V5sE",
      "display_url" : "bit.ly\/1S2V5sE"
    } ]
  },
  "geo" : { },
  "id_str" : "719919429115637760",
  "text" : "dir.create(\"dir_name\") will create a directory in your working directory https:\/\/t.co\/5zOCaZg7da #rstats",
  "id" : 719919429115637760,
  "created_at" : "2016-04-12 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/3xmZS4XMQg",
      "expanded_url" : "http:\/\/as.Date",
      "display_url" : "as.Date"
    }, {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/CTBzSdx4XX",
      "expanded_url" : "http:\/\/bit.ly\/1in7U1f",
      "display_url" : "bit.ly\/1in7U1f"
    } ]
  },
  "geo" : { },
  "id_str" : "719557027077427202",
  "text" : "Use https:\/\/t.co\/3xmZS4XMQg( ) to convert strings to dates #rstats https:\/\/t.co\/CTBzSdx4XX",
  "id" : 719557027077427202,
  "created_at" : "2016-04-11 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Q1ciJ2IRdN",
      "expanded_url" : "http:\/\/bit.ly\/19AH5ne",
      "display_url" : "bit.ly\/19AH5ne"
    } ]
  },
  "geo" : { },
  "id_str" : "718469904328957952",
  "text" : "Use stack() to stack the columns of a data frame into a single column #rstats https:\/\/t.co\/Q1ciJ2IRdN",
  "id" : 718469904328957952,
  "created_at" : "2016-04-08 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/1jABYwVyHU",
      "expanded_url" : "http:\/\/bit.ly\/TCNTZ4",
      "display_url" : "bit.ly\/TCNTZ4"
    } ]
  },
  "geo" : { },
  "id_str" : "718107509144350721",
  "text" : "Details of how method dispatch works for objects in R: https:\/\/t.co\/1jABYwVyHU #rstats",
  "id" : 718107509144350721,
  "created_at" : "2016-04-07 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thanos Papaoikonomou",
      "screen_name" : "erwtokritos",
      "indices" : [ 109, 121 ],
      "id_str" : "20789946",
      "id" : 20789946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Ol6QVzePVN",
      "expanded_url" : "http:\/\/bit.ly\/UpZfgq",
      "display_url" : "bit.ly\/UpZfgq"
    } ]
  },
  "geo" : { },
  "id_str" : "717745121853308929",
  "text" : "Explanations of lexical scope, function closures and environments in R: https:\/\/t.co\/Ol6QVzePVN #rstats (via @erwtokritos)",
  "id" : 717745121853308929,
  "created_at" : "2016-04-06 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/j96TMQKHIB",
      "expanded_url" : "http:\/\/bit.ly\/1PKUHdW",
      "display_url" : "bit.ly\/1PKUHdW"
    } ]
  },
  "geo" : { },
  "id_str" : "717382717105651713",
  "text" : "Use rug() in \u007Bgraphics\u007D to add a rug representation (1-d plot) of the data to a plot https:\/\/t.co\/j96TMQKHIB #rstats",
  "id" : 717382717105651713,
  "created_at" : "2016-04-05 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Ptt6fDCtfk",
      "expanded_url" : "http:\/\/bit.ly\/1Sswx9T",
      "display_url" : "bit.ly\/1Sswx9T"
    } ]
  },
  "geo" : { },
  "id_str" : "717020329642749952",
  "text" : "Fit a Tweedie GLM with tweedie() in \u007Bstatmod\u007D https:\/\/t.co\/Ptt6fDCtfk  #rstats",
  "id" : 717020329642749952,
  "created_at" : "2016-04-04 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/QpweD9bHDk",
      "expanded_url" : "http:\/\/bit.ly\/S4Q0P6",
      "display_url" : "bit.ly\/S4Q0P6"
    } ]
  },
  "geo" : { },
  "id_str" : "715933198539218944",
  "text" : "Use read.csv2 to import ASCII data from countries that use the comma as a decimal point #rstats https:\/\/t.co\/QpweD9bHDk",
  "id" : 715933198539218944,
  "created_at" : "2016-04-01 16:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]