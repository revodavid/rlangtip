Grailbird.data.tweets_2018_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/rvR9E6nlYv",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/forecast\/versions\/8.3\/topics\/auto.arima",
      "display_url" : "rdocumentation.org\/packages\/forec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1002218145719844865",
  "text" : "auto.arima() \u007Bforecast\u007D will return the best ARIMA fit to a time series using the AIC, AICc or BIC criterion https:\/\/t.co\/rvR9E6nlYv #rstats",
  "id" : 1002218145719844865,
  "created_at" : "2018-05-31 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/1OBV1OiXgR",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/NumericConstants",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1001901058266841088",
  "text" : "You can use hexadecimal numbers in R by starting with 0x, eg 0xDEADBEEF https:\/\/t.co\/1OBV1OiXgR #rstats",
  "id" : 1001901058266841088,
  "created_at" : "2018-05-30 19:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/dxBYYeAeA8",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/unlist",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1001493371406315527",
  "text" : "Use unlist() to flatten out a list of lists into a single vector: https:\/\/t.co\/dxBYYeAeA8 #rstats",
  "id" : 1001493371406315527,
  "created_at" : "2018-05-29 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/U9DGcrtjjY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/grDevices\/versions\/3.5.0\/topics\/plotmath",
      "display_url" : "rdocumentation.org\/packages\/grDev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1001130985784672258",
  "text" : "Syntax for mathematical annotation in R: https:\/\/t.co\/U9DGcrtjjY #rstats",
  "id" : 1001130985784672258,
  "created_at" : "2018-05-28 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/ErFgWMBrgc",
      "expanded_url" : "http:\/\/Sys.Date",
      "display_url" : "Sys.Date"
    }, {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/5OCKjA9dhh",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/Sys.time",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1000043821575692290",
  "text" : "Get the current date with https:\/\/t.co\/ErFgWMBrgc() and the time with Sys.time() #rstats https:\/\/t.co\/5OCKjA9dhh",
  "id" : 1000043821575692290,
  "created_at" : "2018-05-25 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/saIRT8ihiZ",
      "expanded_url" : "https:\/\/mran.microsoft.com\/web\/packages\/AzureML\/vignettes\/getting_started.html",
      "display_url" : "mran.microsoft.com\/web\/packages\/A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "999681438055153664",
  "text" : "Publish R functions to the cloud as a Web service with the AzureML package https:\/\/t.co\/saIRT8ihiZ #rstats",
  "id" : 999681438055153664,
  "created_at" : "2018-05-24 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/jxcKF2OgtL",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/SASxport\/",
      "display_url" : "mran.microsoft.com\/package\/SASxpo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "999319041222234112",
  "text" : "Use the SASxport package to read\/write data in the XPORT file format (req by FDA for clinical submissions) https:\/\/t.co\/jxcKF2OgtL #rstats",
  "id" : 999319041222234112,
  "created_at" : "2018-05-23 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 72, 81 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fHUO6FUGRo",
      "expanded_url" : "https:\/\/ropensci.org\/packages",
      "display_url" : "ropensci.org\/packages"
    } ]
  },
  "geo" : { },
  "id_str" : "998956655856439296",
  "text" : "List of R packages for data access and scientific analysis developed by @ROpenSci https:\/\/t.co\/fHUO6FUGRo #rstats",
  "id" : 998956655856439296,
  "created_at" : "2018-05-22 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/HQyEbefQvH",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/FAQ\/R-FAQ.html#What-are-valid-names_003f",
      "display_url" : "cran.r-project.org\/doc\/FAQ\/R-FAQ.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "998594265918812160",
  "text" : "Object names in R usually contain letters, numbers, periods and underscores, but other names are possible: https:\/\/t.co\/HQyEbefQvH #rstats",
  "id" : 998594265918812160,
  "created_at" : "2018-05-21 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/K7cWMaeExh",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/list.files",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "997507103693594624",
  "text" : "Find out what files are in your working directory with dir(), also list.files() https:\/\/t.co\/K7cWMaeExh #rstats",
  "id" : 997507103693594624,
  "created_at" : "2018-05-18 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ULjQDWrmob",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/libPaths",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "997144713911308288",
  "text" : "You can create a local library by setting R_LIBS_USER in your .Renviron configuration file https:\/\/t.co\/ULjQDWrmob #rstats",
  "id" : 997144713911308288,
  "created_at" : "2018-05-17 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/1K5ahhFnSi",
      "expanded_url" : "https:\/\/cda.ms\/t5",
      "display_url" : "cda.ms\/t5"
    } ]
  },
  "geo" : { },
  "id_str" : "996782328289644544",
  "text" : "How to add interactive R-based visualizations to Power BI https:\/\/t.co\/1K5ahhFnSi #rstats",
  "id" : 996782328289644544,
  "created_at" : "2018-05-16 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/wAxOm3kRy0",
      "expanded_url" : "https:\/\/www.r-project.org\/posting-guide.html",
      "display_url" : "r-project.org\/posting-guide.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "996419945088147457",
  "text" : "Posting guide for the official R mailing lists: How to ask good questions that prompt useful answers https:\/\/t.co\/wAxOm3kRy0 #rstats",
  "id" : 996419945088147457,
  "created_at" : "2018-05-15 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/9jFFUNRSwE",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/viridis\/",
      "display_url" : "mran.microsoft.com\/package\/viridi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "996057558191194112",
  "text" : "Create perceptive color-blind-safe scales for heatmap charts with the viridis package https:\/\/t.co\/9jFFUNRSwE #rstats",
  "id" : 996057558191194112,
  "created_at" : "2018-05-14 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/EpLI0bj0BT",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/invisible",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "994970386818322433",
  "text" : "In R scripts, use invisible() to prevent functions from generating unwanted output: https:\/\/t.co\/EpLI0bj0BT #rstats",
  "id" : 994970386818322433,
  "created_at" : "2018-05-11 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/3LpwqlcOTZ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/system.time",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "994608004761726977",
  "text" : "Benchmark how long it takes R code to run with system.time(\u007B expr \u007D). The \"elapsed\" value is usually the most relevant. https:\/\/t.co\/3LpwqlcOTZ",
  "id" : 994608004761726977,
  "created_at" : "2018-05-10 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 171, 178 ]
    } ],
    "urls" : [ {
      "indices" : [ 147, 170 ],
      "url" : "https:\/\/t.co\/QB6E7NfqHc",
      "expanded_url" : "https:\/\/cda.ms\/s0",
      "display_url" : "cda.ms\/s0"
    } ]
  },
  "geo" : { },
  "id_str" : "994245612299259905",
  "text" : "By launching the RStudio Server service on the Ubuntu Data Science Virtual Machine, you can log in and access R and the terminal from your browser https:\/\/t.co\/QB6E7NfqHc #rstats",
  "id" : 994245612299259905,
  "created_at" : "2018-05-09 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/LotZxOj7xA",
      "expanded_url" : "https:\/\/svn.r-project.org\/R\/branches\/ALTREP\/ALTREP.html",
      "display_url" : "svn.r-project.org\/R\/branches\/ALT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "993883223150284802",
  "text" : "An overview of the new ALTREP representation of objects in R 3.5.0 and later #rstats https:\/\/t.co\/LotZxOj7xA",
  "id" : 993883223150284802,
  "created_at" : "2018-05-08 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/kDt29vR9jF",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/match",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "993520845271240706",
  "text" : "match(x,y) returns a vector of the positions of 1st matches of x in y: https:\/\/t.co\/kDt29vR9jF #rstats",
  "id" : 993520845271240706,
  "created_at" : "2018-05-07 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/EDbIyjC01Q",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/unique",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "992433670962102272",
  "text" : "Get the set of distinct values in a vector, x, with unique(x) #rstats https:\/\/t.co\/EDbIyjC01Q",
  "id" : 992433670962102272,
  "created_at" : "2018-05-04 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/jc5C1IOdT6",
      "expanded_url" : "https:\/\/github.com\/tarakc02\/ratelimitr",
      "display_url" : "github.com\/tarakc02\/ratel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "992071284400971776",
  "text" : "Use the ratelimitr package on CRAN to slow down requests to rate-limited APIs: https:\/\/t.co\/jc5C1IOdT6 #rstats",
  "id" : 992071284400971776,
  "created_at" : "2018-05-03 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/SV62qT7z1o",
      "expanded_url" : "https:\/\/mran.microsoft.com\/documents\/rro\/multithread",
      "display_url" : "mran.microsoft.com\/documents\/rro\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "991708896267001857",
  "text" : "Microsoft R Open links #rstats with multi-threaded libraries for faster performance: https:\/\/t.co\/SV62qT7z1o",
  "id" : 991708896267001857,
  "created_at" : "2018-05-02 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/a6iDMGtXXi",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.0\/topics\/Last.value",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "991346507621187584",
  "text" : "Forgot to save the output from the last R command? Retrieve it with\n \nv &lt;- .Last.value\n\nhttps:\/\/t.co\/a6iDMGtXXi #rstats",
  "id" : 991346507621187584,
  "created_at" : "2018-05-01 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]