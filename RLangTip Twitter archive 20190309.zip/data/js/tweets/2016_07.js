Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/kC2xX7tF77",
      "expanded_url" : "http:\/\/bit.ly\/2ammcme",
      "display_url" : "bit.ly\/2ammcme"
    } ]
  },
  "geo" : { },
  "id_str" : "759057310249385988",
  "text" : "Use ellipse() in the mixtools package to draw a 95% confidence ellipse for a bivariate normal distribution https:\/\/t.co\/kC2xX7tF77 #rstats",
  "id" : 759057310249385988,
  "created_at" : "2016-07-29 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/cILvkrRnOe",
      "expanded_url" : "http:\/\/bit.ly\/1mH7iES",
      "display_url" : "bit.ly\/1mH7iES"
    } ]
  },
  "geo" : { },
  "id_str" : "758694931879849984",
  "text" : "na.omit(df) will omit all rows of a data frame containing NAs https:\/\/t.co\/cILvkrRnOe #rstats",
  "id" : 758694931879849984,
  "created_at" : "2016-07-28 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/22rUdujuvF",
      "expanded_url" : "http:\/\/bit.ly\/29SGVtN",
      "display_url" : "bit.ly\/29SGVtN"
    } ]
  },
  "geo" : { },
  "id_str" : "758332534560358400",
  "text" : "See the vignette ( https:\/\/t.co\/22rUdujuvF ) of the sparseM package for an introduction to sparse matrices in R #rstats",
  "id" : 758332534560358400,
  "created_at" : "2016-07-27 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/M9hFH2qNZe",
      "expanded_url" : "http:\/\/bit.ly\/1y4AUzY",
      "display_url" : "bit.ly\/1y4AUzY"
    } ]
  },
  "geo" : { },
  "id_str" : "757970132882878464",
  "text" : "The TSA package has a nice collection of data sets for getting started with ARIMA models https:\/\/t.co\/M9hFH2qNZe #rstats",
  "id" : 757970132882878464,
  "created_at" : "2016-07-26 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Sskr4Xrlgr",
      "expanded_url" : "http:\/\/bit.ly\/2ahtdoS",
      "display_url" : "bit.ly\/2ahtdoS"
    } ]
  },
  "geo" : { },
  "id_str" : "757607729389338628",
  "text" : "bkde2D \u007BKernSmooth\u007D computes a binned kernel density estimate from samples of a 2 dim distribution https:\/\/t.co\/Sskr4Xrlgr #rstats",
  "id" : 757607729389338628,
  "created_at" : "2016-07-25 16:05:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/r3akJKl4eB",
      "expanded_url" : "http:\/\/bit.ly\/1mjbJUs",
      "display_url" : "bit.ly\/1mjbJUs"
    } ]
  },
  "geo" : { },
  "id_str" : "756520600257105920",
  "text" : "Compute a kernel density extimate of a vector with density(x) https:\/\/t.co\/r3akJKl4eB #rstats",
  "id" : 756520600257105920,
  "created_at" : "2016-07-22 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/QggZGCXq2O",
      "expanded_url" : "http:\/\/bit.ly\/13SdrZ8",
      "display_url" : "bit.ly\/13SdrZ8"
    } ]
  },
  "geo" : { },
  "id_str" : "756158206141837313",
  "text" : "#rstats Access or set the attributes of an R object with attributes() https:\/\/t.co\/QggZGCXq2O",
  "id" : 756158206141837313,
  "created_at" : "2016-07-21 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/sq02tc8yMC",
      "expanded_url" : "http:\/\/bit.ly\/29AVlCp",
      "display_url" : "bit.ly\/29AVlCp"
    } ]
  },
  "geo" : { },
  "id_str" : "755795825993875456",
  "text" : "list.dirs() \u007Bbase\u007D will list the subdirectories in your working directory https:\/\/t.co\/sq02tc8yMC #rstats",
  "id" : 755795825993875456,
  "created_at" : "2016-07-20 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hAGPymvR2i",
      "expanded_url" : "http:\/\/bit.ly\/ILpoTs",
      "display_url" : "bit.ly\/ILpoTs"
    } ]
  },
  "geo" : { },
  "id_str" : "755433430284926976",
  "text" : "Merge two data frames with merge(df1, df2) for an inner join and merge(df1,df2,all=TRUE) for an outer join. #rstats https:\/\/t.co\/hAGPymvR2i",
  "id" : 755433430284926976,
  "created_at" : "2016-07-19 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/H6pf0Beuru",
      "expanded_url" : "http:\/\/bit.ly\/29UJq1r",
      "display_url" : "bit.ly\/29UJq1r"
    } ]
  },
  "geo" : { },
  "id_str" : "755071035272269824",
  "text" : "basename() \u007Bbase\u007D removes all of the path upt to and including the last path separator. #rstats https:\/\/t.co\/H6pf0Beuru",
  "id" : 755071035272269824,
  "created_at" : "2016-07-18 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/tasrBFe84Z",
      "expanded_url" : "http:\/\/bit.ly\/29x396O",
      "display_url" : "bit.ly\/29x396O"
    } ]
  },
  "geo" : { },
  "id_str" : "753983886846205957",
  "text" : "Use the tm package for basix text mining. https:\/\/t.co\/tasrBFe84Z #rstats",
  "id" : 753983886846205957,
  "created_at" : "2016-07-15 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/gByjk08BSu",
      "expanded_url" : "http:\/\/bit.ly\/116RV0J",
      "display_url" : "bit.ly\/116RV0J"
    } ]
  },
  "geo" : { },
  "id_str" : "753621481477857286",
  "text" : "#rstats Try data.table as a substitute for data frames when working with big data https:\/\/t.co\/gByjk08BSu",
  "id" : 753621481477857286,
  "created_at" : "2016-07-14 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/pLCbxanVLm",
      "expanded_url" : "http:\/\/bit.ly\/1xF7rO9",
      "display_url" : "bit.ly\/1xF7rO9"
    } ]
  },
  "geo" : { },
  "id_str" : "753259088625164293",
  "text" : "#rstats use aperm() \u007Bbase\u007D to transpose an array by permuting its dimensions https:\/\/t.co\/pLCbxanVLm",
  "id" : 753259088625164293,
  "created_at" : "2016-07-13 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/p6WYZH0p0j",
      "expanded_url" : "http:\/\/bit.ly\/10z1lBR",
      "display_url" : "bit.ly\/10z1lBR"
    } ]
  },
  "geo" : { },
  "id_str" : "752896709643165697",
  "text" : "#rstats find() tells what package a function came from. e.g. find(\"find\") https:\/\/t.co\/p6WYZH0p0j",
  "id" : 752896709643165697,
  "created_at" : "2016-07-12 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/yNjhyPQKzr",
      "expanded_url" : "http:\/\/bit.ly\/29CHOLs",
      "display_url" : "bit.ly\/29CHOLs"
    } ]
  },
  "geo" : { },
  "id_str" : "752534362571276288",
  "text" : "Perform a likelihood ration test for nested GLM models with lrtest(m1,m2) \u007Blmtest\u007D https:\/\/t.co\/yNjhyPQKzr #rstats",
  "id" : 752534362571276288,
  "created_at" : "2016-07-11 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/76lSTb3NNr",
      "expanded_url" : "http:\/\/bit.ly\/OrT9bX",
      "display_url" : "bit.ly\/OrT9bX"
    } ]
  },
  "geo" : { },
  "id_str" : "751447182121824256",
  "text" : "To speed up your R code, use Rprof() to turn on profiling, and summaryRprof() to find the slow parts: https:\/\/t.co\/76lSTb3NNr #rstats",
  "id" : 751447182121824256,
  "created_at" : "2016-07-08 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/1cdax1e46P",
      "expanded_url" : "http:\/\/bit.ly\/1mmkytP",
      "display_url" : "bit.ly\/1mmkytP"
    } ]
  },
  "geo" : { },
  "id_str" : "751084786039582720",
  "text" : "gregexpr() \u007Bbase\u007D finds all instances of a pattern https:\/\/t.co\/1cdax1e46P #rstats",
  "id" : 751084786039582720,
  "created_at" : "2016-07-07 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/3yR24qxzH9",
      "expanded_url" : "http:\/\/bit.ly\/UQLrR5",
      "display_url" : "bit.ly\/UQLrR5"
    } ]
  },
  "geo" : { },
  "id_str" : "750722396072636417",
  "text" : "Use lines() \u007Bgraphics\u007D to add connected line segments to base R plots https:\/\/t.co\/3yR24qxzH9 #rstats",
  "id" : 750722396072636417,
  "created_at" : "2016-07-06 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/OfWYSp6cEZ",
      "expanded_url" : "http:\/\/bit.ly\/29n2F2g",
      "display_url" : "bit.ly\/29n2F2g"
    } ]
  },
  "geo" : { },
  "id_str" : "750359976963665921",
  "text" : "Nice explanation of R's cut \u007Bbase\u007D: function https:\/\/t.co\/OfWYSp6cEZ #rstats",
  "id" : 750359976963665921,
  "created_at" : "2016-07-05 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/QYxcMHluyL",
      "expanded_url" : "http:\/\/bit.ly\/28WCr7o",
      "display_url" : "bit.ly\/28WCr7o"
    } ]
  },
  "geo" : { },
  "id_str" : "749997569997213696",
  "text" : "sample(x,replace=TRUE) will yield a random permutation of the vector x. https:\/\/t.co\/QYxcMHluyL #rstats",
  "id" : 749997569997213696,
  "created_at" : "2016-07-04 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/j1hJfoWG57",
      "expanded_url" : "http:\/\/bit.ly\/28TUDgA",
      "display_url" : "bit.ly\/28TUDgA"
    } ]
  },
  "geo" : { },
  "id_str" : "748910447546466304",
  "text" : "Look at package infotheo to compute entropy measures from information theory #rstats https:\/\/t.co\/j1hJfoWG57",
  "id" : 748910447546466304,
  "created_at" : "2016-07-01 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]