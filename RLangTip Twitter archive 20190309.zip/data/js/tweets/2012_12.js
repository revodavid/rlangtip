Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/u38nUaMk",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "284690369462013953",
  "text" : "To create the list of every possible combination of levels in multiple factors, use expand.grid: http:\/\/t.co\/u38nUaMk #rstats",
  "id" : 284690369462013953,
  "created_at" : "2012-12-28 16:00:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/XMnF96Tl",
      "expanded_url" : "http:\/\/bit.ly\/auoC65",
      "display_url" : "bit.ly\/auoC65"
    } ]
  },
  "geo" : { },
  "id_str" : "284327986797355008",
  "text" : "log1p(x) computes log(1 + x). Why is such a function necessary? http:\/\/t.co\/XMnF96Tl #rstats",
  "id" : 284327986797355008,
  "created_at" : "2012-12-27 16:00:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/2AOYHwZd",
      "expanded_url" : "http:\/\/bit.ly\/t2OR0K",
      "display_url" : "bit.ly\/t2OR0K"
    } ]
  },
  "geo" : { },
  "id_str" : "283965527796363264",
  "text" : "To speed an R function, use cmpfun to byte-compile it: http:\/\/t.co\/2AOYHwZd #rstats",
  "id" : 283965527796363264,
  "created_at" : "2012-12-26 16:00:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/r3eufIpm",
      "expanded_url" : "http:\/\/bit.ly\/Y04DGq",
      "display_url" : "bit.ly\/Y04DGq"
    } ]
  },
  "geo" : { },
  "id_str" : "283603152643690496",
  "text" : "How Santa figures out the optimal set of presents that can fit into his sack: http:\/\/t.co\/r3eufIpm #rstats",
  "id" : 283603152643690496,
  "created_at" : "2012-12-25 16:00:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/0u0NIslY",
      "expanded_url" : "http:\/\/rseek.org\/",
      "display_url" : "rseek.org"
    } ]
  },
  "geo" : { },
  "id_str" : "283240747921195009",
  "text" : "R-specific web search http:\/\/t.co\/0u0NIslY #rstats",
  "id" : 283240747921195009,
  "created_at" : "2012-12-24 16:00:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/6VllFQgL",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "282176029815099392",
  "text" : "which(x &gt; 0) returns the locations of positive elements in numeric vector x http:\/\/t.co\/6VllFQgL #rstats",
  "id" : 282176029815099392,
  "created_at" : "2012-12-21 17:29:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/86vBmDTQ",
      "expanded_url" : "http:\/\/bit.ly\/RAEbGC",
      "display_url" : "bit.ly\/RAEbGC"
    } ]
  },
  "geo" : { },
  "id_str" : "281807803000180736",
  "text" : "Use the sqldf package to select and merge data frames with SQL. Video tutorial: http:\/\/t.co\/86vBmDTQ #rstats",
  "id" : 281807803000180736,
  "created_at" : "2012-12-20 17:06:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Pq1ZWiA4",
      "expanded_url" : "http:\/\/bit.ly\/qokamy",
      "display_url" : "bit.ly\/qokamy"
    } ]
  },
  "geo" : { },
  "id_str" : "281445545313177600",
  "text" : "Not sure why your R function threw an error? Use traceback() to find out where it occurred. http:\/\/t.co\/Pq1ZWiA4",
  "id" : 281445545313177600,
  "created_at" : "2012-12-19 17:07:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyFunky",
      "screen_name" : "EpiFunky",
      "indices" : [ 119, 128 ],
      "id_str" : "476678759",
      "id" : 476678759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/qu2rQ2LM",
      "expanded_url" : "http:\/\/bit.ly\/UMV4dA",
      "display_url" : "bit.ly\/UMV4dA"
    } ]
  },
  "geo" : { },
  "id_str" : "281066484535525376",
  "text" : "The \"tabular\" function generates crosstabs with summary stats a la SAS PROC TABULATE #rstats http:\/\/t.co\/qu2rQ2LM (via @EpiFunky)",
  "id" : 281066484535525376,
  "created_at" : "2012-12-18 16:00:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/g40rN0tH",
      "expanded_url" : "http:\/\/bit.ly\/K5JXa7",
      "display_url" : "bit.ly\/K5JXa7"
    } ]
  },
  "geo" : { },
  "id_str" : "280722558494597121",
  "text" : "A ten-hour video introduction to R, presented by Roger Peng: http:\/\/t.co\/g40rN0tH #rstats",
  "id" : 280722558494597121,
  "created_at" : "2012-12-17 17:14:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279617013905780736",
  "text" : "The # character introduces comments in R. Everything after the # character to end-of-line is ignored by the interpreter. #rstats",
  "id" : 279617013905780736,
  "created_at" : "2012-12-14 16:01:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279254602065539072",
  "text" : "Efficiency tip: When selecting from a data frame, df$a[1] is much faster than df[1,\"a\"] #rstats",
  "id" : 279254602065539072,
  "created_at" : "2012-12-13 16:01:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/5gzYaYQz",
      "expanded_url" : "http:\/\/bit.ly\/AE2djP",
      "display_url" : "bit.ly\/AE2djP"
    } ]
  },
  "geo" : { },
  "id_str" : "278892265609498624",
  "text" : "Try demo('graphics') ... and type demo() to see other demos available in attached packages. http:\/\/t.co\/5gzYaYQz #rstats",
  "id" : 278892265609498624,
  "created_at" : "2012-12-12 16:01:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/tj1xWBgs",
      "expanded_url" : "http:\/\/bit.ly\/vlOimZ",
      "display_url" : "bit.ly\/vlOimZ"
    } ]
  },
  "geo" : { },
  "id_str" : "278529755949723648",
  "text" : "Public data sets available online to use with R: http:\/\/t.co\/tj1xWBgs #rstats",
  "id" : 278529755949723648,
  "created_at" : "2012-12-11 16:00:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/ZR6YhJ3q",
      "expanded_url" : "http:\/\/bit.ly\/qnRaaf",
      "display_url" : "bit.ly\/qnRaaf"
    } ]
  },
  "geo" : { },
  "id_str" : "278254298536751104",
  "text" : "List of R functions and packages for Optimization and Mathematical Programming: http:\/\/t.co\/ZR6YhJ3q #rstats",
  "id" : 278254298536751104,
  "created_at" : "2012-12-10 21:46:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/vvCnqC9N",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "277104789907701761",
  "text" : "Negative indexes remove elements from a vector. x[-1] is x without the first element. http:\/\/t.co\/vvCnqC9N #rstats",
  "id" : 277104789907701761,
  "created_at" : "2012-12-07 17:38:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/CbTqy07j",
      "expanded_url" : "http:\/\/bit.ly\/VJt1wl",
      "display_url" : "bit.ly\/VJt1wl"
    } ]
  },
  "geo" : { },
  "id_str" : "276739718002122752",
  "text" : "Add a zero imaginary part to a number for complex arguments. sqrt(-1) returns NaN; sqrt(-1+0i) returns 1i #rstats http:\/\/t.co\/CbTqy07j",
  "id" : 276739718002122752,
  "created_at" : "2012-12-06 17:27:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/avQoTTrI",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "276377222355496960",
  "text" : "search() is an easy way to find out what packages are loaded and available for use: http:\/\/t.co\/avQoTTrI #rstats",
  "id" : 276377222355496960,
  "created_at" : "2012-12-05 17:27:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/VPFs7YMF",
      "expanded_url" : "http:\/\/bit.ly\/r6YJTu",
      "display_url" : "bit.ly\/r6YJTu"
    } ]
  },
  "geo" : { },
  "id_str" : "276009268086468608",
  "text" : "List of R functions and packages for Time Series Analysis: http:\/\/t.co\/VPFs7YMF #rstats",
  "id" : 276009268086468608,
  "created_at" : "2012-12-04 17:05:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/f5r5OyNn",
      "expanded_url" : "http:\/\/bit.ly\/QvVJ4G",
      "display_url" : "bit.ly\/QvVJ4G"
    } ]
  },
  "geo" : { },
  "id_str" : "275647876787482624",
  "text" : "Topic coding and text classification for unstructured data: the RTextTools package #rstats http:\/\/t.co\/f5r5OyNn",
  "id" : 275647876787482624,
  "created_at" : "2012-12-03 17:09:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]