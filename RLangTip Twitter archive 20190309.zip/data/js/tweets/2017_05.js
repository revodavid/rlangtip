Grailbird.data.tweets_2017_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/9DNFvyUPE4",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2017\/04\/sqlrutils.html",
      "display_url" : "blog.revolutionanalytics.com\/2017\/04\/sqlrut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "869946576969621505",
  "text" : "Publish R functions as SQL Server stored procedures with the sqlrutils package in Microsoft R: https:\/\/t.co\/9DNFvyUPE4 #rstats",
  "id" : 869946576969621505,
  "created_at" : "2017-05-31 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noam Ross",
      "screen_name" : "noamross",
      "indices" : [ 79, 88 ],
      "id_str" : "97582853",
      "id" : 97582853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/caCon7LZRD",
      "expanded_url" : "http:\/\/www.noamross.net\/blog\/2013\/1\/7\/collaborating-with-r.html",
      "display_url" : "noamross.net\/blog\/2013\/1\/7\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "869584188617351168",
  "text" : "A guide to collaborating with (and getting help from) other R users online, by @noamross https:\/\/t.co\/caCon7LZRD #rstats",
  "id" : 869584188617351168,
  "created_at" : "2017-05-30 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/4KXYFXOvM3",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/options",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "869221798830788612",
  "text" : "To debug warnings, options(warn=2) converts warnings into errors https:\/\/t.co\/4KXYFXOvM3 #rstats",
  "id" : 869221798830788612,
  "created_at" : "2017-05-29 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868134638144847873",
  "text" : "Syntax trap: The ':' operator has higher precedence than '-' so 0:N-1 evaluates to (0:N)-1, not 0:(N-1) like you probably wanted #rstats",
  "id" : 868134638144847873,
  "created_at" : "2017-05-26 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/o4lmkl6Up1",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.0\/topics\/anova",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "867772245812420609",
  "text" : "One way to do a one-way analysis of variance: anova(lm(y ~ x)) where x is a factor https:\/\/t.co\/o4lmkl6Up1 #rstats",
  "id" : 867772245812420609,
  "created_at" : "2017-05-25 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/1ELmYTphez",
      "expanded_url" : "https:\/\/blogs.msdn.microsoft.com\/rserver\/2017\/05\/10\/rxexecby-productivity-and-scale-with-partitioned-data\/",
      "display_url" : "blogs.msdn.microsoft.com\/rserver\/2017\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "867409873121759234",
  "text" : "Offload parallel processing jobs on partitioned data to remote clusters with rxExecBy in Microsoft R: https:\/\/t.co\/1ELmYTphez #rstats",
  "id" : 867409873121759234,
  "created_at" : "2017-05-24 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRAN Package Updates",
      "screen_name" : "CRANberriesFeed",
      "indices" : [ 53, 69 ],
      "id_str" : "233585808",
      "id" : 233585808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/O9dymbxt9r",
      "expanded_url" : "http:\/\/dirk.eddelbuettel.com\/cranberries",
      "display_url" : "dirk.eddelbuettel.com\/cranberries"
    } ]
  },
  "geo" : { },
  "id_str" : "867047485130366978",
  "text" : "Get notifications of new and updated R packages with @CRANberriesFeed https:\/\/t.co\/O9dymbxt9r #rstats",
  "id" : 867047485130366978,
  "created_at" : "2017-05-23 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/tzPS3nnQ3L",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.0\/topics\/simulate",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "866685084593795078",
  "text" : "simulate(obj) in \u007Bstats\u007D will simulate one or more responses from the distribution of a fitted model object https:\/\/t.co\/tzPS3nnQ3L #rstats",
  "id" : 866685084593795078,
  "created_at" : "2017-05-22 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/gqE26ew5gf",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/cut",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "865597927447777280",
  "text" : "Convert a numeric vector to a factor with \"cut\", e.g. cut(rnorm(100),3,c(\"Low\",\"Med\",\"High\")) #rstats https:\/\/t.co\/gqE26ew5gf",
  "id" : 865597927447777280,
  "created_at" : "2017-05-19 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "865235546389532672",
  "text" : "Generate a data frame with detailed info on every package on CRAN: tools::CRAN_package_db() #rstats",
  "id" : 865235546389532672,
  "created_at" : "2017-05-18 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/RxRysKjOYI",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/azure\/hdinsight\/hdinsight-hadoop-r-server-storage",
      "display_url" : "docs.microsoft.com\/en-us\/azure\/hd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "864873156657373185",
  "text" : "How to access data in Azure Blob Storage or Data Lake from R #rstats on HDInsight https:\/\/t.co\/RxRysKjOYI",
  "id" : 864873156657373185,
  "created_at" : "2017-05-17 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/NzDvtwIQHb",
      "expanded_url" : "https:\/\/jumpingrivers.github.io\/meetingsR\/",
      "display_url" : "jumpingrivers.github.io\/meetingsR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "864510758096257024",
  "text" : "Find an R conference or user group near you at https:\/\/t.co\/NzDvtwIQHb #rstats",
  "id" : 864510758096257024,
  "created_at" : "2017-05-16 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/cLEgBF5xwc",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/Quotes",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "864148381828075521",
  "text" : "To include a quote character in a string, use \\\"\"\nUse \\\\ for a single backslash\n#rstats https:\/\/t.co\/cLEgBF5xwc",
  "id" : 864148381828075521,
  "created_at" : "2017-05-15 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/JMO7zKUH2g",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/rpart\/versions\/4.1-11\/topics\/rpart",
      "display_url" : "rdocumentation.org\/packages\/rpart\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "863061215148421124",
  "text" : "rpart is an R function for CART-like classification and regression trees https:\/\/t.co\/JMO7zKUH2g #rstats",
  "id" : 863061215148421124,
  "created_at" : "2017-05-12 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Freeman",
      "screen_name" : "mf_viz",
      "indices" : [ 69, 76 ],
      "id_str" : "282130842",
      "id" : 282130842
    }, {
      "name" : "Joel Ross",
      "screen_name" : "joelwross",
      "indices" : [ 81, 91 ],
      "id_str" : "36789423",
      "id" : 36789423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/XwSRkJ5nAz",
      "expanded_url" : "https:\/\/info201-s17.github.io\/book\/",
      "display_url" : "info201-s17.github.io\/book\/"
    } ]
  },
  "geo" : { },
  "id_str" : "862698828801224704",
  "text" : "Technical Foundations of Informatics: A modern introduction to R, by @mf_viz and @joelwross https:\/\/t.co\/XwSRkJ5nAz #rstats",
  "id" : 862698828801224704,
  "created_at" : "2017-05-11 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/EZ5ugjozoy",
      "expanded_url" : "https:\/\/azure.microsoft.com\/en-us\/blog\/optimization-tips-and-tricks-on-azure-sql-server-for-machine-learning-services\/",
      "display_url" : "azure.microsoft.com\/en-us\/blog\/opt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "862336440566403077",
  "text" : "Tips and tricks for optimizing R applications deployed in SQL Server https:\/\/t.co\/EZ5ugjozoy #rstats",
  "id" : 862336440566403077,
  "created_at" : "2017-05-10 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/zrDgf4bcnY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/solve",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "861974046539358208",
  "text" : "To calculate the inverse of a square numeric matrix, use solve(X):  https:\/\/t.co\/zrDgf4bcnY #rstats",
  "id" : 861974046539358208,
  "created_at" : "2017-05-09 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/EvX0XF4nc8",
      "expanded_url" : "https:\/\/cloud.r-project.org\/web\/views\/DifferentialEquations.html",
      "display_url" : "cloud.r-project.org\/web\/views\/Diff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "861611656475848705",
  "text" : "R functions and packages for differential equations: ODEs, SDEs, PDEs etc: https:\/\/t.co\/EvX0XF4nc8 #rstats",
  "id" : 861611656475848705,
  "created_at" : "2017-05-08 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/7cY53DwoY4",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/nrow",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "860524490530459650",
  "text" : "Use NROW\/NCOL instead of nrow\/ncol to treat vectors as 1-column matrices #rstats https:\/\/t.co\/7cY53DwoY4",
  "id" : 860524490530459650,
  "created_at" : "2017-05-05 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/0P9apN7PP1",
      "expanded_url" : "https:\/\/github.com\/hadley\/lubridate\/",
      "display_url" : "github.com\/hadley\/lubrida\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "860162107228135424",
  "text" : "The lubridate package simplifies operations on dates and times: https:\/\/t.co\/0P9apN7PP1 #rstats",
  "id" : 860162107228135424,
  "created_at" : "2017-05-04 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/9CgeIO7wYY",
      "expanded_url" : "https:\/\/plot.ly\/r\/",
      "display_url" : "plot.ly\/r\/"
    } ]
  },
  "geo" : { },
  "id_str" : "859799738698178560",
  "text" : "The Plotly R library provides a way to plot and share interactive graphics on the web using ggplot2 syntax https:\/\/t.co\/9CgeIO7wYY #rstats",
  "id" : 859799738698178560,
  "created_at" : "2017-05-03 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/V9JvfkG57v",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.0\/topics\/arima.sim",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "859437334860881920",
  "text" : "Use arima.sim() to simulate time series under an ARIMA model https:\/\/t.co\/V9JvfkG57v #rstats",
  "id" : 859437334860881920,
  "created_at" : "2017-05-02 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Itz845RFhL",
      "expanded_url" : "http:\/\/www.imachordata.com\/extra-extra-get-your-gridextra\/",
      "display_url" : "imachordata.com\/extra-extra-ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "859074959641063424",
  "text" : "Use the gridExtra package to lay out multiple ggplot2 charts on a single page https:\/\/t.co\/Itz845RFhL #rstats",
  "id" : 859074959641063424,
  "created_at" : "2017-05-01 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]