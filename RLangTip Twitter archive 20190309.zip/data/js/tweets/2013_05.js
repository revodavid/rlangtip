Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/k9p7CSA767",
      "expanded_url" : "http:\/\/bit.ly\/10WrbZo",
      "display_url" : "bit.ly\/10WrbZo"
    } ]
  },
  "geo" : { },
  "id_str" : "340500702352773120",
  "text" : "You can include mathematical equations in R charts. Cheat sheet of all the math symbols you can use: http:\/\/t.co\/k9p7CSA767 #rstats",
  "id" : 340500702352773120,
  "created_at" : "2013-05-31 16:11:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 95, 109 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/nFTPUHnkI9",
      "expanded_url" : "http:\/\/bit.ly\/KGRu37",
      "display_url" : "bit.ly\/KGRu37"
    } ]
  },
  "geo" : { },
  "id_str" : "340138410478039040",
  "text" : "Get a quick visual overview of your data with the tabplot package: http:\/\/t.co\/nFTPUHnkI9 (via @JacquelynGill)",
  "id" : 340138410478039040,
  "created_at" : "2013-05-30 16:11:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/YQ814nIj8i",
      "expanded_url" : "http:\/\/bit.ly\/LEU8S0",
      "display_url" : "bit.ly\/LEU8S0"
    } ]
  },
  "geo" : { },
  "id_str" : "339775980279308289",
  "text" : "Concatenate elements of a vector to a single comma-separated string: paste(letters, collapse=\", \") #rstats http:\/\/t.co\/YQ814nIj8i",
  "id" : 339775980279308289,
  "created_at" : "2013-05-29 16:11:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "finance",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KdThi9ixrn",
      "expanded_url" : "http:\/\/bit.ly\/zpAoep",
      "display_url" : "bit.ly\/zpAoep"
    } ]
  },
  "geo" : { },
  "id_str" : "339413790296780801",
  "text" : "quantmod: An R package where quant traders can quickly and cleanly explore and build trading models: http:\/\/t.co\/KdThi9ixrn #rstats #finance",
  "id" : 339413790296780801,
  "created_at" : "2013-05-28 16:12:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/f7fljUUsjS",
      "expanded_url" : "http:\/\/bit.ly\/14oJGdc",
      "display_url" : "bit.ly\/14oJGdc"
    } ]
  },
  "geo" : { },
  "id_str" : "339051337264279552",
  "text" : "R resources for Econometrics and Psychometrics: http:\/\/t.co\/f7fljUUsjS #rstats",
  "id" : 339051337264279552,
  "created_at" : "2013-05-27 16:11:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337962796903956480",
  "text" : "If x is a list, then x[2] &lt;- NULL removes the second element, whereas x[2] &lt;- list(NULL) replaces it with NULL. #rstats",
  "id" : 337962796903956480,
  "created_at" : "2013-05-24 16:06:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/9IzoRtVyX2",
      "expanded_url" : "http:\/\/bit.ly\/GzYTQZ",
      "display_url" : "bit.ly\/GzYTQZ"
    } ]
  },
  "geo" : { },
  "id_str" : "337600371675500545",
  "text" : "Differences between R and S+: http:\/\/t.co\/9IzoRtVyX2 #rstats",
  "id" : 337600371675500545,
  "created_at" : "2013-05-23 16:06:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336875495809486850",
  "text" : "Imported a column of numbers, but it read in as a factor? Convert it with as.numeric(as.character(df$num.col)) #rstats",
  "id" : 336875495809486850,
  "created_at" : "2013-05-21 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DsJpvlTJha",
      "expanded_url" : "http:\/\/bit.ly\/If5SJP",
      "display_url" : "bit.ly\/If5SJP"
    } ]
  },
  "geo" : { },
  "id_str" : "336513178412404737",
  "text" : "Search R-help mailing list archives, help pages, vignettes and task views with RSiteSearch: http:\/\/t.co\/DsJpvlTJha #rstats",
  "id" : 336513178412404737,
  "created_at" : "2013-05-20 16:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/reo3hy7LLv",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "335425949128597505",
  "text" : "Return the row\/column indices of positive elements of matrix x: which(x&gt;0, arr.ind=TRUE) #rstats http:\/\/t.co\/reo3hy7LLv",
  "id" : 335425949128597505,
  "created_at" : "2013-05-17 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "finance",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KdThi9ixrn",
      "expanded_url" : "http:\/\/bit.ly\/zpAoep",
      "display_url" : "bit.ly\/zpAoep"
    } ]
  },
  "geo" : { },
  "id_str" : "335063613465321477",
  "text" : "quantmod: An R package where quant traders can quickly and cleanly explore and build trading models: http:\/\/t.co\/KdThi9ixrn #rstats #finance",
  "id" : 335063613465321477,
  "created_at" : "2013-05-16 16:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/CxtPrpmv2p",
      "expanded_url" : "http:\/\/bit.ly\/JwCeEd",
      "display_url" : "bit.ly\/JwCeEd"
    } ]
  },
  "geo" : { },
  "id_str" : "334701420945211394",
  "text" : "To calculate the inverse of a square numeric matrix, use solve(X): http:\/\/t.co\/CxtPrpmv2p #rstats",
  "id" : 334701420945211394,
  "created_at" : "2013-05-15 16:06:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/njqaWuoEPy",
      "expanded_url" : "http:\/\/bit.ly\/x8ecZY",
      "display_url" : "bit.ly\/x8ecZY"
    } ]
  },
  "geo" : { },
  "id_str" : "334338798433497088",
  "text" : "List of R packages for statistical genetics and genetic analysis: http:\/\/t.co\/njqaWuoEPy #rstats",
  "id" : 334338798433497088,
  "created_at" : "2013-05-14 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/4g4yqyFWlJ",
      "expanded_url" : "http:\/\/bit.ly\/n4V3sw",
      "display_url" : "bit.ly\/n4V3sw"
    } ]
  },
  "geo" : { },
  "id_str" : "333976437247836161",
  "text" : "Look here (http:\/\/t.co\/4g4yqyFWlJ) for a fairly comprehensive list of R #rstats resources.",
  "id" : 333976437247836161,
  "created_at" : "2013-05-13 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/buVGwvUdQB",
      "expanded_url" : "http:\/\/bit.ly\/elVw2",
      "display_url" : "bit.ly\/elVw2"
    } ]
  },
  "geo" : { },
  "id_str" : "332889271138676736",
  "text" : "Better R #rstats console fonts http:\/\/t.co\/buVGwvUdQB",
  "id" : 332889271138676736,
  "created_at" : "2013-05-10 16:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ziFsVMW4Pv",
      "expanded_url" : "http:\/\/bit.ly\/Lbt65p",
      "display_url" : "bit.ly\/Lbt65p"
    } ]
  },
  "geo" : { },
  "id_str" : "332527052525797377",
  "text" : "New to R? Try the \"sample session\" in the Introduction to R Manual for a 10-min tour: http:\/\/t.co\/ziFsVMW4Pv #rstats",
  "id" : 332527052525797377,
  "created_at" : "2013-05-09 16:06:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/FP4v42iALc",
      "expanded_url" : "http:\/\/bit.ly\/p6epvV",
      "display_url" : "bit.ly\/p6epvV"
    } ]
  },
  "geo" : { },
  "id_str" : "332164470157766657",
  "text" : "Yes, you can return more than one value from a function: use a list! return(list(val1, val2, val3)) #rstats http:\/\/t.co\/FP4v42iALc",
  "id" : 332164470157766657,
  "created_at" : "2013-05-08 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/BikRtSysBY",
      "expanded_url" : "http:\/\/bit.ly\/KglkJC",
      "display_url" : "bit.ly\/KglkJC"
    } ]
  },
  "geo" : { },
  "id_str" : "331802055146618881",
  "text" : "Use read.fwf to read a fixed-format data file (ASCII data without delimiters) into R: http:\/\/t.co\/BikRtSysBY #rstats",
  "id" : 331802055146618881,
  "created_at" : "2013-05-07 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/YZWQFwQ8A0",
      "expanded_url" : "http:\/\/bit.ly\/IlFfpk",
      "display_url" : "bit.ly\/IlFfpk"
    } ]
  },
  "geo" : { },
  "id_str" : "331439755348815872",
  "text" : "Side by side comparisons of analysis tasks done in SAS and R: http:\/\/t.co\/YZWQFwQ8A0 #rstats",
  "id" : 331439755348815872,
  "created_at" : "2013-05-06 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/vY4yQvK6X5",
      "expanded_url" : "http:\/\/bit.ly\/H9znwZ",
      "display_url" : "bit.ly\/H9znwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "330352518074863616",
  "text" : "In an #rstats function, return the list of arguments supplied in the call with: as.list(match.call())[-1] http:\/\/t.co\/vY4yQvK6X5",
  "id" : 330352518074863616,
  "created_at" : "2013-05-03 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/NNqZweHlaC",
      "expanded_url" : "http:\/\/bit.ly\/FO6A1a",
      "display_url" : "bit.ly\/FO6A1a"
    } ]
  },
  "geo" : { },
  "id_str" : "329627667718615040",
  "text" : "To change where R exports files, use setwd() to change the current working directory first: http:\/\/t.co\/NNqZweHlaC #rstats",
  "id" : 329627667718615040,
  "created_at" : "2013-05-01 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]