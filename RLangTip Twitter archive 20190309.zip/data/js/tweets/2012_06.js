Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/l8mIkVi1",
      "expanded_url" : "http:\/\/bit.ly\/KRocvC",
      "display_url" : "bit.ly\/KRocvC"
    } ]
  },
  "geo" : { },
  "id_str" : "218720834745925632",
  "text" : "Tutorial \/ cheat sheet for data visualization with ggplot2 (PDF): http:\/\/t.co\/l8mIkVi1 #rstats",
  "id" : 218720834745925632,
  "created_at" : "2012-06-29 15:01:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/1Zw6f8rD",
      "expanded_url" : "http:\/\/bit.ly\/L22Wbm",
      "display_url" : "bit.ly\/L22Wbm"
    } ]
  },
  "geo" : { },
  "id_str" : "218358432980406272",
  "text" : "On Windows, use odbcConnectExcel\/sqlQuery from package RODBC to extract data from Excel worksheets via SQL http:\/\/t.co\/1Zw6f8rD #rstats",
  "id" : 218358432980406272,
  "created_at" : "2012-06-28 15:01:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/Gb6k4QGe",
      "expanded_url" : "http:\/\/bit.ly\/NOuduT",
      "display_url" : "bit.ly\/NOuduT"
    } ]
  },
  "geo" : { },
  "id_str" : "218010613228638208",
  "text" : "Use dput to archive an R object to a file; load into another R session with dget #rstats http:\/\/t.co\/Gb6k4QGe",
  "id" : 218010613228638208,
  "created_at" : "2012-06-27 15:59:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/SeUTfELn",
      "expanded_url" : "http:\/\/bit.ly\/LMBnkg",
      "display_url" : "bit.ly\/LMBnkg"
    } ]
  },
  "geo" : { },
  "id_str" : "217648198242680832",
  "text" : "If ch is a character vector, then noquote(ch) prints it without the usual quotes surrounding each element #rstats http:\/\/t.co\/SeUTfELn",
  "id" : 217648198242680832,
  "created_at" : "2012-06-26 15:59:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/qVoDCshs",
      "expanded_url" : "http:\/\/bit.ly\/N8qc7Y",
      "display_url" : "bit.ly\/N8qc7Y"
    } ]
  },
  "geo" : { },
  "id_str" : "217271438330175490",
  "text" : "A %x% B calculates the kronecker product of matrices A and B #rstats http:\/\/t.co\/qVoDCshs",
  "id" : 217271438330175490,
  "created_at" : "2012-06-25 15:02:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 64, 74 ],
      "id_str" : "62183077",
      "id" : 62183077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/NZ7he8X5",
      "expanded_url" : "http:\/\/bit.ly\/LpzOtd",
      "display_url" : "bit.ly\/LpzOtd"
    } ]
  },
  "geo" : { },
  "id_str" : "216184324725293056",
  "text" : "Tutorial: Basic graphics in R http:\/\/t.co\/NZ7he8X5 #rstats (via @vsbuffalo)",
  "id" : 216184324725293056,
  "created_at" : "2012-06-22 15:02:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/P78fiCAt",
      "expanded_url" : "http:\/\/bit.ly\/N8snbL",
      "display_url" : "bit.ly\/N8snbL"
    } ]
  },
  "geo" : { },
  "id_str" : "215821793338994688",
  "text" : "You can use the readHTMLTable function to scrape data from a Web page: http:\/\/t.co\/P78fiCAt #rstats",
  "id" : 215821793338994688,
  "created_at" : "2012-06-21 15:01:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/L7S5DRFL",
      "expanded_url" : "http:\/\/bit.ly\/KETjbI",
      "display_url" : "bit.ly\/KETjbI"
    } ]
  },
  "geo" : { },
  "id_str" : "215459658742243329",
  "text" : "Index of datasets included with R: http:\/\/t.co\/L7S5DRFL #rstats",
  "id" : 215459658742243329,
  "created_at" : "2012-06-20 15:02:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle White",
      "screen_name" : "kysquare",
      "indices" : [ 3, 12 ],
      "id_str" : "237325739",
      "id" : 237325739
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 19, 28 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215196782534209536",
  "text" : "RT @kysquare: Used @RLangTip Rprof() tip. Wrote my own outer product function(v), matrix(rep(v,p),p,p) * matrix(rep(v,p),p,p,byrow=T) to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 5, 14 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215151722132287488",
    "text" : "Used @RLangTip Rprof() tip. Wrote my own outer product function(v), matrix(rep(v,p),p,p) * matrix(rep(v,p),p,p,byrow=T) to speed up by ~23%",
    "id" : 215151722132287488,
    "created_at" : "2012-06-19 18:39:02 +0000",
    "user" : {
      "name" : "Kyle White",
      "screen_name" : "kysquare",
      "protected" : false,
      "id_str" : "237325739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1922885640\/cap2_normal.png",
      "id" : 237325739,
      "verified" : false
    }
  },
  "id" : 215196782534209536,
  "created_at" : "2012-06-19 21:38:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/mFJNY7mR",
      "expanded_url" : "http:\/\/bit.ly\/OrT9bX",
      "display_url" : "bit.ly\/OrT9bX"
    } ]
  },
  "geo" : { },
  "id_str" : "215097002034343938",
  "text" : "To speed up your R code, use Rprof() to turn on profiling, and summaryRprof() to find the slow parts: http:\/\/t.co\/mFJNY7mR #rstats",
  "id" : 215097002034343938,
  "created_at" : "2012-06-19 15:01:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/cDDnytm2",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "214837104608419843",
  "text" : "Efficiency tip: TRUE || (x &lt;-3) will never evaluate the right hand side. Using &amp;&amp; and || can save cycles #rstats http:\/\/t.co\/cDDnytm2",
  "id" : 214837104608419843,
  "created_at" : "2012-06-18 21:48:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/YYDjGENs",
      "expanded_url" : "http:\/\/bit.ly\/LpJWCh",
      "display_url" : "bit.ly\/LpJWCh"
    } ]
  },
  "geo" : { },
  "id_str" : "213647697482223616",
  "text" : "Extracting data from PDFs with #rstats. Vector Image Processing http:\/\/t.co\/YYDjGENs (PDF)",
  "id" : 213647697482223616,
  "created_at" : "2012-06-15 15:02:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/PF3qAzME",
      "expanded_url" : "http:\/\/bit.ly\/LpJ0Of",
      "display_url" : "bit.ly\/LpJ0Of"
    } ]
  },
  "geo" : { },
  "id_str" : "213285281451868162",
  "text" : "Random input testing with R: http:\/\/t.co\/PF3qAzME #rstats",
  "id" : 213285281451868162,
  "created_at" : "2012-06-14 15:02:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/NoPK1Sl3",
      "expanded_url" : "http:\/\/bit.ly\/LpHjjQ",
      "display_url" : "bit.ly\/LpHjjQ"
    } ]
  },
  "geo" : { },
  "id_str" : "212922860916850689",
  "text" : "Design of Experiments in #rstats: http:\/\/t.co\/NoPK1Sl3 (VIDEO)",
  "id" : 212922860916850689,
  "created_at" : "2012-06-13 15:02:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/dgwXUfFU",
      "expanded_url" : "http:\/\/bitly.com\/R-ecosystem",
      "display_url" : "bitly.com\/R-ecosystem"
    } ]
  },
  "geo" : { },
  "id_str" : "212560396366778368",
  "text" : "The R Ecosystem: http:\/\/t.co\/dgwXUfFU #rstats",
  "id" : 212560396366778368,
  "created_at" : "2012-06-12 15:02:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/YfFjC5ds",
      "expanded_url" : "http:\/\/bit.ly\/LpG9Vs",
      "display_url" : "bit.ly\/LpG9Vs"
    } ]
  },
  "geo" : { },
  "id_str" : "212198152948809730",
  "text" : "How to create interactive #rstats charts on the web with RGoogleVis: http:\/\/t.co\/YfFjC5ds (PDF)",
  "id" : 212198152948809730,
  "created_at" : "2012-06-11 15:02:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "useR2012",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/3ZByFeuK",
      "expanded_url" : "http:\/\/bit.ly\/LpKeZN",
      "display_url" : "bit.ly\/LpKeZN"
    } ]
  },
  "geo" : { },
  "id_str" : "212196404922294273",
  "text" : "This week, in honour of the #useR2012 conference, we'll highlight each day a talk from last year http:\/\/t.co\/3ZByFeuK #rstats",
  "id" : 212196404922294273,
  "created_at" : "2012-06-11 14:55:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/fqFWsxV8",
      "expanded_url" : "http:\/\/bit.ly\/Lpx9Q7",
      "display_url" : "bit.ly\/Lpx9Q7"
    } ]
  },
  "geo" : { },
  "id_str" : "211110878995693568",
  "text" : "How to create or catch warnings and errors in R code: http:\/\/t.co\/fqFWsxV8 #rstats",
  "id" : 211110878995693568,
  "created_at" : "2012-06-08 15:02:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/ArEKGwSb",
      "expanded_url" : "http:\/\/bit.ly\/ubNibd",
      "display_url" : "bit.ly\/ubNibd"
    } ]
  },
  "geo" : { },
  "id_str" : "210790863880728579",
  "text" : "Example of using the twitteR package for sentiment analysis of tweets: http:\/\/t.co\/ArEKGwSb #rstats",
  "id" : 210790863880728579,
  "created_at" : "2012-06-07 17:50:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "statfact",
      "screen_name" : "statfact",
      "indices" : [ 3, 12 ],
      "id_str" : "3882163932",
      "id" : 3882163932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210482977715662848",
  "text" : "RT @StatFact: What's available in R before you load any packages? ls(envir=asNamespace(\"base\"))",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210461419211198464",
    "text" : "What's available in R before you load any packages? ls(envir=asNamespace(\"base\"))",
    "id" : 210461419211198464,
    "created_at" : "2012-06-06 20:01:27 +0000",
    "user" : {
      "name" : "Data Science Fact",
      "screen_name" : "DataSciFact",
      "protected" : false,
      "id_str" : "220139885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871521787300855809\/sMpYCCGn_normal.jpg",
      "id" : 220139885,
      "verified" : false
    }
  },
  "id" : 210482977715662848,
  "created_at" : "2012-06-06 21:27:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/WbkWctX4",
      "expanded_url" : "http:\/\/bit.ly\/H7Ako0",
      "display_url" : "bit.ly\/H7Ako0"
    } ]
  },
  "geo" : { },
  "id_str" : "210403197012017152",
  "text" : "Many functions, like \"plot\", are generic. Use methods(plot) to see all the object types that can be visualized #rstats http:\/\/t.co\/WbkWctX4",
  "id" : 210403197012017152,
  "created_at" : "2012-06-06 16:10:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/8kPR5YVx",
      "expanded_url" : "http:\/\/bit.ly\/LiAcJX",
      "display_url" : "bit.ly\/LiAcJX"
    } ]
  },
  "geo" : { },
  "id_str" : "210047719585226753",
  "text" : "A collection of tips for R beginners: http:\/\/t.co\/8kPR5YVx #rstats",
  "id" : 210047719585226753,
  "created_at" : "2012-06-05 16:37:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/eJzO7kH0",
      "expanded_url" : "http:\/\/bit.ly\/LCS4L1",
      "display_url" : "bit.ly\/LCS4L1"
    } ]
  },
  "geo" : { },
  "id_str" : "209676856750915585",
  "text" : "Tutorial: Analysis of Variance (ANOVA) for comparing the means http:\/\/t.co\/eJzO7kH0 #rstats (via @FelipeRiveroli)",
  "id" : 209676856750915585,
  "created_at" : "2012-06-04 16:03:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 93, 107 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/UuowmMUp",
      "expanded_url" : "http:\/\/bit.ly\/KGRu37",
      "display_url" : "bit.ly\/KGRu37"
    } ]
  },
  "geo" : { },
  "id_str" : "208582628599799808",
  "text" : "Get a quick visual overview of your data with the tabplot package: http:\/\/t.co\/UuowmMUp (via @JacquelynGill)",
  "id" : 208582628599799808,
  "created_at" : "2012-06-01 15:35:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]