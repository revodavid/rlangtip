Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230060542830718977",
  "geo" : { },
  "id_str" : "230316839866097665",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman Thanks!",
  "id" : 230316839866097665,
  "in_reply_to_status_id" : 230060542830718977,
  "created_at" : "2012-07-31 14:59:48 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/rwOXIHKC",
      "expanded_url" : "http:\/\/bit.ly\/OCVKRF",
      "display_url" : "bit.ly\/OCVKRF"
    } ]
  },
  "geo" : { },
  "id_str" : "230316299400654849",
  "text" : "missing(x) determines whether an argument x was supplied when a function was invoked: http:\/\/t.co\/rwOXIHKC #rstats",
  "id" : 230316299400654849,
  "created_at" : "2012-07-31 14:57:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/lXZICLS1",
      "expanded_url" : "http:\/\/bit.ly\/maI9yM",
      "display_url" : "bit.ly\/maI9yM"
    } ]
  },
  "geo" : { },
  "id_str" : "229987156423225345",
  "text" : "ESS (Emacs Speaks Statistics) is a popular add-on for working with R inside Emacs. http:\/\/t.co\/lXZICLS1 #rstats",
  "id" : 229987156423225345,
  "created_at" : "2012-07-30 17:09:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/vcKPZG4C",
      "expanded_url" : "http:\/\/bit.ly\/PENr8M",
      "display_url" : "bit.ly\/PENr8M"
    } ]
  },
  "geo" : { },
  "id_str" : "228882404780154880",
  "text" : "Trigonometric functions in R use radians. For example, cos(355) prints as -1 (and this is why: http:\/\/t.co\/vcKPZG4C ) #rstats",
  "id" : 228882404780154880,
  "created_at" : "2012-07-27 15:59:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noam Ross",
      "screen_name" : "noamross",
      "indices" : [ 0, 9 ],
      "id_str" : "97582853",
      "id" : 97582853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228576860953534464",
  "geo" : { },
  "id_str" : "228595125121585152",
  "in_reply_to_user_id" : 97582853,
  "text" : "@noamross Thanks for the tip!",
  "id" : 228595125121585152,
  "in_reply_to_status_id" : 228576860953534464,
  "created_at" : "2012-07-26 20:58:19 +0000",
  "in_reply_to_screen_name" : "noamross",
  "in_reply_to_user_id_str" : "97582853",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/NiKciq6z",
      "expanded_url" : "http:\/\/bit.ly\/M6mig1",
      "display_url" : "bit.ly\/M6mig1"
    } ]
  },
  "geo" : { },
  "id_str" : "228556428695199744",
  "text" : "To see the output when running a script file, use source(\"myscript.R\", echo=TRUE) #rstats http:\/\/t.co\/NiKciq6z",
  "id" : 228556428695199744,
  "created_at" : "2012-07-26 18:24:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/0dWxfKXY",
      "expanded_url" : "http:\/\/bit.ly\/NmbZye",
      "display_url" : "bit.ly\/NmbZye"
    } ]
  },
  "geo" : { },
  "id_str" : "228161505131130881",
  "text" : "Convert a design matrix (indicator matrix) back into a factor variable: http:\/\/t.co\/0dWxfKXY #rstats (via @therealprotonk)",
  "id" : 228161505131130881,
  "created_at" : "2012-07-25 16:15:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/pmRDe1QD",
      "expanded_url" : "http:\/\/bit.ly\/M6msE6",
      "display_url" : "bit.ly\/M6msE6"
    } ]
  },
  "geo" : { },
  "id_str" : "227795245507690496",
  "text" : "Object names in R usually contain letters, numbers, periods and underscores, but other names are possible: http:\/\/t.co\/pmRDe1QD #rstats",
  "id" : 227795245507690496,
  "created_at" : "2012-07-24 15:59:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/hlIc5bqq",
      "expanded_url" : "http:\/\/bit.ly\/NrMKyM",
      "display_url" : "bit.ly\/NrMKyM"
    } ]
  },
  "geo" : { },
  "id_str" : "227432601256853505",
  "text" : "For complex optimization problems (e.g. mixed-integer programming), try the lpSolveAPI package: http:\/\/t.co\/hlIc5bqq #rstats",
  "id" : 227432601256853505,
  "created_at" : "2012-07-23 15:58:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 115, 129 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226323391026712579",
  "text" : "Search the #rstats NEWS file from the command line: db &lt;- news(); news(grepl(\"&lt;topic&gt;\", Text), db=db) (by @joshua_ulrich)",
  "id" : 226323391026712579,
  "created_at" : "2012-07-20 14:31:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/hPVhTffN",
      "expanded_url" : "http:\/\/bit.ly\/NmhrRE",
      "display_url" : "bit.ly\/NmhrRE"
    } ]
  },
  "geo" : { },
  "id_str" : "226011688686743553",
  "text" : "Use an existing SAS script to import an ASCII data file into R (without needing SAS): http:\/\/t.co\/hPVhTffN #rstats",
  "id" : 226011688686743553,
  "created_at" : "2012-07-19 17:52:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/d2FLLIDv",
      "expanded_url" : "http:\/\/bit.ly\/Nmiq4e",
      "display_url" : "bit.ly\/Nmiq4e"
    } ]
  },
  "geo" : { },
  "id_str" : "225644071148982272",
  "text" : "To search for R-related FAQs on StackOverflow, precede your search query with [r] at http:\/\/t.co\/d2FLLIDv #rstats",
  "id" : 225644071148982272,
  "created_at" : "2012-07-18 17:31:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/bHx9iJO2",
      "expanded_url" : "http:\/\/bit.ly\/NcjzyZ",
      "display_url" : "bit.ly\/NcjzyZ"
    } ]
  },
  "geo" : { },
  "id_str" : "225243961378357251",
  "text" : "How to create animated graphics in R: http:\/\/t.co\/bHx9iJO2 (see p23) #rstats",
  "id" : 225243961378357251,
  "created_at" : "2012-07-17 15:01:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 3, 17 ],
      "id_str" : "69133574",
      "id" : 69133574
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 19, 28 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224896276121128960",
  "text" : "RT @hadleywickham: @RLangTip to=\"ASCII\/\/translit\" is handy #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "224881671634300929",
    "geo" : { },
    "id_str" : "224886413626322945",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip to=\"ASCII\/\/translit\" is handy #rstats",
    "id" : 224886413626322945,
    "in_reply_to_status_id" : 224881671634300929,
    "created_at" : "2012-07-16 15:21:13 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "protected" : false,
      "id_str" : "69133574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905186381995147264\/7zKAG5sY_normal.jpg",
      "id" : 69133574,
      "verified" : true
    }
  },
  "id" : 224896276121128960,
  "created_at" : "2012-07-16 16:00:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/4Wr4Jflw",
      "expanded_url" : "http:\/\/bit.ly\/RPbC3U",
      "display_url" : "bit.ly\/RPbC3U"
    } ]
  },
  "geo" : { },
  "id_str" : "224881671634300929",
  "text" : "Strip non-ASCII characters from a string with iconv(bad.text, to=\"ASCII\", sub=\"\") #rstats http:\/\/t.co\/4Wr4Jflw",
  "id" : 224881671634300929,
  "created_at" : "2012-07-16 15:02:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/cDDnytm2",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "223794394627710977",
  "text" : "Use the || and &amp;&amp; operators when working with scalar booleans; use | and &amp; when working with vectors #rstats http:\/\/t.co\/cDDnytm2",
  "id" : 223794394627710977,
  "created_at" : "2012-07-13 15:01:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Gombin",
      "screen_name" : "joelgombin",
      "indices" : [ 116, 127 ],
      "id_str" : "15724284",
      "id" : 15724284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223432046385709056",
  "text" : "Use readOGR() (that gets the projection) rather than readShapeSpatial() (that doesn't) to open .shp shapefiles (via @joelgombin) #rstats...",
  "id" : 223432046385709056,
  "created_at" : "2012-07-12 15:02:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/YhVPn7bl",
      "expanded_url" : "http:\/\/bit.ly\/Nm6yiE",
      "display_url" : "bit.ly\/Nm6yiE"
    } ]
  },
  "geo" : { },
  "id_str" : "223069565171671040",
  "text" : "Online index of ggplot2 functions, with charts included in the examples: http:\/\/t.co\/YhVPn7bl #rstats",
  "id" : 223069565171671040,
  "created_at" : "2012-07-11 15:01:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/AjfDBiT9",
      "expanded_url" : "http:\/\/bit.ly\/N63GcJ",
      "display_url" : "bit.ly\/N63GcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "222707152169607169",
  "text" : "R functions and packages for differential equations: ODEs, SDEs, PDEs etc: http:\/\/t.co\/AjfDBiT9 #rstats",
  "id" : 222707152169607169,
  "created_at" : "2012-07-10 15:01:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/pFx9fftk",
      "expanded_url" : "http:\/\/bit.ly\/Jz3aVm",
      "display_url" : "bit.ly\/Jz3aVm"
    } ]
  },
  "geo" : { },
  "id_str" : "222345112309608448",
  "text" : "Convert a comma-separated string to a vector: strsplit(\"red,green,blue\",\",\")[[1]] #rstats http:\/\/t.co\/pFx9fftk",
  "id" : 222345112309608448,
  "created_at" : "2012-07-09 15:03:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 54, 64 ],
      "id_str" : "62183077",
      "id" : 62183077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/pL5UZExU",
      "expanded_url" : "http:\/\/bit.ly\/NPG1Nz",
      "display_url" : "bit.ly\/NPG1Nz"
    } ]
  },
  "geo" : { },
  "id_str" : "221257621301239809",
  "text" : "R debugging tricks: http:\/\/t.co\/pL5UZExU #rstats (via @vsbuffalo)",
  "id" : 221257621301239809,
  "created_at" : "2012-07-06 15:01:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/dl63wD1p",
      "expanded_url" : "http:\/\/bit.ly\/N8v9h0",
      "display_url" : "bit.ly\/N8v9h0"
    } ]
  },
  "geo" : { },
  "id_str" : "220895205258309634",
  "text" : "Time short code snippets through replication: system.time(replicate(1000, &lt;expression&gt;)) #rstats http:\/\/t.co\/dl63wD1p",
  "id" : 220895205258309634,
  "created_at" : "2012-07-05 15:01:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/SQDR5PqA",
      "expanded_url" : "http:\/\/bit.ly\/N4cAV6",
      "display_url" : "bit.ly\/N4cAV6"
    } ]
  },
  "geo" : { },
  "id_str" : "220532889190801409",
  "text" : "Draw a map of the United States: require(maps); map('usa') #rstats http:\/\/t.co\/SQDR5PqA",
  "id" : 220532889190801409,
  "created_at" : "2012-07-04 15:01:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/T8LfDT9J",
      "expanded_url" : "http:\/\/bit.ly\/unTY2g",
      "display_url" : "bit.ly\/unTY2g"
    } ]
  },
  "geo" : { },
  "id_str" : "220170396304019456",
  "text" : "Google's style guide for R programmers: http:\/\/t.co\/T8LfDT9J #rstats",
  "id" : 220170396304019456,
  "created_at" : "2012-07-03 15:01:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/29Pi5aLM",
      "expanded_url" : "http:\/\/bit.ly\/MO2agl",
      "display_url" : "bit.ly\/MO2agl"
    } ]
  },
  "geo" : { },
  "id_str" : "219827018328576002",
  "text" : "Check which packages you have installed with names(installed.packages()[,1]) http:\/\/t.co\/29Pi5aLM #rstats",
  "id" : 219827018328576002,
  "created_at" : "2012-07-02 16:17:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]