Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/lnSc7NvJ",
      "expanded_url" : "http:\/\/bit.ly\/pOBXUl",
      "display_url" : "bit.ly\/pOBXUl"
    } ]
  },
  "geo" : { },
  "id_str" : "119788799759884288",
  "text" : "Many packages have \"vignette\" examples: use vignette() to see which installed packages have them: http:\/\/t.co\/lnSc7NvJ",
  "id" : 119788799759884288,
  "created_at" : "2011-09-30 15:00:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/tyCdMsUU",
      "expanded_url" : "http:\/\/bit.ly\/p8qFdV",
      "display_url" : "bit.ly\/p8qFdV"
    } ]
  },
  "geo" : { },
  "id_str" : "119426415077769216",
  "text" : "Use textConnection() to import data that's already stored in an R object (rather than a file): http:\/\/t.co\/tyCdMsUU #rstats",
  "id" : 119426415077769216,
  "created_at" : "2011-09-29 15:00:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution Analytics",
      "screen_name" : "RevolutionR",
      "indices" : [ 22, 34 ],
      "id_str" : "4800170479",
      "id" : 4800170479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/RYlxj2mx",
      "expanded_url" : "http:\/\/bit.ly\/qrM8X9",
      "display_url" : "bit.ly\/qrM8X9"
    } ]
  },
  "geo" : { },
  "id_str" : "119064036318003200",
  "text" : "On Windows and Linux, @RevolutionR links #rstats with Intel MKL multi-threaded libraries for faster performance: http:\/\/t.co\/RYlxj2mx",
  "id" : 119064036318003200,
  "created_at" : "2011-09-28 15:00:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/6VlqdqpV",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "118701602671575043",
  "text" : "which(x &gt; 0) returns the locations of positive elements in numeric vector x http:\/\/t.co\/6VlqdqpV #rstats",
  "id" : 118701602671575043,
  "created_at" : "2011-09-27 15:00:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 7, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/4D9txkl0",
      "expanded_url" : "http:\/\/bit.ly\/p6epvV",
      "display_url" : "bit.ly\/p6epvV"
    } ]
  },
  "geo" : { },
  "id_str" : "118339256388304896",
  "text" : "If the #rstats list \"x\" is a train carrying objects, then x[[5]] is the object in car 5; x[4:6] is a train of cars 4-6. http:\/\/t.co\/4D9txkl0",
  "id" : 118339256388304896,
  "created_at" : "2011-09-26 15:00:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117252072612691969",
  "text" : "To create a custom plot, set up axes with plot(...,type=\"n\"), then annotate with points, lines, text etc. #rstats",
  "id" : 117252072612691969,
  "created_at" : "2011-09-23 15:00:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/wQQNeprB",
      "expanded_url" : "http:\/\/bit.ly\/oIZqS4",
      "display_url" : "bit.ly\/oIZqS4"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/2W35tFGk",
      "expanded_url" : "http:\/\/bit.ly\/qVaFKO",
      "display_url" : "bit.ly\/qVaFKO"
    } ]
  },
  "geo" : { },
  "id_str" : "116889668372541440",
  "text" : "Use sink http:\/\/t.co\/wQQNeprB to direct R's output to a file, or use capture.output http:\/\/t.co\/2W35tFGk to save it in an object #rstats",
  "id" : 116889668372541440,
  "created_at" : "2011-09-22 15:00:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/lTMg274G",
      "expanded_url" : "http:\/\/bit.ly\/oa5sx5",
      "display_url" : "bit.ly\/oa5sx5"
    } ]
  },
  "geo" : { },
  "id_str" : "116527281530339328",
  "text" : "Meet other R users at a local R user group in your area: http:\/\/t.co\/lTMg274G #rstats",
  "id" : 116527281530339328,
  "created_at" : "2011-09-21 15:00:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/TNQlyAPv",
      "expanded_url" : "http:\/\/bit.ly\/rgwKt9",
      "display_url" : "bit.ly\/rgwKt9"
    } ]
  },
  "geo" : { },
  "id_str" : "116164885821394945",
  "text" : "Use lsf.str(\"package:foo\") to see a list all the functions in package foo: http:\/\/t.co\/TNQlyAPv #rstats",
  "id" : 116164885821394945,
  "created_at" : "2011-09-20 15:00:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/4tMbTjyi",
      "expanded_url" : "http:\/\/bit.ly\/qXsMe5",
      "display_url" : "bit.ly\/qXsMe5"
    } ]
  },
  "geo" : { },
  "id_str" : "115802511453061120",
  "text" : "Turn off all warnings in R with options(warn=-1), or use suppressWarnings(&lt;expr&gt;) http:\/\/t.co\/4tMbTjyi #rstats",
  "id" : 115802511453061120,
  "created_at" : "2011-09-19 15:00:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Eddelbuettel",
      "screen_name" : "eddelbuettel",
      "indices" : [ 3, 16 ],
      "id_str" : "2385131",
      "id" : 2385131
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 64, 73 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114735765321289728",
  "text" : "RT @eddelbuettel: Rscript and\/or r (from littler) are better. \u267B @RLangTip: Run an R script from the command line in batch mode with R CM ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/choqok.gnufolks.org\/\" rel=\"nofollow\"\u003EKubuntu Choqok\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 46, 55 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114716359497232385",
    "text" : "Rscript and\/or r (from littler) are better. \u267B @RLangTip: Run an R script from the command line in batch mode with R CMD BATCH #rstats",
    "id" : 114716359497232385,
    "created_at" : "2011-09-16 15:04:46 +0000",
    "user" : {
      "name" : "Dirk Eddelbuettel",
      "screen_name" : "eddelbuettel",
      "protected" : false,
      "id_str" : "2385131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509888693478248448\/rvqUa5YA_normal.jpeg",
      "id" : 2385131,
      "verified" : false
    }
  },
  "id" : 114735765321289728,
  "created_at" : "2011-09-16 16:21:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/DaU446jm",
      "expanded_url" : "http:\/\/bit.ly\/qRgbld",
      "display_url" : "bit.ly\/qRgbld"
    } ]
  },
  "geo" : { },
  "id_str" : "114715336523259904",
  "text" : "Run an R script from the command line in batch mode with R CMD BATCH: http:\/\/t.co\/DaU446jm   #rstats",
  "id" : 114715336523259904,
  "created_at" : "2011-09-16 15:00:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114352944018763776",
  "text" : "The subset function is a convenient way of selecting rows from a data frame: http:\/\/ow.ly\/67CqR  #rstats",
  "id" : 114352944018763776,
  "created_at" : "2011-09-15 15:00:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution Analytics",
      "screen_name" : "RevolutionR",
      "indices" : [ 32, 44 ],
      "id_str" : "4800170479",
      "id" : 4800170479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113990573949583360",
  "text" : "Build R Packages for Windows in @RevolutionR by selecting Build R Package from the Solution Explorer's context menu  #rstats",
  "id" : 113990573949583360,
  "created_at" : "2011-09-14 15:00:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/zdl160q",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "113628185463238656",
  "text" : "search() is an easy way to find out what packages are loaded and available for use: http:\/\/t.co\/zdl160q  #rstats",
  "id" : 113628185463238656,
  "created_at" : "2011-09-13 15:00:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/kfu0ryA",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "113265806674108417",
  "text" : "To create the list of every possible combination of levels in multiple factors, use expand.grid: http:\/\/t.co\/kfu0ryA  #rstats",
  "id" : 113265806674108417,
  "created_at" : "2011-09-12 15:00:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112178623431188480",
  "text" : "Installing R and packages on a linux box without root access: http:\/\/ow.ly\/67BWX  #rstats",
  "id" : 112178623431188480,
  "created_at" : "2011-09-09 15:00:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111816245589970944",
  "text" : "Use the args() function to get a quick reminder of a function's argument names:  http:\/\/ow.ly\/67BQN  #rstats",
  "id" : 111816245589970944,
  "created_at" : "2011-09-08 15:00:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/756RZYi",
      "expanded_url" : "http:\/\/bit.ly\/rfMShP",
      "display_url" : "bit.ly\/rfMShP"
    } ]
  },
  "geo" : { },
  "id_str" : "111453840318021632",
  "text" : "For reproducible simulations, use set.seed to start the random number sequence from a fixed point http:\/\/t.co\/756RZYi  #rstats",
  "id" : 111453840318021632,
  "created_at" : "2011-09-07 15:00:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 109 ],
      "url" : "http:\/\/t.co\/6bmd7YK",
      "expanded_url" : "http:\/\/bit.ly\/pbhQWd",
      "display_url" : "bit.ly\/pbhQWd"
    } ]
  },
  "geo" : { },
  "id_str" : "111091441413001216",
  "text" : "For tables in R like those from SAS's PROC FREQ, use CrossTable from the gmodels package: http:\/\/t.co\/6bmd7YK  #rstats",
  "id" : 111091441413001216,
  "created_at" : "2011-09-06 15:00:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution Analytics",
      "screen_name" : "RevolutionR",
      "indices" : [ 3, 15 ],
      "id_str" : "4800170479",
      "id" : 4800170479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110729148355452928",
  "text" : "In @RevolutionR for Windows, turn an R package into an editable solution with using File&gt;New&gt;Solution From Folder... #rstats",
  "id" : 110729148355452928,
  "created_at" : "2011-09-05 15:01:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/jVOQnuA",
      "expanded_url" : "http:\/\/bit.ly\/qokamy",
      "display_url" : "bit.ly\/qokamy"
    } ]
  },
  "geo" : { },
  "id_str" : "109641893910028289",
  "text" : "Not sure why your R function threw an error? Use traceback() to find out where it occurred. http:\/\/t.co\/jVOQnuA  #rstats",
  "id" : 109641893910028289,
  "created_at" : "2011-09-02 15:00:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/IqovoNI",
      "expanded_url" : "http:\/\/bit.ly\/pr0Fsj",
      "display_url" : "bit.ly\/pr0Fsj"
    } ]
  },
  "geo" : { },
  "id_str" : "109279518736384002",
  "text" : "Need to pass a whole bunch of arguments to a function, but want to select them in code? Use do.call http:\/\/t.co\/IqovoNI  #rstats",
  "id" : 109279518736384002,
  "created_at" : "2011-09-01 15:00:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]