Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/7ysDgrwSiT",
      "expanded_url" : "http:\/\/bit.ly\/8XdUan",
      "display_url" : "bit.ly\/8XdUan"
    }, {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/233FrPnHYh",
      "expanded_url" : "http:\/\/bit.ly\/YkLupC",
      "display_url" : "bit.ly\/YkLupC"
    }, {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YuhhFDEv8V",
      "expanded_url" : "http:\/\/bit.ly\/1okQ5PE",
      "display_url" : "bit.ly\/1okQ5PE"
    } ]
  },
  "geo" : { },
  "id_str" : "516981544796577793",
  "text" : "Regular expressions in R: http:\/\/t.co\/7ysDgrwSiT and  http:\/\/t.co\/233FrPnHYh and http:\/\/t.co\/YuhhFDEv8V #rstats",
  "id" : 516981544796577793,
  "created_at" : "2014-09-30 16:02:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/gMQe6C2kvv",
      "expanded_url" : "http:\/\/bit.ly\/1utKiOS",
      "display_url" : "bit.ly\/1utKiOS"
    } ]
  },
  "geo" : { },
  "id_str" : "516619742053138432",
  "text" : "Get started with foreach and parallel programming: http:\/\/t.co\/gMQe6C2kvv #rstats",
  "id" : 516619742053138432,
  "created_at" : "2014-09-29 16:05:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/8sFxO2gOSK",
      "expanded_url" : "http:\/\/bit.ly\/NOuduT",
      "display_url" : "bit.ly\/NOuduT"
    } ]
  },
  "geo" : { },
  "id_str" : "515532682206674944",
  "text" : "Use dput to archive an R object to a file; load into another R session with dget #rstats http:\/\/t.co\/8sFxO2gOSK",
  "id" : 515532682206674944,
  "created_at" : "2014-09-26 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/6AROK7nmDy",
      "expanded_url" : "http:\/\/bit.ly\/N8v9h0",
      "display_url" : "bit.ly\/N8v9h0"
    } ]
  },
  "geo" : { },
  "id_str" : "515170296425619456",
  "text" : "Time short code snippets through replication: system.time(replicate(1000, &lt;expression&gt;)) #rstats http:\/\/t.co\/6AROK7nmDy",
  "id" : 515170296425619456,
  "created_at" : "2014-09-25 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/FFn5ovfrt5",
      "expanded_url" : "http:\/\/bit.ly\/1v1euxv",
      "display_url" : "bit.ly\/1v1euxv"
    } ]
  },
  "geo" : { },
  "id_str" : "514807987094183938",
  "text" : "For base graphics, use curve(dnorm(x),add=T) to add a normal curve to a histogram #rstats http:\/\/t.co\/FFn5ovfrt5",
  "id" : 514807987094183938,
  "created_at" : "2014-09-24 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/b24RuaSUv6",
      "expanded_url" : "http:\/\/bit.ly\/1sbigr1",
      "display_url" : "bit.ly\/1sbigr1"
    } ]
  },
  "geo" : { },
  "id_str" : "514445489098743808",
  "text" : "Look here http:\/\/t.co\/b24RuaSUv6  for documentation on \"special functions\" like beta(a,b) or gamma(x) #rstats",
  "id" : 514445489098743808,
  "created_at" : "2014-09-23 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GpbjOQeCxL",
      "expanded_url" : "http:\/\/bit.ly\/1AVQlKp",
      "display_url" : "bit.ly\/1AVQlKp"
    } ]
  },
  "geo" : { },
  "id_str" : "514083063157231616",
  "text" : "To search for statistical tests in R start with help.search(keyword=\"htest\") #rstats http:\/\/t.co\/GpbjOQeCxL",
  "id" : 514083063157231616,
  "created_at" : "2014-09-22 16:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/jQv1aADsRS",
      "expanded_url" : "http:\/\/bit.ly\/I7rm0p",
      "display_url" : "bit.ly\/I7rm0p"
    } ]
  },
  "geo" : { },
  "id_str" : "512995939456679936",
  "text" : "Robust regression in R (PDF, Fox &amp; Weisberg): http:\/\/t.co\/jQv1aADsRS #rstats",
  "id" : 512995939456679936,
  "created_at" : "2014-09-19 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/zLsPhyHL0z",
      "expanded_url" : "http:\/\/bit.ly\/IS1LDg",
      "display_url" : "bit.ly\/IS1LDg"
    } ]
  },
  "geo" : { },
  "id_str" : "512633948103794688",
  "text" : "Use \\n to embed a newline within a string, e.g. cat(\"Line 1\\nLine 2\") #rstats http:\/\/t.co\/zLsPhyHL0z",
  "id" : 512633948103794688,
  "created_at" : "2014-09-18 16:07:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/vH6SSlC3j1",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "512271194981421056",
  "text" : "which(x &gt; 0) returns the locations of positive elements in numeric vector x http:\/\/t.co\/vH6SSlC3j1 #rstats",
  "id" : 512271194981421056,
  "created_at" : "2014-09-17 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/LUzOwZ3qDm",
      "expanded_url" : "http:\/\/bit.ly\/sXKxj8",
      "display_url" : "bit.ly\/sXKxj8"
    } ]
  },
  "geo" : { },
  "id_str" : "511908832638144512",
  "text" : "For precise formatting of numbers (e.g. consistent decimal places for tables), use formatC: http:\/\/t.co\/LUzOwZ3qDm #rstats",
  "id" : 511908832638144512,
  "created_at" : "2014-09-16 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/PUw1LieLz8",
      "expanded_url" : "http:\/\/bit.ly\/PJsGZY",
      "display_url" : "bit.ly\/PJsGZY"
    } ]
  },
  "geo" : { },
  "id_str" : "511546352766308353",
  "text" : "Use the testthat package to create a testing framework for R packages: http:\/\/t.co\/PUw1LieLz8 #rstats",
  "id" : 511546352766308353,
  "created_at" : "2014-09-15 16:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/kdQITJW1Kx",
      "expanded_url" : "http:\/\/bit.ly\/t0Bi1Y",
      "display_url" : "bit.ly\/t0Bi1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "510459234241490944",
  "text" : "ifelse(b,u,v) where b is a boolean expression, is a vectorized if-then-else construct: http:\/\/t.co\/kdQITJW1Kx #rstats",
  "id" : 510459234241490944,
  "created_at" : "2014-09-12 16:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/HfyGkRHHQ6",
      "expanded_url" : "http:\/\/bit.ly\/qPEhsk",
      "display_url" : "bit.ly\/qPEhsk"
    } ]
  },
  "geo" : { },
  "id_str" : "510096941787906048",
  "text" : "Use the subset() function to select rows and columns from a data frame, based on the data it contains: http:\/\/t.co\/HfyGkRHHQ6 #rstats",
  "id" : 510096941787906048,
  "created_at" : "2014-09-11 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KpaiwOxTnI",
      "expanded_url" : "http:\/\/bit.ly\/1rHzfie",
      "display_url" : "bit.ly\/1rHzfie"
    } ]
  },
  "geo" : { },
  "id_str" : "509734428915294208",
  "text" : "Use formals(foo) to get the formal arguments of a function http:\/\/t.co\/KpaiwOxTnI #rstats",
  "id" : 509734428915294208,
  "created_at" : "2014-09-10 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/OCow1r0XPA",
      "expanded_url" : "http:\/\/bit.ly\/1BgCeS4",
      "display_url" : "bit.ly\/1BgCeS4"
    } ]
  },
  "geo" : { },
  "id_str" : "509372035517403136",
  "text" : "A compact ggplot2 tutorial: http:\/\/t.co\/OCow1r0XPA #rstats",
  "id" : 509372035517403136,
  "created_at" : "2014-09-09 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/RS4LXYOpGe",
      "expanded_url" : "http:\/\/www.quandl.com\/help\/r",
      "display_url" : "quandl.com\/help\/r"
    } ]
  },
  "geo" : { },
  "id_str" : "509009630589353984",
  "text" : "Get financial data and more from Quandl with R http:\/\/t.co\/RS4LXYOpGe #rstats",
  "id" : 509009630589353984,
  "created_at" : "2014-09-08 16:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Hlppm7aYPx",
      "expanded_url" : "http:\/\/bit.ly\/oFfHWu",
      "display_url" : "bit.ly\/oFfHWu"
    } ]
  },
  "geo" : { },
  "id_str" : "507922507119489024",
  "text" : "The xmlToDataFrame function can extract data from structured XML documents http:\/\/t.co\/Hlppm7aYPx #rstats",
  "id" : 507922507119489024,
  "created_at" : "2014-09-05 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/bFLwXc7X6R",
      "expanded_url" : "http:\/\/bit.ly\/oSevHz",
      "display_url" : "bit.ly\/oSevHz"
    } ]
  },
  "geo" : { },
  "id_str" : "507559424291254272",
  "text" : "Use sqldf to select rows from a data frame using SQL syntax: http:\/\/t.co\/bFLwXc7X6R #rstats",
  "id" : 507559424291254272,
  "created_at" : "2014-09-04 16:02:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/BnFa7J2nQG",
      "expanded_url" : "http:\/\/cran.r-project.org\/src\/contrib\/3.0.3\/Recommended\/",
      "display_url" : "cran.r-project.org\/src\/contrib\/3.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507197707904385024",
  "text" : "#rstats To get the list of recommended packages for R version 3.0.3: http:\/\/t.co\/BnFa7J2nQG",
  "id" : 507197707904385024,
  "created_at" : "2014-09-03 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/VI0079Svl7",
      "expanded_url" : "http:\/\/www.inside-r.org\/r-doc",
      "display_url" : "inside-r.org\/r-doc"
    } ]
  },
  "geo" : { },
  "id_str" : "506835289567154176",
  "text" : "#rstats To get a list of R's base and recommended packages: http:\/\/t.co\/VI0079Svl7",
  "id" : 506835289567154176,
  "created_at" : "2014-09-02 16:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/FNdcMuRYOT",
      "expanded_url" : "http:\/\/bit.ly\/1B22Q98",
      "display_url" : "bit.ly\/1B22Q98"
    } ]
  },
  "geo" : { },
  "id_str" : "506472864145756161",
  "text" : "Try hcust() in the stats package for hierarchical clustering http:\/\/t.co\/FNdcMuRYOT #rstats",
  "id" : 506472864145756161,
  "created_at" : "2014-09-01 16:05:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]