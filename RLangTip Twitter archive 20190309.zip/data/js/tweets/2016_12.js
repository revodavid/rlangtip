Grailbird.data.tweets_2016_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Ftsbwxp4H7",
      "expanded_url" : "http:\/\/yihui.name\/en\/2009\/12\/happy-new-year-with-r\/",
      "display_url" : "yihui.name\/en\/2009\/12\/hap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814878727037480960",
  "text" : "An R \"Happy New Year\" greeting from Yihui Xie #rstats https:\/\/t.co\/Ftsbwxp4H7",
  "id" : 814878727037480960,
  "created_at" : "2016-12-30 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/9GYgbWo8At",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2011\/07\/a-bit-of-fun-with-r.html",
      "display_url" : "blog.revolutionanalytics.com\/2011\/07\/a-bit-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814516340048400386",
  "text" : "Some fun, non-work things you can do you do with R #rstats https:\/\/t.co\/9GYgbWo8At",
  "id" : 814516340048400386,
  "created_at" : "2016-12-29 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/WHpKrkWUC9",
      "expanded_url" : "https:\/\/www.edx.org\/course\/introduction-r-data-science-microsoft-dat204x-3#",
      "display_url" : "edx.org\/course\/introdu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "814153955068547072",
  "text" : "Free R online R course starting January 1: Introduction to R https:\/\/t.co\/WHpKrkWUC9! #rstats",
  "id" : 814153955068547072,
  "created_at" : "2016-12-28 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/7qChWrZJSf",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/eval",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "813791568863920128",
  "text" : "In scripts, wrap code in local(\u007B \u007D) to prevent temporary variables overwriting global data: https:\/\/t.co\/7qChWrZJSf #rstats",
  "id" : 813791568863920128,
  "created_at" : "2016-12-27 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LfvUVq9MJv",
      "expanded_url" : "http:\/\/www.r-graph-gallery.com\/",
      "display_url" : "r-graph-gallery.com"
    } ]
  },
  "geo" : { },
  "id_str" : "813429181103149056",
  "text" : "Find many examples of R charts (with code) at the R Graph Gallery https:\/\/t.co\/LfvUVq9MJv #rstats",
  "id" : 813429181103149056,
  "created_at" : "2016-12-26 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EEB&Flow",
      "screen_name" : "EEB_Flow",
      "indices" : [ 36, 45 ],
      "id_str" : "92676153",
      "id" : 92676153
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RLangTip\/status\/812342008484282368\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9Ym1PECw4G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0ED-3ZUkAAXyuI.jpg",
      "id_str" : "810933786460327936",
      "id" : 810933786460327936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0ED-3ZUkAAXyuI.jpg",
      "sizes" : [ {
        "h" : 642,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 735,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 735,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 735,
        "resize" : "fit",
        "w" : 778
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/9Ym1PECw4G"
    } ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/OxTuNp4cFu",
      "expanded_url" : "http:\/\/evol-eco.blogspot.com\/2016\/12\/2016-holiday-card.html",
      "display_url" : "evol-eco.blogspot.com\/2016\/12\/2016-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812342008484282368",
  "text" : "A holiday wreath, created with R by @EEB_Flow https:\/\/t.co\/OxTuNp4cFu #rstats https:\/\/t.co\/9Ym1PECw4G",
  "id" : 812342008484282368,
  "created_at" : "2016-12-23 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/DAtjNI7Wxe",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/traceback",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811979623982452736",
  "text" : "Not sure why your R function threw an error? Use traceback() to find out where it occurred https:\/\/t.co\/DAtjNI7Wxe #rstats",
  "id" : 811979623982452736,
  "created_at" : "2016-12-22 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/v7dOXjNtRI",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/operationalize\/app-developer-get-started",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811617238780432385",
  "text" : "How to use API Client libraries from Swagger to integrate R into applications with Microsoft R Server https:\/\/t.co\/v7dOXjNtRI #rstats",
  "id" : 811617238780432385,
  "created_at" : "2016-12-21 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/jRPUNzRDCs",
      "expanded_url" : "https:\/\/www.ggplot2-exts.org\/gganimate.html",
      "display_url" : "ggplot2-exts.org\/gganimate.html"
    } ]
  },
  "geo" : { },
  "id_str" : "811254854936973312",
  "text" : "Use the gganimate package to create animations from ggplot2 charts https:\/\/t.co\/jRPUNzRDCs #rstats",
  "id" : 811254854936973312,
  "created_at" : "2016-12-20 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/6fIRefjZPF",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/gR.html",
      "display_url" : "cran.r-project.org\/web\/views\/gR.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "810892460591153152",
  "text" : "List of R packages related to networks, graphs, Bayesian models, and flow diagrams: https:\/\/t.co\/6fIRefjZPF #rstats",
  "id" : 810892460591153152,
  "created_at" : "2016-12-19 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/meQm97lC9w",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/which",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809805301105000453",
  "text" : "which(x &gt; 0) returns the locations of positive elements in numeric vector x https:\/\/t.co\/meQm97lC9w #rstats",
  "id" : 809805301105000453,
  "created_at" : "2016-12-16 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/HxyxaOxlBS",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.3.1\/topics\/Poisson",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809442909598584832",
  "text" : "Use rpois(n,lambda) to generate n random draws from a Poisson distribution with rate lambda https:\/\/t.co\/HxyxaOxlBS #rstats",
  "id" : 809442909598584832,
  "created_at" : "2016-12-15 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/xkNkBaie6T",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/microsoftml-algorithm-cheat-sheet",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "809080527567384577",
  "text" : "Cheat sheet for machine learning functions in Microsoft R's MicrosoftML package https:\/\/t.co\/xkNkBaie6T #rstats",
  "id" : 809080527567384577,
  "created_at" : "2016-12-14 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "indices" : [ 37, 49 ],
      "id_str" : "152862026",
      "id" : 152862026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Rx3IC59FZI",
      "expanded_url" : "http:\/\/motioninsocial.com\/tufte\/",
      "display_url" : "motioninsocial.com\/tufte\/"
    } ]
  },
  "geo" : { },
  "id_str" : "808718131195760641",
  "text" : "How to create charts in the style of @edwardtufte with R: https:\/\/t.co\/Rx3IC59FZI #rstats",
  "id" : 808718131195760641,
  "created_at" : "2016-12-13 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/oqaDXSSlbP",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/1295955\/what-is-the-most-useful-r-trick",
      "display_url" : "stackoverflow.com\/questions\/1295\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "808355749265031168",
  "text" : "The most useful R tricks, according to StackOverflow https:\/\/t.co\/oqaDXSSlbP #rstats",
  "id" : 808355749265031168,
  "created_at" : "2016-12-12 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/qELSOX0RKt",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.2\/topics\/combn",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "807268589455769602",
  "text" : "Use combn(1:n,m) to find all combinations of the first n numbers taken m at a time https:\/\/t.co\/qELSOX0RKt #rstats",
  "id" : 807268589455769602,
  "created_at" : "2016-12-09 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CmUhFoNsfg",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/tables\/versions\/0.7.92\/topics\/tabular",
      "display_url" : "rdocumentation.org\/packages\/table\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "806906199539142656",
  "text" : "The \"tabular\" function generates crosstabs with summary stats a la SAS PROC TABULATE #rstats https:\/\/t.co\/CmUhFoNsfg",
  "id" : 806906199539142656,
  "created_at" : "2016-12-08 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/WRvwJiNKxe",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/grDevices\/versions\/3.3.2\/topics\/plotmath",
      "display_url" : "rdocumentation.org\/packages\/grDev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "806543819177074688",
  "text" : "See demo(plotmath) for examples of mathematics (exponents, greek symbols etc) in #rstats plots https:\/\/t.co\/WRvwJiNKxe",
  "id" : 806543819177074688,
  "created_at" : "2016-12-07 17:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/cJAB5tOFT6",
      "expanded_url" : "https:\/\/www.ggplot2-exts.org\/ggTimeSeries.html",
      "display_url" : "ggplot2-exts.org\/ggTimeSeries.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "806181421551263744",
  "text" : "Calendar heat maps, stream graphs, and other ggplot2 extensions for time series https:\/\/t.co\/cJAB5tOFT6 #rstats",
  "id" : 806181421551263744,
  "created_at" : "2016-12-06 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/ozMD0bkGEZ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Arithmetic",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805819043013750784",
  "text" : "%% is the integer modulus function. 12 %% 5 returns 2 https:\/\/t.co\/ozMD0bkGEZ #rstats",
  "id" : 805819043013750784,
  "created_at" : "2016-12-05 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/HgZO0k5L8K",
      "expanded_url" : "http:\/\/rseek.org\/",
      "display_url" : "rseek.org"
    } ]
  },
  "geo" : { },
  "id_str" : "804731877105876992",
  "text" : "Search the web for information specific to R https:\/\/t.co\/HgZO0k5L8K #rstats",
  "id" : 804731877105876992,
  "created_at" : "2016-12-02 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804369482798039040",
  "text" : "Explore the capabilities of your installed R packages with browseVignettes() #rstats",
  "id" : 804369482798039040,
  "created_at" : "2016-12-01 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]