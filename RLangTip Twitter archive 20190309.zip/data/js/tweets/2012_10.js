Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/P5hYT3wM",
      "expanded_url" : "http:\/\/bit.ly\/PF2fa7",
      "display_url" : "bit.ly\/PF2fa7"
    } ]
  },
  "geo" : { },
  "id_str" : "263675850480824320",
  "text" : "Create a Halloween card with #rstats: http:\/\/t.co\/P5hYT3wM",
  "id" : 263675850480824320,
  "created_at" : "2012-10-31 16:16:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/yW2y4ypp",
      "expanded_url" : "http:\/\/bit.ly\/sXKxj8",
      "display_url" : "bit.ly\/sXKxj8"
    } ]
  },
  "geo" : { },
  "id_str" : "263316018573737984",
  "text" : "Format numbers \"v\" as currency, like $2,101,944: gsub(\"^ *\",\"$\",prettyNum(v, big.mark=\",\")) #rstats http:\/\/t.co\/yW2y4ypp",
  "id" : 263316018573737984,
  "created_at" : "2012-10-30 16:26:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/BeIoaY26",
      "expanded_url" : "http:\/\/bit.ly\/TCNTZ4",
      "display_url" : "bit.ly\/TCNTZ4"
    } ]
  },
  "geo" : { },
  "id_str" : "262953618028765185",
  "text" : "Details of how method dispatch works for objects in R: http:\/\/t.co\/BeIoaY26 #rstats",
  "id" : 262953618028765185,
  "created_at" : "2012-10-29 16:26:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/WbkWctX4",
      "expanded_url" : "http:\/\/bit.ly\/H7Ako0",
      "display_url" : "bit.ly\/H7Ako0"
    } ]
  },
  "geo" : { },
  "id_str" : "261814541988552704",
  "text" : "Use methods(class='lm') to list all the special operations available on \"lm\" regression objects: http:\/\/t.co\/WbkWctX4",
  "id" : 261814541988552704,
  "created_at" : "2012-10-26 13:00:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/sYGhUSg3",
      "expanded_url" : "http:\/\/bit.ly\/qjhWGI",
      "display_url" : "bit.ly\/qjhWGI"
    } ]
  },
  "geo" : { },
  "id_str" : "261451181073784832",
  "text" : "In R, NA represents missing values. To check for NA's, use the is.na function, not the == operator http:\/\/t.co\/sYGhUSg3 #rstats",
  "id" : 261451181073784832,
  "created_at" : "2012-10-25 12:56:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/zfPEAMVf",
      "expanded_url" : "http:\/\/ow.ly\/6244Q",
      "display_url" : "ow.ly\/6244Q"
    } ]
  },
  "geo" : { },
  "id_str" : "261084765686476800",
  "text" : "Use str(obj) to display the components of any object in human-readable format. http:\/\/t.co\/zfPEAMVf #rstats",
  "id" : 261084765686476800,
  "created_at" : "2012-10-24 12:40:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/5p5qk25t",
      "expanded_url" : "http:\/\/bit.ly\/TbbAFO",
      "display_url" : "bit.ly\/TbbAFO"
    } ]
  },
  "geo" : { },
  "id_str" : "260743968655020035",
  "text" : "Not sure where to add text or other annotations to your #rstats chart? Use 'locator' to pinpoint with the mouse: http:\/\/t.co\/5p5qk25t",
  "id" : 260743968655020035,
  "created_at" : "2012-10-23 14:06:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Eddelbuettel",
      "screen_name" : "eddelbuettel",
      "indices" : [ 3, 16 ],
      "id_str" : "2385131",
      "id" : 2385131
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 18, 27 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260444651209760768",
  "text" : "RT @eddelbuettel: @RLangTip Or use package latticeExtra which had a chart theme styles after The Econmist for long time.  #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "260413725582966785",
    "geo" : { },
    "id_str" : "260430444980498432",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip Or use package latticeExtra which had a chart theme styles after The Econmist for long time.  #rstats",
    "id" : 260430444980498432,
    "in_reply_to_status_id" : 260413725582966785,
    "created_at" : "2012-10-22 17:20:31 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Dirk Eddelbuettel",
      "screen_name" : "eddelbuettel",
      "protected" : false,
      "id_str" : "2385131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509888693478248448\/rvqUa5YA_normal.jpeg",
      "id" : 2385131,
      "verified" : false
    }
  },
  "id" : 260444651209760768,
  "created_at" : "2012-10-22 18:16:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/hbzKWAyi",
      "expanded_url" : "http:\/\/bit.ly\/QL8NSF",
      "display_url" : "bit.ly\/QL8NSF"
    } ]
  },
  "geo" : { },
  "id_str" : "260413725582966785",
  "text" : "Use ggplot 'Themes' to draw your #rstats charts in the style of publications like \"The Economist\": http:\/\/t.co\/hbzKWAyi",
  "id" : 260413725582966785,
  "created_at" : "2012-10-22 16:14:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/k1zqbn3U",
      "expanded_url" : "http:\/\/bit.ly\/WzSaeR",
      "display_url" : "bit.ly\/WzSaeR"
    } ]
  },
  "geo" : { },
  "id_str" : "259324124218925057",
  "text" : "Include .progress=\"text\" as an argument to many plyr functions to display a progress bar during computation: http:\/\/t.co\/k1zqbn3U #rstats",
  "id" : 259324124218925057,
  "created_at" : "2012-10-19 16:04:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/6F21GuKm",
      "expanded_url" : "http:\/\/bit.ly\/Qs64Kj",
      "display_url" : "bit.ly\/Qs64Kj"
    } ]
  },
  "geo" : { },
  "id_str" : "258961038144311296",
  "text" : "The ddply function (in package plyr) makes aggregating rows of data (e.g. medians by group) simpler: http:\/\/t.co\/6F21GuKm",
  "id" : 258961038144311296,
  "created_at" : "2012-10-18 16:01:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 97, 111 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/TnNtIDVp",
      "expanded_url" : "http:\/\/bit.ly\/Xob3Rq",
      "display_url" : "bit.ly\/Xob3Rq"
    } ]
  },
  "geo" : { },
  "id_str" : "258598355012308993",
  "text" : "Tips on writing efficient #rstats code (from R co-creator Ross Ihaka): http:\/\/t.co\/TnNtIDVp (via @hadleywickham)",
  "id" : 258598355012308993,
  "created_at" : "2012-10-17 16:00:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/kiG56haD",
      "expanded_url" : "http:\/\/bit.ly\/OET7Ri",
      "display_url" : "bit.ly\/OET7Ri"
    } ]
  },
  "geo" : { },
  "id_str" : "258221089845542912",
  "text" : "Use the integrate function to calculate the area under a curve: http:\/\/t.co\/kiG56haD #rstats",
  "id" : 258221089845542912,
  "created_at" : "2012-10-16 15:01:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noam Ross",
      "screen_name" : "noamross",
      "indices" : [ 126, 135 ],
      "id_str" : "97582853",
      "id" : 97582853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/kR2pLmWp",
      "expanded_url" : "http:\/\/bit.ly\/PxLttn",
      "display_url" : "bit.ly\/PxLttn"
    } ]
  },
  "geo" : { },
  "id_str" : "257876924498604032",
  "text" : "A progress bar that shows only in the console: if(interactive) \u007Bpb &lt;- txtProgressBar(\u2026)\u007D #rstats http:\/\/t.co\/kR2pLmWp (via @noamross)",
  "id" : 257876924498604032,
  "created_at" : "2012-10-15 16:13:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/h5yrtLAT",
      "expanded_url" : "http:\/\/bit.ly\/Pq3v0n",
      "display_url" : "bit.ly\/Pq3v0n"
    } ]
  },
  "geo" : { },
  "id_str" : "256785153056190464",
  "text" : "How to calculate Prob(X &gt; Y) where X and Y are Gamma distributed: http:\/\/t.co\/h5yrtLAT #rstats",
  "id" : 256785153056190464,
  "created_at" : "2012-10-12 15:55:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Excel",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/1NzOsYMD",
      "expanded_url" : "http:\/\/bit.ly\/Pq2LbK",
      "display_url" : "bit.ly\/Pq2LbK"
    } ]
  },
  "geo" : { },
  "id_str" : "256427821046575107",
  "text" : "Video: Getting familiar with R's user interface, for Microsoft #Excel users: http:\/\/t.co\/1NzOsYMD #rstats",
  "id" : 256427821046575107,
  "created_at" : "2012-10-11 16:15:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark the Graph",
      "screen_name" : "Mark_Graph",
      "indices" : [ 45, 56 ],
      "id_str" : "522124915",
      "id" : 522124915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/pMOA8EHa",
      "expanded_url" : "http:\/\/bit.ly\/UzCoCj",
      "display_url" : "bit.ly\/UzCoCj"
    } ]
  },
  "geo" : { },
  "id_str" : "256077251190341632",
  "text" : "Cheat sheet on working with factors in R (by @Mark_Graph): http:\/\/t.co\/pMOA8EHa #rstats",
  "id" : 256077251190341632,
  "created_at" : "2012-10-10 17:02:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Lemaitre",
      "screen_name" : "joshlemaitre",
      "indices" : [ 112, 125 ],
      "id_str" : "21264652",
      "id" : 21264652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/CvGnNW2e",
      "expanded_url" : "http:\/\/bit.ly\/QKKDsn",
      "display_url" : "bit.ly\/QKKDsn"
    } ]
  },
  "geo" : { },
  "id_str" : "255699491582267393",
  "text" : "Forgot to save the output from the last #rstats command? Retrieve it with .Last.value http:\/\/t.co\/CvGnNW2e (via @joshlemaitre)",
  "id" : 255699491582267393,
  "created_at" : "2012-10-09 16:01:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/GuAeBYmZ",
      "expanded_url" : "http:\/\/bit.ly\/RDGBB8",
      "display_url" : "bit.ly\/RDGBB8"
    } ]
  },
  "geo" : { },
  "id_str" : "255346053539328000",
  "text" : "Use model.matrix to convert factors into binary indicator columns in a matrix: http:\/\/t.co\/GuAeBYmZ #rstats",
  "id" : 255346053539328000,
  "created_at" : "2012-10-08 16:36:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/G8gnzmSL",
      "expanded_url" : "http:\/\/bit.ly\/RE2H6l",
      "display_url" : "bit.ly\/RE2H6l"
    } ]
  },
  "geo" : { },
  "id_str" : "254272140038262784",
  "text" : "Use \"deriv\" to create a function that returns the derivative and hessian of a symbolic expression: http:\/\/t.co\/G8gnzmSL #rstats",
  "id" : 254272140038262784,
  "created_at" : "2012-10-05 17:29:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/acJpZW8C",
      "expanded_url" : "http:\/\/bit.ly\/Svpkai",
      "display_url" : "bit.ly\/Svpkai"
    } ]
  },
  "geo" : { },
  "id_str" : "253887144542744576",
  "text" : "Visualize a 3-D surface with the persp function: http:\/\/t.co\/acJpZW8C #rstats",
  "id" : 253887144542744576,
  "created_at" : "2012-10-04 15:59:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/3zDLiG0I",
      "expanded_url" : "http:\/\/bit.ly\/SAFtuh",
      "display_url" : "bit.ly\/SAFtuh"
    } ]
  },
  "geo" : { },
  "id_str" : "253555219319902208",
  "text" : "Customize your R environment with these suggestions for your .Rprofile: http:\/\/t.co\/3zDLiG0I #rstats",
  "id" : 253555219319902208,
  "created_at" : "2012-10-03 18:00:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/aGfhfa8w",
      "expanded_url" : "http:\/\/bit.ly\/TNcLO8",
      "display_url" : "bit.ly\/TNcLO8"
    } ]
  },
  "geo" : { },
  "id_str" : "253163765321830400",
  "text" : "Find the list of changes in the forthcoming release of R (R-devel) here: http:\/\/t.co\/aGfhfa8w #rstats",
  "id" : 253163765321830400,
  "created_at" : "2012-10-02 16:05:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/HWixGuzE",
      "expanded_url" : "http:\/\/bit.ly\/TN8ryt",
      "display_url" : "bit.ly\/TN8ryt"
    } ]
  },
  "geo" : { },
  "id_str" : "252802159148683264",
  "text" : "Resources for spatial data analysis with R: http:\/\/t.co\/HWixGuzE #rstats",
  "id" : 252802159148683264,
  "created_at" : "2012-10-01 16:08:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]