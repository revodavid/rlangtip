Grailbird.data.tweets_2018_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ANF2CwL3BD",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/write.table",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "979750096890863616",
  "text" : "Print a human-readable version of a matrix: write.table(format(X), row.names=F, col.names=F, quote=F) #rstats https:\/\/t.co\/ANF2CwL3BD",
  "id" : 979750096890863616,
  "created_at" : "2018-03-30 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/NWr8c3NfJy",
      "expanded_url" : "http:\/\/web.warwick.ac.uk\/statsdept\/user-2011\/TalkSlides\/Contributed\/18Aug_1400_KaleidIIIb_2-Murrell.pdf",
      "display_url" : "web.warwick.ac.uk\/statsdept\/user\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "979387711688663040",
  "text" : "Extracting data from PDF graphics with #rstats. Vector Image Processing https:\/\/t.co\/NWr8c3NfJy (PDF)",
  "id" : 979387711688663040,
  "created_at" : "2018-03-29 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/K4B4VXeRrj",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/machine-learning-server\/r\/tutorial-large-data-tips",
      "display_url" : "docs.microsoft.com\/en-us\/machine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "979025330433269761",
  "text" : "Tips on computing with big data in R https:\/\/t.co\/K4B4VXeRrj #rstats",
  "id" : 979025330433269761,
  "created_at" : "2018-03-28 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Silge",
      "screen_name" : "juliasilge",
      "indices" : [ 30, 41 ],
      "id_str" : "13074042",
      "id" : 13074042
    }, {
      "name" : "David Robinson",
      "screen_name" : "drob",
      "indices" : [ 46, 51 ],
      "id_str" : "46245868",
      "id" : 46245868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/eOKV5QyPBH",
      "expanded_url" : "https:\/\/www.tidytextmining.com\/",
      "display_url" : "tidytextmining.com"
    } ]
  },
  "geo" : { },
  "id_str" : "978662938197331968",
  "text" : "Text Mining with R, a book by @juliasilge and @drob https:\/\/t.co\/eOKV5QyPBH #rstats",
  "id" : 978662938197331968,
  "created_at" : "2018-03-27 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/wFn6X4dFHr",
      "expanded_url" : "https:\/\/stackoverflow.com\/questions\/4862178\/remove-rows-with-nas-missing-values-in-data-frame",
      "display_url" : "stackoverflow.com\/questions\/4862\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "978300562222534656",
  "text" : "Know the difference between complete.cases() and na.omit() when handling missing values in data frames #rstats https:\/\/t.co\/wFn6X4dFHr",
  "id" : 978300562222534656,
  "created_at" : "2018-03-26 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "977253646424559616",
  "text" : "Check which packages you have installed with row.names(installed.packages()) #rstats",
  "id" : 977253646424559616,
  "created_at" : "2018-03-23 18:40:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Cj1p3ELC1w",
      "expanded_url" : "https:\/\/mran.microsoft.com\/rro\/installed",
      "display_url" : "mran.microsoft.com\/rro\/installed"
    } ]
  },
  "geo" : { },
  "id_str" : "976851005852667904",
  "text" : "A list of R's base and recommended packages, and the extra packages bundled with Microsoft R Open https:\/\/t.co\/Cj1p3ELC1w",
  "id" : 976851005852667904,
  "created_at" : "2018-03-22 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 143, 150 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/68Qa95pwY2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.3\/topics\/vcov",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "976488617781608448",
  "text" : "vcov(obj) returns the variance-covariance matrix for the parameters of lm, glm, nls, lme and several other model types https:\/\/t.co\/68Qa95pwY2 #rstats",
  "id" : 976488617781608448,
  "created_at" : "2018-03-21 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/rkNalt5Nl8",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/ModelDeployment.html",
      "display_url" : "cran.r-project.org\/web\/views\/Mode\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "976126234219503620",
  "text" : "Functions and packages for model deployment with R: a CRAN Task View https:\/\/t.co\/rkNalt5Nl8 #rstats",
  "id" : 976126234219503620,
  "created_at" : "2018-03-20 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Eg5Z4GJpxw",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/abbreviate",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "975763832172761088",
  "text" : "abbreviate(x,n) returns readable and unique abbreviations of the strings in x, of length n or more https:\/\/t.co\/Eg5Z4GJpxw #rstats",
  "id" : 975763832172761088,
  "created_at" : "2018-03-19 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "974676678084628481",
  "text" : "You can use single-quotes to delimit a string. Handy for including double-quotes, 'like \"this\" trick' #rstats",
  "id" : 974676678084628481,
  "created_at" : "2018-03-16 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/C56ElX2EEe",
      "expanded_url" : "https:\/\/cda.ms\/hJ",
      "display_url" : "cda.ms\/hJ"
    } ]
  },
  "geo" : { },
  "id_str" : "974314290512650240",
  "text" : "How to build a local subset of CRAN, and access R packages behind a corporate firewall https:\/\/t.co\/C56ElX2EEe #rstats",
  "id" : 974314290512650240,
  "created_at" : "2018-03-15 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 155, 162 ]
    } ],
    "urls" : [ {
      "indices" : [ 163, 186 ],
      "url" : "https:\/\/t.co\/MB4AuEW76J",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/Rmpfr",
      "display_url" : "mran.microsoft.com\/package\/Rmpfr"
    } ]
  },
  "geo" : { },
  "id_str" : "973951904223932416",
  "text" : "The Rmpfr package provides arbitrary-precision floating point calculations in R. Here's \u03C0 with 3321 bits of precision Pi &lt;- Const(\"pi\", 1000 *log2(10)) #rstats https:\/\/t.co\/MB4AuEW76J",
  "id" : 973951904223932416,
  "created_at" : "2018-03-14 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 54, 68 ],
      "id_str" : "69133574",
      "id" : 69133574
    }, {
      "name" : "Garrett Grolemund",
      "screen_name" : "StatGarrett",
      "indices" : [ 73, 85 ],
      "id_str" : "2499047479",
      "id" : 2499047479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xVitkNgtKB",
      "expanded_url" : "http:\/\/r4ds.had.co.nz\/",
      "display_url" : "r4ds.had.co.nz"
    } ]
  },
  "geo" : { },
  "id_str" : "973589511929237506",
  "text" : "\"R for data science\", a book on tidy data analysis by @hadleywickham and @StatGarrett https:\/\/t.co\/xVitkNgtKB #rstats",
  "id" : 973589511929237506,
  "created_at" : "2018-03-13 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 138, 145 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/WVP7Rd2yrs",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/",
      "display_url" : "cran.r-project.org\/web\/views\/"
    } ]
  },
  "geo" : { },
  "id_str" : "973227115415068673",
  "text" : "Check out CRAN Task Views for curated lists of R packages by topic area (Bayesian, Finance, Web Technologies etc) https:\/\/t.co\/WVP7Rd2yrs #rstats",
  "id" : 973227115415068673,
  "created_at" : "2018-03-12 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/ddcDn1AGHY",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.3\/topics\/model.matrix",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "972155071512399873",
  "text" : "\"One-hot encoding\" in R: model.matrix converts factors into binary indicator columns in a matrix: https:\/\/t.co\/ddcDn1AGHY #rstats",
  "id" : 972155071512399873,
  "created_at" : "2018-03-09 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/5BDUj7WrQf",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/ns-dblcolon",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "971792678571659266",
  "text" : "Avoid namespace clashes! Use :: to specify an object within a specific package, e.g. MASS::mvnorm https:\/\/t.co\/5BDUj7WrQf #rstats",
  "id" : 971792678571659266,
  "created_at" : "2018-03-08 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/34ozzzs5ud",
      "expanded_url" : "https:\/\/cran.microsoft.com",
      "display_url" : "cran.microsoft.com"
    } ]
  },
  "geo" : { },
  "id_str" : "971430274327224321",
  "text" : "Microsoft R Open installs packages from an static CRAN archive by default. Get the latest with install.packages(\"thepackage\", repos=\"https:\/\/t.co\/34ozzzs5ud\") or just change the default CRAN repository.",
  "id" : 971430274327224321,
  "created_at" : "2018-03-07 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/brdYX6IWQa",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/sample",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "971067894808264704",
  "text" : "sample(vec, n) will randomly select elements n elements from a vector #rstats https:\/\/t.co\/brdYX6IWQa",
  "id" : 971067894808264704,
  "created_at" : "2018-03-06 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Sense",
      "screen_name" : "flosense",
      "indices" : [ 0, 9 ],
      "id_str" : "712732875062452224",
      "id" : 712732875062452224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "970714694192455681",
  "geo" : { },
  "id_str" : "970735060398854145",
  "in_reply_to_user_id" : 712732875062452224,
  "text" : "@flosense Thanks for the feedback. If you can suggest more suitable wording, we'll use that next time this tip is posted.",
  "id" : 970735060398854145,
  "in_reply_to_status_id" : 970714694192455681,
  "created_at" : "2018-03-05 18:57:28 +0000",
  "in_reply_to_screen_name" : "flosense",
  "in_reply_to_user_id_str" : "712732875062452224",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/EeqTaufus2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.3\/topics\/prop.test",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "970705502396182530",
  "text" : "Use prop.test to test whether incidences within groups are equal: https:\/\/t.co\/EeqTaufus2 #rstats",
  "id" : 970705502396182530,
  "created_at" : "2018-03-05 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/2YmatQKq7l",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/numbers\/versions\/0.6-6\/topics\/coprime",
      "display_url" : "rdocumentation.org\/packages\/numbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "969618345925292032",
  "text" : "Determine whether two integers m and n are relatively prime or coprime with coprime(m,n) #rstats https:\/\/t.co\/2YmatQKq7l",
  "id" : 969618345925292032,
  "created_at" : "2018-03-02 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/OlY9S6Na2G",
      "expanded_url" : "https:\/\/ropensci.org\/blog\/2017\/07\/11\/skimr\/",
      "display_url" : "ropensci.org\/blog\/2017\/07\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "969255969564844032",
  "text" : "Get a quick overview of a data set with the skimr package https:\/\/t.co\/OlY9S6Na2G #rstats",
  "id" : 969255969564844032,
  "created_at" : "2018-03-01 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]