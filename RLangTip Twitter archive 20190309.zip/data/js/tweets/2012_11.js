Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/6HztUbYA",
      "expanded_url" : "http:\/\/bit.ly\/QvipSJ",
      "display_url" : "bit.ly\/QvipSJ"
    } ]
  },
  "geo" : { },
  "id_str" : "274554705319964672",
  "text" : "ggplot2 examples of bar charts, scatterplots, histograms, density plots and more: http:\/\/t.co\/6HztUbYA #rstats",
  "id" : 274554705319964672,
  "created_at" : "2012-11-30 16:45:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/aVhUlGOP",
      "expanded_url" : "http:\/\/cran.revolutionanalytics.com",
      "display_url" : "cran.revolutionanalytics.com"
    } ]
  },
  "geo" : { },
  "id_str" : "274236485136416768",
  "text" : "options(repos=\"http:\/\/t.co\/aVhUlGOP\") [or your local mirror] in .Rprofile prevents #rstats prompting on package install",
  "id" : 274236485136416768,
  "created_at" : "2012-11-29 19:40:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 112, 126 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/iB8iffBT",
      "expanded_url" : "http:\/\/bit.ly\/TqVLZ3",
      "display_url" : "bit.ly\/TqVLZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "273827292927623169",
  "text" : "If two packages define functions with the same name, use :: to call the one you want: http:\/\/t.co\/iB8iffBT (via @joshua_ulrich) #rstats",
  "id" : 273827292927623169,
  "created_at" : "2012-11-28 16:34:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/uTmSW4NL",
      "expanded_url" : "http:\/\/bit.ly\/WWkU3m",
      "display_url" : "bit.ly\/WWkU3m"
    } ]
  },
  "geo" : { },
  "id_str" : "273475317480452096",
  "text" : "On a Mac, read from the clipboard with readLines(pipe(\"pbpaste\")) #rstats http:\/\/t.co\/uTmSW4NL",
  "id" : 273475317480452096,
  "created_at" : "2012-11-27 17:16:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/tbQAU8Nn",
      "expanded_url" : "http:\/\/bit.ly\/pbemkM",
      "display_url" : "bit.ly\/pbemkM"
    } ]
  },
  "geo" : { },
  "id_str" : "273112916906110976",
  "text" : "options(stringsAsFactors=FALSE) will force R to always import character data as character objects: http:\/\/t.co\/tbQAU8Nn #rstats",
  "id" : 273112916906110976,
  "created_at" : "2012-11-26 17:16:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/3HVMC5EU",
      "expanded_url" : "http:\/\/bit.ly\/uf2eFb",
      "display_url" : "bit.ly\/uf2eFb"
    } ]
  },
  "geo" : { },
  "id_str" : "272017964528717824",
  "text" : "There is a Wikipedia page for R at http:\/\/t.co\/3HVMC5EU #rstats",
  "id" : 272017964528717824,
  "created_at" : "2012-11-23 16:45:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/a6Xyi1Gs",
      "expanded_url" : "http:\/\/bit.ly\/uG6J1C",
      "display_url" : "bit.ly\/uG6J1C"
    } ]
  },
  "geo" : { },
  "id_str" : "271644323135778816",
  "text" : "The holiday function in the timeDate package looks up holiday dates, e.g. holiday(2012,\"USThanksgivingDay\") http:\/\/t.co\/a6Xyi1Gs #rstats",
  "id" : 271644323135778816,
  "created_at" : "2012-11-22 16:00:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/vp1j5QM9",
      "expanded_url" : "http:\/\/bit.ly\/vkHZxy",
      "display_url" : "bit.ly\/vkHZxy"
    } ]
  },
  "geo" : { },
  "id_str" : "271289804040323072",
  "text" : "The tryCatch function lets an R programmer respond to an error without crashing back to the interpreter: http:\/\/t.co\/vp1j5QM9 #rstats",
  "id" : 271289804040323072,
  "created_at" : "2012-11-21 16:31:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/6FWYQ5By",
      "expanded_url" : "http:\/\/bit.ly\/Sa02k9",
      "display_url" : "bit.ly\/Sa02k9"
    } ]
  },
  "geo" : { },
  "id_str" : "270960752532271104",
  "text" : "Not sure which CRAN mirror to use? Visit http:\/\/t.co\/6FWYQ5By, the default \"current mirror\" is closest to you. #rstats",
  "id" : 270960752532271104,
  "created_at" : "2012-11-20 18:44:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iBartomeus",
      "screen_name" : "ibartomeus",
      "indices" : [ 119, 130 ],
      "id_str" : "14226594",
      "id" : 14226594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/VeOQU3B2",
      "expanded_url" : "http:\/\/bit.ly\/QTueDq",
      "display_url" : "bit.ly\/QTueDq"
    } ]
  },
  "geo" : { },
  "id_str" : "270574263600291842",
  "text" : "Select only rows of a data frame without any missing values: df[complete.cases(df),] #rstats http:\/\/t.co\/VeOQU3B2 (via @ibartomeus)",
  "id" : 270574263600291842,
  "created_at" : "2012-11-19 17:08:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Rowlingson\uD83D\uDC3A",
      "screen_name" : "geospacedman",
      "indices" : [ 56, 69 ],
      "id_str" : "88731801",
      "id" : 88731801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/1V465JcU",
      "expanded_url" : "http:\/\/bit.ly\/RYUtGK",
      "display_url" : "bit.ly\/RYUtGK"
    } ]
  },
  "geo" : { },
  "id_str" : "269480514656808960",
  "text" : "Cheat sheet for geospatial data analysis in #rstats (by @geospacedman): http:\/\/t.co\/1V465JcU",
  "id" : 269480514656808960,
  "created_at" : "2012-11-16 16:42:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/cDDnytm2",
      "expanded_url" : "http:\/\/bit.ly\/mW93Px",
      "display_url" : "bit.ly\/mW93Px"
    } ]
  },
  "geo" : { },
  "id_str" : "269111337496477697",
  "text" : "NA's have special handling for logical comparisons. NA &amp; FALSE is always FALSE, NA | TRUE is TRUE. http:\/\/t.co\/cDDnytm2 #rstats",
  "id" : 269111337496477697,
  "created_at" : "2012-11-15 16:15:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/XGsxt44S",
      "expanded_url" : "http:\/\/bit.ly\/rfMShP",
      "display_url" : "bit.ly\/rfMShP"
    } ]
  },
  "geo" : { },
  "id_str" : "268746435149844482",
  "text" : "For reproducible simulations, use set.seed to start the random number sequence from a fixed point http:\/\/t.co\/XGsxt44S #rstats",
  "id" : 268746435149844482,
  "created_at" : "2012-11-14 16:05:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 7, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/4D9oZKbQ",
      "expanded_url" : "http:\/\/bit.ly\/p6epvV",
      "display_url" : "bit.ly\/p6epvV"
    } ]
  },
  "geo" : { },
  "id_str" : "268375867468681216",
  "text" : "If the #rstats list \"x\" is a train carrying objects, then x[[5]] is the object in car 5; x[4:6] is a train of cars 4-6. http:\/\/t.co\/4D9oZKbQ",
  "id" : 268375867468681216,
  "created_at" : "2012-11-13 15:32:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/oqjXCiKC",
      "expanded_url" : "http:\/\/bit.ly\/pr0Fsj",
      "display_url" : "bit.ly\/pr0Fsj"
    } ]
  },
  "geo" : { },
  "id_str" : "268043056450789376",
  "text" : "Need to pass a whole bunch of arguments to a function, but want to select them in code? Use do.call http:\/\/t.co\/oqjXCiKC",
  "id" : 268043056450789376,
  "created_at" : "2012-11-12 17:30:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/jtemvgFR",
      "expanded_url" : "http:\/\/bit.ly\/PF2nXj",
      "display_url" : "bit.ly\/PF2nXj"
    } ]
  },
  "geo" : { },
  "id_str" : "266937036450172928",
  "text" : "Print a human-readable version of a matrix: write.table(format(X), row.names=F, col.names=F, quote=F) #rstats http:\/\/t.co\/jtemvgFR",
  "id" : 266937036450172928,
  "created_at" : "2012-11-09 16:15:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266586292551290880",
  "text" : "When selecting from vectors, repeated indexes are allowed. x[c(1,1,2,2,3,3)] duplicates the first 3 elements of x #rstats",
  "id" : 266586292551290880,
  "created_at" : "2012-11-08 17:01:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266208501754372096",
  "text" : "In R scripts that access files, use relative (not absolute) file names to make the script portable. #rstats",
  "id" : 266208501754372096,
  "created_at" : "2012-11-07 16:00:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xiaochuan Yu",
      "screen_name" : "0x00BAB10C",
      "indices" : [ 0, 11 ],
      "id_str" : "845676413600632832",
      "id" : 845676413600632832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265863479104241664",
  "geo" : { },
  "id_str" : "265865704144769024",
  "in_reply_to_user_id" : 72940933,
  "text" : "@0x00BAB10C Thanks, will update for the next time this tip runs.",
  "id" : 265865704144769024,
  "in_reply_to_status_id" : 265863479104241664,
  "created_at" : "2012-11-06 17:18:18 +0000",
  "in_reply_to_screen_name" : "def_const",
  "in_reply_to_user_id_str" : "72940933",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/oE6G5eAQ",
      "expanded_url" : "http:\/\/bit.ly\/PUt4Ye",
      "display_url" : "bit.ly\/PUt4Ye"
    } ]
  },
  "geo" : { },
  "id_str" : "265861536772395008",
  "text" : "Add or modify the main title of a ggplot2 chart: myplot + opts(title=\"My Title\") #rstats http:\/\/t.co\/oE6G5eAQ",
  "id" : 265861536772395008,
  "created_at" : "2012-11-06 17:01:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/qBIXHD3g",
      "expanded_url" : "http:\/\/bit.ly\/s3u5Xe",
      "display_url" : "bit.ly\/s3u5Xe"
    } ]
  },
  "geo" : { },
  "id_str" : "265502869933940737",
  "text" : "is.finite(x) is a useful test for \"proper\" data: it returns FALSE for NA, NaN and Inf: http:\/\/t.co\/qBIXHD3g #rstats",
  "id" : 265502869933940737,
  "created_at" : "2012-11-05 17:16:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/UoMirJMf",
      "expanded_url" : "http:\/\/bit.ly\/tmxyn2",
      "display_url" : "bit.ly\/tmxyn2"
    } ]
  },
  "geo" : { },
  "id_str" : "264422838532993024",
  "text" : "Search the R mailing list archives: http:\/\/t.co\/UoMirJMf #rstats",
  "id" : 264422838532993024,
  "created_at" : "2012-11-02 17:44:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/owwPSy1b",
      "expanded_url" : "http:\/\/bit.ly\/pM20DY",
      "display_url" : "bit.ly\/pM20DY"
    } ]
  },
  "geo" : { },
  "id_str" : "264036204092198914",
  "text" : "The foreach function can be used to speed up loops by running in parallel on multi-core machines: http:\/\/t.co\/owwPSy1b",
  "id" : 264036204092198914,
  "created_at" : "2012-11-01 16:08:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]