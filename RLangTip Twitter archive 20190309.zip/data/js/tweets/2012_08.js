Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 3, 17 ],
      "id_str" : "69133574",
      "id" : 69133574
    }, {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 19, 28 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241586929383129088",
  "text" : "RT @hadleywickham: @RLangTip better use cut to continuous variables into categorical #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One R Tip a Day",
        "screen_name" : "RLangTip",
        "indices" : [ 0, 9 ],
        "id_str" : "295344317",
        "id" : 295344317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "241569767000002561",
    "geo" : { },
    "id_str" : "241586737728598017",
    "in_reply_to_user_id" : 295344317,
    "text" : "@RLangTip better use cut to continuous variables into categorical #rstats",
    "id" : 241586737728598017,
    "in_reply_to_status_id" : 241569767000002561,
    "created_at" : "2012-08-31 17:22:21 +0000",
    "in_reply_to_screen_name" : "RLangTip",
    "in_reply_to_user_id_str" : "295344317",
    "user" : {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "protected" : false,
      "id_str" : "69133574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905186381995147264\/7zKAG5sY_normal.jpg",
      "id" : 69133574,
      "verified" : true
    }
  },
  "id" : 241586929383129088,
  "created_at" : "2012-08-31 17:23:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ObePQ86q",
      "expanded_url" : "http:\/\/bit.ly\/N1IVBw",
      "display_url" : "bit.ly\/N1IVBw"
    } ]
  },
  "geo" : { },
  "id_str" : "241569767000002561",
  "text" : "How to use the ifelse function to dichotomize a variable [video]: http:\/\/t.co\/ObePQ86q #rstats",
  "id" : 241569767000002561,
  "created_at" : "2012-08-31 16:14:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/Qv5bBP9a",
      "expanded_url" : "http:\/\/bit.ly\/PJsGZY",
      "display_url" : "bit.ly\/PJsGZY"
    } ]
  },
  "geo" : { },
  "id_str" : "241223705429164032",
  "text" : "Use the testthat package to create a testing framework for R packages: http:\/\/t.co\/Qv5bBP9a #rstats",
  "id" : 241223705429164032,
  "created_at" : "2012-08-30 17:19:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/eTn4Ojfq",
      "expanded_url" : "http:\/\/bit.ly\/SpgMXb",
      "display_url" : "bit.ly\/SpgMXb"
    } ]
  },
  "geo" : { },
  "id_str" : "240830013656670210",
  "text" : "Serialization: save a single R object to disk with saveRDS; restore in a new session with readRDS http:\/\/t.co\/eTn4Ojfq #rstats",
  "id" : 240830013656670210,
  "created_at" : "2012-08-29 15:15:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/F6NNnQ6B",
      "expanded_url" : "http:\/\/bit.ly\/Sppip1",
      "display_url" : "bit.ly\/Sppip1"
    } ]
  },
  "geo" : { },
  "id_str" : "240482661553033216",
  "text" : "Compare the speed of several R expressions with the benchmark function: http:\/\/t.co\/F6NNnQ6B #rstats",
  "id" : 240482661553033216,
  "created_at" : "2012-08-28 16:15:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/xvCd4G9L",
      "expanded_url" : "http:\/\/bit.ly\/N2RSf6",
      "display_url" : "bit.ly\/N2RSf6"
    } ]
  },
  "geo" : { },
  "id_str" : "240119034648080385",
  "text" : "Quirks of R's scoping rules: http:\/\/t.co\/xvCd4G9L #rstats",
  "id" : 240119034648080385,
  "created_at" : "2012-08-27 16:10:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/mtZvfmVS",
      "expanded_url" : "http:\/\/bit.ly\/RJLJpS",
      "display_url" : "bit.ly\/RJLJpS"
    } ]
  },
  "geo" : { },
  "id_str" : "239034106254610433",
  "text" : "You can use the Rcpp package to convert simple R loops into fast C++ code: http:\/\/t.co\/mtZvfmVS #rstats",
  "id" : 239034106254610433,
  "created_at" : "2012-08-24 16:19:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/jkXMibLp",
      "expanded_url" : "http:\/\/bit.ly\/N8U0vZ",
      "display_url" : "bit.ly\/N8U0vZ"
    } ]
  },
  "geo" : { },
  "id_str" : "238671822307078144",
  "text" : "Video introduction to object-oriented programming in R with S3 classes (by @mensurationist): http:\/\/t.co\/jkXMibLp",
  "id" : 238671822307078144,
  "created_at" : "2012-08-23 16:19:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/9QwAlfws",
      "expanded_url" : "http:\/\/bit.ly\/N8Uzpr",
      "display_url" : "bit.ly\/N8Uzpr"
    } ]
  },
  "geo" : { },
  "id_str" : "238305950820343808",
  "text" : "Two-sample T tests and permutation tests in #rstats: http:\/\/t.co\/9QwAlfws",
  "id" : 238305950820343808,
  "created_at" : "2012-08-22 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hadoop",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/6lvVjBtS",
      "expanded_url" : "http:\/\/bit.ly\/Pz0nKZ",
      "display_url" : "bit.ly\/Pz0nKZ"
    } ]
  },
  "geo" : { },
  "id_str" : "237985776237948928",
  "text" : "Tutorial: Mapreduce in R and #Hadoop with RHahoop http:\/\/t.co\/6lvVjBtS #rstats",
  "id" : 237985776237948928,
  "created_at" : "2012-08-21 18:53:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/e1ntw1rE",
      "expanded_url" : "http:\/\/bit.ly\/PNsI3S",
      "display_url" : "bit.ly\/PNsI3S"
    } ]
  },
  "geo" : { },
  "id_str" : "237585250388148224",
  "text" : "Add row sums, columns sums and grand total to a table with addmargins(my.table) #rstats http:\/\/t.co\/e1ntw1rE",
  "id" : 237585250388148224,
  "created_at" : "2012-08-20 16:21:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portfolio Probe",
      "screen_name" : "portfolioprobe",
      "indices" : [ 67, 82 ],
      "id_str" : "177229649",
      "id" : 177229649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/NpYvf7Y8",
      "expanded_url" : "http:\/\/bit.ly\/N8U7HQ",
      "display_url" : "bit.ly\/N8U7HQ"
    } ]
  },
  "geo" : { },
  "id_str" : "236497215558926336",
  "text" : "The difference between the order and rank functions in #rstats (by @portfolioprobe): http:\/\/t.co\/NpYvf7Y8",
  "id" : 236497215558926336,
  "created_at" : "2012-08-17 16:18:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/WiOcdZMQ",
      "expanded_url" : "http:\/\/bit.ly\/NE1Rpo",
      "display_url" : "bit.ly\/NE1Rpo"
    } ]
  },
  "geo" : { },
  "id_str" : "236128529245421568",
  "text" : "How to use the caret package to select, train and optimize predictive models: http:\/\/t.co\/WiOcdZMQ #rstats",
  "id" : 236128529245421568,
  "created_at" : "2012-08-16 15:53:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portfolio Probe",
      "screen_name" : "portfolioprobe",
      "indices" : [ 100, 115 ],
      "id_str" : "177229649",
      "id" : 177229649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Wh0wmwHf",
      "expanded_url" : "http:\/\/bit.ly\/N04dAD",
      "display_url" : "bit.ly\/N04dAD"
    } ]
  },
  "geo" : { },
  "id_str" : "235761060634824704",
  "text" : "Presentations on financial data analysis with #rstats from R\/Finance 2012 http:\/\/t.co\/Wh0wmwHf (via @portfolioprobe)",
  "id" : 235761060634824704,
  "created_at" : "2012-08-15 15:33:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ToKO2N3v",
      "expanded_url" : "http:\/\/bit.ly\/IqTdbe",
      "display_url" : "bit.ly\/IqTdbe"
    } ]
  },
  "geo" : { },
  "id_str" : "235405426903113729",
  "text" : "List the row\/column indices of matrix x, from largest to smallest: cbind(row(x)[order(-x)],col(x)[order(-x)]) #rstats http:\/\/t.co\/ToKO2N3v",
  "id" : 235405426903113729,
  "created_at" : "2012-08-14 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/uMFgX6NK",
      "expanded_url" : "http:\/\/bit.ly\/LpxvWU",
      "display_url" : "bit.ly\/LpxvWU"
    } ]
  },
  "geo" : { },
  "id_str" : "235043053411389441",
  "text" : "Command-line tools for debugging and tracing R code: http:\/\/t.co\/uMFgX6NK #rstats",
  "id" : 235043053411389441,
  "created_at" : "2012-08-13 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "khaneboubi",
      "screen_name" : "mehdikhaneboubi",
      "indices" : [ 103, 119 ],
      "id_str" : "522126905",
      "id" : 522126905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/cPfsQZ40",
      "expanded_url" : "http:\/\/bit.ly\/To3vfw",
      "display_url" : "bit.ly\/To3vfw"
    } ]
  },
  "geo" : { },
  "id_str" : "233950915718172673",
  "text" : "Make R pause for 3 seconds during a script or function: Sys.sleep(3) #rstats http:\/\/t.co\/cPfsQZ40 (via @mehdikhaneboubi)",
  "id" : 233950915718172673,
  "created_at" : "2012-08-10 15:40:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/x50GznL4",
      "expanded_url" : "http:\/\/bit.ly\/S4Q0P6",
      "display_url" : "bit.ly\/S4Q0P6"
    } ]
  },
  "geo" : { },
  "id_str" : "233604998917939200",
  "text" : "Use read.csv2 to import ASCII data from countries that use the comma as a decimal point #rstats http:\/\/t.co\/x50GznL4",
  "id" : 233604998917939200,
  "created_at" : "2012-08-09 16:45:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Lyov9Cdb",
      "expanded_url" : "http:\/\/bit.ly\/PIZFgJ",
      "display_url" : "bit.ly\/PIZFgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "233232191591690241",
  "text" : "Function to find the peaks in a time series: http:\/\/t.co\/Lyov9Cdb #rstats (via @therealprotonk)",
  "id" : 233232191591690241,
  "created_at" : "2012-08-08 16:04:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/uLlDSa8N",
      "expanded_url" : "http:\/\/bit.ly\/M6mDiL",
      "display_url" : "bit.ly\/M6mDiL"
    } ]
  },
  "geo" : { },
  "id_str" : "232878950697795584",
  "text" : "On Windows, you can substitute forward slashes for backslashes in filenames (for convenience or portability): http:\/\/t.co\/uLlDSa8N #rstats",
  "id" : 232878950697795584,
  "created_at" : "2012-08-07 16:40:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/Y0OmU92y",
      "expanded_url" : "http:\/\/bit.ly\/M6mPOW",
      "display_url" : "bit.ly\/M6mPOW"
    } ]
  },
  "geo" : { },
  "id_str" : "232497313153687552",
  "text" : "Handy for interactive use, you can set up packages to automatically load when a function is used: http:\/\/t.co\/Y0OmU92y #rstats",
  "id" : 232497313153687552,
  "created_at" : "2012-08-06 15:24:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "easteregg",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231403068057608193",
  "text" : "If you have an active trans-temporal internet connection, you can use ???? for extra help, e.g. ????t.test #rstats #easteregg",
  "id" : 231403068057608193,
  "created_at" : "2012-08-03 14:56:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 58, 68 ],
      "id_str" : "17522755",
      "id" : 17522755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/OxvDbdCe",
      "expanded_url" : "http:\/\/bit.ly\/OV6lDY",
      "display_url" : "bit.ly\/OV6lDY"
    } ]
  },
  "geo" : { },
  "id_str" : "231056812802207745",
  "text" : "Regular expressions in R http:\/\/t.co\/OxvDbdCe #rstats (by @johndcook)",
  "id" : 231056812802207745,
  "created_at" : "2012-08-02 16:00:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/xGgUnRg0",
      "expanded_url" : "http:\/\/bit.ly\/ODuLqM",
      "display_url" : "bit.ly\/ODuLqM"
    } ]
  },
  "geo" : { },
  "id_str" : "230690027322105857",
  "text" : "Create dynamic, interactive graphics for the Web with the gridSVG package: http:\/\/t.co\/xGgUnRg0 #rstats",
  "id" : 230690027322105857,
  "created_at" : "2012-08-01 15:42:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]