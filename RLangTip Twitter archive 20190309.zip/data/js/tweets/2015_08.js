Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/3xmZS4XMQg",
      "expanded_url" : "http:\/\/as.Date",
      "display_url" : "as.Date"
    }, {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ErFgWMBrgc",
      "expanded_url" : "http:\/\/Sys.Date",
      "display_url" : "Sys.Date"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/R6LbsYrADM",
      "expanded_url" : "http:\/\/bit.ly\/1VjOong",
      "display_url" : "bit.ly\/1VjOong"
    } ]
  },
  "geo" : { },
  "id_str" : "638382251261173760",
  "text" : "Weeks to Christmas: difftime(http:\/\/t.co\/3xmZS4XMQg(\"2015-12-15\"),http:\/\/t.co\/ErFgWMBrgc(),units=\"weeks\") http:\/\/t.co\/R6LbsYrADM #rstats",
  "id" : 638382251261173760,
  "created_at" : "2015-08-31 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/m38wcr3hi7",
      "expanded_url" : "http:\/\/bit.ly\/lnfBfG",
      "display_url" : "bit.ly\/lnfBfG"
    } ]
  },
  "geo" : { },
  "id_str" : "637295088448765952",
  "text" : "Making Publication-Ready Figures in R http:\/\/t.co\/m38wcr3hi7 #rstats",
  "id" : 637295088448765952,
  "created_at" : "2015-08-28 16:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/CkvHTE8pAj",
      "expanded_url" : "http:\/\/bit.ly\/1NKInvi",
      "display_url" : "bit.ly\/1NKInvi"
    } ]
  },
  "geo" : { },
  "id_str" : "636932715116277760",
  "text" : "One way to do a \"one way\" ANOVA: anova(lm(y ~ x)) where x is a factor http:\/\/t.co\/CkvHTE8pAj #rstats",
  "id" : 636932715116277760,
  "created_at" : "2015-08-27 16:06:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/i621JoPYz1",
      "expanded_url" : "http:\/\/bit.ly\/1UY85kc",
      "display_url" : "bit.ly\/1UY85kc"
    } ]
  },
  "geo" : { },
  "id_str" : "636570315477401600",
  "text" : "Use is.atomic(v) NOT is.vector(v) to test if vector. Try v=9; attr(v,\"A\") = \"attr\" See Wickham, Advanced R http:\/\/t.co\/i621JoPYz1 #rstats",
  "id" : 636570315477401600,
  "created_at" : "2015-08-26 16:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7i0AbbSOxh",
      "expanded_url" : "http:\/\/bit.ly\/pzIdlb",
      "display_url" : "bit.ly\/pzIdlb"
    } ]
  },
  "geo" : { },
  "id_str" : "636207966295859200",
  "text" : "Use the transform() function to add a new column to a data frame, using the data from existing columns: http:\/\/t.co\/7i0AbbSOxh #rstats",
  "id" : 636207966295859200,
  "created_at" : "2015-08-25 16:06:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JsvCvtuvhp",
      "expanded_url" : "http:\/\/bit.ly\/qOmjEl",
      "display_url" : "bit.ly\/qOmjEl"
    } ]
  },
  "geo" : { },
  "id_str" : "635845504333684737",
  "text" : "R interprets literal numbers like 4 as floating-point; use 4L for the integer 4. http:\/\/t.co\/JsvCvtuvhp #rstats",
  "id" : 635845504333684737,
  "created_at" : "2015-08-24 16:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/5KVNzWXLrP",
      "expanded_url" : "http:\/\/bit.ly\/srEahw",
      "display_url" : "bit.ly\/srEahw"
    } ]
  },
  "geo" : { },
  "id_str" : "634758395292164097",
  "text" : "Moving data between R and Excel via the Windows clipboard: http:\/\/t.co\/5KVNzWXLrP #rstats",
  "id" : 634758395292164097,
  "created_at" : "2015-08-21 16:06:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/eEyEeufWeP",
      "expanded_url" : "http:\/\/bit.ly\/1haoRhZ",
      "display_url" : "bit.ly\/1haoRhZ"
    } ]
  },
  "geo" : { },
  "id_str" : "634395995158224896",
  "text" : "Consider partial least sqares (PLS) for regresssions problems with many predictors http:\/\/t.co\/eEyEeufWeP #rstats",
  "id" : 634395995158224896,
  "created_at" : "2015-08-20 16:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634033600044863488",
  "text" : "Collecting results in a loop? Pre-allocate a vector res=rep(0,N) and assign res[i]=val. Avoid extending in the loop: res=c(res,val) #rstats",
  "id" : 634033600044863488,
  "created_at" : "2015-08-19 16:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Hrf0DsJqhT",
      "expanded_url" : "http:\/\/bit.ly\/1DQqlrI",
      "display_url" : "bit.ly\/1DQqlrI"
    } ]
  },
  "geo" : { },
  "id_str" : "633671208534474753",
  "text" : "Add or modify the main title of a ggplot2 chart: myplot + ggtitle(\"title\") http:\/\/t.co\/Hrf0DsJqhT #rstats",
  "id" : 633671208534474753,
  "created_at" : "2015-08-18 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/8ZKmJ046Pf",
      "expanded_url" : "http:\/\/bit.ly\/1Msd4IB",
      "display_url" : "bit.ly\/1Msd4IB"
    } ]
  },
  "geo" : { },
  "id_str" : "633308836636573696",
  "text" : "Get started analyzing graphs and social networks with the igraph package http:\/\/t.co\/8ZKmJ046Pf #rstats",
  "id" : 633308836636573696,
  "created_at" : "2015-08-17 16:06:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/mBey9N1Pq2",
      "expanded_url" : "http:\/\/bit.ly\/LCS4L1",
      "display_url" : "bit.ly\/LCS4L1"
    } ]
  },
  "geo" : { },
  "id_str" : "632221640559079424",
  "text" : "Tutorial: Analysis of Variance (ANOVA) for comparing the means http:\/\/t.co\/mBey9N1Pq2 #rstats",
  "id" : 632221640559079424,
  "created_at" : "2015-08-14 16:05:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/t1BFHXHZFS",
      "expanded_url" : "http:\/\/bit.ly\/yk582p",
      "display_url" : "bit.ly\/yk582p"
    } ]
  },
  "geo" : { },
  "id_str" : "631859253444263936",
  "text" : "List of R packages and functions for high-performance and parallel computing with R: http:\/\/t.co\/t1BFHXHZFS #rstats",
  "id" : 631859253444263936,
  "created_at" : "2015-08-13 16:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/VpAfPfosFo",
      "expanded_url" : "http:\/\/bit.ly\/ywEk5w",
      "display_url" : "bit.ly\/ywEk5w"
    } ]
  },
  "geo" : { },
  "id_str" : "631496894724898816",
  "text" : "Guidance for use of #rstats in regulated clinical trial environments (incl. for FDA): http:\/\/t.co\/VpAfPfosFo",
  "id" : 631496894724898816,
  "created_at" : "2015-08-12 16:06:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/MdPVDj4MYd",
      "expanded_url" : "http:\/\/bit.ly\/1HvOkqK",
      "display_url" : "bit.ly\/1HvOkqK"
    } ]
  },
  "geo" : { },
  "id_str" : "631134489398390784",
  "text" : "ks.test() in the \u007Bstats\u007D package implements the Kolmogorov-Smirnov Test http:\/\/t.co\/MdPVDj4MYd #rstats",
  "id" : 631134489398390784,
  "created_at" : "2015-08-11 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/TFLlwagr7J",
      "expanded_url" : "http:\/\/bit.ly\/1EdU8oK",
      "display_url" : "bit.ly\/1EdU8oK"
    } ]
  },
  "geo" : { },
  "id_str" : "630772122542055427",
  "text" : "The mi package is very helpful when dealing with missing values  http:\/\/t.co\/TFLlwagr7J #rstats",
  "id" : 630772122542055427,
  "created_at" : "2015-08-10 16:06:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/5EcK8qU5a2",
      "expanded_url" : "http:\/\/bit.ly\/1HaU4pN",
      "display_url" : "bit.ly\/1HaU4pN"
    } ]
  },
  "geo" : { },
  "id_str" : "629685141753999360",
  "text" : "Use the sqldf package to select and merge data frames with SQL.http:\/\/t.co\/5EcK8qU5a2  #rstats",
  "id" : 629685141753999360,
  "created_at" : "2015-08-07 16:06:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Fx604Uz912",
      "expanded_url" : "http:\/\/bit.ly\/Sa02k9",
      "display_url" : "bit.ly\/Sa02k9"
    } ]
  },
  "geo" : { },
  "id_str" : "629322690063634432",
  "text" : "Not sure which CRAN mirror to use? Visit http:\/\/t.co\/Fx604Uz912, the default \"current mirror\" is closest to you. #rstats",
  "id" : 629322690063634432,
  "created_at" : "2015-08-06 16:06:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/i0Cc6pDmat",
      "expanded_url" : "http:\/\/bit.ly\/1IdbaFd",
      "display_url" : "bit.ly\/1IdbaFd"
    } ]
  },
  "geo" : { },
  "id_str" : "628960117589999617",
  "text" : "table(x) \u007Bbase\u007D will build a contingency table http:\/\/t.co\/i0Cc6pDmat #rstats",
  "id" : 628960117589999617,
  "created_at" : "2015-08-05 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wSCnQspo0l",
      "expanded_url" : "http:\/\/bit.ly\/1UcAz9s",
      "display_url" : "bit.ly\/1UcAz9s"
    } ]
  },
  "geo" : { },
  "id_str" : "628597739656454144",
  "text" : "Use factor(vector) \u007Bbase\u007D to work with categorical variables http:\/\/t.co\/wSCnQspo0l #rstats",
  "id" : 628597739656454144,
  "created_at" : "2015-08-04 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/e5ykITgeGs",
      "expanded_url" : "http:\/\/bit.ly\/1OFoeHo",
      "display_url" : "bit.ly\/1OFoeHo"
    } ]
  },
  "geo" : { },
  "id_str" : "628235384711999488",
  "text" : "Guidance on how to create a reproducible example in R http:\/\/t.co\/e5ykITgeGs (via Wickham: Advanced R) #rstats",
  "id" : 628235384711999488,
  "created_at" : "2015-08-03 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]