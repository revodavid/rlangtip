Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/B4Duqw8CBp",
      "expanded_url" : "https:\/\/www.visualstudio.com\/en-us\/features\/rtvs-vs.aspx",
      "display_url" : "visualstudio.com\/en-us\/features\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771014729548505088",
  "text" : "RTVS is a free extension for Visual Studio for R programming and debugging https:\/\/t.co\/B4Duqw8CBp #rstats",
  "id" : 771014729548505088,
  "created_at" : "2016-08-31 16:00:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Z0wGPTJAuu",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/magrittr\/vignettes\/magrittr.html",
      "display_url" : "cran.r-project.org\/web\/packages\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770652320132542464",
  "text" : "The %&gt;% operator from the magrittr package pipes data from function to function for more readable R code https:\/\/t.co\/Z0wGPTJAuu #rstats",
  "id" : 770652320132542464,
  "created_at" : "2016-08-30 16:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/4AZsimye3Y",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.1\/topics\/read.table",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770289959806734336",
  "text" : "The \"file\" argument to data import functions like read.table can be a URL, to read data from a website  https:\/\/t.co\/4AZsimye3Y #rstats",
  "id" : 770289959806734336,
  "created_at" : "2016-08-29 16:00:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/kfNEoBPcvM",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/miniCRAN\/",
      "display_url" : "mran.microsoft.com\/package\/miniCR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769202793445941249",
  "text" : "Use miniCRAN to create an offline repository with a subset of CRAN of packages and their dependencies https:\/\/t.co\/kfNEoBPcvM #rstats",
  "id" : 769202793445941249,
  "created_at" : "2016-08-26 16:00:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/EdUDpgcij9",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/KernSmooth\/versions\/2.23-15\/topics\/locpoly",
      "display_url" : "rdocumentation.org\/packages\/KernS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768840402040332288",
  "text" : "locpoly(x) \u007BKernSmooth\u007D estimates a probability distribution function from observed data https:\/\/t.co\/EdUDpgcij9 #rstats",
  "id" : 768840402040332288,
  "created_at" : "2016-08-25 16:00:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/EpLI0b1pdj",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/invisible",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768478004318121984",
  "text" : "In R scripts, use invisible() to prevent functions from generating unwanted output: https:\/\/t.co\/EpLI0b1pdj #rstats",
  "id" : 768478004318121984,
  "created_at" : "2016-08-24 16:00:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/bV36jrcMnG",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/seq",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768115616582553601",
  "text" : "Robust function writing tip: use seq_len(N) instead of 1:N (it handles the N&lt;1 case appropriately) https:\/\/t.co\/bV36jrcMnG #rstats",
  "id" : 768115616582553601,
  "created_at" : "2016-08-23 16:00:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/J1wEKlRiwL",
      "expanded_url" : "http:\/\/rmarkdown.rstudio.com\/formats.html",
      "display_url" : "rmarkdown.rstudio.com\/formats.html"
    } ]
  },
  "geo" : { },
  "id_str" : "767753263751974913",
  "text" : "Use R Markdown to generate HTML, PDF, Word documents (and more) with R graphics and output https:\/\/t.co\/J1wEKlRiwL #rstats",
  "id" : 767753263751974913,
  "created_at" : "2016-08-22 16:00:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/nDiaH6nVmP",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/forecast\/versions\/7.1\/topics\/auto.arima",
      "display_url" : "rdocumentation.org\/packages\/forec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766668921353048065",
  "text" : "auto.arima() \u007Bforecast\u007D will return the best ARIMA fit to a time series using the AIC, AICc or BIC criterion https:\/\/t.co\/nDiaH6nVmP #rstats",
  "id" : 766668921353048065,
  "created_at" : "2016-08-19 16:11:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/W1c7L73jJh",
      "expanded_url" : "http:\/\/bit.ly\/UDQtyf",
      "display_url" : "bit.ly\/UDQtyf"
    } ]
  },
  "geo" : { },
  "id_str" : "766303680777691138",
  "text" : "format(x, scientific=TRUE) prints numeric data in exponential format, so 0.0001 prints as 1e-04 https:\/\/t.co\/W1c7L73jJh #rstats",
  "id" : 766303680777691138,
  "created_at" : "2016-08-18 16:00:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/70XwjnPuAm",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/checkpoint\/",
      "display_url" : "mran.microsoft.com\/package\/checkp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765941322364522500",
  "text" : "Use checkpoint(\"2016-08-17\") to force your project to always use today's package versions from now on https:\/\/t.co\/70XwjnPuAm #rstats",
  "id" : 765941322364522500,
  "created_at" : "2016-08-17 16:00:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765578939297206273",
  "text" : "Just because you *can* redefine built-in functions in R doesn't mean it's a good idea. Avoid function names like c, t, sum etc. #rstats",
  "id" : 765578939297206273,
  "created_at" : "2016-08-16 16:00:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/CTGSo8qXQm",
      "expanded_url" : "http:\/\/www.r-bloggers.com\/",
      "display_url" : "r-bloggers.com"
    } ]
  },
  "geo" : { },
  "id_str" : "765268942495506432",
  "text" : "Over 500 people who blog about R https:\/\/t.co\/CTGSo8qXQm #rstats",
  "id" : 765268942495506432,
  "created_at" : "2016-08-15 19:28:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/W9gWc3qucK",
      "expanded_url" : "http:\/\/bit.ly\/o0z4Mh",
      "display_url" : "bit.ly\/o0z4Mh"
    } ]
  },
  "geo" : { },
  "id_str" : "764130778724888576",
  "text" : "The standard random number generator in R is the Mersenne Twister, but other RNGs are available: https:\/\/t.co\/W9gWc3qucK #rstats",
  "id" : 764130778724888576,
  "created_at" : "2016-08-12 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thanos Papaoikonomou",
      "screen_name" : "erwtokritos",
      "indices" : [ 59, 71 ],
      "id_str" : "20789946",
      "id" : 20789946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/tqIF91ueME",
      "expanded_url" : "http:\/\/bit.ly\/VLxPTH",
      "display_url" : "bit.ly\/VLxPTH"
    } ]
  },
  "geo" : { },
  "id_str" : "763768365609521152",
  "text" : "Tips on managing memory in R: https:\/\/t.co\/tqIF91ueME (via @erwtokritos) #rstats",
  "id" : 763768365609521152,
  "created_at" : "2016-08-11 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0meQV7ONtj",
      "expanded_url" : "http:\/\/bit.ly\/QvVJ4G",
      "display_url" : "bit.ly\/QvVJ4G"
    } ]
  },
  "geo" : { },
  "id_str" : "763405996509323264",
  "text" : "Topic coding and text classification for unstructured data: the RTextTools package #rstats https:\/\/t.co\/0meQV7ONtj",
  "id" : 763405996509323264,
  "created_at" : "2016-08-10 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/t6la2Exqwe",
      "expanded_url" : "http:\/\/bit.ly\/oa5sx5",
      "display_url" : "bit.ly\/oa5sx5"
    } ]
  },
  "geo" : { },
  "id_str" : "763042905883811840",
  "text" : "Meet other R users at a local R user group in your area: https:\/\/t.co\/t6la2Exqwe #rstats",
  "id" : 763042905883811840,
  "created_at" : "2016-08-09 16:03:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portfolio Probe",
      "screen_name" : "portfolioprobe",
      "indices" : [ 67, 82 ],
      "id_str" : "177229649",
      "id" : 177229649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/P2MEx1PIdS",
      "expanded_url" : "http:\/\/bit.ly\/N8U7HQ",
      "display_url" : "bit.ly\/N8U7HQ"
    } ]
  },
  "geo" : { },
  "id_str" : "762681215065423872",
  "text" : "The difference between the order and rank functions in #rstats (by @portfolioprobe): https:\/\/t.co\/P2MEx1PIdS",
  "id" : 762681215065423872,
  "created_at" : "2016-08-08 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/8yESDQnQ3X",
      "expanded_url" : "http:\/\/bit.ly\/2awMtw3",
      "display_url" : "bit.ly\/2awMtw3"
    } ]
  },
  "geo" : { },
  "id_str" : "761594036528508928",
  "text" : "Review and update installed packages to the latest version: update.packages(ask=\"graphics\")  https:\/\/t.co\/8yESDQnQ3X #rstats",
  "id" : 761594036528508928,
  "created_at" : "2016-08-05 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Fzplt8X3Ws",
      "expanded_url" : "http:\/\/bit.ly\/2aEbLI2",
      "display_url" : "bit.ly\/2aEbLI2"
    } ]
  },
  "geo" : { },
  "id_str" : "761230904312332288",
  "text" : "Consider the mvtnorm package for calculating multivariate normal and t distribution probabilities. https:\/\/t.co\/Fzplt8X3Ws #rstats",
  "id" : 761230904312332288,
  "created_at" : "2016-08-04 16:02:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/OLKxCAJgVr",
      "expanded_url" : "http:\/\/bit.ly\/2awMpMJ",
      "display_url" : "bit.ly\/2awMpMJ"
    } ]
  },
  "geo" : { },
  "id_str" : "760869253994180608",
  "text" : "Use names(x) &lt;- c to set the names of the elements of vector x to the values of the character vector c https:\/\/t.co\/OLKxCAJgVr #rstats",
  "id" : 760869253994180608,
  "created_at" : "2016-08-03 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/1Zz9LGUHo3",
      "expanded_url" : "http:\/\/bit.ly\/22f3tgE",
      "display_url" : "bit.ly\/22f3tgE"
    } ]
  },
  "geo" : { },
  "id_str" : "760506843709972480",
  "text" : "Type help(regex) to get started with regular expressions https:\/\/t.co\/1Zz9LGUHo3 #rstats",
  "id" : 760506843709972480,
  "created_at" : "2016-08-02 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/E5Ja4piRDK",
      "expanded_url" : "http:\/\/bit.ly\/2auw1Oy",
      "display_url" : "bit.ly\/2auw1Oy"
    } ]
  },
  "geo" : { },
  "id_str" : "760144436227612672",
  "text" : "Look for the list of R operators here; https:\/\/t.co\/E5Ja4piRDK #rstats",
  "id" : 760144436227612672,
  "created_at" : "2016-08-01 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]