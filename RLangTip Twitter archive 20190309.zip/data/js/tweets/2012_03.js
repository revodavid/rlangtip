Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MegaMillions",
      "indices" : [ 31, 44 ]
    }, {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/lmyJNaYC",
      "expanded_url" : "http:\/\/bit.ly\/x9UdLI",
      "display_url" : "bit.ly\/x9UdLI"
    } ]
  },
  "geo" : { },
  "id_str" : "185853167622299649",
  "text" : "Generate a random entry to the #MegaMillions lottery with R: sample(1:56,6) #rstats http:\/\/t.co\/lmyJNaYC",
  "id" : 185853167622299649,
  "created_at" : "2012-03-30 22:17:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/xB3f1ToP",
      "expanded_url" : "http:\/\/bit.ly\/zIdY6J",
      "display_url" : "bit.ly\/zIdY6J"
    } ]
  },
  "geo" : { },
  "id_str" : "185743701539164163",
  "text" : "getwd() returns the current working directory, the place where R reads and write files by default: http:\/\/t.co\/xB3f1ToP #rstats",
  "id" : 185743701539164163,
  "created_at" : "2012-03-30 15:02:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/spbfudqF",
      "expanded_url" : "http:\/\/bit.ly\/GA096H",
      "display_url" : "bit.ly\/GA096H"
    } ]
  },
  "geo" : { },
  "id_str" : "185381310116802560",
  "text" : "See demo(plotmath) for examples of mathematics (exponents, greek symbols etc) in #rstats plots http:\/\/t.co\/spbfudqF",
  "id" : 185381310116802560,
  "created_at" : "2012-03-29 15:02:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/X2SVnj5p",
      "expanded_url" : "http:\/\/bit.ly\/zZ4eL3",
      "display_url" : "bit.ly\/zZ4eL3"
    } ]
  },
  "geo" : { },
  "id_str" : "185019016174247936",
  "text" : "Check availability status of CRAN mirrors: http:\/\/t.co\/X2SVnj5p #rstats",
  "id" : 185019016174247936,
  "created_at" : "2012-03-28 15:02:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/ZxopTBKc",
      "expanded_url" : "http:\/\/bit.ly\/HbMcJo",
      "display_url" : "bit.ly\/HbMcJo"
    } ]
  },
  "geo" : { },
  "id_str" : "184656471571697664",
  "text" : "fitdistr fits a univariate probability distribution to a vector of data using maximum likelihood estimation: http:\/\/t.co\/ZxopTBKc #rstats",
  "id" : 184656471571697664,
  "created_at" : "2012-03-27 15:01:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/5v6V98TT",
      "expanded_url" : "http:\/\/bit.ly\/wSwsQA",
      "display_url" : "bit.ly\/wSwsQA"
    } ]
  },
  "geo" : { },
  "id_str" : "184294277067706368",
  "text" : "List of R packages for design of experiments and analysis of experimental data: http:\/\/t.co\/5v6V98TT #rstats",
  "id" : 184294277067706368,
  "created_at" : "2012-03-26 15:02:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183207124917161984",
  "text" : "To get help on some R operators, use quotes, e.g. ?\"%*%, ?\"if\", ?\"!\" etc. If in doubt, add quotes. #rstats",
  "id" : 183207124917161984,
  "created_at" : "2012-03-23 15:02:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/wXKq4EMx",
      "expanded_url" : "http:\/\/bit.ly\/nLuDqT",
      "display_url" : "bit.ly\/nLuDqT"
    } ]
  },
  "geo" : { },
  "id_str" : "182844623985717250",
  "text" : "Review and update installed packages to the latest version: update.packages(ask=\"graphics\") #rstats http:\/\/t.co\/wXKq4EMx",
  "id" : 182844623985717250,
  "created_at" : "2012-03-22 15:02:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/xB3f1ToP",
      "expanded_url" : "http:\/\/bit.ly\/zIdY6J",
      "display_url" : "bit.ly\/zIdY6J"
    } ]
  },
  "geo" : { },
  "id_str" : "182482131593859072",
  "text" : "The lubridate package simplifies operations on dates and times: http:\/\/t.co\/xB3f1ToP #rstats",
  "id" : 182482131593859072,
  "created_at" : "2012-03-21 15:01:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/zXqtPeCo",
      "expanded_url" : "http:\/\/bit.ly\/GzYTQZ",
      "display_url" : "bit.ly\/GzYTQZ"
    } ]
  },
  "geo" : { },
  "id_str" : "182119985546657793",
  "text" : "Differences between R and S+: http:\/\/t.co\/zXqtPeCo #rstats",
  "id" : 182119985546657793,
  "created_at" : "2012-03-20 15:02:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/gdvMySmb",
      "expanded_url" : "http:\/\/bit.ly\/ytcsHj",
      "display_url" : "bit.ly\/ytcsHj"
    } ]
  },
  "geo" : { },
  "id_str" : "181757423424520192",
  "text" : "List of R packages for the analysis of medical images: http:\/\/t.co\/gdvMySmb #rstats",
  "id" : 181757423424520192,
  "created_at" : "2012-03-19 15:02:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstat",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/mXmdGg7u",
      "expanded_url" : "http:\/\/bit.ly\/y4JP9f",
      "display_url" : "bit.ly\/y4JP9f"
    } ]
  },
  "geo" : { },
  "id_str" : "180670120555843584",
  "text" : "Two-minute video tutorials for R beginners:http:\/\/t.co\/mXmdGg7u #rstat",
  "id" : 180670120555843584,
  "created_at" : "2012-03-16 15:01:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/wTwvDrZi",
      "expanded_url" : "http:\/\/bit.ly\/xywuih",
      "display_url" : "bit.ly\/xywuih"
    } ]
  },
  "geo" : { },
  "id_str" : "180307725593481218",
  "text" : "In R scripts, use invisible() to prevent functions from generating unwanted output: http:\/\/t.co\/wTwvDrZi #rstats",
  "id" : 180307725593481218,
  "created_at" : "2012-03-15 15:01:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "finance",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/4sTcXIlr",
      "expanded_url" : "http:\/\/bit.ly\/wlAddo",
      "display_url" : "bit.ly\/wlAddo"
    } ]
  },
  "geo" : { },
  "id_str" : "179945332308840448",
  "text" : "xts: an R package for handling financial time series. http:\/\/t.co\/4sTcXIlr #rstats #finance",
  "id" : 179945332308840448,
  "created_at" : "2012-03-14 15:01:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/oHj9F9BJ",
      "expanded_url" : "http:\/\/bit.ly\/we8tgt",
      "display_url" : "bit.ly\/we8tgt"
    } ]
  },
  "geo" : { },
  "id_str" : "179583070616305665",
  "text" : "Calculate running 30-day means of values in vector x: filter(x,rep(1\/30,30)) #rstats http:\/\/t.co\/oHj9F9BJ",
  "id" : 179583070616305665,
  "created_at" : "2012-03-13 15:01:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/J2AUVFZU",
      "expanded_url" : "http:\/\/bit.ly\/A6eN6I",
      "display_url" : "bit.ly\/A6eN6I"
    } ]
  },
  "geo" : { },
  "id_str" : "179220577947627520",
  "text" : "List of R packages for survival analysis, censored data, and failure time modeling: http:\/\/t.co\/J2AUVFZU #rstats",
  "id" : 179220577947627520,
  "created_at" : "2012-03-12 15:01:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/KrqQ0ZUv",
      "expanded_url" : "http:\/\/bit.ly\/yGdRZ7",
      "display_url" : "bit.ly\/yGdRZ7"
    } ]
  },
  "geo" : { },
  "id_str" : "178148537131995136",
  "text" : "How to generate random numbers in R: http:\/\/t.co\/KrqQ0ZUv #rstats",
  "id" : 178148537131995136,
  "created_at" : "2012-03-09 16:01:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/0MLOj64a",
      "expanded_url" : "http:\/\/bit.ly\/yUSrZr",
      "display_url" : "bit.ly\/yUSrZr"
    } ]
  },
  "geo" : { },
  "id_str" : "177786018697719809",
  "text" : "Install an R package directly from GitHub with devtools package: http:\/\/t.co\/0MLOj64a #rstats",
  "id" : 177786018697719809,
  "created_at" : "2012-03-08 16:01:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerzy Wieczorek",
      "screen_name" : "civilstat",
      "indices" : [ 3, 13 ],
      "id_str" : "213030756",
      "id" : 213030756
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/O9jpcJiH",
      "expanded_url" : "http:\/\/bit.ly\/Ap6TbH",
      "display_url" : "bit.ly\/Ap6TbH"
    } ]
  },
  "geo" : { },
  "id_str" : "177423755864326144",
  "text" : "RT @civilstat For quick edits to shapefile .dbf, Excel is finicky; thank goodness for R's write.dbf() http:\/\/t.co\/O9jpcJiH #rstats",
  "id" : 177423755864326144,
  "created_at" : "2012-03-07 16:01:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/8DTKk0RE",
      "expanded_url" : "http:\/\/bit.ly\/AcyE6T",
      "display_url" : "bit.ly\/AcyE6T"
    } ]
  },
  "geo" : { },
  "id_str" : "177061365041733632",
  "text" : "Good for journals, etc: create EPS graphics file: setEPS(); postscript(\"mychart.eps\"); plot( &lt;whatever&gt; ); dev.off() # http:\/\/t.co\/8DTKk0RE",
  "id" : 177061365041733632,
  "created_at" : "2012-03-06 16:01:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/ZH8LwJSM",
      "expanded_url" : "http:\/\/bit.ly\/zmXTHZ",
      "display_url" : "bit.ly\/zmXTHZ"
    } ]
  },
  "geo" : { },
  "id_str" : "176698973938135040",
  "text" : "List of R packages for survey design, missing value imputation, and official statistics: http:\/\/t.co\/ZH8LwJSM #rstats",
  "id" : 176698973938135040,
  "created_at" : "2012-03-05 16:01:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/XXpNPHUt",
      "expanded_url" : "http:\/\/bit.ly\/woMnsV",
      "display_url" : "bit.ly\/woMnsV"
    } ]
  },
  "geo" : { },
  "id_str" : "175612520252440576",
  "text" : "Every row of a data frame has a unique label, which you can set or retrieve with row.names: http:\/\/t.co\/XXpNPHUt #rstats",
  "id" : 175612520252440576,
  "created_at" : "2012-03-02 16:04:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/LhP7DdJu",
      "expanded_url" : "http:\/\/bit.ly\/yPYjn5",
      "display_url" : "bit.ly\/yPYjn5"
    } ]
  },
  "geo" : { },
  "id_str" : "175249414712070145",
  "text" : "Some common pitfalls when working with floating-point numbers in #rstats: http:\/\/t.co\/LhP7DdJu",
  "id" : 175249414712070145,
  "created_at" : "2012-03-01 16:01:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]