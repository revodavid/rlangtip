Grailbird.data.tweets_2018_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/RdbLpYbA7o",
      "expanded_url" : "https:\/\/docs.microsoft.com\/machine-learning-server\/operationalize\/how-to-consume-web-service-asynchronously-batch?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/machine-learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1057663492189229060",
  "text" : "How to schedule R jobs as batch tasks with Microsoft ML Server https:\/\/t.co\/RdbLpYbA7o #rstats",
  "id" : 1057663492189229060,
  "created_at" : "2018-10-31 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/wFYondcKj3",
      "expanded_url" : "https:\/\/www.rocker-project.org\/images\/",
      "display_url" : "rocker-project.org\/images\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1057301100229988352",
  "text" : "Get docker containers with specific versions of R, RStudio, tidyverse and more from the rocker project https:\/\/t.co\/wFYondcKj3 #rstats",
  "id" : 1057301100229988352,
  "created_at" : "2018-10-30 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/z2iRBfRHHM",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/remove",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1056938717485637632",
  "text" : "rm(list=ls()) will remove almost everything from your working environment. Be careful! Be sure! https:\/\/t.co\/z2iRBfRHHM #rstats",
  "id" : 1056938717485637632,
  "created_at" : "2018-10-29 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/yXB1mH0LdH",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/nlme\/versions\/3.1-137\/topics\/gnls",
      "display_url" : "rdocumentation.org\/packages\/nlme\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1055851554723389440",
  "text" : "Use \"gnls\" in the nlme package to fit a nonlinear model using generalized least squares https:\/\/t.co\/yXB1mH0LdH #rstats",
  "id" : 1055851554723389440,
  "created_at" : "2018-10-26 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/bV36jrunMg",
      "expanded_url" : "http:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/seq",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1055489163645067264",
  "text" : "Robust function writing tip: use seq_len(N) instead of 1:N (it handles the N&lt;1 case appropriately) https:\/\/t.co\/bV36jrunMg #rstats",
  "id" : 1055489163645067264,
  "created_at" : "2018-10-25 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike K Smith",
      "screen_name" : "MikeKSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "13967522",
      "id" : 13967522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 159, 166 ]
    } ],
    "urls" : [ {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/VPadM9rVfD",
      "expanded_url" : "https:\/\/mran.microsoft.com\/timemachine",
      "display_url" : "mran.microsoft.com\/timemachine"
    } ]
  },
  "geo" : { },
  "id_str" : "1055126771895582720",
  "text" : "RT @MikeKSmith Looking for older versions of R packages, but don\u2019t want to have to compile from source? You need the MRAN TimeMachine: https:\/\/t.co\/VPadM9rVfD #rstats",
  "id" : 1055126771895582720,
  "created_at" : "2018-10-24 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 147, 154 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/FPrucBJCcy",
      "expanded_url" : "https:\/\/github.com\/wch\/r-source",
      "display_url" : "github.com\/wch\/r-source"
    } ]
  },
  "geo" : { },
  "id_str" : "1054764392313733126",
  "text" : "The R source code is made up of 32% C, 24% Fortran, and 37% R. You can find a read-only mirror of the sources on Github at https:\/\/t.co\/FPrucBJCcy #rstats",
  "id" : 1054764392313733126,
  "created_at" : "2018-10-23 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/lwvRNvU8Sf",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/SAScii\/versions\/1.0\/topics\/read.SAScii",
      "display_url" : "rdocumentation.org\/packages\/SASci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1054401996185321472",
  "text" : "Use the SAScii package to run an existing SAS script for importing ASCII data into R -- without needing SAS: https:\/\/t.co\/lwvRNvU8Sf  #rstats",
  "id" : 1054401996185321472,
  "created_at" : "2018-10-22 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Burns",
      "screen_name" : "burnsstat",
      "indices" : [ 98, 108 ],
      "id_str" : "1068157430",
      "id" : 1068157430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/yRroUrffeZ",
      "expanded_url" : "http:\/\/www.burns-stat.com\/pages\/Tutor\/R_inferno.pdf",
      "display_url" : "burns-stat.com\/pages\/Tutor\/R_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1053314835692294144",
  "text" : "If you are using R and think you're in hell, this is a map for you. \"The R Inferno\", a classic by @burnsstat: https:\/\/t.co\/yRroUrffeZ #rstats",
  "id" : 1053314835692294144,
  "created_at" : "2018-10-19 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1052952448837537792",
  "text" : "Add row sums, column sums and grand total to a table with addmargins(my.table) #rstats htthttps:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/addmargins",
  "id" : 1052952448837537792,
  "created_at" : "2018-10-18 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/kG3IuXZoKu",
      "expanded_url" : "https:\/\/docs.microsoft.com\/machine-learning-server\/operationalize\/configure-manage-r-packages?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/machine-learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1052590057255780352",
  "text" : "How to manage R packages in Microsoft ML Server https:\/\/t.co\/kG3IuXZoKu #rstats",
  "id" : 1052590057255780352,
  "created_at" : "2018-10-17 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/7Hh1PeKKzZ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/anova",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1052227670040354816",
  "text" : "anova(model) will compute and print Analysis of Variance tables for models fitted with lm() and glm(). #rstats https:\/\/t.co\/7Hh1PeKKzZ",
  "id" : 1052227670040354816,
  "created_at" : "2018-10-16 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/pl3R7WAW3Q",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/Cluster.html",
      "display_url" : "cran.r-project.org\/web\/views\/Clus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1051865280740085761",
  "text" : "List of R packages and functions for Cluster Analysis &amp; Finite Mixture Models: https:\/\/t.co\/pl3R7WAW3Q #rstats",
  "id" : 1051865280740085761,
  "created_at" : "2018-10-15 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/DGnSLfvXZu",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.1\/topics\/Question",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1050778119903293440",
  "text" : "Type ?\"?\" or ?Question at the command line to get help with help in R https:\/\/t.co\/DGnSLfvXZu #rstats",
  "id" : 1050778119903293440,
  "created_at" : "2018-10-12 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 147, 154 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/kgQ7WbDhSN",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/rep",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1050415734487019520",
  "text" : "Use a vector second argument to rep() to replicate *within* a vector. Example: \n  rep(1:3, 1:3) \nreturns \n  c(1,2,2,3,3,3) https:\/\/t.co\/kgQ7WbDhSN #rstats",
  "id" : 1050415734487019520,
  "created_at" : "2018-10-11 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stacia Varga",
      "screen_name" : "_StaciaV_",
      "indices" : [ 39, 49 ],
      "id_str" : "59038874",
      "id" : 59038874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ROIB5X9n04",
      "expanded_url" : "https:\/\/www.pluralsight.com\/courses\/microsoft-data-platform-get-started-with-r",
      "display_url" : "pluralsight.com\/courses\/micros\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1050053341819142147",
  "text" : "Online Pluralsight course presented by @_StaciaV_: Getting Started with R in the Microsoft Data Platform https:\/\/t.co\/ROIB5X9n04 #rstats",
  "id" : 1050053341819142147,
  "created_at" : "2018-10-10 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/oLEOlAXQCr",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/HighPerformanceComputing.html",
      "display_url" : "cran.r-project.org\/web\/views\/High\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1049690957552082944",
  "text" : "List of R packages and functions for high-performance and parallel computing with R: https:\/\/t.co\/oLEOlAXQCr #rstats",
  "id" : 1049690957552082944,
  "created_at" : "2018-10-09 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/nKJDOC62KC",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.5.1\/topics\/xtabs",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1049328565936738310",
  "text" : "Use xtabs(formula,data) \u007Bstats\u007D to create a contingency table from cross-classifying factors https:\/\/t.co\/nKJDOC62KC #rstats",
  "id" : 1049328565936738310,
  "created_at" : "2018-10-08 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/vz4PnPX3Mr",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/e1071\/versions\/1.7-0\/topics\/svm",
      "display_url" : "rdocumentation.org\/packages\/e1071\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1048241414625083392",
  "text" : "Train support vector machines with the \"svm\" function from the e1071 package: https:\/\/t.co\/vz4PnPX3Mr #rstats",
  "id" : 1048241414625083392,
  "created_at" : "2018-10-05 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Hxph06HPIY",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/Distributions.html",
      "display_url" : "cran.r-project.org\/web\/views\/Dist\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1047879018932973569",
  "text" : "List of 100+ probability distributions (densities, quantiles, simulation) supported in R: https:\/\/t.co\/Hxph06HPIY #rstats",
  "id" : 1047879018932973569,
  "created_at" : "2018-10-04 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/UGJTUV7S05",
      "expanded_url" : "https:\/\/docs.microsoft.com\/machine-learning-server\/operationalize\/how-to-consume-web-service-interact-in-r?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/machine-learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1047516636427800578",
  "text" : "How to call R functions via a RESTful API, at scale, with Microsoft ML Server https:\/\/t.co\/UGJTUV7S05 #rstats",
  "id" : 1047516636427800578,
  "created_at" : "2018-10-03 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/oh9i7zf0kR",
      "expanded_url" : "https:\/\/github.com\/thomasp85\/gganimate",
      "display_url" : "github.com\/thomasp85\/ggan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1047154246586699778",
  "text" : "Use the gganimate package to create smooth animations with ggplot2 https:\/\/t.co\/oh9i7zf0kR #rstats",
  "id" : 1047154246586699778,
  "created_at" : "2018-10-02 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 171, 178 ]
    } ],
    "urls" : [ {
      "indices" : [ 147, 170 ],
      "url" : "https:\/\/t.co\/73AI3zkRmV",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/diag",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1046791852903432193",
  "text" : "The behaviour of diag() depends on the length of its argument: diag(5) construct the 5x5 identity matrix, but diag(1:5) places 1:5 on the diagonal https:\/\/t.co\/73AI3zkRmV #rstats",
  "id" : 1046791852903432193,
  "created_at" : "2018-10-01 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]