Grailbird.data.tweets_2017_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/PVl91v5VmI",
      "expanded_url" : "http:\/\/journal.r-project.org\/",
      "display_url" : "journal.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "880818216456646657",
  "text" : "Keep up with R by reading the R Journal: https:\/\/t.co\/PVl91v5VmI #rstats",
  "id" : 880818216456646657,
  "created_at" : "2017-06-30 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/gNrjx1kxQT",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/libPaths",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880455822496714754",
  "text" : ".libPaths() will show the directories where R looks for packages https:\/\/t.co\/gNrjx1kxQT #rstats",
  "id" : 880455822496714754,
  "created_at" : "2017-06-29 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "useR!2017",
      "screen_name" : "useR_Brussels",
      "indices" : [ 21, 35 ],
      "id_str" : "736216890662658048",
      "id" : 736216890662658048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/RwAmd8dgDf",
      "expanded_url" : "https:\/\/channel9.msdn.com\/Events\/useR-international-R-User-conference\/useR2016",
      "display_url" : "channel9.msdn.com\/Events\/useR-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880093439672668160",
  "text" : "The useR! conference @UseR_Brussels takes place next week. Watch presentations from last year, here: https:\/\/t.co\/RwAmd8dgDf #rstats",
  "id" : 880093439672668160,
  "created_at" : "2017-06-28 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/NohBPcwt8q",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/expm\/versions\/0.99-1.1\/topics\/matpow",
      "display_url" : "rdocumentation.org\/packages\/expm\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "879731045893001217",
  "text" : "With the expm package, M %^% n is an efficient function for raising a matrix to a power https:\/\/t.co\/NohBPcwt8q #rstats",
  "id" : 879731045893001217,
  "created_at" : "2017-06-27 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/NRu3F5kZn1",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/bayesSurv\/",
      "display_url" : "mran.microsoft.com\/package\/bayesS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "879368673697202177",
  "text" : "Get started with Bayesian Survival Analysis with the bayesSurv package https:\/\/t.co\/NRu3F5kZn1 #rstats",
  "id" : 879368673697202177,
  "created_at" : "2017-06-26 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/IONffxEy3R",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2009\/03\/when-is-a-zero-not-a-zero.html",
      "display_url" : "blog.revolutionanalytics.com\/2009\/03\/when-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878281495177244677",
  "text" : "Some common pitfalls when working with floating-point numbers in #rstats: https:\/\/t.co\/IONffxEy3R",
  "id" : 878281495177244677,
  "created_at" : "2017-06-23 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/1PvluCuiL6",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/duplicated",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877919107991052288",
  "text" : "x[duplicated(x)] lists the repeated values in a vector x https:\/\/t.co\/1PvluCuiL6 #rstats",
  "id" : 877919107991052288,
  "created_at" : "2017-06-22 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ki24Jo7uOU",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2017\/03\/doazureparallel.html",
      "display_url" : "blog.revolutionanalytics.com\/2017\/03\/doazur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877556735891963904",
  "text" : "The doAzureParallel package  uses low-priority VMs for cost-efficient large-scale parallel computations https:\/\/t.co\/ki24Jo7uOU #rstats",
  "id" : 877556735891963904,
  "created_at" : "2017-06-21 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Aldhous",
      "screen_name" : "paldhous",
      "indices" : [ 37, 46 ],
      "id_str" : "589535421",
      "id" : 589535421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xjsI2wxbsH",
      "expanded_url" : "http:\/\/paldhous.github.io\/ucb\/2016\/dataviz\/week1.html",
      "display_url" : "paldhous.github.io\/ucb\/2016\/datav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877194335200169985",
  "text" : "Course notes for data journalists by @paldhous: Introduction to Data Visualization https:\/\/t.co\/xjsI2wxbsH #rstats",
  "id" : 877194335200169985,
  "created_at" : "2017-06-20 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vBahAU54fT",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/strsplit",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876831966376722433",
  "text" : "Convert a comma-separated string to a vector: strsplit(\"red,green,blue\",\",\")[[1]] #rstats https:\/\/t.co\/vBahAU54fT",
  "id" : 876831966376722433,
  "created_at" : "2017-06-19 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ycPbnIj93y",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.4.0\/topics\/par",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875744786132738048",
  "text" : "With base graphics, par(mfrow=c(2,2)) will let you put 4 plots on the same device https:\/\/t.co\/ycPbnIj93y #rstats",
  "id" : 875744786132738048,
  "created_at" : "2017-06-16 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/LgE5LMVaUh",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/cumsum",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875382400687190016",
  "text" : "cumprod(x) returns a vector containing the cumulative products of the vector x https:\/\/t.co\/LgE5LMVaUh #rstats",
  "id" : 875382400687190016,
  "created_at" : "2017-06-15 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/c1nlVe9DRz",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/microsoftml\/packagehelp\/rxneuralnet",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875020012527919104",
  "text" : "Use the rxNeuralNet function in Microsoft R to train deep neural networks with GPU acceleration https:\/\/t.co\/c1nlVe9DRz #rstats",
  "id" : 875020012527919104,
  "created_at" : "2017-06-14 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/1VMfkuyG1Y",
      "expanded_url" : "https:\/\/mran.microsoft.com\/web\/packages\/margins\/vignettes\/Introduction.html",
      "display_url" : "mran.microsoft.com\/web\/packages\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874657621382488068",
  "text" : "The \"margins\" package calculates partial effects for covariates in models (like Stata does) https:\/\/t.co\/1VMfkuyG1Y #rstats",
  "id" : 874657621382488068,
  "created_at" : "2017-06-13 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/smAKvoqrRq",
      "expanded_url" : "https:\/\/cloud.r-project.org\/doc\/manuals\/R-intro.html#A-sample-session",
      "display_url" : "cloud.r-project.org\/doc\/manuals\/R-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874295241787887616",
  "text" : "New to R? Try the \"sample session\" in the Introduction to R Manual for a 10-min tour: https:\/\/t.co\/smAKvoqrRq #rstats",
  "id" : 874295241787887616,
  "created_at" : "2017-06-12 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/FfxZwhyehG",
      "expanded_url" : "http:\/\/www.dummies.com\/programming\/r\/how-to-use-the-clipboard-to-copy-and-paste-data-in-r\/",
      "display_url" : "dummies.com\/programming\/r\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873208082444292096",
  "text" : "read.table(\"clipboard\") can be a timesaver for quick copy-and-paste from spreadsheets into R https:\/\/t.co\/FfxZwhyehG #rstats",
  "id" : 873208082444292096,
  "created_at" : "2017-06-09 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/sn6Ha8XYzH",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.0\/topics\/biplot.princomp",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872845687167123458",
  "text" : "Use biplot() to visualize principal components: biplot(princomp(USArrests)) https:\/\/t.co\/sn6Ha8XYzH #rstats",
  "id" : 872845687167123458,
  "created_at" : "2017-06-08 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/AMzfaXxOs4",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/scaler-getting-started",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872483290455965696",
  "text" : "Getting started with RevoScaleR: package of big-data functions in Microsoft R Client &amp; Server https:\/\/t.co\/AMzfaXxOs4 #rstats",
  "id" : 872483290455965696,
  "created_at" : "2017-06-07 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 72, 81 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fHUO6FD5ZQ",
      "expanded_url" : "https:\/\/ropensci.org\/packages",
      "display_url" : "ropensci.org\/packages"
    } ]
  },
  "geo" : { },
  "id_str" : "872120909955551234",
  "text" : "List of R packages for data access and scientific analysis developed by @ROpenSci https:\/\/t.co\/fHUO6FD5ZQ #rstats",
  "id" : 872120909955551234,
  "created_at" : "2017-06-06 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/hmFkNCucyE",
      "expanded_url" : "https:\/\/journal.r-project.org\/archive\/2011-1\/RJournal_2011-1_Wickham.pdf",
      "display_url" : "journal.r-project.org\/archive\/2011-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "871758528804814848",
  "text" : "Use the testthat package to create a testing framework for R packages: https:\/\/t.co\/hmFkNCucyE #rstats",
  "id" : 871758528804814848,
  "created_at" : "2017-06-05 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/heh19U1yr1",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.0\/topics\/strptime",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870671349198364672",
  "text" : "You may find strptime() and strftime() useful for inputting and formatting dates https:\/\/t.co\/heh19U1yr1 #rstats",
  "id" : 870671349198364672,
  "created_at" : "2017-06-02 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Fkn0dG1VOT",
      "expanded_url" : "http:\/\/tolstoy.newcastle.edu.au\/R\/help\/9704\/0000.html",
      "display_url" : "tolstoy.newcastle.edu.au\/R\/help\/9704\/00\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870308965422309377",
  "text" : "The r-help mailing list has beein going since April 1, 1997. Many thanks to all who have contributed! #rstats https:\/\/t.co\/Fkn0dG1VOT",
  "id" : 870308965422309377,
  "created_at" : "2017-06-01 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]