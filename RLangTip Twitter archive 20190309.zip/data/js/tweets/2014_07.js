Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/22cSR3JT8B",
      "expanded_url" : "http:\/\/bit.ly\/Nmiq4e",
      "display_url" : "bit.ly\/Nmiq4e"
    } ]
  },
  "geo" : { },
  "id_str" : "494876563964723201",
  "text" : "To search for R-related FAQs on StackOverflow, precede your search query with [r] at http:\/\/t.co\/22cSR3JT8B #rstats",
  "id" : 494876563964723201,
  "created_at" : "2014-07-31 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Qli7iHRXN5",
      "expanded_url" : "http:\/\/bit.ly\/1o0jrAW",
      "display_url" : "bit.ly\/1o0jrAW"
    } ]
  },
  "geo" : { },
  "id_str" : "494514198886748160",
  "text" : "Use the recode() function in the car package to recode variables. http:\/\/t.co\/Qli7iHRXN5 #rstats",
  "id" : 494514198886748160,
  "created_at" : "2014-07-30 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zpdv5rUWUO",
      "expanded_url" : "http:\/\/bit.ly\/1ooNuHx",
      "display_url" : "bit.ly\/1ooNuHx"
    } ]
  },
  "geo" : { },
  "id_str" : "494151810324918272",
  "text" : "For complex optimization problems (e.g. mixed-integer programming), try the lpSolveAPI package: http:\/\/t.co\/zpdv5rUWUO #rstats",
  "id" : 494151810324918272,
  "created_at" : "2014-07-29 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DdHlaP6erm",
      "expanded_url" : "http:\/\/bit.ly\/1t4vZPC",
      "display_url" : "bit.ly\/1t4vZPC"
    } ]
  },
  "geo" : { },
  "id_str" : "493789354515394563",
  "text" : "You may find strptime() and strftime() useful for inputting and formatting dates http:\/\/t.co\/DdHlaP6erm #rstats",
  "id" : 493789354515394563,
  "created_at" : "2014-07-28 16:05:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/zoSD1FTQlN",
      "expanded_url" : "http:\/\/bit.ly\/unTY2g",
      "display_url" : "bit.ly\/unTY2g"
    } ]
  },
  "geo" : { },
  "id_str" : "492702198397407232",
  "text" : "Google's style guide for R programmers: http:\/\/t.co\/zoSD1FTQlN #rstats",
  "id" : 492702198397407232,
  "created_at" : "2014-07-25 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ye8N5E3zVd",
      "expanded_url" : "http:\/\/bit.ly\/1nFwLup",
      "display_url" : "bit.ly\/1nFwLup"
    } ]
  },
  "geo" : { },
  "id_str" : "492339810275954688",
  "text" : "Get started debugging with R's browser() function http:\/\/t.co\/ye8N5E3zVd #rstats",
  "id" : 492339810275954688,
  "created_at" : "2014-07-24 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/rFlij3kmCf",
      "expanded_url" : "http:\/\/bit.ly\/1n1KEHp",
      "display_url" : "bit.ly\/1n1KEHp"
    } ]
  },
  "geo" : { },
  "id_str" : "491977432728354816",
  "text" : "Perform the Kruskal-Wallis Rank Sum Test with kruskal.test(formula,data) http:\/\/t.co\/rFlij3kmCf #stats",
  "id" : 491977432728354816,
  "created_at" : "2014-07-23 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ur2ycb5FAU",
      "expanded_url" : "http:\/\/bit.ly\/1njScXK",
      "display_url" : "bit.ly\/1njScXK"
    } ]
  },
  "geo" : { },
  "id_str" : "491615090786205698",
  "text" : "Fit a Cox Proportional Hazards Regression Model with the coxph() function in the survival package http:\/\/t.co\/ur2ycb5FAU #rstats",
  "id" : 491615090786205698,
  "created_at" : "2014-07-22 16:05:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fV4GHQYLd8",
      "expanded_url" : "http:\/\/bit.ly\/RPbC3U",
      "display_url" : "bit.ly\/RPbC3U"
    } ]
  },
  "geo" : { },
  "id_str" : "490165517567922176",
  "text" : "Strip non-ASCII characters from a string with iconv(bad.text, to=\"ASCII\", sub=\"\") #rstats http:\/\/t.co\/fV4GHQYLd8",
  "id" : 490165517567922176,
  "created_at" : "2014-07-18 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/ynbmvB9yq5",
      "expanded_url" : "http:\/\/bit.ly\/1mH7iES",
      "display_url" : "bit.ly\/1mH7iES"
    } ]
  },
  "geo" : { },
  "id_str" : "489803133154230272",
  "text" : "na.omit(df) will omit all rows of a data frame containing NAs http:\/\/t.co\/ynbmvB9yq5 #rstats",
  "id" : 489803133154230272,
  "created_at" : "2014-07-17 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/5qUT9YUGZg",
      "expanded_url" : "http:\/\/bit.ly\/n5mCJZ",
      "display_url" : "bit.ly\/n5mCJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "489440779405115392",
  "text" : "Type data() to see a list of all available data sets http:\/\/t.co\/5qUT9YUGZg #rstats",
  "id" : 489440779405115392,
  "created_at" : "2014-07-16 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/Z3CV0fBLw5",
      "expanded_url" : "http:\/\/bit.ly\/1y4GIcV",
      "display_url" : "bit.ly\/1y4GIcV"
    } ]
  },
  "geo" : { },
  "id_str" : "489078314049732608",
  "text" : "See the vignette ( http:\/\/t.co\/Z3CV0fBLw5 ) of the sparseM package for an introduction to sparse matrices in R #rstats",
  "id" : 489078314049732608,
  "created_at" : "2014-07-15 16:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/M9hFH29KXe",
      "expanded_url" : "http:\/\/bit.ly\/1y4AUzY",
      "display_url" : "bit.ly\/1y4AUzY"
    } ]
  },
  "geo" : { },
  "id_str" : "488715977925070848",
  "text" : "The TSA package has a nice collection of data sets for getting started with ARIMA models http:\/\/t.co\/M9hFH29KXe #rstats",
  "id" : 488715977925070848,
  "created_at" : "2014-07-14 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/iqrSRhX2Lj",
      "expanded_url" : "http:\/\/bit.ly\/10WrbZo",
      "display_url" : "bit.ly\/10WrbZo"
    } ]
  },
  "geo" : { },
  "id_str" : "487628782313152512",
  "text" : "You can include mathematical equations in R charts. Cheat sheet of all the math symbols you can use: http:\/\/t.co\/iqrSRhX2Lj #rstats",
  "id" : 487628782313152512,
  "created_at" : "2014-07-11 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/IWkGMUG6Zu",
      "expanded_url" : "http:\/\/bit.ly\/NmhrRE",
      "display_url" : "bit.ly\/NmhrRE"
    } ]
  },
  "geo" : { },
  "id_str" : "487266388676182017",
  "text" : "Use an existing SAS script to import an ASCII data file into R (without needing SAS): http:\/\/t.co\/IWkGMUG6Zu #rstats",
  "id" : 487266388676182017,
  "created_at" : "2014-07-10 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/iMSBt0CPLQ",
      "expanded_url" : "http:\/\/bit.ly\/1t6R7Ww",
      "display_url" : "bit.ly\/1t6R7Ww"
    } ]
  },
  "geo" : { },
  "id_str" : "486903337213001728",
  "text" : "Get started with R's XML package with Duncan Temple Lang's introduction: http:\/\/t.co\/iMSBt0CPLQ  #rstats",
  "id" : 486903337213001728,
  "created_at" : "2014-07-09 16:02:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/1egKs3suLI",
      "expanded_url" : "http:\/\/bit.ly\/1oiwAr3",
      "display_url" : "bit.ly\/1oiwAr3"
    } ]
  },
  "geo" : { },
  "id_str" : "486541602366963712",
  "text" : ".Library will give you the path to your devault R library http:\/\/t.co\/1egKs3suLI #rstats",
  "id" : 486541602366963712,
  "created_at" : "2014-07-08 16:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/uH7y9Clk3X",
      "expanded_url" : "http:\/\/rfunction.com\/archives\/2238",
      "display_url" : "rfunction.com\/archives\/2238"
    } ]
  },
  "geo" : { },
  "id_str" : "486183016767963136",
  "text" : "Use unlist() to flatten out a list of lists into a single vector: http:\/\/t.co\/uH7y9Clk3X #rstats",
  "id" : 486183016767963136,
  "created_at" : "2014-07-07 16:20:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/76lSTaMKLr",
      "expanded_url" : "http:\/\/bit.ly\/OrT9bX",
      "display_url" : "bit.ly\/OrT9bX"
    } ]
  },
  "geo" : { },
  "id_str" : "485092067337842688",
  "text" : "To speed up your R code, use Rprof() to turn on profiling, and summaryRprof() to find the slow parts: http:\/\/t.co\/76lSTaMKLr #rstats",
  "id" : 485092067337842688,
  "created_at" : "2014-07-04 16:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/1cdax0X14P",
      "expanded_url" : "http:\/\/bit.ly\/1mmkytP",
      "display_url" : "bit.ly\/1mmkytP"
    } ]
  },
  "geo" : { },
  "id_str" : "484729711088902145",
  "text" : "gregexpr() \u007Bbase\u007D finds all instances of a pattern http:\/\/t.co\/1cdax0X14P #rstats",
  "id" : 484729711088902145,
  "created_at" : "2014-07-03 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/3yR24qgwF9",
      "expanded_url" : "http:\/\/bit.ly\/UQLrR5",
      "display_url" : "bit.ly\/UQLrR5"
    } ]
  },
  "geo" : { },
  "id_str" : "484367296283312128",
  "text" : "Use lines() \u007Bgraphics\u007D to add connected line segments to base R plots http:\/\/t.co\/3yR24qgwF9 #rstats",
  "id" : 484367296283312128,
  "created_at" : "2014-07-02 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/DgIk6ZMe2c",
      "expanded_url" : "http:\/\/adv-r.had.co.nz\/Environments.html",
      "display_url" : "adv-r.had.co.nz\/Environments.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484004205796265984",
  "text" : "#rstats a very nice discussion of R Environments from Hadley Wickham http:\/\/t.co\/DgIk6ZMe2c",
  "id" : 484004205796265984,
  "created_at" : "2014-07-01 16:02:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]