Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/8uqYP8z0WS",
      "expanded_url" : "http:\/\/bit.ly\/LEU8S0",
      "display_url" : "bit.ly\/LEU8S0"
    } ]
  },
  "geo" : { },
  "id_str" : "604317787058761728",
  "text" : "Concatenate elements of a vector to a single comma-separated string: paste(letters, collapse=\", \") #rstats http:\/\/t.co\/8uqYP8z0WS",
  "id" : 604317787058761728,
  "created_at" : "2015-05-29 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/OsIGWggOEe",
      "expanded_url" : "http:\/\/bit.ly\/1pkampQ",
      "display_url" : "bit.ly\/1pkampQ"
    } ]
  },
  "geo" : { },
  "id_str" : "603955385419051008",
  "text" : "Leave out the mth column of a data frame: dF[,-m]  http:\/\/t.co\/OsIGWggOEe #rstats",
  "id" : 603955385419051008,
  "created_at" : "2015-05-28 16:05:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/b9IVCmSWtN",
      "expanded_url" : "http:\/\/bit.ly\/1JHVLAB",
      "display_url" : "bit.ly\/1JHVLAB"
    } ]
  },
  "geo" : { },
  "id_str" : "603592981963243520",
  "text" : "par(mfrow=c(2,2)); plot(lm(y~x)) will produce 4 nice plots of the regression residuals http:\/\/t.co\/b9IVCmSWtN #rstats",
  "id" : 603592981963243520,
  "created_at" : "2015-05-27 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/EElq2l0jk9",
      "expanded_url" : "http:\/\/bit.ly\/1SpvhaQ",
      "display_url" : "bit.ly\/1SpvhaQ"
    } ]
  },
  "geo" : { },
  "id_str" : "603230635256328192",
  "text" : "shapiro.test(x) performs the Shapiro-Wilk Normality Test on the vector x. http:\/\/t.co\/EElq2l0jk9 #rstats",
  "id" : 603230635256328192,
  "created_at" : "2015-05-26 16:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/SjfxkAlCus",
      "expanded_url" : "http:\/\/bit.ly\/1RaHmiy",
      "display_url" : "bit.ly\/1RaHmiy"
    } ]
  },
  "geo" : { },
  "id_str" : "602868188070735872",
  "text" : "Look here (http:\/\/t.co\/SjfxkAlCus) for documentation on \"Model Training and Tuning\" with the caret package.  #rstats",
  "id" : 602868188070735872,
  "created_at" : "2015-05-25 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Cgm69PamVN",
      "expanded_url" : "http:\/\/bit.ly\/1FU7kmW",
      "display_url" : "bit.ly\/1FU7kmW"
    } ]
  },
  "geo" : { },
  "id_str" : "601781018278891520",
  "text" : "Use the digits option to display a number to desired precision. e.g. print(pi, digits=16). http:\/\/t.co\/Cgm69PamVN #rstats",
  "id" : 601781018278891520,
  "created_at" : "2015-05-22 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/9OeWVViaD0",
      "expanded_url" : "http:\/\/bit.ly\/Lpx9Q7",
      "display_url" : "bit.ly\/Lpx9Q7"
    } ]
  },
  "geo" : { },
  "id_str" : "601418601212555264",
  "text" : "How to create or catch warnings and errors in R code: http:\/\/t.co\/9OeWVViaD0 #rstats",
  "id" : 601418601212555264,
  "created_at" : "2015-05-21 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5xJmW6iwaY",
      "expanded_url" : "http:\/\/bit.ly\/16wTl6t",
      "display_url" : "bit.ly\/16wTl6t"
    } ]
  },
  "geo" : { },
  "id_str" : "601056218241769472",
  "text" : "Read a .csv file from a website into a data frame: fp &lt;- file.path(\"URL\",\"filename.csv\"); df &lt;- read.csv(fp) http:\/\/t.co\/5xJmW6iwaY",
  "id" : 601056218241769472,
  "created_at" : "2015-05-20 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/FKs3Qc4yi5",
      "expanded_url" : "http:\/\/bit.ly\/1RQYtqT",
      "display_url" : "bit.ly\/1RQYtqT"
    } ]
  },
  "geo" : { },
  "id_str" : "600693827788214273",
  "text" : "pmin(x,y) and pmax(z,w) return the parallel minima and maxima of their arguments http:\/\/t.co\/FKs3Qc4yi5 #rstats",
  "id" : 600693827788214273,
  "created_at" : "2015-05-19 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/m2d6ibla6R",
      "expanded_url" : "http:\/\/bit.ly\/1Fpf7ue",
      "display_url" : "bit.ly\/1Fpf7ue"
    } ]
  },
  "geo" : { },
  "id_str" : "600331449573707776",
  "text" : "Use hclust() in \u007Bstats\u007D for hierarchical clustering http:\/\/t.co\/m2d6ibla6R #rstats",
  "id" : 600331449573707776,
  "created_at" : "2015-05-18 16:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/sgqPXFYItX",
      "expanded_url" : "http:\/\/bit.ly\/1IpcyYd",
      "display_url" : "bit.ly\/1IpcyYd"
    } ]
  },
  "geo" : { },
  "id_str" : "599244416902156288",
  "text" : "The $ operator uses partial matching. mylist$el returns the contents of mylist$element if no exact match #rstats http:\/\/t.co\/sgqPXFYItX",
  "id" : 599244416902156288,
  "created_at" : "2015-05-15 16:06:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Cgm69PamVN",
      "expanded_url" : "http:\/\/bit.ly\/1FU7kmW",
      "display_url" : "bit.ly\/1FU7kmW"
    } ]
  },
  "geo" : { },
  "id_str" : "598881934098432000",
  "text" : "To debug warnings, options(warn=2) converts warnings into errors #rstats http:\/\/t.co\/Cgm69PamVN",
  "id" : 598881934098432000,
  "created_at" : "2015-05-14 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Z5SxoATxSA",
      "expanded_url" : "http:\/\/bit.ly\/N4cAV6",
      "display_url" : "bit.ly\/N4cAV6"
    } ]
  },
  "geo" : { },
  "id_str" : "598519554487230464",
  "text" : "Draw a map of the United States: library(maps); map('usa') #rstats http:\/\/t.co\/Z5SxoATxSA",
  "id" : 598519554487230464,
  "created_at" : "2015-05-13 16:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/EwROJqG014",
      "expanded_url" : "http:\/\/bit.ly\/1Rlmi9Y",
      "display_url" : "bit.ly\/1Rlmi9Y"
    } ]
  },
  "geo" : { },
  "id_str" : "598157172732727296",
  "text" : "Get started with Bayesian Survival Analysis with the bayesSurv package http:\/\/t.co\/EwROJqG014 #rstats",
  "id" : 598157172732727296,
  "created_at" : "2015-05-12 16:05:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/MPZ73QBNOS",
      "expanded_url" : "http:\/\/bit.ly\/1cw7RjO",
      "display_url" : "bit.ly\/1cw7RjO"
    } ]
  },
  "geo" : { },
  "id_str" : "597794791032774656",
  "text" : "Use jitter(x) \u007Bbase\u007D to add some noise to your data. Very useful for dealing with overplotting. #rstats http:\/\/t.co\/MPZ73QBNOS",
  "id" : 597794791032774656,
  "created_at" : "2015-05-11 16:05:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/EmQgmwijho",
      "expanded_url" : "http:\/\/bit.ly\/1dBKJAA",
      "display_url" : "bit.ly\/1dBKJAA"
    } ]
  },
  "geo" : { },
  "id_str" : "596707593034342400",
  "text" : "The function t() \u007Bbase\u007D will transpose a matrix http:\/\/t.co\/EmQgmwijho #rstats",
  "id" : 596707593034342400,
  "created_at" : "2015-05-08 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ABZ1yVmaEA",
      "expanded_url" : "http:\/\/bit.ly\/HbMcJo",
      "display_url" : "bit.ly\/HbMcJo"
    } ]
  },
  "geo" : { },
  "id_str" : "596345196100591617",
  "text" : "fitdistr fits a univariate probability distribution to a vector of data using maximum likelihood estimation: http:\/\/t.co\/ABZ1yVmaEA #rstats",
  "id" : 596345196100591617,
  "created_at" : "2015-05-07 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/4u7rHQvJgg",
      "expanded_url" : "http:\/\/docs.ggplot2.org\/current\/",
      "display_url" : "docs.ggplot2.org\/current\/"
    } ]
  },
  "geo" : { },
  "id_str" : "595982804569223169",
  "text" : "Online help for ggplot2  http:\/\/t.co\/4u7rHQvJgg #rstats",
  "id" : 595982804569223169,
  "created_at" : "2015-05-06 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/zMZk1k7Rpv",
      "expanded_url" : "http:\/\/bit.ly\/1PcXf5f",
      "display_url" : "bit.ly\/1PcXf5f"
    } ]
  },
  "geo" : { },
  "id_str" : "595620426010734592",
  "text" : "xor(x,y) (element wise exclusive OR) is one of R's logical operators http:\/\/t.co\/zMZk1k7Rpv #rstats",
  "id" : 595620426010734592,
  "created_at" : "2015-05-05 16:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/i3GdYeuvnD",
      "expanded_url" : "http:\/\/bit.ly\/1Fm53R7",
      "display_url" : "bit.ly\/1Fm53R7"
    } ]
  },
  "geo" : { },
  "id_str" : "595258010680844289",
  "text" : "as.data.frame(x) \u007Bbase\u007D to turn lists, matrices, tables and more data structures into data frames http:\/\/t.co\/i3GdYeuvnD #rstats",
  "id" : 595258010680844289,
  "created_at" : "2015-05-04 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/rnaWi1xzOE",
      "expanded_url" : "http:\/\/rfunction.com",
      "display_url" : "rfunction.com"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/81igovFF4M",
      "expanded_url" : "http:\/\/bit.ly\/1mI1RnG",
      "display_url" : "bit.ly\/1mI1RnG"
    } ]
  },
  "geo" : { },
  "id_str" : "594170823491067905",
  "text" : "Some examples of get() to call an R object using a character string: http:\/\/t.co\/rnaWi1xzOE (http:\/\/t.co\/81igovFF4M) #rstats",
  "id" : 594170823491067905,
  "created_at" : "2015-05-01 16:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]