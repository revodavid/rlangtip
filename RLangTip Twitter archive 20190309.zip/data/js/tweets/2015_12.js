Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Lemaitre",
      "screen_name" : "joshlemaitre",
      "indices" : [ 115, 128 ],
      "id_str" : "21264652",
      "id" : 21264652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/lIC5QjwC5s",
      "expanded_url" : "http:\/\/bit.ly\/QKKDsn",
      "display_url" : "bit.ly\/QKKDsn"
    } ]
  },
  "geo" : { },
  "id_str" : "682487688080048132",
  "text" : "Forgot to save the output from the last #rstats command? Retrieve it with .Last.value https:\/\/t.co\/lIC5QjwC5s (via @joshlemaitre)",
  "id" : 682487688080048132,
  "created_at" : "2015-12-31 09:05:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/CY2xisnlzG",
      "expanded_url" : "http:\/\/bit.ly\/1NPdoxd",
      "display_url" : "bit.ly\/1NPdoxd"
    } ]
  },
  "geo" : { },
  "id_str" : "682246222107799552",
  "text" : "edit(object) \u007Butils\u007D will invoke a text editor for an R object  https:\/\/t.co\/CY2xisnlzG #rstats",
  "id" : 682246222107799552,
  "created_at" : "2015-12-30 17:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/pPkXM3tOcT",
      "expanded_url" : "http:\/\/bit.ly\/1J8wbXO",
      "display_url" : "bit.ly\/1J8wbXO"
    } ]
  },
  "geo" : { },
  "id_str" : "681883808031981568",
  "text" : "Learn or teach integration with area() \u007BMASS\u007D e.g. area(sin,0,pi) to integrate sin over [0,pi] https:\/\/t.co\/pPkXM3tOcT #rstats",
  "id" : 681883808031981568,
  "created_at" : "2015-12-29 17:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/nGyeFEZvZ9",
      "expanded_url" : "http:\/\/bit.ly\/NaIjcI",
      "display_url" : "bit.ly\/NaIjcI"
    } ]
  },
  "geo" : { },
  "id_str" : "681521472888791041",
  "text" : "To convert dates\/times from one timezone to another, use format() on a POSIXct object. Details: https:\/\/t.co\/nGyeFEZvZ9 #rstats",
  "id" : 681521472888791041,
  "created_at" : "2015-12-28 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/W48N8N7LKI",
      "expanded_url" : "http:\/\/bit.ly\/1T6EW4J",
      "display_url" : "bit.ly\/1T6EW4J"
    } ]
  },
  "geo" : { },
  "id_str" : "680434223023570947",
  "text" : "Happy Holidays and demo('Xmas\") \u007Banimation\u007D https:\/\/t.co\/W48N8N7LKI #rstats",
  "id" : 680434223023570947,
  "created_at" : "2015-12-25 17:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    }, {
      "text" : "bioconductor",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/iG4GAVo1eI",
      "expanded_url" : "http:\/\/bit.ly\/1YmXg0a",
      "display_url" : "bit.ly\/1YmXg0a"
    } ]
  },
  "geo" : { },
  "id_str" : "680056756253421568",
  "text" : "SANTA will help you quantify the association between a gene and a molecular network https:\/\/t.co\/iG4GAVo1eI #rstats #bioconductor",
  "id" : 680056756253421568,
  "created_at" : "2015-12-24 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/IuZIa5IqMS",
      "expanded_url" : "http:\/\/bit.ly\/18bS1Sy",
      "display_url" : "bit.ly\/18bS1Sy"
    } ]
  },
  "geo" : { },
  "id_str" : "679709518159298560",
  "text" : "Use library() to see all packages installed, search() to see all packages loaded #rstats https:\/\/t.co\/IuZIa5IqMS",
  "id" : 679709518159298560,
  "created_at" : "2015-12-23 17:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/wz52IQbtje",
      "expanded_url" : "http:\/\/bit.ly\/1mcYCJs",
      "display_url" : "bit.ly\/1mcYCJs"
    } ]
  },
  "geo" : { },
  "id_str" : "679346507443781632",
  "text" : "convolve(x,y) \u007Bstats\u007D uses the FFT to convolve two sequences of the same length. https:\/\/t.co\/wz52IQbtje #rstats",
  "id" : 679346507443781632,
  "created_at" : "2015-12-22 17:03:23 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/1ZRhl7txdr",
      "expanded_url" : "http:\/\/bit.ly\/1YmEFl2",
      "display_url" : "bit.ly\/1YmEFl2"
    } ]
  },
  "geo" : { },
  "id_str" : "678984754318954497",
  "text" : "For rpart classification trees: residuals(fit,type=\"deviance\") returns the deviance residuals https:\/\/t.co\/1ZRhl7txdr #rstats",
  "id" : 678984754318954497,
  "created_at" : "2015-12-21 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Cr0dHFDTZf",
      "expanded_url" : "http:\/\/bit.ly\/14qtBWO",
      "display_url" : "bit.ly\/14qtBWO"
    } ]
  },
  "geo" : { },
  "id_str" : "677897682132840449",
  "text" : "Use savePlot() from the grDevices package to save a Windows plot to a file #rstats https:\/\/t.co\/Cr0dHFDTZf",
  "id" : 677897682132840449,
  "created_at" : "2015-12-18 17:06:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/lBavsorL5l",
      "expanded_url" : "http:\/\/cran.revolutionanalytics.com",
      "display_url" : "cran.revolutionanalytics.com"
    } ]
  },
  "geo" : { },
  "id_str" : "677534790871031808",
  "text" : "options(repos=\"https:\/\/t.co\/lBavsorL5l\") [or your local mirror] in .Rprofile prevents #rstats prompting on package install",
  "id" : 677534790871031808,
  "created_at" : "2015-12-17 17:04:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/bC0mWds0Tj",
      "expanded_url" : "http:\/\/bit.ly\/1Q8fxKp",
      "display_url" : "bit.ly\/1Q8fxKp"
    } ]
  },
  "geo" : { },
  "id_str" : "677172884540887041",
  "text" : ".libPaths() will show the directories R looks in for packages. https:\/\/t.co\/bC0mWds0Tj #rstats",
  "id" : 677172884540887041,
  "created_at" : "2015-12-16 17:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/W9flz3FDrK",
      "expanded_url" : "http:\/\/bit.ly\/21VOW79",
      "display_url" : "bit.ly\/21VOW79"
    } ]
  },
  "geo" : { },
  "id_str" : "676810465218048000",
  "text" : "condest(M) \u007BMatrix\u007D computes the approximate condition number and 1-Norm of large matrices https:\/\/t.co\/W9flz3FDrK #rstats",
  "id" : 676810465218048000,
  "created_at" : "2015-12-15 17:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/W9flz3FDrK",
      "expanded_url" : "http:\/\/bit.ly\/21VOW79",
      "display_url" : "bit.ly\/21VOW79"
    } ]
  },
  "geo" : { },
  "id_str" : "676448032360144896",
  "text" : "daisy(df) \u007Bcluster\u007D computes all the pairwise dissimilarities between observations in the data frame https:\/\/t.co\/W9flz3FDrK #rstats",
  "id" : 676448032360144896,
  "created_at" : "2015-12-14 17:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/NNqSqvq0MT",
      "expanded_url" : "http:\/\/bit.ly\/1ODroyf",
      "display_url" : "bit.ly\/1ODroyf"
    } ]
  },
  "geo" : { },
  "id_str" : "675360943308742657",
  "text" : "uniroot(fun,c(a,b)) in \u007Bstats\u007D will search for the root of a function in the interval [a,b]. https:\/\/t.co\/NNqSqvq0MT #rstats",
  "id" : 675360943308742657,
  "created_at" : "2015-12-11 17:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/GijbrMnCVZ",
      "expanded_url" : "http:\/\/bit.ly\/PF2nXj",
      "display_url" : "bit.ly\/PF2nXj"
    } ]
  },
  "geo" : { },
  "id_str" : "674998529530662912",
  "text" : "Print a human-readable version of a matrix: write.table(format(X), row.names=F, col.names=F, quote=F) #rstats https:\/\/t.co\/GijbrMnCVZ",
  "id" : 674998529530662912,
  "created_at" : "2015-12-10 17:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/oJvtrX1joZ",
      "expanded_url" : "http:\/\/bit.ly\/1O8gfkz",
      "display_url" : "bit.ly\/1O8gfkz"
    } ]
  },
  "geo" : { },
  "id_str" : "674636309978312704",
  "text" : "simulate(obj) in \u007Bstats\u007D will simulate one or more responses from the distribution of a fitted model object https:\/\/t.co\/oJvtrX1joZ #rstats",
  "id" : 674636309978312704,
  "created_at" : "2015-12-09 17:06:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/RDFSsjp35Q",
      "expanded_url" : "http:\/\/bit.ly\/1awt2J7",
      "display_url" : "bit.ly\/1awt2J7"
    } ]
  },
  "geo" : { },
  "id_str" : "674273745972908032",
  "text" : "Calculate the differences between every nth value of a vector x with diff(x,n) #rstats https:\/\/t.co\/RDFSsjp35Q",
  "id" : 674273745972908032,
  "created_at" : "2015-12-08 17:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/2GTMP1kkyb",
      "expanded_url" : "http:\/\/bit.ly\/PG2UmB",
      "display_url" : "bit.ly\/PG2UmB"
    } ]
  },
  "geo" : { },
  "id_str" : "673911368907649024",
  "text" : "Convert a numeric vector to a factor with \"cut\", e.g. cut(rnorm(100),3,c(\"Low\",\"Med\",\"High\")) #rstats https:\/\/t.co\/2GTMP1kkyb",
  "id" : 673911368907649024,
  "created_at" : "2015-12-07 17:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/cytvjYjCHi",
      "expanded_url" : "http:\/\/bit.ly\/pxeDBp",
      "display_url" : "bit.ly\/pxeDBp"
    } ]
  },
  "geo" : { },
  "id_str" : "672824205977722880",
  "text" : "Download and install new packages from the R command line with the install.packages function: https:\/\/t.co\/cytvjYjCHi #rstats",
  "id" : 672824205977722880,
  "created_at" : "2015-12-04 17:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/PGqo2tpjuC",
      "expanded_url" : "http:\/\/bit.ly\/s3u5Xe",
      "display_url" : "bit.ly\/s3u5Xe"
    } ]
  },
  "geo" : { },
  "id_str" : "672461834184708097",
  "text" : "is.finite(x) is a useful test for \"proper\" data: it returns FALSE for NA, NaN and Inf: https:\/\/t.co\/PGqo2tpjuC #rstats",
  "id" : 672461834184708097,
  "created_at" : "2015-12-03 17:06:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/nYsflC1uAz",
      "expanded_url" : "http:\/\/bit.ly\/qjhWGI",
      "display_url" : "bit.ly\/qjhWGI"
    } ]
  },
  "geo" : { },
  "id_str" : "672104986998939648",
  "text" : "In R, NA represents missing values. To check for NA's, use the is.na function, not the == operator https:\/\/t.co\/nYsflC1uAz #rstats",
  "id" : 672104986998939648,
  "created_at" : "2015-12-02 17:28:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/w1PVekCEue",
      "expanded_url" : "http:\/\/bit.ly\/1Ifoi2a",
      "display_url" : "bit.ly\/1Ifoi2a"
    } ]
  },
  "geo" : { },
  "id_str" : "671737081551527936",
  "text" : "body(fun) \u007Bbase\u007D will print the body of a function e.g. try body(lm) https:\/\/t.co\/w1PVekCEue #rstats",
  "id" : 671737081551527936,
  "created_at" : "2015-12-01 17:06:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]