Grailbird.data.tweets_2018_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ctexWUPmI7",
      "expanded_url" : "http:\/\/cda.ms\/6r",
      "display_url" : "cda.ms\/6r"
    } ]
  },
  "geo" : { },
  "id_str" : "958746707457724416",
  "text" : "Overview of the RevoScaleR package for data science at scale (part of Microsoft ML Server) https:\/\/t.co\/ctexWUPmI7 #rstats",
  "id" : 958746707457724416,
  "created_at" : "2018-01-31 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 153, 160 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/ChPj7UcR5O",
      "expanded_url" : "https:\/\/hub.docker.com\/r\/rocker",
      "display_url" : "hub.docker.com\/r\/rocker"
    }, {
      "indices" : [ 129, 152 ],
      "url" : "https:\/\/t.co\/zYfP3XvgoP",
      "expanded_url" : "https:\/\/journal.r-project.org\/archive\/2017\/RJ-2017-065\/RJ-2017-065.pdf",
      "display_url" : "journal.r-project.org\/archive\/2017\/R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958384322125459457",
  "text" : "Find curated Docker images for R-based workloads at https:\/\/t.co\/ChPj7UcR5O, and see this R Journal article for more background: https:\/\/t.co\/zYfP3XvgoP #rstats",
  "id" : 958384322125459457,
  "created_at" : "2018-01-30 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "rstats",
      "indices" : [ 141, 148 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EJMCA5JBKd",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/apropos",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958021931915243527",
  "text" : "Don't know the full name of a function? Perform a fuzzy search with the apropos function: apropos(\"summary\") #rstats https:\/\/t.co\/EJMCA5JBKd #rstats",
  "id" : 958021931915243527,
  "created_at" : "2018-01-29 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/LrWFGFvWha",
      "expanded_url" : "http:\/\/cda.ms\/6t",
      "display_url" : "cda.ms\/6t"
    } ]
  },
  "geo" : { },
  "id_str" : "956934762135982080",
  "text" : "How to launch R in the Data Science Virtual Machine https:\/\/t.co\/LrWFGFvWha #rstats",
  "id" : 956934762135982080,
  "created_at" : "2018-01-26 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/w0EQyYegqr",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/oz\/versions\/1.0-21\/topics\/oz",
      "display_url" : "rdocumentation.org\/packages\/oz\/ve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956577405652500480",
  "text" : "library(oz); oz() creates a map of Australia https:\/\/t.co\/w0EQyYegqr",
  "id" : 956577405652500480,
  "created_at" : "2018-01-25 17:20:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/3UIFu89Kja",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.3\/topics\/range",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "956209993543507968",
  "text" : "range(x) returns the minimum and maximum values of x https:\/\/t.co\/3UIFu89Kja #rstats",
  "id" : 956209993543507968,
  "created_at" : "2018-01-24 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger D. Peng",
      "screen_name" : "rdpeng",
      "indices" : [ 49, 56 ],
      "id_str" : "9308212",
      "id" : 9308212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/FNb2d2vgFd",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2012\/12\/coursera-videos.html",
      "display_url" : "blog.revolutionanalytics.com\/2012\/12\/course\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955847602829869056",
  "text" : "A ten-hour video introduction to R, presented by @rdpeng https:\/\/t.co\/FNb2d2vgFd #rstats",
  "id" : 955847602829869056,
  "created_at" : "2018-01-23 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Z0wGPTJAuu",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/magrittr\/vignettes\/magrittr.html",
      "display_url" : "cran.r-project.org\/web\/packages\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "955485212133113856",
  "text" : "The %&gt;% operator from the magrittr package pipes data from function to function for more readable R code https:\/\/t.co\/Z0wGPTJAuu #rstats",
  "id" : 955485212133113856,
  "created_at" : "2018-01-22 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/UEJIjr9JAi",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/jitter",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "954398063921192962",
  "text" : "Use jitter(x) to add some noise to your data. Very useful for dealing with overplotting in scatterplots. #rstats https:\/\/t.co\/UEJIjr9JAi",
  "id" : 954398063921192962,
  "created_at" : "2018-01-19 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/znpquUUgnj",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/diffobj",
      "display_url" : "mran.microsoft.com\/package\/diffobj"
    } ]
  },
  "geo" : { },
  "id_str" : "954035657327955968",
  "text" : "Use the diffobj package to compare the results of analysis outputs, for reproducibility https:\/\/t.co\/znpquUUgnj #rstats",
  "id" : 954035657327955968,
  "created_at" : "2018-01-18 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/K2rZcgHcr7",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2017\/12\/r-in-the-windows-subsystem-for-linux.html",
      "display_url" : "blog.revolutionanalytics.com\/2017\/12\/r-in-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "953673269990776832",
  "text" : "How to run R in the Windows Subsystem for Linux https:\/\/t.co\/K2rZcgHcr7 #rstats",
  "id" : 953673269990776832,
  "created_at" : "2018-01-17 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/rqtqB945Ll",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/nlme\/versions\/3.1-68.1\/topics\/nlme",
      "display_url" : "rdocumentation.org\/packages\/nlme\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "952948508226711552",
  "text" : "Fit a nonlinear mixed-effects model with the nlme package https:\/\/t.co\/rqtqB945Ll #rstats",
  "id" : 952948508226711552,
  "created_at" : "2018-01-15 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7Pzqw1IdGS",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.3\/topics\/head",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951861344105566211",
  "text" : "head(x, n) shows the first n elements of x; head(x, -n) shows all but the last n elements https:\/\/t.co\/7Pzqw1IdGS #rstats",
  "id" : 951861344105566211,
  "created_at" : "2018-01-12 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/lH6atMcGFm",
      "expanded_url" : "https:\/\/cloud.r-project.org",
      "display_url" : "cloud.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "951498944432910336",
  "text" : "Download R from (and set your CRAN mirror to) https:\/\/t.co\/lH6atMcGFm. It automatically chooses a fast, nearby mirror for you. #rstats",
  "id" : 951498944432910336,
  "created_at" : "2018-01-11 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 143, 150 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/EOvdlKNIZc",
      "expanded_url" : "https:\/\/jimskinner.github.io\/post\/elegant-linear-algebra-in-r-with-the-matrix-package\/",
      "display_url" : "jimskinner.github.io\/post\/elegant-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "951136572388331522",
  "text" : "Use the Matrix package for efficient linear algebra with sparse, symmetric, positive semidefinite and general matrices https:\/\/t.co\/EOvdlKNIZc #rstats",
  "id" : 951136572388331522,
  "created_at" : "2018-01-10 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/JMyZim93sC",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/benford.analysis\/versions\/0.1.2.1\/topics\/benford",
      "display_url" : "rdocumentation.org\/packages\/benfo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "950774170358444033",
  "text" : "Detect human tampering with numerical data. Check the digits follow Benford's Law: https:\/\/t.co\/JMyZim93sC #rstats",
  "id" : 950774170358444033,
  "created_at" : "2018-01-09 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/v8vWhMgRMe",
      "expanded_url" : "https:\/\/github.com\/r-lib\/later",
      "display_url" : "github.com\/r-lib\/later"
    } ]
  },
  "geo" : { },
  "id_str" : "950411791477231617",
  "text" : "Schedule an R function to run sometime in the future with the \"later\" package https:\/\/t.co\/v8vWhMgRMe #rstats",
  "id" : 950411791477231617,
  "created_at" : "2018-01-08 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 61, 71 ],
      "id_str" : "17522755",
      "id" : 17522755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/vmHCimML3U",
      "expanded_url" : "https:\/\/www.johndcook.com\/blog\/r_language_regex\/",
      "display_url" : "johndcook.com\/blog\/r_languag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "949324619705614336",
  "text" : "Regular expressions in R https:\/\/t.co\/vmHCimML3U #rstats (by @johndcook)",
  "id" : 949324619705614336,
  "created_at" : "2018-01-05 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/RWOPthOIon",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.3\/topics\/Cauchy",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948962239838609413",
  "text" : "The Cauchy distribution has no Expectation! Use rcauchy() to generate pseudorandom samples https:\/\/t.co\/RWOPthOIon #stats",
  "id" : 948962239838609413,
  "created_at" : "2018-01-04 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/e4XKTGzlY5",
      "expanded_url" : "https:\/\/yihui.name\/animation\/",
      "display_url" : "yihui.name\/animation\/"
    } ]
  },
  "geo" : { },
  "id_str" : "948599845236899840",
  "text" : "Use the animation package to create videos and animated GIFs from R graphics https:\/\/t.co\/e4XKTGzlY5 #rstats",
  "id" : 948599845236899840,
  "created_at" : "2018-01-03 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The R Foundation",
      "screen_name" : "_R_Foundation",
      "indices" : [ 63, 77 ],
      "id_str" : "794458165987438592",
      "id" : 794458165987438592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/5MCiE0HMMf",
      "expanded_url" : "https:\/\/www.r-project.org\/foundation\/donations.html",
      "display_url" : "r-project.org\/foundation\/don\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947875069749088256",
  "text" : "Support the R project by making a donation to the R Foundation @_R_Foundation https:\/\/t.co\/5MCiE0HMMf #rstats",
  "id" : 947875069749088256,
  "created_at" : "2018-01-01 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]