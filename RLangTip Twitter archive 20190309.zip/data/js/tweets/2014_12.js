Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/X4JYOMt1Pw",
      "expanded_url" : "http:\/\/bit.ly\/1dgHyKm",
      "display_url" : "bit.ly\/1dgHyKm"
    } ]
  },
  "geo" : { },
  "id_str" : "550336926486921216",
  "text" : "An R \"Happy New Year\" greeting from Yihui Xie #rstats http:\/\/t.co\/X4JYOMt1Pw",
  "id" : 550336926486921216,
  "created_at" : "2014-12-31 17:05:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3wX3OGyI4l",
      "expanded_url" : "http:\/\/bit.ly\/vkHZxy",
      "display_url" : "bit.ly\/vkHZxy"
    } ]
  },
  "geo" : { },
  "id_str" : "549974545533534208",
  "text" : "The tryCatch function lets an R programmer respond to an error without crashing back to the interpreter: http:\/\/t.co\/3wX3OGyI4l #rstats",
  "id" : 549974545533534208,
  "created_at" : "2014-12-30 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/VwcaCDw474",
      "expanded_url" : "http:\/\/bit.ly\/1AYH7OP",
      "display_url" : "bit.ly\/1AYH7OP"
    } ]
  },
  "geo" : { },
  "id_str" : "549612134578286593",
  "text" : "#rstats Use the exists() function \u007Bbase\u007D to see if an R object is defined. http:\/\/t.co\/VwcaCDw474",
  "id" : 549612134578286593,
  "created_at" : "2014-12-29 17:05:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/zk0yC5RnO3",
      "expanded_url" : "http:\/\/bit.ly\/1zGdGS6",
      "display_url" : "bit.ly\/1zGdGS6"
    } ]
  },
  "geo" : { },
  "id_str" : "548524958599888897",
  "text" : "#rstats Do maximum likelihood estimation directly with the mle() function from the stats4 package. http:\/\/t.co\/zk0yC5RnO3",
  "id" : 548524958599888897,
  "created_at" : "2014-12-26 17:05:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/E2pnLyotWN",
      "expanded_url" : "http:\/\/bit.ly\/1vc8q3u",
      "display_url" : "bit.ly\/1vc8q3u"
    }, {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/iT0vaWz2Fq",
      "expanded_url" : "http:\/\/bit.ly\/1c0aZiF",
      "display_url" : "bit.ly\/1c0aZiF"
    } ]
  },
  "geo" : { },
  "id_str" : "548162560449859584",
  "text" : "#rstats A couple of R Merry Christmas wishes! http:\/\/t.co\/E2pnLyotWN and http:\/\/t.co\/iT0vaWz2Fq",
  "id" : 548162560449859584,
  "created_at" : "2014-12-25 17:05:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/t3OA9Yd8rE",
      "expanded_url" : "http:\/\/bit.ly\/wGWFiD",
      "display_url" : "bit.ly\/wGWFiD"
    } ]
  },
  "geo" : { },
  "id_str" : "547800198848999425",
  "text" : "Train support vector machines with the \"svm\" function from the e1071 package: http:\/\/t.co\/t3OA9Yd8rE #rstats",
  "id" : 547800198848999425,
  "created_at" : "2014-12-24 17:05:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/znRMEmvf28",
      "expanded_url" : "http:\/\/bit.ly\/1wuJVnr",
      "display_url" : "bit.ly\/1wuJVnr"
    } ]
  },
  "geo" : { },
  "id_str" : "547436936823320576",
  "text" : "#rstats You may find the function dpith() in the KernSmooth package useful for setting histogram bin widths. http:\/\/t.co\/znRMEmvf28",
  "id" : 547436936823320576,
  "created_at" : "2014-12-23 17:01:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/CxtPrpVHz3",
      "expanded_url" : "http:\/\/bit.ly\/JwCeEd",
      "display_url" : "bit.ly\/JwCeEd"
    } ]
  },
  "geo" : { },
  "id_str" : "547075443346898945",
  "text" : "To calculate the inverse of a square numeric matrix, use solve(X): http:\/\/t.co\/CxtPrpVHz3 #rstats",
  "id" : 547075443346898945,
  "created_at" : "2014-12-22 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/A91PIqEVQU",
      "expanded_url" : "http:\/\/bit.ly\/1woP2Eb",
      "display_url" : "bit.ly\/1woP2Eb"
    } ]
  },
  "geo" : { },
  "id_str" : "545988312616665088",
  "text" : "#rstats Use embed(x,3) to embed a time series,x, into 3 dimensional space. http:\/\/t.co\/A91PIqEVQU",
  "id" : 545988312616665088,
  "created_at" : "2014-12-19 17:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/eGniwrifHc",
      "expanded_url" : "http:\/\/bit.ly\/Pq3v0n",
      "display_url" : "bit.ly\/Pq3v0n"
    } ]
  },
  "geo" : { },
  "id_str" : "545625933831757824",
  "text" : "How to calculate Prob(X &gt; Y) where X and Y are Gamma distributed: http:\/\/t.co\/eGniwrifHc #rstats",
  "id" : 545625933831757824,
  "created_at" : "2014-12-18 17:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uqitB2gF5H",
      "expanded_url" : "http:\/\/bit.ly\/rIMpZa",
      "display_url" : "bit.ly\/rIMpZa"
    } ]
  },
  "geo" : { },
  "id_str" : "545263542820429824",
  "text" : "The \"round\" function uses the \"round-to-even\" rule. round(3.5) and round(4.5) are both 4 http:\/\/t.co\/uqitB2gF5H #rstats",
  "id" : 545263542820429824,
  "created_at" : "2014-12-17 17:05:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/FdL0ZeZ8Z8",
      "expanded_url" : "http:\/\/bit.ly\/1GkDNRw",
      "display_url" : "bit.ly\/1GkDNRw"
    } ]
  },
  "geo" : { },
  "id_str" : "544901194435809280",
  "text" : "#rstats Download maps from Google Maps with get_map from the ggmap package http:\/\/t.co\/FdL0ZeZ8Z8",
  "id" : 544901194435809280,
  "created_at" : "2014-12-16 17:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/WIjhib4z5P",
      "expanded_url" : "http:\/\/bit.ly\/13hMJcq",
      "display_url" : "bit.ly\/13hMJcq"
    } ]
  },
  "geo" : { },
  "id_str" : "544538729176911872",
  "text" : "#rstats read.table() taking too long, try fread() from the data.table package http:\/\/t.co\/WIjhib4z5P",
  "id" : 544538729176911872,
  "created_at" : "2014-12-15 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slawa Rokicki",
      "screen_name" : "slawarokicki",
      "indices" : [ 69, 82 ],
      "id_str" : "926807978",
      "id" : 926807978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/1sAqzk4zOv",
      "expanded_url" : "http:\/\/bit.ly\/VLGCFf",
      "display_url" : "bit.ly\/VLGCFf"
    } ]
  },
  "geo" : { },
  "id_str" : "543451593346404352",
  "text" : "Making sense of R's error messages when working with data frames (by @slawarokicki): http:\/\/t.co\/1sAqzk4zOv #rstats",
  "id" : 543451593346404352,
  "created_at" : "2014-12-12 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BsXzNTodi7",
      "expanded_url" : "http:\/\/bit.ly\/auoC65",
      "display_url" : "bit.ly\/auoC65"
    } ]
  },
  "geo" : { },
  "id_str" : "543089196693749760",
  "text" : "log1p(x) computes log(1 + x). Why is such a function necessary? http:\/\/t.co\/BsXzNTodi7 #rstats",
  "id" : 543089196693749760,
  "created_at" : "2014-12-11 17:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/bsNawXp9de",
      "expanded_url" : "http:\/\/bit.ly\/12sXuHv",
      "display_url" : "bit.ly\/12sXuHv"
    } ]
  },
  "geo" : { },
  "id_str" : "542726823793410048",
  "text" : "#rstats Go between lower and upper case characters and back again with toupper() and tolower(). http:\/\/t.co\/bsNawXp9de",
  "id" : 542726823793410048,
  "created_at" : "2014-12-10 17:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/12mZVS6Hyd",
      "expanded_url" : "http:\/\/bit.ly\/1AxrqOQ",
      "display_url" : "bit.ly\/1AxrqOQ"
    } ]
  },
  "geo" : { },
  "id_str" : "542364419762958336",
  "text" : "#rstats which.min(x) and which.max(x) return the first index of the min and max of x. http:\/\/t.co\/12mZVS6Hyd",
  "id" : 542364419762958336,
  "created_at" : "2014-12-09 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/eDZXGghL9p",
      "expanded_url" : "http:\/\/bit.ly\/1tTQ0ow",
      "display_url" : "bit.ly\/1tTQ0ow"
    } ]
  },
  "geo" : { },
  "id_str" : "542002003975864320",
  "text" : "#rstats setNames(1:3,c(\"foo\",\"bar\",\"baz\") defines vector and assigns names all in one step http:\/\/t.co\/eDZXGghL9p",
  "id" : 542002003975864320,
  "created_at" : "2014-12-08 17:05:22 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/lpBRXiseuc",
      "expanded_url" : "http:\/\/bit.ly\/1xXNkHP",
      "display_url" : "bit.ly\/1xXNkHP"
    } ]
  },
  "geo" : { },
  "id_str" : "540914858087415808",
  "text" : "#rstats To profile R code, install the profr package and use the Rprof \u007Bbase\u007D function. http:\/\/t.co\/lpBRXiseuc",
  "id" : 540914858087415808,
  "created_at" : "2014-12-05 17:05:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/1pSqsUMUIx",
      "expanded_url" : "http:\/\/bit.ly\/10CB8vJ",
      "display_url" : "bit.ly\/10CB8vJ"
    } ]
  },
  "geo" : { },
  "id_str" : "540552538031140864",
  "text" : "The corner function in the BurnsMisc package is a convenient way to view a small part of a data frame http:\/\/t.co\/1pSqsUMUIx #rstats",
  "id" : 540552538031140864,
  "created_at" : "2014-12-04 17:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/dTAEIeY1eE",
      "expanded_url" : "http:\/\/bit.ly\/1xXLLcR",
      "display_url" : "bit.ly\/1xXLLcR"
    } ]
  },
  "geo" : { },
  "id_str" : "540190123191992320",
  "text" : "#rstats For a complete list of functions in a loaded package (eg Rcpp), use library(help=\"Rcpp\") http:\/\/t.co\/dTAEIeY1eE",
  "id" : 540190123191992320,
  "created_at" : "2014-12-03 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/1xO1d8IM2u",
      "expanded_url" : "http:\/\/bit.ly\/1w5pxdf",
      "display_url" : "bit.ly\/1w5pxdf"
    } ]
  },
  "geo" : { },
  "id_str" : "539827767773515776",
  "text" : "#rstats Reverse the elements of  a vector x with rev(x) http:\/\/t.co\/1xO1d8IM2u",
  "id" : 539827767773515776,
  "created_at" : "2014-12-02 17:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/B38pGOJdNC",
      "expanded_url" : "http:\/\/bit.ly\/1zFZMhl",
      "display_url" : "bit.ly\/1zFZMhl"
    } ]
  },
  "geo" : { },
  "id_str" : "539465381346553856",
  "text" : "#rstats Extract the diagonal elements of a square matrix M with diag(M) http:\/\/t.co\/B38pGOJdNC",
  "id" : 539465381346553856,
  "created_at" : "2014-12-01 17:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]