Grailbird.data.tweets_2017_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/hRIc9dHNS8",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/mice\/",
      "display_url" : "mran.microsoft.com\/package\/mice\/"
    } ]
  },
  "geo" : { },
  "id_str" : "826475141538344968",
  "text" : "The mice package can be used to impute missing values in a data set https:\/\/t.co\/hRIc9dHNS8 #rstats",
  "id" : 826475141538344968,
  "created_at" : "2017-01-31 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/JrWNVafGiE",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Quotes",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "826113701006737408",
  "text" : "To include a quote character in a string, use \\\"\nfor a single backslash, use \\\\\n#rstats https:\/\/t.co\/JrWNVafGiE",
  "id" : 826113701006737408,
  "created_at" : "2017-01-30 17:03:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/D30eCr5Cfh",
      "expanded_url" : "https:\/\/mran.microsoft.com\/documents\/data\/",
      "display_url" : "mran.microsoft.com\/documents\/data\/"
    } ]
  },
  "geo" : { },
  "id_str" : "825025578206064641",
  "text" : "A list of data sets you can use with R: https:\/\/t.co\/D30eCr5Cfh #rstats",
  "id" : 825025578206064641,
  "created_at" : "2017-01-27 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/mSTGMCXGsa",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2010\/02\/making-publicationready-tables-with-xtable.html",
      "display_url" : "blog.revolutionanalytics.com\/2010\/02\/making\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824663192710176768",
  "text" : "Make publication-ready tables in R with the xtables package https:\/\/t.co\/mSTGMCXGsa #rstats",
  "id" : 824663192710176768,
  "created_at" : "2017-01-26 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/xqrMLpvqmf",
      "expanded_url" : "https:\/\/biologyforfun.wordpress.com\/2014\/05\/05\/importing-100-years-of-climate-change-into-r\/",
      "display_url" : "biologyforfun.wordpress.com\/2014\/05\/05\/imp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "824302063639269378",
  "text" : "How to import 100 years of Eurpoean climate change data into R: https:\/\/t.co\/xqrMLpvqmf #rstats",
  "id" : 824302063639269378,
  "created_at" : "2017-01-25 17:05:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 7, 16 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/E1pp9NlgQC",
      "expanded_url" : "https:\/\/github.com\/ropensci\/rnoaa",
      "display_url" : "github.com\/ropensci\/rnoaa"
    } ]
  },
  "geo" : { },
  "id_str" : "824300811173949441",
  "text" : "rnoaa: @ROpenSci package to access many NOAA data sources including the NCDC climate API https:\/\/t.co\/E1pp9NlgQC #rstats",
  "id" : 824300811173949441,
  "created_at" : "2017-01-25 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/cFs21JhnQj",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/graphics\/versions\/3.3.2\/topics\/persp",
      "display_url" : "rdocumentation.org\/packages\/graph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "823576027548921856",
  "text" : "Visualize a 3-D surface with the persp function https:\/\/t.co\/cFs21JhnQj #rstats",
  "id" : 823576027548921856,
  "created_at" : "2017-01-23 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/meQm9740KW",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/which",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "822488877407477760",
  "text" : "Return the row\/column indices of positive elements of matrix x: which(x&gt;0, arr.ind=TRUE) #rstats https:\/\/t.co\/meQm9740KW",
  "id" : 822488877407477760,
  "created_at" : "2017-01-20 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/18mpkNWpDE",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/which.min",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "822126490519277568",
  "text" : "which.min(x) and which.max(x) return the first index of the min and max of x https:\/\/t.co\/18mpkNWpDE #rstats",
  "id" : 822126490519277568,
  "created_at" : "2017-01-19 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/CozM2UauQo",
      "expanded_url" : "https:\/\/blogs.msdn.microsoft.com\/microsoftrservertigerteam\/2016\/11\/14\/performance-optimization-when-using-rxexec-to-parallelize-algorithms\/",
      "display_url" : "blogs.msdn.microsoft.com\/microsoftrserv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821764093656920065",
  "text" : "How to optimize parallel algorithms using rExec in Microsoft R Server #rstats https:\/\/t.co\/CozM2UauQo",
  "id" : 821764093656920065,
  "created_at" : "2017-01-18 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/ogeCBWmOLP",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/circlize\/",
      "display_url" : "mran.microsoft.com\/package\/circli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "821401719489732610",
  "text" : "Use the circlize package to create chord diagrams, phylogenetic trees and other circular charts https:\/\/t.co\/ogeCBWmOLP #rstats",
  "id" : 821401719489732610,
  "created_at" : "2017-01-17 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821039311847964672",
  "text" : "Perform a keyword search for help at the #rstats console:\n??keyword",
  "id" : 821039311847964672,
  "created_at" : "2017-01-16 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Xi0LKwfJUL",
      "expanded_url" : "http:\/\/www.stat.pitt.edu\/stoffer\/tsa4\/R_toot.htm",
      "display_url" : "stat.pitt.edu\/stoffer\/tsa4\/R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819952164999049216",
  "text" : "Tutorial introduction to time series in #rstats (4th edition): https:\/\/t.co\/Xi0LKwfJUL",
  "id" : 819952164999049216,
  "created_at" : "2017-01-13 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/T9MAprxUn5",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/devtools\/versions\/1.12.0\/topics\/install_github",
      "display_url" : "rdocumentation.org\/packages\/devto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819589766198992896",
  "text" : "Install an R package directly from GitHub with devtools package: https:\/\/t.co\/T9MAprxUn5 #rstats",
  "id" : 819589766198992896,
  "created_at" : "2017-01-12 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/F6c1TOFERV",
      "expanded_url" : "https:\/\/www.edx.org\/course\/analyzing-big-data-microsoft-r-server-microsoft-dat213x#",
      "display_url" : "edx.org\/course\/analyzi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "819227387107954689",
  "text" : "Free self-paced edX course: Analyzing Big Data with Microsoft R Server https:\/\/t.co\/F6c1TOFERV! #rstats",
  "id" : 819227387107954689,
  "created_at" : "2017-01-11 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Robinson",
      "screen_name" : "drob",
      "indices" : [ 134, 139 ],
      "id_str" : "46245868",
      "id" : 46245868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/7CPZtxNGCz",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/magrittr\/versions\/1.5\/topics\/%25%24%25",
      "display_url" : "rdocumentation.org\/packages\/magri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "818864989184196608",
  "text" : "Use the magrittr pkg %$% operator to extract and process a column from a data frame:\nmtcars %$% mean(mpg)\nhttps:\/\/t.co\/7CPZtxNGCz via @drob",
  "id" : 818864989184196608,
  "created_at" : "2017-01-10 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818502609677983745",
  "text" : "Print numbers as currency in a 6-character wide field: sprintf(\"$%6.2f\",mean(LifeCycleSavings$sr))",
  "id" : 818502609677983745,
  "created_at" : "2017-01-09 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/nfhpaGEtzw",
      "expanded_url" : "http:\/\/cran.r-project.org\/web\/views\/ReproducibleResearch.html",
      "display_url" : "cran.r-project.org\/web\/views\/Repr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "817415446928367616",
  "text" : "List of R functions and packages to support reproducible research https:\/\/t.co\/nfhpaGEtzw #rstats",
  "id" : 817415446928367616,
  "created_at" : "2017-01-06 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DJWkBpTm4t",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.2\/topics\/Startup",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "817053048698732544",
  "text" : "Launch R as a clean session with no extension packages or saved objects: R --vanilla https:\/\/t.co\/DJWkBpTm4t",
  "id" : 817053048698732544,
  "created_at" : "2017-01-05 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/oQHHsrq4fT",
      "expanded_url" : "https:\/\/msdn.microsoft.com\/en-us\/microsoft-r\/microsoft-r-getting-started-tutorial",
      "display_url" : "msdn.microsoft.com\/en-us\/microsof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "816690659146997761",
  "text" : "An R tutorial in 25 functions (including some Microsoft R packages): https:\/\/t.co\/oQHHsrq4fT #rstats",
  "id" : 816690659146997761,
  "created_at" : "2017-01-04 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/A3GQrgQNV7",
      "expanded_url" : "http:\/\/www.twotorials.com\/",
      "display_url" : "twotorials.com"
    } ]
  },
  "geo" : { },
  "id_str" : "816328280613724160",
  "text" : "Two-minute video tutorials for R beginners #rstats https:\/\/t.co\/A3GQrgQNV7",
  "id" : 816328280613724160,
  "created_at" : "2017-01-03 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815965895453540352",
  "text" : "Use help.search to find documentation, vignettes and demos on a specific topic, e.g. help.search(\"time series\") #rstats",
  "id" : 815965895453540352,
  "created_at" : "2017-01-02 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]