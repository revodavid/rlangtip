Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/LUzOwZ3qDm",
      "expanded_url" : "http:\/\/bit.ly\/sXKxj8",
      "display_url" : "bit.ly\/sXKxj8"
    } ]
  },
  "geo" : { },
  "id_str" : "418065800751513600",
  "text" : "Format numbers \"v\" as currency, like $2,101,944: gsub(\"^ *\",\"$\",prettyNum(v, big.mark=\",\")) #rstats http:\/\/t.co\/LUzOwZ3qDm",
  "id" : 418065800751513600,
  "created_at" : "2013-12-31 17:07:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/AGW3Eqg51g",
      "expanded_url" : "http:\/\/bit.ly\/H7Ako0",
      "display_url" : "bit.ly\/H7Ako0"
    } ]
  },
  "geo" : { },
  "id_str" : "417703314529476608",
  "text" : "Use methods(class='lm') to list all the special operations available on \"lm\" regression objects: http:\/\/t.co\/AGW3Eqg51g #rstats",
  "id" : 417703314529476608,
  "created_at" : "2013-12-30 17:06:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/izoJLUhiMA",
      "expanded_url" : "http:\/\/bit.ly\/J7Yvvs",
      "display_url" : "bit.ly\/J7Yvvs"
    } ]
  },
  "geo" : { },
  "id_str" : "416616096553508866",
  "text" : "Efficiency tip: When selecting from a data frame, df$a[1] is much faster than df[1,\"a\"] #rstats http:\/\/t.co\/izoJLUhiMA",
  "id" : 416616096553508866,
  "created_at" : "2013-12-27 17:06:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/kc4xxrFSk3",
      "expanded_url" : "http:\/\/bit.ly\/AE2djP",
      "display_url" : "bit.ly\/AE2djP"
    } ]
  },
  "geo" : { },
  "id_str" : "416253609085767680",
  "text" : "Try demo('graphics') ... and type demo() to see other demos available in attached packages. http:\/\/t.co\/kc4xxrFSk3 #rstats",
  "id" : 416253609085767680,
  "created_at" : "2013-12-26 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/iT0vaWhrxm",
      "expanded_url" : "http:\/\/bit.ly\/1c0aZiF",
      "display_url" : "bit.ly\/1c0aZiF"
    } ]
  },
  "geo" : { },
  "id_str" : "415891320616804352",
  "text" : "An R Merry Christmas from Yihui Xie #rstats http:\/\/t.co\/iT0vaWhrxm",
  "id" : 415891320616804352,
  "created_at" : "2013-12-25 17:06:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/upJrC1vo49",
      "expanded_url" : "http:\/\/bit.ly\/Y04DGq",
      "display_url" : "bit.ly\/Y04DGq"
    } ]
  },
  "geo" : { },
  "id_str" : "415528819333009408",
  "text" : "How Santa figures out the optimal set of presents that can fit into his sack: http:\/\/t.co\/upJrC1vo49 #rstats",
  "id" : 415528819333009408,
  "created_at" : "2013-12-24 17:06:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 114, 128 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/9enK49IOxV",
      "expanded_url" : "http:\/\/bit.ly\/TqVLZ3",
      "display_url" : "bit.ly\/TqVLZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "415166534261420032",
  "text" : "If two packages define functions with the same name, use :: to call the one you want: http:\/\/t.co\/9enK49IOxV (via @joshua_ulrich) #rstats",
  "id" : 415166534261420032,
  "created_at" : "2013-12-23 17:06:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/yR3hmFyxRb",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "414079531642007552",
  "text" : "Negative indexes remove elements from a vector. x[-1] is x without the first element. http:\/\/t.co\/yR3hmFyxRb #rstats",
  "id" : 414079531642007552,
  "created_at" : "2013-12-20 17:07:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/1jABYwVyHU",
      "expanded_url" : "http:\/\/bit.ly\/TCNTZ4",
      "display_url" : "bit.ly\/TCNTZ4"
    } ]
  },
  "geo" : { },
  "id_str" : "413717020308692992",
  "text" : "Details of how method dispatch works for objects in R: http:\/\/t.co\/1jABYwVyHU #rstats",
  "id" : 413717020308692992,
  "created_at" : "2013-12-19 17:06:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyFunky",
      "screen_name" : "EpiFunky",
      "indices" : [ 121, 130 ],
      "id_str" : "476678759",
      "id" : 476678759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/pQSrVEZbny",
      "expanded_url" : "http:\/\/bit.ly\/UMV4dA",
      "display_url" : "bit.ly\/UMV4dA"
    } ]
  },
  "geo" : { },
  "id_str" : "413354505741545472",
  "text" : "The \"tabular\" function generates crosstabs with summary stats a la SAS PROC TABULATE #rstats http:\/\/t.co\/pQSrVEZbny (via @EpiFunky)",
  "id" : 413354505741545472,
  "created_at" : "2013-12-18 17:06:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/lY7vv7mTe1",
      "expanded_url" : "http:\/\/bit.ly\/1hJffYE",
      "display_url" : "bit.ly\/1hJffYE"
    } ]
  },
  "geo" : { },
  "id_str" : "412991973331861504",
  "text" : "Use apropos() to find a variable when you can only remember part of its name #rstats http:\/\/t.co\/lY7vv7mTe1",
  "id" : 412991973331861504,
  "created_at" : "2013-12-17 17:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/VOXYSOcHZ7",
      "expanded_url" : "http:\/\/bit.ly\/19xCFYK",
      "display_url" : "bit.ly\/19xCFYK"
    } ]
  },
  "geo" : { },
  "id_str" : "412629782338502656",
  "text" : "Difference between complete.cases() and na.omit() #rstats http:\/\/t.co\/VOXYSOcHZ7",
  "id" : 412629782338502656,
  "created_at" : "2013-12-16 17:06:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0meQV7ONtj",
      "expanded_url" : "http:\/\/bit.ly\/QvVJ4G",
      "display_url" : "bit.ly\/QvVJ4G"
    } ]
  },
  "geo" : { },
  "id_str" : "411527546241814528",
  "text" : "Topic coding and text classification for unstructured data: the RTextTools package #rstats http:\/\/t.co\/0meQV7ONtj",
  "id" : 411527546241814528,
  "created_at" : "2013-12-13 16:06:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/mSCa72MmYl",
      "expanded_url" : "http:\/\/bit.ly\/VJt1wl",
      "display_url" : "bit.ly\/VJt1wl"
    } ]
  },
  "geo" : { },
  "id_str" : "411180203277582337",
  "text" : "Add a zero imaginary part to a number for complex arguments. sqrt(-1) returns NaN; sqrt(-1+0i) returns 1i #rstats http:\/\/t.co\/mSCa72MmYl",
  "id" : 411180203277582337,
  "created_at" : "2013-12-12 17:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/p09MqF45Au",
      "expanded_url" : "http:\/\/bit.ly\/nkzXJi",
      "display_url" : "bit.ly\/nkzXJi"
    } ]
  },
  "geo" : { },
  "id_str" : "410817734877126656",
  "text" : "search() is an easy way to find out what packages are loaded and available for use: http:\/\/t.co\/p09MqF45Au #rstats",
  "id" : 410817734877126656,
  "created_at" : "2013-12-11 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gfW83kqPqv",
      "expanded_url" : "http:\/\/bit.ly\/18piLBZ",
      "display_url" : "bit.ly\/18piLBZ"
    } ]
  },
  "geo" : { },
  "id_str" : "410455285648457728",
  "text" : "Barplot of counts: ggplot(df, aes(x, counts, fill= factorVar)) + geom_bar(stat=\"identity\", position=\"dodge\") #rstats http:\/\/t.co\/gfW83kqPqv",
  "id" : 410455285648457728,
  "created_at" : "2013-12-10 17:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GJLJI2DE6c",
      "expanded_url" : "http:\/\/bit.ly\/1dVyKwe",
      "display_url" : "bit.ly\/1dVyKwe"
    } ]
  },
  "geo" : { },
  "id_str" : "410092829999124481",
  "text" : "Compact code to get vector of month names: format(ISOdate(2004,1:12,1),\"%B\")  #rstats http:\/\/t.co\/GJLJI2DE6c",
  "id" : 410092829999124481,
  "created_at" : "2013-12-09 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/DPRz0ReWU0",
      "expanded_url" : "http:\/\/bit.ly\/pr0Fsj",
      "display_url" : "bit.ly\/pr0Fsj"
    } ]
  },
  "geo" : { },
  "id_str" : "409005655115460609",
  "text" : "Need to pass a whole bunch of arguments to a function, but want to select them in code? Use do.call http:\/\/t.co\/DPRz0ReWU0 #rstats",
  "id" : 409005655115460609,
  "created_at" : "2013-12-06 17:05:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/YqPlptSfGq",
      "expanded_url" : "http:\/\/bit.ly\/pbemkM",
      "display_url" : "bit.ly\/pbemkM"
    } ]
  },
  "geo" : { },
  "id_str" : "408643296656097280",
  "text" : "options(stringsAsFactors=FALSE) will force R to always import character data as character objects: http:\/\/t.co\/YqPlptSfGq #rstats",
  "id" : 408643296656097280,
  "created_at" : "2013-12-05 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ysdbInnesS",
      "expanded_url" : "http:\/\/bit.ly\/17ZXbWM",
      "display_url" : "bit.ly\/17ZXbWM"
    } ]
  },
  "geo" : { },
  "id_str" : "408280903711219712",
  "text" : "In R, it is possible to use a matrix of integers as an index into another matrix http:\/\/t.co\/ysdbInnesS #rstats",
  "id" : 408280903711219712,
  "created_at" : "2013-12-04 17:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/1vIHAlL5xu",
      "expanded_url" : "http:\/\/bit.ly\/WAnc9y",
      "display_url" : "bit.ly\/WAnc9y"
    } ]
  },
  "geo" : { },
  "id_str" : "407918142674194432",
  "text" : "Some basic examples of sorting data frames with the order() function http:\/\/t.co\/1vIHAlL5xu #rstats",
  "id" : 407918142674194432,
  "created_at" : "2013-12-03 17:03:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/3RljHQEYSw",
      "expanded_url" : "http:\/\/bit.ly\/9b9IS",
      "display_url" : "bit.ly\/9b9IS"
    } ]
  },
  "geo" : { },
  "id_str" : "407556246515232768",
  "text" : "Write professional looking code with Google's R style guide http:\/\/t.co\/3RljHQEYSw #rstats",
  "id" : 407556246515232768,
  "created_at" : "2013-12-02 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]