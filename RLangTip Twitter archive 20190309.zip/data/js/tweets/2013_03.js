Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/CcWQfvbXBp",
      "expanded_url" : "http:\/\/bit.ly\/zZ4eL3",
      "display_url" : "bit.ly\/zZ4eL3"
    } ]
  },
  "geo" : { },
  "id_str" : "317668896960303104",
  "text" : "Check availability status of CRAN mirrors: http:\/\/t.co\/CcWQfvbXBp #rstats",
  "id" : 317668896960303104,
  "created_at" : "2013-03-29 16:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ABZ1yV4zg0",
      "expanded_url" : "http:\/\/bit.ly\/HbMcJo",
      "display_url" : "bit.ly\/HbMcJo"
    } ]
  },
  "geo" : { },
  "id_str" : "317306545547378688",
  "text" : "fitdistr fits a univariate probability distribution to a vector of data using maximum likelihood estimation: http:\/\/t.co\/ABZ1yV4zg0 #rstats",
  "id" : 317306545547378688,
  "created_at" : "2013-03-28 16:05:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UlwKmIhFTV",
      "expanded_url" : "http:\/\/bit.ly\/zIdY6J",
      "display_url" : "bit.ly\/zIdY6J"
    } ]
  },
  "geo" : { },
  "id_str" : "316944181052448768",
  "text" : "The lubridate package simplifies operations on dates and times: http:\/\/t.co\/UlwKmIhFTV #rstats",
  "id" : 316944181052448768,
  "created_at" : "2013-03-27 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/cBIyDq93Au",
      "expanded_url" : "http:\/\/bit.ly\/A6eN6I",
      "display_url" : "bit.ly\/A6eN6I"
    } ]
  },
  "geo" : { },
  "id_str" : "316581780566192129",
  "text" : "List of R packages for survival analysis, censored data, and failure time modeling: http:\/\/t.co\/cBIyDq93Au #rstats",
  "id" : 316581780566192129,
  "created_at" : "2013-03-26 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/4rKmfU3bOj",
      "expanded_url" : "http:\/\/bit.ly\/yGdRZ7",
      "display_url" : "bit.ly\/yGdRZ7"
    } ]
  },
  "geo" : { },
  "id_str" : "316242007624413184",
  "text" : "How to generate random numbers in R: http:\/\/t.co\/4rKmfU3bOj #rstats",
  "id" : 316242007624413184,
  "created_at" : "2013-03-25 17:35:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/oZhMKCyDTh",
      "expanded_url" : "http:\/\/bit.ly\/rOOucD",
      "display_url" : "bit.ly\/rOOucD"
    } ]
  },
  "geo" : { },
  "id_str" : "315132178226872320",
  "text" : "Generate a LaTeX table from an R variable: http:\/\/t.co\/oZhMKCyDTh #rstats",
  "id" : 315132178226872320,
  "created_at" : "2013-03-22 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/zoSD1FThZd",
      "expanded_url" : "http:\/\/bit.ly\/unTY2g",
      "display_url" : "bit.ly\/unTY2g"
    } ]
  },
  "geo" : { },
  "id_str" : "314769778080358400",
  "text" : "Google's style guide for writing maintainable R code: http:\/\/t.co\/zoSD1FThZd #rstats",
  "id" : 314769778080358400,
  "created_at" : "2013-03-21 16:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/yiRZtIK45m",
      "expanded_url" : "http:\/\/bit.ly\/n5mCJZ",
      "display_url" : "bit.ly\/n5mCJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "314407455264219136",
  "text" : "Use data(package=\"foo\") to see a list of data sets included in package foo: http:\/\/t.co\/yiRZtIK45m #rstats",
  "id" : 314407455264219136,
  "created_at" : "2013-03-20 16:05:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ksg6wnhyWA",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "314045013526974465",
  "text" : "Type ?Startup for a description of R's initialization process and how to configure it: http:\/\/t.co\/ksg6wnhyWA #rstats",
  "id" : 314045013526974465,
  "created_at" : "2013-03-19 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/XfNEVXZXSE",
      "expanded_url" : "http:\/\/bit.ly\/sxv5Hx",
      "display_url" : "bit.ly\/sxv5Hx"
    } ]
  },
  "geo" : { },
  "id_str" : "313682655688400898",
  "text" : "file.path is a fast, platform-independent function to create paths to filenames http:\/\/t.co\/XfNEVXZXSE #rstats",
  "id" : 313682655688400898,
  "created_at" : "2013-03-18 16:05:47 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/yFBdboNXxi",
      "expanded_url" : "http:\/\/bit.ly\/xYZJ3s",
      "display_url" : "bit.ly\/xYZJ3s"
    } ]
  },
  "geo" : { },
  "id_str" : "312594592128172034",
  "text" : "List of R packages related to networks, graphs, Bayesian models, and flow diagrams: http:\/\/t.co\/yFBdboNXxi #rstats",
  "id" : 312594592128172034,
  "created_at" : "2013-03-15 16:02:13 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/LwUBFPHdPa",
      "expanded_url" : "http:\/\/bit.ly\/y3ecGN",
      "display_url" : "bit.ly\/y3ecGN"
    } ]
  },
  "geo" : { },
  "id_str" : "312232131906662400",
  "text" : "List of 100+ probability distributions (densities, quantiles, simulation) supported in R: http:\/\/t.co\/LwUBFPHdPa #rstats",
  "id" : 312232131906662400,
  "created_at" : "2013-03-14 16:01:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Jlo5vLAfHX",
      "expanded_url" : "http:\/\/bit.ly\/rLysv3",
      "display_url" : "bit.ly\/rLysv3"
    } ]
  },
  "geo" : { },
  "id_str" : "311869699489165313",
  "text" : "How to source an R file from GitHub (or any other site via https): http:\/\/t.co\/Jlo5vLAfHX #rstats",
  "id" : 311869699489165313,
  "created_at" : "2013-03-13 16:01:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/hU3VAevLW8",
      "expanded_url" : "http:\/\/bit.ly\/t1bNrg",
      "display_url" : "bit.ly\/t1bNrg"
    } ]
  },
  "geo" : { },
  "id_str" : "311507259219918848",
  "text" : "The polypath function can be used to add a vector-based shape or symbol to a chart: http:\/\/t.co\/hU3VAevLW8 #rstats",
  "id" : 311507259219918848,
  "created_at" : "2013-03-12 16:01:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/H5GwiEh9rf",
      "expanded_url" : "http:\/\/bit.ly\/zCxy4H",
      "display_url" : "bit.ly\/zCxy4H"
    } ]
  },
  "geo" : { },
  "id_str" : "311144781558464513",
  "text" : "Constants built into #rstats: letters, months and pi: http:\/\/t.co\/H5GwiEh9rf",
  "id" : 311144781558464513,
  "created_at" : "2013-03-11 16:01:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/QIopI1O0qp",
      "expanded_url" : "http:\/\/bit.ly\/mVysYe",
      "display_url" : "bit.ly\/mVysYe"
    } ]
  },
  "geo" : { },
  "id_str" : "310072737601298433",
  "text" : "List of R functions and packages for finance and risk management: http:\/\/t.co\/QIopI1O0qp #rstats",
  "id" : 310072737601298433,
  "created_at" : "2013-03-08 17:01:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Stednick",
      "screen_name" : "zachstednick",
      "indices" : [ 97, 110 ],
      "id_str" : "90293570",
      "id" : 90293570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/RrVtcoQSwA",
      "expanded_url" : "http:\/\/bit.ly\/163DWYo",
      "display_url" : "bit.ly\/163DWYo"
    } ]
  },
  "geo" : { },
  "id_str" : "309710361194549248",
  "text" : "Tutorial on lattice graphics, from the National Park Service http:\/\/t.co\/RrVtcoQSwA #rstats (via @zachstednick)",
  "id" : 309710361194549248,
  "created_at" : "2013-03-07 17:01:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/NLXqyK3rB7",
      "expanded_url" : "http:\/\/bit.ly\/woMnsV",
      "display_url" : "bit.ly\/woMnsV"
    } ]
  },
  "geo" : { },
  "id_str" : "309347836527538177",
  "text" : "Every row of a data frame has a unique label, which you can set or retrieve with row.names: http:\/\/t.co\/NLXqyK3rB7 #rstats",
  "id" : 309347836527538177,
  "created_at" : "2013-03-06 17:00:46 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ksg6wnhyWA",
      "expanded_url" : "http:\/\/bit.ly\/pYrMeM",
      "display_url" : "bit.ly\/pYrMeM"
    } ]
  },
  "geo" : { },
  "id_str" : "308977592655032320",
  "text" : "Create a file called .Rprofile of commands to run each time R starts. Good for setting options, etc. Example: http:\/\/t.co\/ksg6wnhyWA #rstats",
  "id" : 308977592655032320,
  "created_at" : "2013-03-05 16:29:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3cHPOGwx7g",
      "expanded_url" : "http:\/\/bit.ly\/ZX3lPb",
      "display_url" : "bit.ly\/ZX3lPb"
    } ]
  },
  "geo" : { },
  "id_str" : "308639163270430720",
  "text" : "To tell what version of package foo you're running, you can call packageDescription(foo)$Version #rstats http:\/\/t.co\/3cHPOGwx7g",
  "id" : 308639163270430720,
  "created_at" : "2013-03-04 18:04:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/eeyoXb6lG6",
      "expanded_url" : "http:\/\/bit.ly\/XsdjaS",
      "display_url" : "bit.ly\/XsdjaS"
    } ]
  },
  "geo" : { },
  "id_str" : "307529823981543424",
  "text" : "Easily format numbers with fixed precision in strings with sprintf: http:\/\/t.co\/eeyoXb6lG6 #rstats",
  "id" : 307529823981543424,
  "created_at" : "2013-03-01 16:36:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Zwitch",
      "screen_name" : "randyzwitch",
      "indices" : [ 3, 15 ],
      "id_str" : "98689850",
      "id" : 98689850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307529031937556481",
  "text" : "RT @randyzwitch: Why have I been wasting so much of my #rstats time with paste when sprintf is available?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 38, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307249231100530689",
    "text" : "Why have I been wasting so much of my #rstats time with paste when sprintf is available?",
    "id" : 307249231100530689,
    "created_at" : "2013-02-28 22:01:39 +0000",
    "user" : {
      "name" : "Randy Zwitch",
      "screen_name" : "randyzwitch",
      "protected" : false,
      "id_str" : "98689850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/977628585363234817\/z2y4mR_c_normal.jpg",
      "id" : 98689850,
      "verified" : false
    }
  },
  "id" : 307529031937556481,
  "created_at" : "2013-03-01 16:33:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]