Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Chappel",
      "screen_name" : "kbethany",
      "indices" : [ 47, 56 ],
      "id_str" : "17771293",
      "id" : 17771293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/kZgWdaHWxB",
      "expanded_url" : "http:\/\/bit.ly\/UnI6Fx",
      "display_url" : "bit.ly\/UnI6Fx"
    } ]
  },
  "geo" : { },
  "id_str" : "429299445113823232",
  "text" : "Free text on regression and ANOVA with R: (via @kbethany) http:\/\/t.co\/kZgWdaHWxB #rstats",
  "id" : 429299445113823232,
  "created_at" : "2014-01-31 17:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/N8s3V3pLJ3",
      "expanded_url" : "http:\/\/bit.ly\/pbhQWd",
      "display_url" : "bit.ly\/pbhQWd"
    } ]
  },
  "geo" : { },
  "id_str" : "428937032841580544",
  "text" : "For tables in R like those from SAS's PROC FREQ, use CrossTable from the gmodels package: http:\/\/t.co\/N8s3V3pLJ3 #rstats",
  "id" : 428937032841580544,
  "created_at" : "2014-01-30 17:05:32 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lml7IIHZyz",
      "expanded_url" : "http:\/\/bit.ly\/pOBXUl",
      "display_url" : "bit.ly\/pOBXUl"
    } ]
  },
  "geo" : { },
  "id_str" : "428574671551082496",
  "text" : "\"Many #rstats packages have \"\"vignette\"\" examples: use vignette() to see which installed packages have them: http:\/\/t.co\/lml7IIHZyz\n\"",
  "id" : 428574671551082496,
  "created_at" : "2014-01-29 17:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Uqc5xgS5Im",
      "expanded_url" : "http:\/\/bit.ly\/1dVwYuE",
      "display_url" : "bit.ly\/1dVwYuE"
    } ]
  },
  "geo" : { },
  "id_str" : "428212686359629824",
  "text" : "Compute row sums of a matrix, M, with apply(M, 1, sum) #rstats http:\/\/t.co\/Uqc5xgS5Im",
  "id" : 428212686359629824,
  "created_at" : "2014-01-28 17:07:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/PVl91v5VmI",
      "expanded_url" : "http:\/\/journal.r-project.org\/",
      "display_url" : "journal.r-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "427849882469416960",
  "text" : "Keep up with R by reading the R Journal: http:\/\/t.co\/PVl91v5VmI #rstats",
  "id" : 427849882469416960,
  "created_at" : "2014-01-27 17:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/UNw0846snx",
      "expanded_url" : "http:\/\/bit.ly\/oIZqS4",
      "display_url" : "bit.ly\/oIZqS4"
    }, {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Ov2yNkmIjO",
      "expanded_url" : "http:\/\/bit.ly\/qVaFKO",
      "display_url" : "bit.ly\/qVaFKO"
    } ]
  },
  "geo" : { },
  "id_str" : "426762847780356096",
  "text" : "Use sink http:\/\/t.co\/UNw0846snx to direct R's output to a file, or use capture.output http:\/\/t.co\/Ov2yNkmIjO to save it in an object #rstats",
  "id" : 426762847780356096,
  "created_at" : "2014-01-24 17:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/W9gWc3qucK",
      "expanded_url" : "http:\/\/bit.ly\/o0z4Mh",
      "display_url" : "bit.ly\/o0z4Mh"
    } ]
  },
  "geo" : { },
  "id_str" : "426400412795949056",
  "text" : "The standard random number generator in R is the Mersenne Twister, but other RNGs are available: http:\/\/t.co\/W9gWc3qucK #rstats",
  "id" : 426400412795949056,
  "created_at" : "2014-01-23 17:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Fischetti",
      "screen_name" : "tonyfischetti",
      "indices" : [ 125, 139 ],
      "id_str" : "99390322",
      "id" : 99390322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/oe3EaP7q5t",
      "expanded_url" : "http:\/\/bit.ly\/W0zvcd",
      "display_url" : "bit.ly\/W0zvcd"
    } ]
  },
  "geo" : { },
  "id_str" : "426037953253867520",
  "text" : "Convert addresses to latitude\/longitude and plot them on a map with the geoCode package: http:\/\/t.co\/oe3EaP7q5t #rstats (via @tonyfischetti)",
  "id" : 426037953253867520,
  "created_at" : "2014-01-22 17:05:38 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/0587jr1bsJ",
      "expanded_url" : "http:\/\/bit.ly\/1awH5jp",
      "display_url" : "bit.ly\/1awH5jp"
    } ]
  },
  "geo" : { },
  "id_str" : "425675578533232640",
  "text" : "R For Dummies helps with regular expressions #rstats http:\/\/t.co\/0587jr1bsJ",
  "id" : 425675578533232640,
  "created_at" : "2014-01-21 17:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Y7NSSDjquV",
      "expanded_url" : "http:\/\/bit.ly\/19AH5ne",
      "display_url" : "bit.ly\/19AH5ne"
    } ]
  },
  "geo" : { },
  "id_str" : "425313193372946432",
  "text" : "Use stack() to stack the columns of a data frame into a single column #rstats http:\/\/t.co\/Y7NSSDjquV",
  "id" : 425313193372946432,
  "created_at" : "2014-01-20 17:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thanos Papaoikonomou",
      "screen_name" : "erwtokritos",
      "indices" : [ 58, 70 ],
      "id_str" : "20789946",
      "id" : 20789946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/CFtGjsn43p",
      "expanded_url" : "http:\/\/bit.ly\/VLxPTH",
      "display_url" : "bit.ly\/VLxPTH"
    } ]
  },
  "geo" : { },
  "id_str" : "424226045181829120",
  "text" : "Tips on managing memory in R: http:\/\/t.co\/CFtGjsn43p (via @erwtokritos) #rstats",
  "id" : 424226045181829120,
  "created_at" : "2014-01-17 17:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thanos Papaoikonomou",
      "screen_name" : "erwtokritos",
      "indices" : [ 108, 120 ],
      "id_str" : "20789946",
      "id" : 20789946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Ol6QVyXexd",
      "expanded_url" : "http:\/\/bit.ly\/UpZfgq",
      "display_url" : "bit.ly\/UpZfgq"
    } ]
  },
  "geo" : { },
  "id_str" : "423863647882858496",
  "text" : "Explanations of lexical scope, function closures and environments in R: http:\/\/t.co\/Ol6QVyXexd #rstats (via @erwtokritos)",
  "id" : 423863647882858496,
  "created_at" : "2014-01-16 17:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/MsJLmezUOv",
      "expanded_url" : "http:\/\/bit.ly\/xbz2dH",
      "display_url" : "bit.ly\/xbz2dH"
    } ]
  },
  "geo" : { },
  "id_str" : "423486289674260480",
  "text" : "Need to put R output in a book or paper? Use options(width=60) to limit output to a narrow column. http:\/\/t.co\/MsJLmezUOv #rstats",
  "id" : 423486289674260480,
  "created_at" : "2014-01-15 16:06:14 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/290B5xPTuC",
      "expanded_url" : "http:\/\/bit.ly\/1a7LJHv",
      "display_url" : "bit.ly\/1a7LJHv"
    } ]
  },
  "geo" : { },
  "id_str" : "423138898685222913",
  "text" : "#rstats Use help(\"dataset\") to find out about data sets included in R packages http:\/\/t.co\/290B5xPTuC",
  "id" : 423138898685222913,
  "created_at" : "2014-01-14 17:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/S87uLoKRzW",
      "expanded_url" : "http:\/\/bit.ly\/1d8PYDV",
      "display_url" : "bit.ly\/1d8PYDV"
    } ]
  },
  "geo" : { },
  "id_str" : "422776538334261248",
  "text" : "#rstats An example of using R to confirm results of a JAMA paper from Kelly Black http:\/\/t.co\/S87uLoKRzW",
  "id" : 422776538334261248,
  "created_at" : "2014-01-13 17:05:56 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kko94RYZET",
      "expanded_url" : "http:\/\/bit.ly\/U4vAte",
      "display_url" : "bit.ly\/U4vAte"
    } ]
  },
  "geo" : { },
  "id_str" : "421689521592631296",
  "text" : "cummax(x) returns a vector whose ith element is the maximum of the first i elements of x. cf cumsum, cumprod #rstats http:\/\/t.co\/kko94RYZET",
  "id" : 421689521592631296,
  "created_at" : "2014-01-10 17:06:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Evans",
      "screen_name" : "ThomasEvans",
      "indices" : [ 88, 100 ],
      "id_str" : "16922298",
      "id" : 16922298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/a0syqlJ2nh",
      "expanded_url" : "http:\/\/bit.ly\/VGhPTg",
      "display_url" : "bit.ly\/VGhPTg"
    } ]
  },
  "geo" : { },
  "id_str" : "421326939513978881",
  "text" : "When to use: apply vs lappy vs sapply vs mapply ... http:\/\/t.co\/a0syqlJ2nh #rstats (via @ThomasEvans)",
  "id" : 421326939513978881,
  "created_at" : "2014-01-09 17:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/UlwKmI052n",
      "expanded_url" : "http:\/\/bit.ly\/zIdY6J",
      "display_url" : "bit.ly\/zIdY6J"
    } ]
  },
  "geo" : { },
  "id_str" : "420964860948922368",
  "text" : "Use the lubridate package to easily manipulate dates, times and time zones: http:\/\/t.co\/UlwKmI052n #rstats (via @ranmath_vaidya)",
  "id" : 420964860948922368,
  "created_at" : "2014-01-08 17:06:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420602802927579136",
  "text" : "ggplot2 viz of iris comparing a single variable across multiple categories Bradley Demarest  #rstats Dhttp:\/\/bit.ly\/1bENYOM",
  "id" : 420602802927579136,
  "created_at" : "2014-01-07 17:08:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/KOcmK5aLST",
      "expanded_url" : "http:\/\/bit.ly\/1bEN5Ww",
      "display_url" : "bit.ly\/1bEN5Ww"
    } ]
  },
  "geo" : { },
  "id_str" : "420239857844510721",
  "text" : "Use as.dendrogram() to prepare hierarchical clusters or trees for plotting #rstats http:\/\/t.co\/KOcmK5aLST",
  "id" : 420239857844510721,
  "created_at" : "2014-01-06 17:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/vWWRVmjqc0",
      "expanded_url" : "http:\/\/bit.ly\/1in7U1f",
      "display_url" : "bit.ly\/1in7U1f"
    } ]
  },
  "geo" : { },
  "id_str" : "419152934170267648",
  "text" : "Use as.Date( ) to convert strings to dates #rstats http:\/\/t.co\/vWWRVmjqc0",
  "id" : 419152934170267648,
  "created_at" : "2014-01-03 17:07:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/2XJbPEnOpr",
      "expanded_url" : "http:\/\/bit.ly\/JAErBw",
      "display_url" : "bit.ly\/JAErBw"
    } ]
  },
  "geo" : { },
  "id_str" : "418790279622451200",
  "text" : "See the R Wiki for tips with code snippets. #rstats http:\/\/t.co\/2XJbPEnOpr",
  "id" : 418790279622451200,
  "created_at" : "2014-01-02 17:05:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/6GvHHyoLD4",
      "expanded_url" : "http:\/\/bit.ly\/1dgHyKm",
      "display_url" : "bit.ly\/1dgHyKm"
    } ]
  },
  "geo" : { },
  "id_str" : "418427948908412928",
  "text" : "An R \"Happy New Year\" greeting from Yihui Xie #rstats http:\/\/t.co\/6GvHHyoLD4",
  "id" : 418427948908412928,
  "created_at" : "2014-01-01 17:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]