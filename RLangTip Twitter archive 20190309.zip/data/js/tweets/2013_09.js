Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/hWhB9qcikB",
      "expanded_url" : "http:\/\/oreil.ly\/19PbWsf",
      "display_url" : "oreil.ly\/19PbWsf"
    } ]
  },
  "geo" : { },
  "id_str" : "384710654118334465",
  "text" : "#rstats Use ls(pattern=\"^is\",baseenv()) to see all \"is\" functions in base package (R. Cotton: Learning R) http:\/\/t.co\/hWhB9qcikB",
  "id" : 384710654118334465,
  "created_at" : "2013-09-30 16:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/45mNnD5EKA",
      "expanded_url" : "http:\/\/bit.ly\/y4JP9f",
      "display_url" : "bit.ly\/y4JP9f"
    } ]
  },
  "geo" : { },
  "id_str" : "383623718951723009",
  "text" : "#rstats Two-minute video tutorials for R beginners:http:\/\/t.co\/45mNnD5EKA",
  "id" : 383623718951723009,
  "created_at" : "2013-09-27 16:06:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAS",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "SPSS",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/AtYPj8xd9A",
      "expanded_url" : "http:\/\/bit.ly\/ttStw6",
      "display_url" : "bit.ly\/ttStw6"
    } ]
  },
  "geo" : { },
  "id_str" : "383261223703556096",
  "text" : "R equivalents for #SAS and #SPSS modules: http:\/\/t.co\/AtYPj8xd9A #rstats",
  "id" : 383261223703556096,
  "created_at" : "2013-09-26 16:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/G83J1FfFiq",
      "expanded_url" : "http:\/\/bit.ly\/qXsMe5",
      "display_url" : "bit.ly\/qXsMe5"
    } ]
  },
  "geo" : { },
  "id_str" : "382898796466020353",
  "text" : "Turn off all warnings in R with options(warn=-1), or use suppressWarnings(&lt;expr&gt;) http:\/\/t.co\/G83J1FfFiq #rstats",
  "id" : 382898796466020353,
  "created_at" : "2013-09-25 16:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/gsfN0Tj6rq",
      "expanded_url" : "http:\/\/bit.ly\/1bwnJPS",
      "display_url" : "bit.ly\/1bwnJPS"
    } ]
  },
  "geo" : { },
  "id_str" : "382536365491363840",
  "text" : "#rstats Send plots to pdf file: run pdf(\"myOut.pdf\"), produce plots, turn off with dev.off() http:\/\/t.co\/gsfN0Tj6rq",
  "id" : 382536365491363840,
  "created_at" : "2013-09-24 16:05:51 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/I5Yt73MMNv",
      "expanded_url" : "http:\/\/bit.ly\/14rinAX",
      "display_url" : "bit.ly\/14rinAX"
    } ]
  },
  "geo" : { },
  "id_str" : "382173971653074944",
  "text" : "#rstats Get a list of the arguments for a function: formals(func) http:\/\/t.co\/I5Yt73MMNv",
  "id" : 382173971653074944,
  "created_at" : "2013-09-23 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/nGyeFEZvZ9",
      "expanded_url" : "http:\/\/bit.ly\/NaIjcI",
      "display_url" : "bit.ly\/NaIjcI"
    } ]
  },
  "geo" : { },
  "id_str" : "381087371326132224",
  "text" : "To convert dates\/times from one timezone to another, use format() on a POSIXct object. Details: http:\/\/t.co\/nGyeFEZvZ9 #rstats",
  "id" : 381087371326132224,
  "created_at" : "2013-09-20 16:08:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/7GlKaEuUTt",
      "expanded_url" : "http:\/\/bit.ly\/163iD5E",
      "display_url" : "bit.ly\/163iD5E"
    } ]
  },
  "geo" : { },
  "id_str" : "380724584506732544",
  "text" : "Remove all objects from your current environment with rm(list=ls()) but be careful #rstats http:\/\/t.co\/7GlKaEuUTt",
  "id" : 380724584506732544,
  "created_at" : "2013-09-19 16:06:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/LNEBSiAQLt",
      "expanded_url" : "http:\/\/bit.ly\/oa5sx5",
      "display_url" : "bit.ly\/oa5sx5"
    } ]
  },
  "geo" : { },
  "id_str" : "380362151686582272",
  "text" : "Meet other R users at a local R user group in your area: http:\/\/t.co\/LNEBSiAQLt #rstats",
  "id" : 380362151686582272,
  "created_at" : "2013-09-18 16:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8VMflVaPAe",
      "expanded_url" : "http:\/\/bit.ly\/NaI9lG",
      "display_url" : "bit.ly\/NaI9lG"
    } ]
  },
  "geo" : { },
  "id_str" : "379999694401064960",
  "text" : "Type ?Syntax to learn the precedence of operators in the R language: http:\/\/t.co\/8VMflVaPAe #rstats",
  "id" : 379999694401064960,
  "created_at" : "2013-09-17 16:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/VhcJlxAAUY",
      "expanded_url" : "http:\/\/bit.ly\/18cN8XN",
      "display_url" : "bit.ly\/18cN8XN"
    } ]
  },
  "geo" : { },
  "id_str" : "379638706355048448",
  "text" : "Use variable name in plot title: hist(var,main=substitute(paste(\"Dist of \",var))) #rstats http:\/\/t.co\/VhcJlxAAUY",
  "id" : 379638706355048448,
  "created_at" : "2013-09-16 16:11:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/BBiYEtV7On",
      "expanded_url" : "http:\/\/bit.ly\/17EZMlU",
      "display_url" : "bit.ly\/17EZMlU"
    } ]
  },
  "geo" : { },
  "id_str" : "378551003353989120",
  "text" : "Get the unique values of a variable, x, with unique(x) #rstats http:\/\/t.co\/BBiYEtV7On",
  "id" : 378551003353989120,
  "created_at" : "2013-09-13 16:09:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/UYEUq86IHJ",
      "expanded_url" : "http:\/\/bit.ly\/O8Qg3A",
      "display_url" : "bit.ly\/O8Qg3A"
    } ]
  },
  "geo" : { },
  "id_str" : "378187756331347968",
  "text" : "Search the documentation for any function in base R or any CRAN package at http:\/\/t.co\/UYEUq86IHJ #rstats",
  "id" : 378187756331347968,
  "created_at" : "2013-09-12 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Lemaitre",
      "screen_name" : "joshlemaitre",
      "indices" : [ 114, 127 ],
      "id_str" : "21264652",
      "id" : 21264652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/lIC5QjwC5s",
      "expanded_url" : "http:\/\/bit.ly\/QKKDsn",
      "display_url" : "bit.ly\/QKKDsn"
    } ]
  },
  "geo" : { },
  "id_str" : "377825350027591681",
  "text" : "Forgot to save the output from the last #rstats command? Retrieve it with .Last.value http:\/\/t.co\/lIC5QjwC5s (via @joshlemaitre)",
  "id" : 377825350027591681,
  "created_at" : "2013-09-11 16:05:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/whT3RuekBP",
      "expanded_url" : "http:\/\/bit.ly\/rgwKt9",
      "display_url" : "bit.ly\/rgwKt9"
    } ]
  },
  "geo" : { },
  "id_str" : "377462997427707904",
  "text" : "Use lsf.str(\"package:foo\") to see a list all the functions in package foo: http:\/\/t.co\/whT3RuekBP #rstats",
  "id" : 377462997427707904,
  "created_at" : "2013-09-10 16:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/95Ib4J5HpK",
      "expanded_url" : "http:\/\/bit.ly\/1dYFk2m",
      "display_url" : "bit.ly\/1dYFk2m"
    } ]
  },
  "geo" : { },
  "id_str" : "377100909643595776",
  "text" : "Use object.size() to estimate the amount of memory an R object is consuming #rstats http:\/\/t.co\/95Ib4J5HpK",
  "id" : 377100909643595776,
  "created_at" : "2013-09-09 16:07:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/xwY555V8qc",
      "expanded_url" : "http:\/\/bit.ly\/orRZFu",
      "display_url" : "bit.ly\/orRZFu"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/wDcZppVv09",
      "expanded_url" : "http:\/\/bit.ly\/oMhDcj",
      "display_url" : "bit.ly\/oMhDcj"
    } ]
  },
  "geo" : { },
  "id_str" : "376013401740574720",
  "text" : "Automated variable selection for regressions: \"step\" http:\/\/t.co\/xwY555V8qc and \"leaps\" http:\/\/t.co\/wDcZppVv09 #rstats",
  "id" : 376013401740574720,
  "created_at" : "2013-09-06 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/yppChnYeJf",
      "expanded_url" : "http:\/\/bit.ly\/I3YiHQ",
      "display_url" : "bit.ly\/I3YiHQ"
    } ]
  },
  "geo" : { },
  "id_str" : "375651052856827906",
  "text" : "Change direction of plot axis labels with las \u007B0,1,2,3\u007D e.g. plot(x,y,las=1) #rstats http:\/\/t.co\/yppChnYeJf",
  "id" : 375651052856827906,
  "created_at" : "2013-09-05 16:06:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/npd5TM91kN",
      "expanded_url" : "http:\/\/bit.ly\/NcjwTL",
      "display_url" : "bit.ly\/NcjwTL"
    } ]
  },
  "geo" : { },
  "id_str" : "375288785522937856",
  "text" : "How to include non-standard fonts (Chinese, Cyrillic, CM Math etc) in PDF\/Postscript charts: http:\/\/t.co\/npd5TM91kN (p41) #rstats",
  "id" : 375288785522937856,
  "created_at" : "2013-09-04 16:06:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/QcdufWuN6T",
      "expanded_url" : "http:\/\/bit.ly\/18bS1Sy",
      "display_url" : "bit.ly\/18bS1Sy"
    } ]
  },
  "geo" : { },
  "id_str" : "374926175476658176",
  "text" : "Use library() to see all packages installed, search() to see all packages loaded #rstats http:\/\/t.co\/QcdufWuN6T",
  "id" : 374926175476658176,
  "created_at" : "2013-09-03 16:05:40 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/3dbyKEEA9U",
      "expanded_url" : "http:\/\/bit.ly\/17saavu",
      "display_url" : "bit.ly\/17saavu"
    } ]
  },
  "geo" : { },
  "id_str" : "374563766681485312",
  "text" : "Find out what files are in your working directory with dir(), also list.files()  #rstats http:\/\/t.co\/3dbyKEEA9U",
  "id" : 374563766681485312,
  "created_at" : "2013-09-02 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]