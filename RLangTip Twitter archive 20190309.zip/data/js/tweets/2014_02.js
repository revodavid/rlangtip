Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yrsoM1AoAw",
      "expanded_url" : "http:\/\/bit.ly\/H8SSce",
      "display_url" : "bit.ly\/H8SSce"
    } ]
  },
  "geo" : { },
  "id_str" : "439446297033318401",
  "text" : "You can plot a function object to create a chart of its equation, e.g. plot(dnorm, xlim=c(-4,4)) #rstats http:\/\/t.co\/yrsoM1AoAw",
  "id" : 439446297033318401,
  "created_at" : "2014-02-28 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RpxQDlhlHP",
      "expanded_url" : "http:\/\/bit.ly\/we8tgt",
      "display_url" : "bit.ly\/we8tgt"
    } ]
  },
  "geo" : { },
  "id_str" : "439083871024717824",
  "text" : "Calculate running 30-day means of values in vector x: filter(x,rep(1\/30,30)) #rstats http:\/\/t.co\/RpxQDlhlHP",
  "id" : 439083871024717824,
  "created_at" : "2014-02-27 17:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/v8L5JS7Mbu",
      "expanded_url" : "http:\/\/bit.ly\/yPYjn5",
      "display_url" : "bit.ly\/yPYjn5"
    } ]
  },
  "geo" : { },
  "id_str" : "438721546111434753",
  "text" : "Some common pitfalls when working with floating-point numbers in #rstats: http:\/\/t.co\/v8L5JS7Mbu",
  "id" : 438721546111434753,
  "created_at" : "2014-02-26 17:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/r3akJKl4eB",
      "expanded_url" : "http:\/\/bit.ly\/1mjbJUs",
      "display_url" : "bit.ly\/1mjbJUs"
    } ]
  },
  "geo" : { },
  "id_str" : "438359133075808257",
  "text" : "Compute a kernel density extimate of a vector with density(x) http:\/\/t.co\/r3akJKl4eB #rstats",
  "id" : 438359133075808257,
  "created_at" : "2014-02-25 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/IWtAIZTHAf",
      "expanded_url" : "http:\/\/bit.ly\/MhoEcd",
      "display_url" : "bit.ly\/MhoEcd"
    } ]
  },
  "geo" : { },
  "id_str" : "437996679632289792",
  "text" : "help.search(\"linear\") will search all of the R help files for the character string linear http:\/\/t.co\/IWtAIZTHAf #rstats",
  "id" : 437996679632289792,
  "created_at" : "2014-02-24 17:05:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/Z38LbrYUiD",
      "expanded_url" : "http:\/\/bit.ly\/N8qc7Y",
      "display_url" : "bit.ly\/N8qc7Y"
    } ]
  },
  "geo" : { },
  "id_str" : "436909581626015745",
  "text" : "A %x% B calculates the kronecker product of matrices A and B http:\/\/t.co\/Z38LbrYUiD  #rstats",
  "id" : 436909581626015745,
  "created_at" : "2014-02-21 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/kdkA65ezFu",
      "expanded_url" : "http:\/\/bit.ly\/nLuDqT",
      "display_url" : "bit.ly\/nLuDqT"
    } ]
  },
  "geo" : { },
  "id_str" : "436547232389922816",
  "text" : "Review and update installed packages to the latest version: update.packages(ask=\"graphics\")  http:\/\/t.co\/kdkA65ezFu #rstats",
  "id" : 436547232389922816,
  "created_at" : "2014-02-20 17:05:45 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/8Ah64k0Cle",
      "expanded_url" : "http:\/\/bit.ly\/1dR1WOK",
      "display_url" : "bit.ly\/1dR1WOK"
    } ]
  },
  "geo" : { },
  "id_str" : "436184772273250304",
  "text" : "Use names(x) &lt;- c to set the names of the elements of vector x to the values of the character vector c http:\/\/t.co\/8Ah64k0Cle #rstats",
  "id" : 436184772273250304,
  "created_at" : "2014-02-19 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/YslH55smvh",
      "expanded_url" : "http:\/\/bit.ly\/1fnkLtW",
      "display_url" : "bit.ly\/1fnkLtW"
    } ]
  },
  "geo" : { },
  "id_str" : "435822370130243584",
  "text" : "Type help(regex) to get started with regular expressions http:\/\/t.co\/YslH55smvh #rstats",
  "id" : 435822370130243584,
  "created_at" : "2014-02-18 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/CTmDLFMPXa",
      "expanded_url" : "http:\/\/bit.ly\/M1a1tx",
      "display_url" : "bit.ly\/M1a1tx"
    }, {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/6oHqK4nE6r",
      "expanded_url" : "http:\/\/bit.ly\/NMfAxS",
      "display_url" : "bit.ly\/NMfAxS"
    } ]
  },
  "geo" : { },
  "id_str" : "435460011993890817",
  "text" : "Get started with testing your R code (tips from Hadley Wickham) http:\/\/t.co\/CTmDLFMPXa and http:\/\/t.co\/6oHqK4nE6r #rstats",
  "id" : 435460011993890817,
  "created_at" : "2014-02-17 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Bekh5ct44u",
      "expanded_url" : "http:\/\/bit.ly\/1aEKphL",
      "display_url" : "bit.ly\/1aEKphL"
    } ]
  },
  "geo" : { },
  "id_str" : "434357759187099648",
  "text" : "Send an R Valentine http:\/\/t.co\/Bekh5ct44u #rstats",
  "id" : 434357759187099648,
  "created_at" : "2014-02-14 16:05:34 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/UNzzNlmGmh",
      "expanded_url" : "http:\/\/bit.ly\/roo0w5",
      "display_url" : "bit.ly\/roo0w5"
    } ]
  },
  "geo" : { },
  "id_str" : "434010493960077312",
  "text" : "Create a deck of cards in #rstats: expand.grid(rank=c(\"A\",2:10,\"J\",\"Q\",\"K\"),suit=c(\"S\",\"H\",\"D\",\"C\")) #rstats http:\/\/t.co\/UNzzNlmGmh",
  "id" : 434010493960077312,
  "created_at" : "2014-02-13 17:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Burns",
      "screen_name" : "burnsstat",
      "indices" : [ 121, 131 ],
      "id_str" : "1068157430",
      "id" : 1068157430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/FFewHXoU9v",
      "expanded_url" : "http:\/\/bit.ly\/14EaAxX",
      "display_url" : "bit.ly\/14EaAxX"
    } ]
  },
  "geo" : { },
  "id_str" : "433648115951087616",
  "text" : "Use the ... syntax to pass arguments to a subfunction. Use this to simplify complex #rstats: http:\/\/t.co\/FFewHXoU9v (via @burnsstat)",
  "id" : 433648115951087616,
  "created_at" : "2014-02-12 17:05:42 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/5Av9k37eip",
      "expanded_url" : "http:\/\/bit.ly\/1bxtskA",
      "display_url" : "bit.ly\/1bxtskA"
    } ]
  },
  "geo" : { },
  "id_str" : "433285666815107072",
  "text" : "Use strftime(date, format=\"%m-%d\") to shorten a POSIXct date and convert to character string #rstats http:\/\/t.co\/5Av9k37eip",
  "id" : 433285666815107072,
  "created_at" : "2014-02-11 17:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/0CsCLYQvpV",
      "expanded_url" : "http:\/\/bit.ly\/1cc6oYr",
      "display_url" : "bit.ly\/1cc6oYr"
    } ]
  },
  "geo" : { },
  "id_str" : "432923287325536256",
  "text" : "Type ?file to get help with R functions to manipulate connections #rstats http:\/\/t.co\/0CsCLYQvpV",
  "id" : 432923287325536256,
  "created_at" : "2014-02-10 17:05:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/8uqYP8z0WS",
      "expanded_url" : "http:\/\/bit.ly\/LEU8S0",
      "display_url" : "bit.ly\/LEU8S0"
    } ]
  },
  "geo" : { },
  "id_str" : "431821049739874304",
  "text" : "The paste0 function concatenates strings back-to-back, without any separating characters http:\/\/t.co\/8uqYP8z0WS #rstats",
  "id" : 431821049739874304,
  "created_at" : "2014-02-07 16:05:35 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/EVG3XoSYNj",
      "expanded_url" : "http:\/\/bit.ly\/u6tXtb",
      "display_url" : "bit.ly\/u6tXtb"
    } ]
  },
  "geo" : { },
  "id_str" : "431473832638300160",
  "text" : "In scripts, wrap code in local(\u007B \u007D) to prevent temporary variables overwriting global data: http:\/\/t.co\/EVG3XoSYNj #rstats",
  "id" : 431473832638300160,
  "created_at" : "2014-02-06 17:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/hIyATdwhWi",
      "expanded_url" : "http:\/\/bit.ly\/1gyFrFY",
      "display_url" : "bit.ly\/1gyFrFY"
    } ]
  },
  "geo" : { },
  "id_str" : "431111444332310528",
  "text" : "is.na() finds NAs and NaNs. Use is.nan() to find only NaNs #rstats http:\/\/t.co\/hIyATdwhWi",
  "id" : 431111444332310528,
  "created_at" : "2014-02-05 17:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/fn1qER1vbw",
      "expanded_url" : "http:\/\/bit.ly\/1kn3A0n",
      "display_url" : "bit.ly\/1kn3A0n"
    } ]
  },
  "geo" : { },
  "id_str" : "430748937998565376",
  "text" : "An online Introduction to R with some R history, linear models, glm and more #rstats http:\/\/t.co\/fn1qER1vbw",
  "id" : 430748937998565376,
  "created_at" : "2014-02-04 17:05:24 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/wRGFa9sDvD",
      "expanded_url" : "http:\/\/bit.ly\/1iVnphq",
      "display_url" : "bit.ly\/1iVnphq"
    } ]
  },
  "geo" : { },
  "id_str" : "430386580445200384",
  "text" : "Look at package infotheo to compute entropy measures from information theory #rstats http:\/\/t.co\/wRGFa9sDvD",
  "id" : 430386580445200384,
  "created_at" : "2014-02-03 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]