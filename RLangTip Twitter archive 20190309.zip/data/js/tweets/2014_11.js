Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/NoIWc5jP5h",
      "expanded_url" : "http:\/\/bit.ly\/1qITkHb",
      "display_url" : "bit.ly\/1qITkHb"
    } ]
  },
  "geo" : { },
  "id_str" : "538378149747490816",
  "text" : "#rstats By default, sample(x) randomly permutes x. With the option replace=TRUE it samples with replacement. http:\/\/t.co\/NoIWc5jP5h",
  "id" : 538378149747490816,
  "created_at" : "2014-11-28 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/LwUBFQgqlO",
      "expanded_url" : "http:\/\/bit.ly\/y3ecGN",
      "display_url" : "bit.ly\/y3ecGN"
    } ]
  },
  "geo" : { },
  "id_str" : "538015796375875585",
  "text" : "List of 100+ probability distributions (densities, quantiles, simulation) supported in R: http:\/\/t.co\/LwUBFQgqlO #rstats",
  "id" : 538015796375875585,
  "created_at" : "2014-11-27 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyFunky",
      "screen_name" : "EpiFunky",
      "indices" : [ 121, 130 ],
      "id_str" : "476678759",
      "id" : 476678759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Vllf6KlAJc",
      "expanded_url" : "http:\/\/bit.ly\/UMV4dA",
      "display_url" : "bit.ly\/UMV4dA"
    } ]
  },
  "geo" : { },
  "id_str" : "537653372200181760",
  "text" : "The \"tabular\" function generates crosstabs with summary stats a la SAS PROC TABULATE #rstats http:\/\/t.co\/Vllf6KlAJc (via @EpiFunky)",
  "id" : 537653372200181760,
  "created_at" : "2014-11-26 17:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4w5WJz1I0I",
      "expanded_url" : "http:\/\/bit.ly\/1pkampQ",
      "display_url" : "bit.ly\/1pkampQ"
    } ]
  },
  "geo" : { },
  "id_str" : "537290996418359296",
  "text" : "#rstats important distinction between [, [[ and $ : [ can select &gt; 1 element but [[ and $ select a single element http:\/\/t.co\/4w5WJz1I0I",
  "id" : 537290996418359296,
  "created_at" : "2014-11-25 17:05:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BxTVTBKkWU",
      "expanded_url" : "http:\/\/bit.ly\/1xcO4s7",
      "display_url" : "bit.ly\/1xcO4s7"
    } ]
  },
  "geo" : { },
  "id_str" : "536928633768919040",
  "text" : "#rstats keep from converting to factors with I() the inhibit function (dd &lt;- cbind(d, char = I(letters[1:10]))) http:\/\/t.co\/BxTVTBKkWU",
  "id" : 536928633768919040,
  "created_at" : "2014-11-24 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/cKjvocOfiL",
      "expanded_url" : "http:\/\/bit.ly\/OET7Ri",
      "display_url" : "bit.ly\/OET7Ri"
    } ]
  },
  "geo" : { },
  "id_str" : "535841455320088577",
  "text" : "Use the integrate function to calculate the area under a curve: http:\/\/t.co\/cKjvocOfiL #rstats",
  "id" : 535841455320088577,
  "created_at" : "2014-11-21 17:05:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/oHEca2Jj3C",
      "expanded_url" : "http:\/\/bit.ly\/XQ9n67",
      "display_url" : "bit.ly\/XQ9n67"
    } ]
  },
  "geo" : { },
  "id_str" : "535479059997032448",
  "text" : "A ten-hour video introduction to R, presented by Roger Peng: http:\/\/t.co\/oHEca2Jj3C #rstats",
  "id" : 535479059997032448,
  "created_at" : "2014-11-20 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/scf684wg4z",
      "expanded_url" : "http:\/\/bit.ly\/1xoRYTZ",
      "display_url" : "bit.ly\/1xoRYTZ"
    } ]
  },
  "geo" : { },
  "id_str" : "535116680360636416",
  "text" : "#rstats Make data cleaning a bit easier with Hadley Wickham's Tidy Data Tools http:\/\/t.co\/scf684wg4z",
  "id" : 535116680360636416,
  "created_at" : "2014-11-19 17:05:33 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/YYr33M5pDm",
      "expanded_url" : "http:\/\/bit.ly\/116RV0J",
      "display_url" : "bit.ly\/116RV0J"
    } ]
  },
  "geo" : { },
  "id_str" : "534754325990760448",
  "text" : "#rstats Try data.table as a substitute for data frames when working with big data http:\/\/t.co\/YYr33M5pDm",
  "id" : 534754325990760448,
  "created_at" : "2014-11-18 17:05:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/pLCbxbeJ9y",
      "expanded_url" : "http:\/\/bit.ly\/1xF7rO9",
      "display_url" : "bit.ly\/1xF7rO9"
    } ]
  },
  "geo" : { },
  "id_str" : "534391931460386816",
  "text" : "#rstats use aperm() \u007Bbase\u007D to transpose an array by permuting its dimensions http:\/\/t.co\/pLCbxbeJ9y",
  "id" : 534391931460386816,
  "created_at" : "2014-11-17 17:05:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/p6WYZHRcov",
      "expanded_url" : "http:\/\/bit.ly\/10z1lBR",
      "display_url" : "bit.ly\/10z1lBR"
    } ]
  },
  "geo" : { },
  "id_str" : "533289618763153408",
  "text" : "#rstats find() tells what package a function came from. e.g. find(\"find\") http:\/\/t.co\/p6WYZHRcov",
  "id" : 533289618763153408,
  "created_at" : "2014-11-14 16:05:27 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/fXadmzdFgG",
      "expanded_url" : "http:\/\/bit.ly\/QvipSJ",
      "display_url" : "bit.ly\/QvipSJ"
    } ]
  },
  "geo" : { },
  "id_str" : "532942367553519616",
  "text" : "ggplot2 examples of bar charts, scatterplots, histograms, density plots and more: http:\/\/t.co\/fXadmzdFgG #rstats",
  "id" : 532942367553519616,
  "created_at" : "2014-11-13 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hNR4lqZCOZ",
      "expanded_url" : "http:\/\/bit.ly\/1Gy6j33",
      "display_url" : "bit.ly\/1Gy6j33"
    } ]
  },
  "geo" : { },
  "id_str" : "532579977330692096",
  "text" : "#rstats When reading a file with read.table() or read.csv() use the na.strings argument to identify\/set NAs http:\/\/t.co\/hNR4lqZCOZ",
  "id" : 532579977330692096,
  "created_at" : "2014-11-12 17:05:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/kWG1Yc1J1g",
      "expanded_url" : "http:\/\/bit.ly\/13SdrZ8",
      "display_url" : "bit.ly\/13SdrZ8"
    } ]
  },
  "geo" : { },
  "id_str" : "532217595618144256",
  "text" : "#rstats Access or set the attributes of an R object with attributes() http:\/\/t.co\/kWG1Yc1J1g",
  "id" : 532217595618144256,
  "created_at" : "2014-11-11 17:05:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/2F4EvU94Vg",
      "expanded_url" : "http:\/\/bit.ly\/1pwM94m",
      "display_url" : "bit.ly\/1pwM94m"
    } ]
  },
  "geo" : { },
  "id_str" : "531855155382484992",
  "text" : "#rstats Improve performance by using the RRO open source distribution of R that is compiled with the MKL http:\/\/t.co\/2F4EvU94Vg",
  "id" : 531855155382484992,
  "created_at" : "2014-11-10 17:05:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/5PNbQGl0xO",
      "expanded_url" : "http:\/\/bit.ly\/1h71inM",
      "display_url" : "bit.ly\/1h71inM"
    } ]
  },
  "geo" : { },
  "id_str" : "530768071339040768",
  "text" : "#rstats Back up your work frequently by running save.image() from the console http:\/\/t.co\/5PNbQGl0xO",
  "id" : 530768071339040768,
  "created_at" : "2014-11-07 17:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/K19KZXyhQG",
      "expanded_url" : "http:\/\/bit.ly\/Svpkai",
      "display_url" : "bit.ly\/Svpkai"
    } ]
  },
  "geo" : { },
  "id_str" : "530405685096644609",
  "text" : "Visualize a 3-D surface with the persp function: http:\/\/t.co\/K19KZXyhQG #rstats",
  "id" : 530405685096644609,
  "created_at" : "2014-11-06 17:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/hWhB9qcikB",
      "expanded_url" : "http:\/\/oreil.ly\/19PbWsf",
      "display_url" : "oreil.ly\/19PbWsf"
    } ]
  },
  "geo" : { },
  "id_str" : "530043241396441088",
  "text" : "#rstats Use ls(pattern=\"^is\",baseenv()) to see all \"is\" functions in base package (R. Cotton: Learning R) http:\/\/t.co\/hWhB9qcikB",
  "id" : 530043241396441088,
  "created_at" : "2014-11-05 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/NlZdaouWn6",
      "expanded_url" : "http:\/\/bit.ly\/1tq6oPl",
      "display_url" : "bit.ly\/1tq6oPl"
    } ]
  },
  "geo" : { },
  "id_str" : "529680842155900928",
  "text" : "#rstats Determine the internal storage type, or storage mode, of any R object with typeof() http:\/\/t.co\/NlZdaouWn6",
  "id" : 529680842155900928,
  "created_at" : "2014-11-04 17:05:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/rIJTH9kgQr",
      "expanded_url" : "http:\/\/bit.ly\/1wlvzFp",
      "display_url" : "bit.ly\/1wlvzFp"
    } ]
  },
  "geo" : { },
  "id_str" : "529318468240551936",
  "text" : "#rstats Create NAs of a specific type with NA_real_, NA_integer_ and NA_character_  http:\/\/t.co\/rIJTH9kgQr",
  "id" : 529318468240551936,
  "created_at" : "2014-11-03 17:05:31 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]