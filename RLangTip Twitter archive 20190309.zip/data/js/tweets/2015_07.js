Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/pWx0CmbcKp",
      "expanded_url" : "http:\/\/bit.ly\/N2RSf6",
      "display_url" : "bit.ly\/N2RSf6"
    } ]
  },
  "geo" : { },
  "id_str" : "627148190786154496",
  "text" : "Quirks of R's scoping rules: http:\/\/t.co\/pWx0CmbcKp #rstats",
  "id" : 627148190786154496,
  "created_at" : "2015-07-31 16:05:55 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "khaneboubi",
      "screen_name" : "mehdikhaneboubi",
      "indices" : [ 105, 121 ],
      "id_str" : "522126905",
      "id" : 522126905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/oGcfwbC82g",
      "expanded_url" : "http:\/\/bit.ly\/To3vfw",
      "display_url" : "bit.ly\/To3vfw"
    } ]
  },
  "geo" : { },
  "id_str" : "626787234491056129",
  "text" : "Make R pause for 3 seconds during a script or function: Sys.sleep(3) #rstats http:\/\/t.co\/oGcfwbC82g (via @mehdikhaneboubi)",
  "id" : 626787234491056129,
  "created_at" : "2015-07-30 16:11:36 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/iHvWWllHCw",
      "expanded_url" : "http:\/\/bit.ly\/1CZB0zF",
      "display_url" : "bit.ly\/1CZB0zF"
    } ]
  },
  "geo" : { },
  "id_str" : "626423462584799233",
  "text" : "Don't forget about \u007Bcar\u007D and \u007BMASS\u007D when looking for sample data: data(package=c(\"MASS\",\"car\")) http:\/\/t.co\/iHvWWllHCw #rstats",
  "id" : 626423462584799233,
  "created_at" : "2015-07-29 16:06:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/20ujx2AE3O",
      "expanded_url" : "http:\/\/bit.ly\/LpxvWU",
      "display_url" : "bit.ly\/LpxvWU"
    } ]
  },
  "geo" : { },
  "id_str" : "626061041219313665",
  "text" : "Command-line tools for debugging and tracing R code: http:\/\/t.co\/20ujx2AE3O #rstats",
  "id" : 626061041219313665,
  "created_at" : "2015-07-28 16:05:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/wcljJrTypR",
      "expanded_url" : "http:\/\/bit.ly\/1HYhQXJ",
      "display_url" : "bit.ly\/1HYhQXJ"
    } ]
  },
  "geo" : { },
  "id_str" : "625698706902355968",
  "text" : "The base package foreign contains functions to r\/w data from SAS, SPSS and other stats formats #rstats http:\/\/t.co\/wcljJrTypR",
  "id" : 625698706902355968,
  "created_at" : "2015-07-27 16:06:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/fa4LgIJugb",
      "expanded_url" : "http:\/\/bit.ly\/TbbAFO",
      "display_url" : "bit.ly\/TbbAFO"
    } ]
  },
  "geo" : { },
  "id_str" : "624611501991596032",
  "text" : "Not sure where to add text or other annotations to your #rstats chart? Use 'locator' to pinpoint with the mouse: http:\/\/t.co\/fa4LgIJugb",
  "id" : 624611501991596032,
  "created_at" : "2015-07-24 16:06:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/VI0079Svl7",
      "expanded_url" : "http:\/\/www.inside-r.org\/r-doc",
      "display_url" : "inside-r.org\/r-doc"
    } ]
  },
  "geo" : { },
  "id_str" : "624249110628073473",
  "text" : "Look here: http:\/\/t.co\/VI0079Svl7 to get the list of base and recommended packages",
  "id" : 624249110628073473,
  "created_at" : "2015-07-23 16:06:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/W05D066oBh",
      "expanded_url" : "http:\/\/bit.ly\/1KcJsOE",
      "display_url" : "bit.ly\/1KcJsOE"
    } ]
  },
  "geo" : { },
  "id_str" : "623886732577083393",
  "text" : "getOption(\"defaultPackages\") \u007Bbase\u007D gives the packages (in addition to base) loaded at startup http:\/\/t.co\/W05D066oBh #rstats",
  "id" : 623886732577083393,
  "created_at" : "2015-07-22 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/cJncZsvO1a",
      "expanded_url" : "http:\/\/bit.ly\/1Mzb1z6",
      "display_url" : "bit.ly\/1Mzb1z6"
    } ]
  },
  "geo" : { },
  "id_str" : "623524285617934336",
  "text" : "coef(model.object) \u007Bstats\u007D extracts the model coefficients from a model object http:\/\/t.co\/cJncZsvO1a #rstats",
  "id" : 623524285617934336,
  "created_at" : "2015-07-21 16:05:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/2C6Lk05Mxj",
      "expanded_url" : "http:\/\/bit.ly\/IkF5m6",
      "display_url" : "bit.ly\/IkF5m6"
    } ]
  },
  "geo" : { },
  "id_str" : "623161911820066816",
  "text" : "Get information about your R session: sessionInfo() http:\/\/t.co\/2C6Lk05Mxj #rstats",
  "id" : 623161911820066816,
  "created_at" : "2015-07-20 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622074793077121024",
  "text" : "Syntax trap: The ':' operator has higher precedence than '-' so 0:N-1 evaluates to (0:N)-1, not 0:(N-1) like you probably wanted #rstats",
  "id" : 622074793077121024,
  "created_at" : "2015-07-17 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/RuqUQBPTmu",
      "expanded_url" : "http:\/\/bit.ly\/OCVKRF",
      "display_url" : "bit.ly\/OCVKRF"
    } ]
  },
  "geo" : { },
  "id_str" : "621712621348196352",
  "text" : "Use missing(x) to test whether an argument x was supplied when a function was invoked: http:\/\/t.co\/RuqUQBPTmu #rstats",
  "id" : 621712621348196352,
  "created_at" : "2015-07-16 16:06:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/cXMYpWofmv",
      "expanded_url" : "http:\/\/bit.ly\/M6mig1",
      "display_url" : "bit.ly\/M6mig1"
    } ]
  },
  "geo" : { },
  "id_str" : "621350190881067008",
  "text" : "To see the output when running a script file, use source(\"myscript.R\", echo=TRUE) #rstats http:\/\/t.co\/cXMYpWofmv",
  "id" : 621350190881067008,
  "created_at" : "2015-07-15 16:06:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eHeXaUYdFD",
      "expanded_url" : "http:\/\/bit.ly\/1eNYQD9",
      "display_url" : "bit.ly\/1eNYQD9"
    } ]
  },
  "geo" : { },
  "id_str" : "620987866932314112",
  "text" : "args(function) \u007Bbase\u007D will display the argument names and default values of a function http:\/\/t.co\/eHeXaUYdFD #rstats",
  "id" : 620987866932314112,
  "created_at" : "2015-07-14 16:06:59 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/f0ylP6e3dJ",
      "expanded_url" : "http:\/\/bit.ly\/1hHnLSE",
      "display_url" : "bit.ly\/1hHnLSE"
    } ]
  },
  "geo" : { },
  "id_str" : "620625452529545216",
  "text" : "In base graphics, par(mfrow=c(2,2)) will let you put 4 plots on the same device http:\/\/t.co\/f0ylP6e3dJ #rstats",
  "id" : 620625452529545216,
  "created_at" : "2015-07-13 16:06:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/MKNR4MRHjH",
      "expanded_url" : "http:\/\/bit.ly\/qJoACW",
      "display_url" : "bit.ly\/qJoACW"
    } ]
  },
  "geo" : { },
  "id_str" : "619538327692267520",
  "text" : "The \"break\" statement immediately exits from a \"for\" or \"while\" loop: http:\/\/t.co\/MKNR4MRHjH #rstats",
  "id" : 619538327692267520,
  "created_at" : "2015-07-10 16:07:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619175807349563392",
  "text" : "If x is a list, then x[2] &lt;- NULL removes the second element, whereas x[2] &lt;- list(NULL) replaces it with NULL. #rstats",
  "id" : 619175807349563392,
  "created_at" : "2015-07-09 16:06:30 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/buVGwwbPfb",
      "expanded_url" : "http:\/\/bit.ly\/elVw2",
      "display_url" : "bit.ly\/elVw2"
    } ]
  },
  "geo" : { },
  "id_str" : "618813334176055297",
  "text" : "Better R console fonts http:\/\/t.co\/buVGwwbPfb #rstats",
  "id" : 618813334176055297,
  "created_at" : "2015-07-08 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/StKeufGntD",
      "expanded_url" : "http:\/\/bit.ly\/1KATJCy",
      "display_url" : "bit.ly\/1KATJCy"
    } ]
  },
  "geo" : { },
  "id_str" : "618450944976683008",
  "text" : "methods(generic.function) \u007Butils\u007D lists all methods for a generic function http:\/\/t.co\/StKeufGntD",
  "id" : 618450944976683008,
  "created_at" : "2015-07-07 16:06:10 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Ttbw2sRrBf",
      "expanded_url" : "http:\/\/bit.ly\/1eppJwX",
      "display_url" : "bit.ly\/1eppJwX"
    } ]
  },
  "geo" : { },
  "id_str" : "618088501763031040",
  "text" : "Use locpoly(x) \u007BKernSmooth\u007D to estimate a pdf. http:\/\/t.co\/Ttbw2sRrBf #rstats",
  "id" : 618088501763031040,
  "created_at" : "2015-07-06 16:05:57 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/CcWQfuUmJR",
      "expanded_url" : "http:\/\/bit.ly\/zZ4eL3",
      "display_url" : "bit.ly\/zZ4eL3"
    } ]
  },
  "geo" : { },
  "id_str" : "617001421850980352",
  "text" : "Check availability status of CRAN mirrors: http:\/\/t.co\/CcWQfuUmJR #rstats",
  "id" : 617001421850980352,
  "created_at" : "2015-07-03 16:06:16 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/0koTRpM9fJ",
      "expanded_url" : "http:\/\/bit.ly\/M6msE6",
      "display_url" : "bit.ly\/M6msE6"
    } ]
  },
  "geo" : { },
  "id_str" : "616638974635941888",
  "text" : "Object names in R usually contain letters, numbers, periods and underscores, but other names are possible: http:\/\/t.co\/0koTRpM9fJ #rstats",
  "id" : 616638974635941888,
  "created_at" : "2015-07-02 16:06:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5CvqlToq6H",
      "expanded_url" : "http:\/\/bit.ly\/n8LEBm",
      "display_url" : "bit.ly\/n8LEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "616276530038243328",
  "text" : "To select a column from a matrix and keep it as a column matrix, not a vector: X[,1,drop=FALSE] http:\/\/t.co\/5CvqlToq6H #rstats",
  "id" : 616276530038243328,
  "created_at" : "2015-07-01 16:05:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]