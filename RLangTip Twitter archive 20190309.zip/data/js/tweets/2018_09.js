Grailbird.data.tweets_2018_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/vZAhi5wqRq",
      "expanded_url" : "https:\/\/github.com\/RLesur\/Rcade",
      "display_url" : "github.com\/RLesur\/Rcade"
    } ]
  },
  "geo" : { },
  "id_str" : "1045704694717284352",
  "text" : "Got time to kill waiting for an R computation? Play games like Tetris and Pacman in RStudio with Rcade https:\/\/t.co\/vZAhi5wqRq #rstats",
  "id" : 1045704694717284352,
  "created_at" : "2018-09-28 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/EgZTVrZAVs",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/Rnews\/Rnews_2006-2.pdf",
      "display_url" : "cran.r-project.org\/doc\/Rnews\/Rnew\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1045342311679504385",
  "text" : "How to include non-standard fonts (Chinese, Cyrillic, CM Math etc) in PDF\/Postscript charts: https:\/\/t.co\/EgZTVrZAVs (p41) #rstats",
  "id" : 1045342311679504385,
  "created_at" : "2018-09-27 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Ij4XvatvgI",
      "expanded_url" : "https:\/\/docs.microsoft.com\/azure\/machine-learning\/r-developers-guide?WT.mc_id=rlangtip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/azure\/machine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1044979917069389824",
  "text" : "R developer's guide to Azure, documentation for Azure services supporting R https:\/\/t.co\/Ij4XvatvgI #rstats",
  "id" : 1044979917069389824,
  "created_at" : "2018-09-26 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/sMYqwiJmYu",
      "expanded_url" : "http:\/\/arrgh.tim-smith.us\/syntax.html",
      "display_url" : "arrgh.tim-smith.us\/syntax.html"
    } ]
  },
  "geo" : { },
  "id_str" : "1044617528406929410",
  "text" : "Basic R syntax gotchas, from aRrgh: a newcomer\u2019s (angry) guide to R https:\/\/t.co\/sMYqwiJmYu #rstats",
  "id" : 1044617528406929410,
  "created_at" : "2018-09-25 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 191, 198 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1044255141249998849",
  "text" : "options(stringsAsFactors=FALSE) forces R to import character data as character objects, but avoid the temptation to add it to your .Rprofile file: your code may not work for others if you do #rstats",
  "id" : 1044255141249998849,
  "created_at" : "2018-09-24 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 139, 146 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fCw32MlrUz",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.1\/topics\/txtProgressBar",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1043167974872506368",
  "text" : "Show a progress bar for in R console only when running interactively: if(interactive) \u007Bpb &lt;- txtProgressBar(\u2026)\u007D https:\/\/t.co\/fCw32MlrUz #rstats",
  "id" : 1043167974872506368,
  "created_at" : "2018-09-21 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/kqOZvTMrIw",
      "expanded_url" : "https:\/\/paulvanderlaken.com\/2017\/08\/10\/r-resources-cheatsheets-tutorials-books\/",
      "display_url" : "paulvanderlaken.com\/2017\/08\/10\/r-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1042820684085264384",
  "text" : "A list of free courses, books, tutorials and cheat sheets for R https:\/\/t.co\/kqOZvTMrIw #rstats",
  "id" : 1042820684085264384,
  "created_at" : "2018-09-20 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/35myNyYGku",
      "expanded_url" : "https:\/\/docs.microsoft.com\/machine-learning-server\/operationalize\/how-to-deploy-web-service-publish-manage-in-r?WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/machine-learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1042443201343188993",
  "text" : "How to publish R functions as Web services with Microsoft ML Server https:\/\/t.co\/35myNyYGku #rstats",
  "id" : 1042443201343188993,
  "created_at" : "2018-09-19 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 144, 151 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/rSS4b88bxh",
      "expanded_url" : "https:\/\/shiny.rstudio.com\/tutorial\/",
      "display_url" : "shiny.rstudio.com\/tutorial\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1042095912884023296",
  "text" : "Use the \"shiny\" package to easily create web-based applications with R. Get started with video and written tutorials at https:\/\/t.co\/rSS4b88bxh #rstats",
  "id" : 1042095912884023296,
  "created_at" : "2018-09-18 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/n3MrYVEd4H",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/arules",
      "display_url" : "rdocumentation.org\/packages\/arules"
    } ]
  },
  "geo" : { },
  "id_str" : "1041718420494938112",
  "text" : "The arules package provides functions for mining itemsets and discovering association rules https:\/\/t.co\/n3MrYVEd4H #rstats",
  "id" : 1041718420494938112,
  "created_at" : "2018-09-17 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1040631261788745728",
  "text" : "Add a zero imaginary part to a number for complex arguments. sqrt(-1) returns NaN; sqrt(-1+0i) returns 1i #rstats",
  "id" : 1040631261788745728,
  "created_at" : "2018-09-14 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/4dV8HIjhUl",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/mgcv\/versions\/1.8-24\/topics\/inSide",
      "display_url" : "rdocumentation.org\/packages\/mgcv\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1040268871653965830",
  "text" : "inSide() \u007Bmgcv\u007D may help you determine if points are inside a boundary. https:\/\/t.co\/4dV8HIjhUl #rstats",
  "id" : 1040268871653965830,
  "created_at" : "2018-09-13 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039906488532127744",
  "text" : "To get the very latest versions of R packages with Microsoft R Open, run chooseCRANmirror() before calling install.packages #rstats",
  "id" : 1039906488532127744,
  "created_at" : "2018-09-12 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/xKJ4qQYh87",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/writexl",
      "display_url" : "rdocumentation.org\/packages\/write\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1039544093406154752",
  "text" : "Export a data frame to Excel with the writexl package: write_xlsx(mydata, \"mydata.xlsx\") https:\/\/t.co\/xKJ4qQYh87 #rstats",
  "id" : 1039544093406154752,
  "created_at" : "2018-09-11 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/UzIfSANXG4",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.5.1\/topics\/rle",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1039181711903518720",
  "text" : "Run-length encoding: count the number of times sequential repeats appear with rle(x) #rstats https:\/\/t.co\/UzIfSANXG4",
  "id" : 1039181711903518720,
  "created_at" : "2018-09-10 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/W7TXC3ekl2",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.5.1\/topics\/RSiteSearch",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1038094543030239232",
  "text" : "Search R-help mailing list archives, help pages, vignettes and task views with RSiteSearch(\"keyword\") https:\/\/t.co\/W7TXC3ekl2 #rstats",
  "id" : 1038094543030239232,
  "created_at" : "2018-09-07 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/NrygnpE7Ti",
      "expanded_url" : "https:\/\/www.computerworld.com\/article\/3109890\/data-analytics\/these-r-packages-import-sports-weather-stock-data-and-more.html",
      "display_url" : "computerworld.com\/article\/310989\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1037732155831382016",
  "text" : "Packages for importing financial, sports and weather data into R https:\/\/t.co\/NrygnpE7Ti #rstats",
  "id" : 1037732155831382016,
  "created_at" : "2018-09-06 16:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/eEJTJNQaB1",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/sql\/advanced-analytics\/tutorials\/deepdive-data-science-deep-dive-using-the-revoscaler-packages?view=sql-server-2017&WT.mc_id=RLangTip-twitter-davidsmi",
      "display_url" : "docs.microsoft.com\/en-us\/sql\/adva\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1037369774123245568",
  "text" : "Tutorial: Use RevoScaleR R functions with SQL Server data https:\/\/t.co\/eEJTJNQaB1",
  "id" : 1037369774123245568,
  "created_at" : "2018-09-05 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1037007386215632901",
  "text" : "Time how long your R code takes to run: #rstats\n\ntic &lt;- print(Sys.time()) \n##\n## R code goes here\n##\ntoc &lt;- print(Sys.time()) \nprint(toc-tic)",
  "id" : 1037007386215632901,
  "created_at" : "2018-09-04 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ya8v2qFxBg",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/WebTechnologies.html",
      "display_url" : "cran.r-project.org\/web\/views\/WebT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1036826187342008320",
  "text" : "List of R functions and packages related to internet technologies and services https:\/\/t.co\/ya8v2qFxBg #rstats",
  "id" : 1036826187342008320,
  "created_at" : "2018-09-04 04:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]