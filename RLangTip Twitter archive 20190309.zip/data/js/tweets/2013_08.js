Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/QYuvNFDDIQ",
      "expanded_url" : "http:\/\/bit.ly\/14qtBWO",
      "display_url" : "bit.ly\/14qtBWO"
    } ]
  },
  "geo" : { },
  "id_str" : "373476636253241344",
  "text" : "Use savePlot() from the grDevices package to save a Windows plot to a file #rstats http:\/\/t.co\/QYuvNFDDIQ",
  "id" : 373476636253241344,
  "created_at" : "2013-08-30 16:05:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/PQeAQsbn1m",
      "expanded_url" : "http:\/\/bit.ly\/SpgMXb",
      "display_url" : "bit.ly\/SpgMXb"
    } ]
  },
  "geo" : { },
  "id_str" : "373114309259587584",
  "text" : "Serialization: save a single R object to disk with saveRDS; restore in a new session with readRDS http:\/\/t.co\/PQeAQsbn1m #rstats",
  "id" : 373114309259587584,
  "created_at" : "2013-08-29 16:05:58 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/pWx0CmbcKp",
      "expanded_url" : "http:\/\/bit.ly\/N2RSf6",
      "display_url" : "bit.ly\/N2RSf6"
    } ]
  },
  "geo" : { },
  "id_str" : "372752005099687938",
  "text" : "Quirks of R's scoping rules: http:\/\/t.co\/pWx0CmbcKp #rstats",
  "id" : 372752005099687938,
  "created_at" : "2013-08-28 16:06:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/knHOMOn1WX",
      "expanded_url" : "http:\/\/bit.ly\/N8Uzpr",
      "display_url" : "bit.ly\/N8Uzpr"
    } ]
  },
  "geo" : { },
  "id_str" : "372389917126823936",
  "text" : "Two-sample T tests and permutation tests in #rstats: http:\/\/t.co\/knHOMOn1WX",
  "id" : 372389917126823936,
  "created_at" : "2013-08-27 16:07:29 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/z4pBbb7nxB",
      "expanded_url" : "http:\/\/bit.ly\/189ffrl",
      "display_url" : "bit.ly\/189ffrl"
    } ]
  },
  "geo" : { },
  "id_str" : "372027320145825792",
  "text" : "#rstats Find your R home directory from the command line with Sys.getenv(\"R_Home\") http:\/\/t.co\/z4pBbb7nxB",
  "id" : 372027320145825792,
  "created_at" : "2013-08-26 16:06:39 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/JndgnlKkgS",
      "expanded_url" : "http:\/\/bit.ly\/PNsI3S",
      "display_url" : "bit.ly\/PNsI3S"
    } ]
  },
  "geo" : { },
  "id_str" : "370942692307763200",
  "text" : "Add row sums, columns sums and grand total to a table with addmargins(my.table) #rstats http:\/\/t.co\/JndgnlKkgS",
  "id" : 370942692307763200,
  "created_at" : "2013-08-23 16:16:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portfolio Probe",
      "screen_name" : "portfolioprobe",
      "indices" : [ 67, 82 ],
      "id_str" : "177229649",
      "id" : 177229649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/P2MEx1PIdS",
      "expanded_url" : "http:\/\/bit.ly\/N8U7HQ",
      "display_url" : "bit.ly\/N8U7HQ"
    } ]
  },
  "geo" : { },
  "id_str" : "370579950468083712",
  "text" : "The difference between the order and rank functions in #rstats (by @portfolioprobe): http:\/\/t.co\/P2MEx1PIdS",
  "id" : 370579950468083712,
  "created_at" : "2013-08-22 16:15:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/RoVQv7DcXe",
      "expanded_url" : "http:\/\/bit.ly\/NE1Rpo",
      "display_url" : "bit.ly\/NE1Rpo"
    } ]
  },
  "geo" : { },
  "id_str" : "370215758347132928",
  "text" : "How to use the caret package to select, train and optimize predictive models: http:\/\/t.co\/RoVQv7DcXe #rstats",
  "id" : 370215758347132928,
  "created_at" : "2013-08-21 16:08:09 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/LzmwaWvuEr",
      "expanded_url" : "http:\/\/bit.ly\/IqTdbe",
      "display_url" : "bit.ly\/IqTdbe"
    } ]
  },
  "geo" : { },
  "id_str" : "369853447769968640",
  "text" : "List the row\/column indices of matrix x, from largest to smallest: cbind(row(x)[order(-x)],col(x)[order(-x)]) #rstats http:\/\/t.co\/LzmwaWvuEr",
  "id" : 369853447769968640,
  "created_at" : "2013-08-20 16:08:28 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "khaneboubi",
      "screen_name" : "mehdikhaneboubi",
      "indices" : [ 105, 121 ],
      "id_str" : "522126905",
      "id" : 522126905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/qj9IM826dl",
      "expanded_url" : "http:\/\/bit.ly\/To3vfw",
      "display_url" : "bit.ly\/To3vfw"
    } ]
  },
  "geo" : { },
  "id_str" : "369491401676824576",
  "text" : "Make R pause for 3 seconds during a script or function: Sys.sleep(3) #rstats http:\/\/t.co\/qj9IM826dl (via @mehdikhaneboubi)",
  "id" : 369491401676824576,
  "created_at" : "2013-08-19 16:09:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/y3ZbZmCvFq",
      "expanded_url" : "http:\/\/bit.ly\/M6mPOW",
      "display_url" : "bit.ly\/M6mPOW"
    } ]
  },
  "geo" : { },
  "id_str" : "368403527263350784",
  "text" : "Handy for interactive use, you can set up packages to automatically load when a function is used: http:\/\/t.co\/y3ZbZmCvFq #rstats",
  "id" : 368403527263350784,
  "created_at" : "2013-08-16 16:07:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/QpweD9bHDk",
      "expanded_url" : "http:\/\/bit.ly\/S4Q0P6",
      "display_url" : "bit.ly\/S4Q0P6"
    } ]
  },
  "geo" : { },
  "id_str" : "368041145605308416",
  "text" : "Use read.csv2 to import ASCII data from countries that use the comma as a decimal point #rstats http:\/\/t.co\/QpweD9bHDk",
  "id" : 368041145605308416,
  "created_at" : "2013-08-15 16:07:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/dfKUJ42in7",
      "expanded_url" : "http:\/\/bit.ly\/PIZFgJ",
      "display_url" : "bit.ly\/PIZFgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "367678551581270016",
  "text" : "Function to find the peaks in a time series: http:\/\/t.co\/dfKUJ42in7 #rstats (via @therealprotonk)",
  "id" : 367678551581270016,
  "created_at" : "2013-08-14 16:06:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/rlW8CS2iZp",
      "expanded_url" : "http:\/\/bit.ly\/LpxvWU",
      "display_url" : "bit.ly\/LpxvWU"
    } ]
  },
  "geo" : { },
  "id_str" : "367316340446883840",
  "text" : "Command-line tools for debugging and tracing R code: http:\/\/t.co\/rlW8CS2iZp #rstats",
  "id" : 367316340446883840,
  "created_at" : "2013-08-13 16:06:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/zdMk5bulpB",
      "expanded_url" : "http:\/\/bit.ly\/M6mDiL",
      "display_url" : "bit.ly\/M6mDiL"
    } ]
  },
  "geo" : { },
  "id_str" : "366953690684338177",
  "text" : "On Windows, you can substitute forward slashes for backslashes in filenames (for convenience or portability): http:\/\/t.co\/zdMk5bulpB #rstats",
  "id" : 366953690684338177,
  "created_at" : "2013-08-12 16:05:52 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/aFuYGaxp52",
      "expanded_url" : "http:\/\/bit.ly\/S4Q0P6",
      "display_url" : "bit.ly\/S4Q0P6"
    } ]
  },
  "geo" : { },
  "id_str" : "365866665486974980",
  "text" : "Use read.csv2 to import ASCII data from countries that use the comma as a decimal point #rstats http:\/\/t.co\/aFuYGaxp52",
  "id" : 365866665486974980,
  "created_at" : "2013-08-09 16:06:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/jTy8BgYUnk",
      "expanded_url" : "http:\/\/bit.ly\/PIZFgJ",
      "display_url" : "bit.ly\/PIZFgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "365504146914287618",
  "text" : "Function to find the peaks in a time series: http:\/\/t.co\/jTy8BgYUnk #rstats (via @therealprotonk)",
  "id" : 365504146914287618,
  "created_at" : "2013-08-08 16:05:54 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 60, 70 ],
      "id_str" : "17522755",
      "id" : 17522755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/XKNV33hG58",
      "expanded_url" : "http:\/\/bit.ly\/OV6lDY",
      "display_url" : "bit.ly\/OV6lDY"
    } ]
  },
  "geo" : { },
  "id_str" : "365142473040863233",
  "text" : "Regular expressions in R http:\/\/t.co\/XKNV33hG58 #rstats (by @johndcook)",
  "id" : 365142473040863233,
  "created_at" : "2013-08-07 16:08:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/RuqUQC7ue2",
      "expanded_url" : "http:\/\/bit.ly\/OCVKRF",
      "display_url" : "bit.ly\/OCVKRF"
    } ]
  },
  "geo" : { },
  "id_str" : "364779409938460674",
  "text" : "missing(x) determines whether an argument x was supplied when a function was invoked: http:\/\/t.co\/RuqUQC7ue2 #rstats",
  "id" : 364779409938460674,
  "created_at" : "2013-08-06 16:06:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/MplJy2a0wF",
      "expanded_url" : "http:\/\/bit.ly\/M6mig1",
      "display_url" : "bit.ly\/M6mig1"
    } ]
  },
  "geo" : { },
  "id_str" : "364416943098302464",
  "text" : "To see the output when running a script file, use source(\"myscript.R\", echo=TRUE) #rstats http:\/\/t.co\/MplJy2a0wF",
  "id" : 364416943098302464,
  "created_at" : "2013-08-05 16:05:44 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363330168267350018",
  "text" : "Syntax trap: The ':' operator has higher precedence than '-' so 0:N-1 evaluates to (0:N)-1, not 0:(N-1) like you probably wanted #rstats",
  "id" : 363330168267350018,
  "created_at" : "2013-08-02 16:07:17 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ulrich",
      "screen_name" : "joshua_ulrich",
      "indices" : [ 115, 129 ],
      "id_str" : "19114994",
      "id" : 19114994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362967789973155840",
  "text" : "Search the #rstats NEWS file from the command line: db &lt;- news(); news(grepl(\"&lt;topic&gt;\", Text), db=db) (by @joshua_ulrich)",
  "id" : 362967789973155840,
  "created_at" : "2013-08-01 16:07:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]