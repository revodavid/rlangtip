Grailbird.data.tweets_2016_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/e8TjRQrY21",
      "expanded_url" : "https:\/\/mran.revolutionanalytics.com\/documents\/rro\/multithread\/",
      "display_url" : "mran.revolutionanalytics.com\/documents\/rro\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "804007096249262080",
  "text" : "Microsoft R Open includes MKL multi-threaded math libraries, to improve R performance https:\/\/t.co\/e8TjRQrY21 #rstats",
  "id" : 804007096249262080,
  "created_at" : "2016-11-30 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/dLV5pQcbGU",
      "expanded_url" : "http:\/\/seankross.com\/2016\/11\/17\/How-to-Start-a-Bookdown-Book.html",
      "display_url" : "seankross.com\/2016\/11\/17\/How\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803644705468649472",
  "text" : "How to write a book with R and the bookdown package https:\/\/t.co\/dLV5pQcbGU #rstats",
  "id" : 803644705468649472,
  "created_at" : "2016-11-29 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/yUQyBXfBY3",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Round",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803282323097665536",
  "text" : "signif(x,digits=n) rounds x to n significant digits https:\/\/t.co\/yUQyBXfBY3 #rstats",
  "id" : 803282323097665536,
  "created_at" : "2016-11-28 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DXgifxqbIh",
      "expanded_url" : "http:\/\/stackoverflow.com\/tags\/r",
      "display_url" : "stackoverflow.com\/tags\/r"
    } ]
  },
  "geo" : { },
  "id_str" : "802195153553268736",
  "text" : "To search for R-related FAQs on StackOverflow, precede your search query with [r] at https:\/\/t.co\/DXgifxqbIh #rstats",
  "id" : 802195153553268736,
  "created_at" : "2016-11-25 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/mwKR3pENiL",
      "expanded_url" : "https:\/\/www.r-project.org\/contributors.html",
      "display_url" : "r-project.org\/contributors.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "801832768539758592",
  "text" : "Thanks to the R Core Group, for volunteering their time and expertise to create, improve and support R https:\/\/t.co\/mwKR3pENiL #rstats",
  "id" : 801832768539758592,
  "created_at" : "2016-11-24 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi B Robbins",
      "screen_name" : "nbrgraphs",
      "indices" : [ 37, 47 ],
      "id_str" : "25151614",
      "id" : 25151614
    }, {
      "name" : "Joyce Robbins",
      "screen_name" : "jtrnyc",
      "indices" : [ 52, 59 ],
      "id_str" : "4406202856",
      "id" : 4406202856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/DgiFclStAX",
      "expanded_url" : "https:\/\/info.microsoft.com\/CO-Azure-WBNR-FY16-04Apr-28-Effective-Graphs-with-Microsoft-R-Open-Registration.html",
      "display_url" : "info.microsoft.com\/CO-Azure-WBNR-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "801470384344285189",
  "text" : "Free e-book on effective graphics by @nbrgraphs and @jtrnyc https:\/\/t.co\/DgiFclStAX #rstats",
  "id" : 801470384344285189,
  "created_at" : "2016-11-23 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/LyMvT2iUbF",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Last.value",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "801107996524748803",
  "text" : "Forgot to save the output from the last #rstats command? Retrieve it with .Last.value https:\/\/t.co\/LyMvT2iUbF",
  "id" : 801107996524748803,
  "created_at" : "2016-11-22 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800745601356926977",
  "text" : "x$name and x[[\"name\"]] are equivalent, but the latter is a more robust programming style ($ uses partial matching) #rstats",
  "id" : 800745601356926977,
  "created_at" : "2016-11-21 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAS",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "SPSS",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "rstats",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/dU7Tn5ospF",
      "expanded_url" : "http:\/\/r4stats.com\/articles\/add-ons\/",
      "display_url" : "r4stats.com\/articles\/add-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799658435658645505",
  "text" : "R equivalents for #SAS and #SPSS modules: https:\/\/t.co\/dU7Tn5ospF #rstats",
  "id" : 799658435658645505,
  "created_at" : "2016-11-18 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/bZ1G5UPhZ3",
      "expanded_url" : "https:\/\/cloud.r-project.org\/web\/packages\/caret\/vignettes\/caret.pdf",
      "display_url" : "cloud.r-project.org\/web\/packages\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799296056412532737",
  "text" : "Introduction to the caret package: select, train and optimize predictive models: https:\/\/t.co\/bZ1G5UPhZ3 #rstats",
  "id" : 799296056412532737,
  "created_at" : "2016-11-17 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/bIK77sv8Wc",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/10\/data-science-with-sql-server-2016.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/10\/data-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798933659898286080",
  "text" : "E-book on using R with SQL Server 2016 https:\/\/t.co\/bIK77sv8Wc #rstats",
  "id" : 798933659898286080,
  "created_at" : "2016-11-16 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/roxxjU88As",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.3.1\/topics\/str",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798571274658320384",
  "text" : "Use str(obj) to display the components of any object in human-readable format. https:\/\/t.co\/roxxjU88As #rstats",
  "id" : 798571274658320384,
  "created_at" : "2016-11-15 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/WbgkaKYtlB",
      "expanded_url" : "https:\/\/www.quandl.com\/tools\/r",
      "display_url" : "quandl.com\/tools\/r"
    } ]
  },
  "geo" : { },
  "id_str" : "798208879905517570",
  "text" : "Get financial data and more from Quandl with R https:\/\/t.co\/WbgkaKYtlB #rstats",
  "id" : 798208879905517570,
  "created_at" : "2016-11-14 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/1KQ2wSD6XZ",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/Extract",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "797174568406417409",
  "text" : "Important distinction between [, [[ and $\n[ can select &gt; 1 element but [[ and $ select a single element https:\/\/t.co\/1KQ2wSD6XZ #rstats",
  "id" : 797174568406417409,
  "created_at" : "2016-11-11 20:30:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RStudio",
      "screen_name" : "rstudio",
      "indices" : [ 4, 12 ],
      "id_str" : "235261861",
      "id" : 235261861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/tRLvCj89pB",
      "expanded_url" : "https:\/\/www.rstudio.com\/wp-content\/uploads\/2015\/03\/ggplot2-cheatsheet.pdf",
      "display_url" : "rstudio.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796744253477101572",
  "text" : "The @Rstudio cheat sheet for data visualization with ggplot2 (PDF): https:\/\/t.co\/tRLvCj89pB #rstats",
  "id" : 796744253477101572,
  "created_at" : "2016-11-10 16:00:07 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/wDKV1gKu28",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2016\/10\/sharing-r-code-with-style.html",
      "display_url" : "blog.revolutionanalytics.com\/2016\/10\/sharin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796381850918854656",
  "text" : "Style guide for R programming by Graham Williams https:\/\/t.co\/wDKV1gKu28 #rstats",
  "id" : 796381850918854656,
  "created_at" : "2016-11-09 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/JMyZim93sC",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/benford.analysis\/versions\/0.1.2.1\/topics\/benford",
      "display_url" : "rdocumentation.org\/packages\/benfo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796019465276141568",
  "text" : "Check for human tampering with numerical data. Check the digits follow Benford's Law: https:\/\/t.co\/JMyZim93sC #rstats",
  "id" : 796019465276141568,
  "created_at" : "2016-11-08 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/vxyOV9kUjd",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/unlist",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795672173901938688",
  "text" : "Use unlist() to flatten out a list of lists into a single vector: https:\/\/t.co\/vxyOV9kUjd #rstats",
  "id" : 795672173901938688,
  "created_at" : "2016-11-07 17:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/dEWV7eaWxH",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/formatC",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794569905223790593",
  "text" : "For precise formatting of numbers (e.g. consistent decimal places for tables), use formatC: https:\/\/t.co\/dEWV7eaWxH #rstats",
  "id" : 794569905223790593,
  "created_at" : "2016-11-04 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/esxQWZHsmU",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.3.1\/topics\/warning",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794207518016684032",
  "text" : "Turn off all warnings in R with options(warn=-1), or use suppressWarnings(&lt;expr&gt;) https:\/\/t.co\/esxQWZHsmU #rstats",
  "id" : 794207518016684032,
  "created_at" : "2016-11-03 16:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/sYVYEuNfcl",
      "expanded_url" : "https:\/\/gallery.cortanaintelligence.com\/Notebook\/SAS-to-R-Tutorial-Part-1-1",
      "display_url" : "gallery.cortanaintelligence.com\/Notebook\/SAS-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793845124866256896",
  "text" : "Tutorial: converting SAS routines to R https:\/\/t.co\/sYVYEuNfcl #rstats",
  "id" : 793845124866256896,
  "created_at" : "2016-11-02 16:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Robinson",
      "screen_name" : "drob",
      "indices" : [ 65, 70 ],
      "id_str" : "46245868",
      "id" : 46245868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/qjReGc0ClG",
      "expanded_url" : "https:\/\/www.kaggle.com\/stackoverflow\/rquestions",
      "display_url" : "kaggle.com\/stackoverflow\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793482744076521472",
  "text" : "Archive of all the R questions asked on StackOverflow (thanks to @drob) https:\/\/t.co\/qjReGc0ClG #rstats",
  "id" : 793482744076521472,
  "created_at" : "2016-11-01 16:00:03 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]