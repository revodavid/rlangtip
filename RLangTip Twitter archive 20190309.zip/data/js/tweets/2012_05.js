Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/rxi7ZzUC",
      "expanded_url" : "http:\/\/bit.ly\/LEU8S0",
      "display_url" : "bit.ly\/LEU8S0"
    } ]
  },
  "geo" : { },
  "id_str" : "208298979937619970",
  "text" : "Concatenate elements of a vector to a single comma-separated string: paste(letters, collapse=\", \") #rstats http:\/\/t.co\/rxi7ZzUC",
  "id" : 208298979937619970,
  "created_at" : "2012-05-31 20:48:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/6VllFQgL",
      "expanded_url" : "http:\/\/bit.ly\/qCdKKj",
      "display_url" : "bit.ly\/qCdKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "207864747457118209",
  "text" : "Return the row\/column indices of positive elements of matrix x: which(x&gt;0, arr.ind=TRUE) #rstats http:\/\/t.co\/6VllFQgL",
  "id" : 207864747457118209,
  "created_at" : "2012-05-30 16:03:12 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "finance",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/TSHrWkAt",
      "expanded_url" : "http:\/\/bit.ly\/zpAoep",
      "display_url" : "bit.ly\/zpAoep"
    } ]
  },
  "geo" : { },
  "id_str" : "207511917919617025",
  "text" : "quantmod: An R package where quant traders can quickly and cleanly explore and build trading models: http:\/\/t.co\/TSHrWkAt #rstats #finance",
  "id" : 207511917919617025,
  "created_at" : "2012-05-29 16:41:11 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/woJBx8ma",
      "expanded_url" : "http:\/\/bit.ly\/AvftRi",
      "display_url" : "bit.ly\/AvftRi"
    } ]
  },
  "geo" : { },
  "id_str" : "207124822315110400",
  "text" : "List of R functions for chemometrics and computational physics: http:\/\/t.co\/woJBx8ma #rstats",
  "id" : 207124822315110400,
  "created_at" : "2012-05-28 15:03:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One R Tip a Day",
      "screen_name" : "RLangTip",
      "indices" : [ 22, 31 ],
      "id_str" : "295344317",
      "id" : 295344317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/5S9PKB88",
      "expanded_url" : "http:\/\/bit.ly\/ISiZD6",
      "display_url" : "bit.ly\/ISiZD6"
    } ]
  },
  "geo" : { },
  "id_str" : "206037743720087553",
  "text" : "Browse past tips from @RLangTip at http:\/\/t.co\/5S9PKB88 #rstats",
  "id" : 206037743720087553,
  "created_at" : "2012-05-25 15:03:20 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/u26pid7H",
      "expanded_url" : "http:\/\/bit.ly\/JwCeEd",
      "display_url" : "bit.ly\/JwCeEd"
    } ]
  },
  "geo" : { },
  "id_str" : "205684188412772354",
  "text" : "To calculate the inverse of a square numeric matrix, use solve(X): http:\/\/t.co\/u26pid7H #rstats",
  "id" : 205684188412772354,
  "created_at" : "2012-05-24 15:38:26 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205312535665184768",
  "text" : "Imported a column of numbers, but it read in as a factor? Convert it with as.numeric(as.character(df$num.col)) #rstats",
  "id" : 205312535665184768,
  "created_at" : "2012-05-23 15:01:37 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/FvGfIxoR",
      "expanded_url" : "http:\/\/bit.ly\/Lbt65p",
      "display_url" : "bit.ly\/Lbt65p"
    } ]
  },
  "geo" : { },
  "id_str" : "204950163595341826",
  "text" : "New to R? Try the \"sample session\" in the Introduction to R Manual for a 10-min tour: http:\/\/t.co\/FvGfIxoR #rstats",
  "id" : 204950163595341826,
  "created_at" : "2012-05-22 15:01:41 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ztZIQBUd",
      "expanded_url" : "http:\/\/bit.ly\/x8ecZY",
      "display_url" : "bit.ly\/x8ecZY"
    } ]
  },
  "geo" : { },
  "id_str" : "204587920168984576",
  "text" : "List of R packages for statistical genetics and genetic analysis: http:\/\/t.co\/ztZIQBUd #rstats",
  "id" : 204587920168984576,
  "created_at" : "2012-05-21 15:02:15 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/2pHjbaaF",
      "expanded_url" : "http:\/\/bit.ly\/JwBzT5",
      "display_url" : "bit.ly\/JwBzT5"
    } ]
  },
  "geo" : { },
  "id_str" : "203500641811836928",
  "text" : "How to get data from databases, spreadsheets, binary files and APIs into #rstats. R data import\/export manual: http:\/\/t.co\/2pHjbaaF",
  "id" : 203500641811836928,
  "created_at" : "2012-05-18 15:01:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/4D9txkl0",
      "expanded_url" : "http:\/\/bit.ly\/p6epvV",
      "display_url" : "bit.ly\/p6epvV"
    } ]
  },
  "geo" : { },
  "id_str" : "203138234245578752",
  "text" : "Yes, you can return more than one value from a function: use a list! return(list(val1, val2, val3)) #rstats http:\/\/t.co\/4D9txkl0",
  "id" : 203138234245578752,
  "created_at" : "2012-05-17 15:01:43 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/5nDpNa9F",
      "expanded_url" : "http:\/\/bit.ly\/H9znwZ",
      "display_url" : "bit.ly\/H9znwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "202775991863615489",
  "text" : "In an #rstats function, return the list of arguments supplied in the call with: as.list(match.call())[-1] http:\/\/t.co\/5nDpNa9F",
  "id" : 202775991863615489,
  "created_at" : "2012-05-16 15:02:18 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/rBcOMwdE",
      "expanded_url" : "http:\/\/bit.ly\/FO6A1a",
      "display_url" : "bit.ly\/FO6A1a"
    } ]
  },
  "geo" : { },
  "id_str" : "202413488113582081",
  "text" : "To change where R exports files, use setwd() to change the current working directory first: http:\/\/t.co\/rBcOMwdE #rstats",
  "id" : 202413488113582081,
  "created_at" : "2012-05-15 15:01:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Nusinow",
      "screen_name" : "dnusinow",
      "indices" : [ 0, 9 ],
      "id_str" : "4758231",
      "id" : 4758231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202051802756169728",
  "geo" : { },
  "id_str" : "202059625292500994",
  "in_reply_to_user_id" : 4758231,
  "text" : "@dnusinow Thanks, just sent a correction.",
  "id" : 202059625292500994,
  "in_reply_to_status_id" : 202051802756169728,
  "created_at" : "2012-05-14 15:35:43 +0000",
  "in_reply_to_screen_name" : "dnusinow",
  "in_reply_to_user_id_str" : "4758231",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/z2G13s6n",
      "expanded_url" : "http:\/\/bit.ly\/J4Ax1X",
      "display_url" : "bit.ly\/J4Ax1X"
    } ]
  },
  "geo" : { },
  "id_str" : "202059403644506113",
  "text" : "List of R packages and functions for Cluster Analysis &amp; Finite Mixture Models: http:\/\/t.co\/z2G13s6n #rstats [corrected]",
  "id" : 202059403644506113,
  "created_at" : "2012-05-14 15:34:50 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Munroe",
      "screen_name" : "xkcd",
      "indices" : [ 86, 91 ],
      "id_str" : "21146468",
      "id" : 21146468
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/yr1SB9U6",
      "expanded_url" : "http:\/\/bit.ly\/IVg3F7",
      "display_url" : "bit.ly\/IVg3F7"
    }, {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/6pb4Xet1",
      "expanded_url" : "http:\/\/xkcd.com\/1047\/",
      "display_url" : "xkcd.com\/1047\/"
    } ]
  },
  "geo" : { },
  "id_str" : "200964066150322176",
  "text" : "Jenny's constant in R: (7^(exp(1)-1\/exp(1))-9)*pi^2 #rstats http:\/\/t.co\/yr1SB9U6 (via @xkcd http:\/\/t.co\/6pb4Xet1 )",
  "id" : 200964066150322176,
  "created_at" : "2012-05-11 15:02:21 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/WhPC7N7J",
      "expanded_url" : "http:\/\/bit.ly\/Ilh5KH",
      "display_url" : "bit.ly\/Ilh5KH"
    } ]
  },
  "geo" : { },
  "id_str" : "200601922120581121",
  "text" : "Can't find a package binary on CRAN? Check its build status on all platforms here: http:\/\/t.co\/WhPC7N7J #rstats (via @PairachChamp)",
  "id" : 200601922120581121,
  "created_at" : "2012-05-10 15:03:19 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/vm2fbKcc",
      "expanded_url" : "http:\/\/bit.ly\/I7rm0p",
      "display_url" : "bit.ly\/I7rm0p"
    } ]
  },
  "geo" : { },
  "id_str" : "200239228393758721",
  "text" : "Robust regression in R (PDF, Fox &amp; Weisberg): http:\/\/t.co\/vm2fbKcc #rstats",
  "id" : 200239228393758721,
  "created_at" : "2012-05-09 15:02:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/lixcRhXc",
      "expanded_url" : "http:\/\/bit.ly\/KglkJC",
      "display_url" : "bit.ly\/KglkJC"
    } ]
  },
  "geo" : { },
  "id_str" : "199877020409282561",
  "text" : "Use read.fwf to read a fixed-format data file (ASCII data without delimiters) into R: http:\/\/t.co\/lixcRhXc #rstats",
  "id" : 199877020409282561,
  "created_at" : "2012-05-08 15:02:49 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/9PvuFCoe",
      "expanded_url" : "http:\/\/bit.ly\/y1DUTy",
      "display_url" : "bit.ly\/y1DUTy"
    } ]
  },
  "geo" : { },
  "id_str" : "199514530064252928",
  "text" : "List of R packages for analysis of spatial and geocoded data: http:\/\/t.co\/9PvuFCoe #rstats",
  "id" : 199514530064252928,
  "created_at" : "2012-05-07 15:02:25 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/JxplHv5a",
      "expanded_url" : "http:\/\/bit.ly\/If5SJP",
      "display_url" : "bit.ly\/If5SJP"
    } ]
  },
  "geo" : { },
  "id_str" : "198427296321912833",
  "text" : "Search R-help mailing list archives, help pages, vignettes and task views with RSiteSearch: http:\/\/t.co\/JxplHv5a #rstats",
  "id" : 198427296321912833,
  "created_at" : "2012-05-04 15:02:08 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/CP6gGTAi",
      "expanded_url" : "http:\/\/bit.ly\/IlFfpk",
      "display_url" : "bit.ly\/IlFfpk"
    } ]
  },
  "geo" : { },
  "id_str" : "198064843234885633",
  "text" : "Side by side comparisons of analysis tasks done in SAS and R: http:\/\/t.co\/CP6gGTAi #rstats",
  "id" : 198064843234885633,
  "created_at" : "2012-05-03 15:01:53 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/vPEcDgdl",
      "expanded_url" : "http:\/\/www.inside-r.org\/download",
      "display_url" : "inside-r.org\/download"
    } ]
  },
  "geo" : { },
  "id_str" : "197702437862252544",
  "text" : "Find the closest CRAN mirror to you at http:\/\/t.co\/vPEcDgdl (it will be selected by default) #rstats",
  "id" : 197702437862252544,
  "created_at" : "2012-05-02 15:01:48 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/CAsADBUM",
      "expanded_url" : "http:\/\/bit.ly\/onqu7V",
      "display_url" : "bit.ly\/onqu7V"
    } ]
  },
  "geo" : { },
  "id_str" : "197340097782349826",
  "text" : "with(mydf, \u007B &lt;&lt;R code&gt;&gt; \u007D) is a cleaner way to use columns of a data frame in #rstats code. Examples: http:\/\/t.co\/CAsADBUM",
  "id" : 197340097782349826,
  "created_at" : "2012-05-01 15:02:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]