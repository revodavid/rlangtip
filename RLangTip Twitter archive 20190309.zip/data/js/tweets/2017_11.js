Grailbird.data.tweets_2017_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/J1wEKlRiwL",
      "expanded_url" : "http:\/\/rmarkdown.rstudio.com\/formats.html",
      "display_url" : "rmarkdown.rstudio.com\/formats.html"
    } ]
  },
  "geo" : { },
  "id_str" : "936278668116082688",
  "text" : "Use R Markdown to generate HTML, PDF, Word documents (and more) with R graphics and output https:\/\/t.co\/J1wEKlRiwL #rstats",
  "id" : 936278668116082688,
  "created_at" : "2017-11-30 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/bjxatKlkcD",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/visualstudio\/rtvs\/getting-started-with-r",
      "display_url" : "docs.microsoft.com\/en-us\/visualst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935916281387249669",
  "text" : "Tutorial: Getting started with R Tools for Visual Studio https:\/\/t.co\/bjxatKlkcD #rstats",
  "id" : 935916281387249669,
  "created_at" : "2017-11-29 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/zlCjgMzARE",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/Extract",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935553877117616128",
  "text" : "Descend recursively through lists with a vector index: x[[c(5,3)]] is the same as x[[5]][[3]] https:\/\/t.co\/zlCjgMzARE #rstats",
  "id" : 935553877117616128,
  "created_at" : "2017-11-28 17:00:00 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/hZCz1C2zv7",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/Logic",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935191496801656832",
  "text" : "Efficiency tip: TRUE || (x &lt;-3) will never evaluate the right hand side. Using &amp;&amp; and || can save cycles #rstats https:\/\/t.co\/hZCz1C2zv7",
  "id" : 935191496801656832,
  "created_at" : "2017-11-27 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/RCgvxXtZNA",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/views\/Spatial.html",
      "display_url" : "cran.r-project.org\/web\/views\/Spat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "934104343938289667",
  "text" : "List of R packages for analysis of spatial and geocoded data: https:\/\/t.co\/RCgvxXtZNA #rstats",
  "id" : 934104343938289667,
  "created_at" : "2017-11-24 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RLangTip\/status\/933741957825695744\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Lu4ta0lO9a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPGGcs5V4AIdc44.jpg",
      "id_str" : "932674425488531458",
      "id" : 932674425488531458,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPGGcs5V4AIdc44.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 641
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Lu4ta0lO9a"
    } ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933741957825695744",
  "text" : "library(cowsay)\nsay(\"Happy Thanksgiving!\", by=\"turkey\")\n#rstats https:\/\/t.co\/Lu4ta0lO9a",
  "id" : 933741957825695744,
  "created_at" : "2017-11-23 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/HupoplJCp6",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/timeDate\/versions\/3042.101\/topics\/holiday",
      "display_url" : "rdocumentation.org\/packages\/timeD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933379576285208576",
  "text" : "The holiday function in the timeDate package looks up holiday dates, e.g. holiday(2017,\"USThanksgivingDay\") https:\/\/t.co\/HupoplJCp6 #rstats",
  "id" : 933379576285208576,
  "created_at" : "2017-11-22 17:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/VpAtzGFrYh",
      "expanded_url" : "https:\/\/cran.r-project.org\/doc\/manuals\/r-release\/R-admin.html#Environment-variable-index",
      "display_url" : "cran.r-project.org\/doc\/manuals\/r-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933017168597409797",
  "text" : "List of environment variables that can be used to configure R: https:\/\/t.co\/VpAtzGFrYh #rstats",
  "id" : 933017168597409797,
  "created_at" : "2017-11-21 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/HVmGgtVvah",
      "expanded_url" : "https:\/\/mran.microsoft.com\/package\/pracma",
      "display_url" : "mran.microsoft.com\/package\/pracma"
    } ]
  },
  "geo" : { },
  "id_str" : "932654795923615745",
  "text" : "The pracma package contains a number of functions for linear algebra and numerical analysis https:\/\/t.co\/HVmGgtVvah #rstats",
  "id" : 932654795923615745,
  "created_at" : "2017-11-20 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/LOn7J1k5Ra",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/NumericConstants",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931567624646987776",
  "text" : "R interprets literal numbers like 4 as floating-point; use 4L for the integer 4 https:\/\/t.co\/LOn7J1k5Ra #rstats",
  "id" : 931567624646987776,
  "created_at" : "2017-11-17 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/TPXDE4bo4E",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/stats\/versions\/3.4.1\/topics\/optim",
      "display_url" : "rdocumentation.org\/packages\/stats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931205245849481217",
  "text" : "optim() a general-purpose function in R to find the maximum of a function #rstats https:\/\/t.co\/TPXDE4bo4E",
  "id" : 931205245849481217,
  "created_at" : "2017-11-16 17:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/e8TjRQrY21",
      "expanded_url" : "https:\/\/mran.revolutionanalytics.com\/documents\/rro\/multithread\/",
      "display_url" : "mran.revolutionanalytics.com\/documents\/rro\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930842851193143296",
  "text" : "Microsoft R Open includes MKL multi-threaded math libraries, to improve R performance https:\/\/t.co\/e8TjRQrY21 #rstats",
  "id" : 930842851193143296,
  "created_at" : "2017-11-15 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930480461221994496",
  "text" : "Use replicate to generate multiple simulations. Example: ts.plot(replicate(10, cumsum(rnorm(5))) #rstats",
  "id" : 930480461221994496,
  "created_at" : "2017-11-14 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/WmPQrVPoek",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/paste",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930118076804235270",
  "text" : "Concatenate elements of a vector to a single comma-separated string: paste(letters, collapse=\", \") https:\/\/t.co\/WmPQrVPoek #rstats",
  "id" : 930118076804235270,
  "created_at" : "2017-11-13 17:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/192iEfHCKc",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/doParallel\/vignettes\/gettingstartedParallel.pdf",
      "display_url" : "cran.r-project.org\/web\/packages\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929030915535155201",
  "text" : "Get started with foreach and parallel programming: https:\/\/t.co\/192iEfHCKc #rstats",
  "id" : 929030915535155201,
  "created_at" : "2017-11-10 17:00:05 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/u8qkYjDKvj",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/utils\/versions\/3.4.1\/topics\/data",
      "display_url" : "rdocumentation.org\/packages\/utils\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928668511840243712",
  "text" : "Type data(package = .packages(all.available = TRUE)) to find data sets available in R https:\/\/t.co\/u8qkYjDKvj #rstats",
  "id" : 928668511840243712,
  "created_at" : "2017-11-09 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/q0A6gY3jXD",
      "expanded_url" : "https:\/\/docs.microsoft.com\/en-us\/azure\/machine-learning\/data-science-virtual-machine\/overview",
      "display_url" : "docs.microsoft.com\/en-us\/azure\/ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928306128768835586",
  "text" : "The Data Science VM is a GPU-enabled Azure instance with R, Rattle, RStudio, Jupyter and more https:\/\/t.co\/q0A6gY3jXD #rstats",
  "id" : 928306128768835586,
  "created_at" : "2017-11-08 17:00:02 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/6FCfBrkHIU",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/funprog",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927943736406958080",
  "text" : "Use the Filter function to find the values of x for which a logical function f(x) is TRUE https:\/\/t.co\/6FCfBrkHIU #rstats",
  "id" : 927943736406958080,
  "created_at" : "2017-11-07 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/wl0T6n3Zgk",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/cluster\/versions\/2.0.6\/topics\/diana",
      "display_url" : "rdocumentation.org\/packages\/clust\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927581345404149760",
  "text" : "The function diana() in library(cluster) computes a divisive hierarchial cluster of a data set https:\/\/t.co\/wl0T6n3Zgk #rstats",
  "id" : 927581345404149760,
  "created_at" : "2017-11-06 17:00:01 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/3cnfkaJWR0",
      "expanded_url" : "https:\/\/www.rdocumentation.org\/packages\/base\/versions\/3.4.1\/topics\/iconv",
      "display_url" : "rdocumentation.org\/packages\/base\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926479098561646592",
  "text" : "Strip non-ASCII characters from a string with iconv(bad.text, to=\"ASCII\", sub=\"\") #rstats https:\/\/t.co\/3cnfkaJWR0",
  "id" : 926479098561646592,
  "created_at" : "2017-11-03 16:00:04 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QT6B5rsYrL",
      "expanded_url" : "http:\/\/blog.revolutionanalytics.com\/2011\/11\/three-free-books-on-r-for-statistics.html",
      "display_url" : "blog.revolutionanalytics.com\/2011\/11\/three-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926116717700440067",
  "text" : "Three free books on R for Multivariate Analysis, Biomedical Statistics and Time Series https:\/\/t.co\/QT6B5rsYrL #rstats",
  "id" : 926116717700440067,
  "created_at" : "2017-11-02 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/NLHCatNC6o",
      "expanded_url" : "http:\/\/h-savran.blogspot.co.uk\/2017\/08\/how-to-monitor-r-services-scripts.html",
      "display_url" : "h-savran.blogspot.co.uk\/2017\/08\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925754331080556544",
  "text" : "How to monitor performance of R scripts running in SQL Server 2016 https:\/\/t.co\/NLHCatNC6o #rstats",
  "id" : 925754331080556544,
  "created_at" : "2017-11-01 16:00:06 +0000",
  "user" : {
    "name" : "One R Tip a Day",
    "screen_name" : "RLangTip",
    "protected" : false,
    "id_str" : "295344317",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1344530309\/RLangTip_normal.png",
    "id" : 295344317,
    "verified" : false
  }
} ]