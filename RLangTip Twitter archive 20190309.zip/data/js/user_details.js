var user_details =  {
  "screen_name" : "RLangTip",
  "full_name" : "One R Tip a Day",
  "bio" : "One tip per day M-F on the R programming language #rstats. Brought to you by the R community team at Microsoft.",
  "id" : "295344317",
  "created_at" : "2011-05-08 20:51:40 +0000"
}